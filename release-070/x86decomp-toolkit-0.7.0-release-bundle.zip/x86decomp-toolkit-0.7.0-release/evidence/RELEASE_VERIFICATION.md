## v0.7 verification record

The sealed v0.7 source must pass the complete inherited collection, the independently repeated standalone verifier, versioned function-body coverage for v0.5/v0.6/v0.7, exact CLI/schema catalogs, recursive contracts, both SHA-256 manifests, package extraction, clean installation, and a transactional upgrade from the final v0.6.0 source.

Verified source-tree gates:

- 243 integrated tests, zero failures and zero skips;
- 36 independently repeated standalone verifier tests, zero failures and zero skips;
- 27 dedicated v0.7 tests covering slot classification, protected padding normalization, x86/x64 section export, synthetic COFF generation, expected-byte PE patching, verified hybrid fallback, candidate/original mutation rejection, staging resolution, closed-loop consent, loader checks, Windows launcher selection, response files, manifests, installer rollback helpers, all 33 v0.7 command parsers, and all 12 v0.7 schemas;
- 517/517 retained top-level package function/method bodies executed;
- 142/142 v0.5, 105/105 v0.6, and 74/74 v0.7 namespaced function/method bodies executed;
- a pristine v0.6.0 transactional upgrade passed the same 243 + 36 test gates in staging before commit and verified the regenerated nested and root manifests;
- comprehensive harness result: 161 PASS, 0 FAIL, 0 ERROR, and 7 explicit BLOCKED external adapters;
- statement coverage 79.11740950143182% and branch coverage 52.85163776493256%, above the retained 70%/50% floors.

The blocked integrations on the release host were container runtime, DynamoRIO, Ghidra, llvm-readobj, historical MSVC, objdiff, and pip-audit. They remain visible and become a strict-mode failure; they were not skipped or counted as passes.

The release makes no universal behavioral-equivalence claim. A function is promoted only when its declared comparison policy passes; all other slots retain original bytes and are reported as fallbacks.
