---
title: About
description: Source-of-truth policy for the 0.7.10 documentation.
---

# About

This site documents x86decomp-toolkit 0.7.10. It is synchronized from the release parser, source AST, schemas, manifests, tests, and audit-fix evidence in the bundled source tree.

## 0.7.10 documentation baseline

The site uses `x86decomp-toolkit-0.7.10-audit-fix-release-bundle.zip` as the source of truth for generated source, schema, command, test, and release-evidence pages.
