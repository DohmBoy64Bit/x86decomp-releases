---
title: tests/assembly/test_helpers_and_relocations.py
description: Source-derived test reference for tests/assembly/test_helpers_and_relocations.py
  in x86decomp 0.7.10.
---

# `tests/assembly/test_helpers_and_relocations.py`

- **SHA-256:** `a5a50f7860b8f169441105450065e74a15361ed37c0e5900681b457f20914943`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_assembly_cli_json_integer_and_error_helpers` | function | 14 | Verify assembly cli json integer and error helpers behavior. |
| `test_symbol_address_error_and_render_helpers` | function | 28 | Verify symbol address error and render helpers behavior. |
| `test_relocation_inspection_paths` | function | 40 | Verify relocation inspection paths behavior. |
