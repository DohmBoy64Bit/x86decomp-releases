---
title: tests/reconstruction/test_project_headers_builds.py
description: Source-derived test reference for tests/reconstruction/test_project_headers_builds.py
  in x86decomp 0.7.10.
---

# `tests/reconstruction/test_project_headers_builds.py`

- **SHA-256:** `2b401fe3f216891e28e3da29520ae5d322b45cb5f75721ebbeb7e42957e835c3`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_store_is_additive_and_layout_is_evidence_labeled` | function | 14 | Verify store is additive and layout is evidence labeled behavior. |
| `test_headers_reject_cycles_and_generate_compileable_shape` | function | 34 | Verify headers reject cycles and generate compileable shape behavior. |
| `test_historical_and_portable_build_modes_remain_distinct` | function | 48 | Verify historical and portable build modes remain distinct behavior. |
