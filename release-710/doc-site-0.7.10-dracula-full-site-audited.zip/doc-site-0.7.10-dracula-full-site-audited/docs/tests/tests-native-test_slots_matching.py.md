---
title: tests/native/test_slots_matching.py
description: Source-derived test reference for tests/native/test_slots_matching.py
  in x86decomp 0.7.10.
---

# `tests/native/test_slots_matching.py`

- **SHA-256:** `94855914f406923ea02198bd7484d0f9d64ebb271dbe50c8dd54fbf8abca3a63`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_slot_audit_classifies_exact_padding_and_overlap` | function | 10 | Verify slot audit classifies exact padding and overlap behavior. |
| `test_padding_comparison_is_tail_only_and_protected_aware` | function | 24 | Verify padding comparison is tail only and protected aware behavior. |
| `test_batch_matching_records_safe_and_fallback` | function | 31 | Verify batch matching records safe and fallback behavior. |
| `test_short_candidate_requires_padding_only_remainder` | function | 45 | Verify short candidate requires padding only remainder behavior. |
