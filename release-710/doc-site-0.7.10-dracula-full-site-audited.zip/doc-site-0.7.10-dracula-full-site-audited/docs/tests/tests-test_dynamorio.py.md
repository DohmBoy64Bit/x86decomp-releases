---
title: tests/test_dynamorio.py
description: Source-derived test reference for tests/test_dynamorio.py in x86decomp
  0.7.10.
---

# `tests/test_dynamorio.py`

- **SHA-256:** `41d1f65aeefadb38e4b937899e801f20a93e495c7933427a2c483d7a6d554fcc`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_parse_drcov_text` | function | 14 | Verify parse drcov text behavior. |
| `test_angr_backend_has_explicit_optional_dependency_error` | function | 34 | Verify angr backend has explicit optional dependency error behavior. |
