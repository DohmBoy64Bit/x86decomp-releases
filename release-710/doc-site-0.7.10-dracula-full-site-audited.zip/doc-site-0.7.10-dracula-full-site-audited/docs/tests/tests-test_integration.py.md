---
title: tests/test_integration.py
description: Source-derived test reference for tests/test_integration.py in x86decomp
  0.7.10.
---

# `tests/test_integration.py`

- **SHA-256:** `91835325b62f0d2d14c0b444e88f6572ff68c70825e4932f94ea60fa4c5408cb`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_integration_requires_explicit_host_consent` | function | 71 | Verify integration requires explicit host consent behavior. |
| `test_integration_equivalence_and_difference` | function | 78 | Verify integration equivalence and difference behavior. |
