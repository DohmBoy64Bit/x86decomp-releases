---
title: tests/reconstruction/test_capsules_security_changesets.py
description: Source-derived test reference for tests/reconstruction/test_capsules_security_changesets.py
  in x86decomp 0.7.10.
---

# `tests/reconstruction/test_capsules_security_changesets.py`

- **SHA-256:** `2d777bcb031f015d4c6a585ef90e92b48e48090406f4d7c072203615c7ffe0a0`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_capsule_is_deterministic_verifiable_and_reproducible` | function | 13 | Verify capsule is deterministic verifiable and reproducible behavior. |
| `test_library_recognition_never_silently_replaces_code` | function | 23 | Verify library recognition never silently replaces code behavior. |
| `test_security_scan_reports_without_modifying_behavior` | function | 31 | Verify security scan reports without modifying behavior behavior. |
| `test_semantic_changesets_detect_conflicts_and_verify_clean_merges` | function | 39 | Verify semantic changesets detect conflicts and verify clean merges behavior. |
