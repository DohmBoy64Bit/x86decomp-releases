---
title: tests/test_ghidra.py
description: Source-derived test reference for tests/test_ghidra.py in x86decomp 0.7.10.
---

# `tests/test_ghidra.py`

- **SHA-256:** `923c2293e595fec0df1050bb2c3ee598d2341101bb86a68276710e132afb3c87`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `GhidraCommandTests` | class | 11 | Coordinate ghidra command tests behavior for the current toolkit workflow. |
| `test_build_export_command_is_argument_array` | function | 13 | Verify build export command is argument array behavior. |
