---
title: tests/assembly/test_pipeline_cli_schemas.py
description: Source-derived test reference for tests/assembly/test_pipeline_cli_schemas.py
  in x86decomp 0.7.10.
---

# `tests/assembly/test_pipeline_cli_schemas.py`

- **SHA-256:** `18295390d88a99058b5359457245ce617ed981768004d2e567893a0d30238e42`
- **Collected test definitions/classes:** 8

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_pipeline_all_three_formats_and_durable_reports` | function | 64 | Verify pipeline all three formats and durable reports behavior. |
| `test_assembly_project_cli_and_all_leaf_help` | function | 92 | Verify assembly project cli and all leaf help behavior. |
| `test_main_cli_exposes_assembly_capabilities` | function | 108 | Verify main cli exposes assembly capabilities behavior. |
| `test_assembly_schemas_and_symbol_map_contracts` | function | 119 | Verify assembly schemas and symbol map contracts behavior. |
| `test_store_keeps_all_prior_schema_layers` | function | 131 | Verify store keeps all prior schema layers behavior. |
| `test_pipeline_persists_relocation_evidence` | function | 141 | Verify pipeline persists relocation evidence behavior. |
| `test_hybrid_generate_keeps_bytes_default_and_allows_explicit_modes` | function | 159 | Verify hybrid generate keeps bytes default and allows explicit modes behavior. |
| `test_failed_batch_is_recorded_durably` | function | 189 | Verify failed batch is recorded durably behavior. |
