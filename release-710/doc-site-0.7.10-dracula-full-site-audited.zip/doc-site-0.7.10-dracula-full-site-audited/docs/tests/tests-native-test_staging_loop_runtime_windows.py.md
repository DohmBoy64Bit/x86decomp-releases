---
title: tests/native/test_staging_loop_runtime_windows.py
description: Source-derived test reference for tests/native/test_staging_loop_runtime_windows.py
  in x86decomp 0.7.10.
---

# `tests/native/test_staging_loop_runtime_windows.py`

- **SHA-256:** `cdc2f880f176575abf4e5db1220253592bea5149b9c66ae95d153c1ccd5f2b23`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_staging_context_resolution_and_compile_check` | function | 18 | Verify staging context resolution and compile check behavior. |
| `test_closed_loop_requires_consent_and_records_verified_result` | function | 29 | Verify closed loop requires consent and records verified result behavior. |
| `test_runtime_static_validation_and_crash_mapping` | function | 40 | Verify runtime static validation and crash mapping behavior. |
| `test_windows_launcher_prefers_batch_on_windows_and_response_files` | function | 51 | Verify windows launcher prefers batch on windows and response files behavior. |
