---
title: test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py
description: Source-derived test reference for test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py
  in x86decomp 0.7.10.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py`

- **SHA-256:** `a732ea719dcdebc30e0c4a2bdfb75be4c74ebd55ce96ddc99c70faf3a4ac2092`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_cli_init_config_catalog_and_missing_config` | function | 15 | Verify cli init config catalog and missing config behavior. |
| `test_install_python_command_and_failure` | function | 25 | Verify install python command and failure behavior. |
