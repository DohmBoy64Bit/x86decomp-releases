---
title: test-suite/tests/test_config_models.py
description: Source-derived test reference for test-suite/tests/test_config_models.py
  in x86decomp 0.7.10.
---

# `test-suite/tests/test_config_models.py`

- **SHA-256:** `12d805b02082887a8b8af738f377851f37aab0f2a2dd16bca0f3fe8d4de6f7d5`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_config_roundtrip_and_relative_resolution` | function | 14 | Verify config roundtrip and relative resolution. |
| `test_status_counts_and_strict_exit_code` | function | 44 | Verify status counts and strict exit code. |
