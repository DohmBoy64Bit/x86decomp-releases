---
title: tests/native/test_pe_hybrid.py
description: Source-derived test reference for tests/native/test_pe_hybrid.py in x86decomp
  0.7.10.
---

# `tests/native/test_pe_hybrid.py`

- **SHA-256:** `9cc67751b07555ce543712122eff1abb9c9f687fe944b20cc3e8e49040ecfa9d`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_safe_patch_and_text_swap_preserve_pe_container` | function | 12 | Verify safe patch and text swap preserve pe container behavior. |
| `test_section_export_and_synthetic_coff_for_pe32_and_pe64` | function | 24 | Verify section export and synthetic coff for pe32 and pe64 behavior. |
| `test_hybrid_composer_promotes_only_verified_candidates` | function | 32 | Verify hybrid composer promotes only verified candidates behavior. |
| `test_hybrid_composer_rejects_candidate_changed_after_match` | function | 46 | Verify hybrid composer rejects candidate changed after match behavior. |
