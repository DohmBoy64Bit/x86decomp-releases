---
title: tests/test_dynamic_symbolic.py
description: Source-derived test reference for tests/test_dynamic_symbolic.py in x86decomp
  0.7.10.
---

# `tests/test_dynamic_symbolic.py`

- **SHA-256:** `f664786ae11deadc81c601cf6442f4422b83e3ab3118e75e5384b0a046318be2`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_dynamic_equivalence_and_difference` | function | 15 | Verify dynamic equivalence and difference behavior. |
| `test_symbolic_bounded_equivalence` | function | 31 | Verify symbolic bounded equivalence behavior. |
