---
title: test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py
description: Source-derived test reference for test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py
  in x86decomp 0.7.10.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py`

- **SHA-256:** `3e2b70c05615592089e98fb5dbd393bbeaae40818df0f09db942bf63bdd13303`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_inventory_catalog_and_public_coverage` | function | 32 | Verify inventory catalog and public coverage behavior. |
| `test_junit_process_logging_and_reports` | function | 54 | Verify junit process logging and reports behavior. |
| `test_suite_schemas_and_catalog_are_valid` | function | 84 | Verify suite schemas and catalog are valid behavior. |
| `test_recursive_inventory_includes_capability_packages_and_nested_schemas` | function | 103 | Verify recursive inventory includes capability packages and nested schemas behavior. |
