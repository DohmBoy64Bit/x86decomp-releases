---
title: tests/test_diffing.py
description: Source-derived test reference for tests/test_diffing.py in x86decomp
  0.7.10.
---

# `tests/test_diffing.py`

- **SHA-256:** `de5433ce73dcb97007481caaed594b8b4f9331828f3ebd60873c784129597bd0`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `DiffingTests` | class | 9 | Coordinate diffing tests behavior for the current toolkit workflow. |
| `test_equal` | function | 11 | Verify equal behavior. |
| `test_mismatch` | function | 18 | Verify mismatch behavior. |
