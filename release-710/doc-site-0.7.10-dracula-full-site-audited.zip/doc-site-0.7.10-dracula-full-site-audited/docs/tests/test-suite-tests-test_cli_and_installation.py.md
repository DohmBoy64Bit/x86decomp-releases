---
title: test-suite/tests/test_cli_and_installation.py
description: Source-derived test reference for test-suite/tests/test_cli_and_installation.py
  in x86decomp 0.7.10.
---

# `test-suite/tests/test_cli_and_installation.py`

- **SHA-256:** `e43c9f01f1a7b540d493fdd1ec499d6de66799e921e648d4f5b336116ae49cb5`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_cli_init_config_catalog_and_missing_config` | function | 19 | Verify cli init config catalog and missing config. |
| `test_install_python_command_and_failure` | function | 32 | Verify install python command and failure. |
