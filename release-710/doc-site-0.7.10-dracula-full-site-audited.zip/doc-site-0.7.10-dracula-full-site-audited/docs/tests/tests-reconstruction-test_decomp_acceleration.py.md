---
title: tests/reconstruction/test_decomp_acceleration.py
description: Source-derived test reference for tests/reconstruction/test_decomp_acceleration.py
  in x86decomp 0.7.10.
---

# `tests/reconstruction/test_decomp_acceleration.py`

- **SHA-256:** `b446be684115257ad47fd9132319979d563495e7d965e7897ddd391f8bb59f4d`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_llm_job_create_and_range` | function | 35 | Verify llm job create and range behavior. |
| `test_source_map_and_candidate_promotion` | function | 51 | Verify source map and candidate promotion behavior. |
| `test_planning_helpers` | function | 69 | Verify planning helpers behavior. |
