---
title: tests/reconstruction/test_real_project_acceleration.py
description: Source-derived test reference for tests/reconstruction/test_real_project_acceleration.py
  in x86decomp 0.7.10.
---

# `tests/reconstruction/test_real_project_acceleration.py`

- **SHA-256:** `3dd8b6ae8dc6f943896a19d12c82da87811e72335662a825a4a4ff9ebd8ac198`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_universal_function_pattern_and_text_swap` | function | 54 | Verify universal function pattern and text swap behavior. |
| `test_project_health_hygiene_runtime_and_policy` | function | 89 | Verify project health hygiene runtime and policy behavior. |
| `test_toolchain_rules_and_cleanup` | function | 108 | Verify toolchain rules and cleanup behavior. |
