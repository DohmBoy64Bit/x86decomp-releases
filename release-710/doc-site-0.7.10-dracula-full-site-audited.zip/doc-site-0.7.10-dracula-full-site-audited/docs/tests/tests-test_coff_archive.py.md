---
title: tests/test_coff_archive.py
description: Source-derived test reference for tests/test_coff_archive.py in x86decomp
  0.7.10.
---

# `tests/test_coff_archive.py`

- **SHA-256:** `38b8932cc6744db56c6ca164ad1749229f89daccd8e569f797be64b49b126a60`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_real_coff_archive_members_symbols_and_comdat` | function | 15 | Verify real coff archive members symbols and comdat behavior. |
| `test_static_library_is_inspected_in_safe_bundle` | function | 56 | Verify static library is inspected in safe bundle behavior. |
| `test_real_import_library_records` | function | 89 | Verify real import library records behavior. |
