---
title: test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py
description: Source-derived test reference for test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py
  in x86decomp 0.7.10.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py`

- **SHA-256:** `c9a85a238d72824ef8e346e340dc2607f0ce75d17c102e8d1fb5812973e6c60a`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_safe_zip_and_tar_extraction` | function | 14 | Verify safe zip and tar extraction behavior. |
| `test_rejects_traversal_and_links` | function | 34 | Verify rejects traversal and links behavior. |
| `test_release_asset_selection_is_deterministic` | function | 52 | Verify release asset selection is deterministic behavior. |
| `test_download_file_hash_and_size_limit` | function | 62 | Verify download file hash and size limit behavior. |
