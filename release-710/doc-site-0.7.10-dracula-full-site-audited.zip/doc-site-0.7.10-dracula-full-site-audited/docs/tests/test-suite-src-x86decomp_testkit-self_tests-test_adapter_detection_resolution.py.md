---
title: test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py
description: Source-derived test reference for test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py
  in x86decomp 0.7.10.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py`

- **SHA-256:** `f5088b0b7ffcea762bf15990d087f76b782ae7d2ad88316aa0f532e5620c5cd3`
- **Collected test definitions/classes:** 6

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_installed_adapter_never_prompts` | function | 22 | Verify installed adapter never prompts behavior. |
| `test_missing_adapter_prompts_custom_path_then_accepts` | function | 38 | Verify missing adapter prompts custom path then accepts behavior. |
| `test_missing_noninteractive_is_explicit_unresolved` | function | 60 | Verify missing noninteractive is explicit unresolved behavior. |
| `test_environment_and_configured_root_detection` | function | 69 | Verify environment and configured root detection behavior. |
| `test_path_detection_preserves_symlink_argv0` | function | 87 | Verify that adapter detection keeps a symlinked argv0 path when supported. |
| `test_missing_python_adapter_accepts_custom_interpreter` | function | 105 | Verify missing python adapter accepts custom interpreter behavior. |
