---
title: tests/test_artifacts.py
description: Source-derived test reference for tests/test_artifacts.py in x86decomp
  0.7.10.
---

# `tests/test_artifacts.py`

- **SHA-256:** `7c850b2510db574ec42cd3e1c26245717d225e7a8e91dc66794b8772d797bc84`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ArtifactTests` | class | 12 | Coordinate artifact tests behavior for the current toolkit workflow. |
| `test_import_and_verify` | function | 34 | Verify import and verify behavior. |
| `test_integrity_path_escape_is_rejected` | function | 42 | Verify integrity path escape is rejected behavior. |
