---
title: test-suite/tests/test_architecture_maps.py
description: Source-derived test reference for test-suite/tests/test_architecture_maps.py
  in x86decomp 0.7.10.
---

# `test-suite/tests/test_architecture_maps.py`

- **SHA-256:** `dd3528516dba813a78b9b3b5ad1ecd6e657081ad1415d3db93b290f7d4eff3e0`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_all_architecture_map_artifacts_exist_and_are_versioned` | function | 34 | Verify all architecture map artifacts exist and are versioned. |
| `test_toolkit_mermaid_and_ascii_maps_cover_same_major_planes_and_states` | function | 47 | Verify toolkit mermaid and ascii maps cover same major planes and states. |
| `test_test_suite_mermaid_and_ascii_maps_cover_same_resolution_and_gate_contract` | function | 77 | Verify test suite mermaid and ascii maps cover same resolution and gate contract. |
| `test_architecture_map_cross_links_and_ascii_format_contract` | function | 106 | Verify architecture map cross links and ascii format contract. |
