---
title: tests/native/test_cli_schemas.py
description: Source-derived test reference for tests/native/test_cli_schemas.py in
  x86decomp 0.7.10.
---

# `tests/native/test_cli_schemas.py`

- **SHA-256:** `d5b573570bd917ae036e8c200eff630c4b86a8c95b174cb9641e9b7eb997873f`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_native_project_init_and_all_leaf_help` | function | 29 | Verify native project init and all leaf help behavior. |
| `test_main_cli_exposes_native_capabilities` | function | 40 | Verify main cli exposes native capabilities behavior. |
| `test_native_schemas_meta_validate` | function | 51 | Verify native schemas meta validate behavior. |
| `test_native_store_keeps_all_prior_schema_layers` | function | 57 | Verify native store keeps all prior schema layers behavior. |
