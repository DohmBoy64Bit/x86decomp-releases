---
title: tests/test_linker_metadata_corpus.py
description: Source-derived test reference for tests/test_linker_metadata_corpus.py
  in x86decomp 0.7.10.
---

# `tests/test_linker_metadata_corpus.py`

- **SHA-256:** `8f0ae11983ae7264ab57a796a2f8fe155225fd61194674c7cc08796f681cf015`
- **Collected test definitions/classes:** 10

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_bigobj_and_comdat_resolution` | function | 61 | Verify bigobj and comdat resolution behavior. |
| `test_map_parser_and_layout_reconstruction` | function | 86 | Verify map parser and layout reconstruction behavior. |
| `test_target_specific_image_normalization` | function | 114 | Verify target specific image normalization behavior. |
| `test_msvc_rtti_unwind_and_static_initializer_recovery` | function | 132 | Verify msvc rtti unwind and static initializer recovery behavior. |
| `test_compiler_ground_truth_corpus` | function | 169 | Verify compiler ground truth corpus behavior. |
| `test_symbolic_memory_alias_model` | function | 193 | Verify symbolic memory alias model behavior. |
| `test_real_clang_weak_external_and_tls_coff` | function | 222 | Verify real clang weak external and tls coff behavior. |
| `test_builtin_corpus_manifest_is_expanded_and_sources_compile` | function | 254 | Verify builtin corpus manifest is expanded and sources compile behavior. |
| `test_ground_truth_cross_report_comparison` | function | 267 | Verify ground truth cross report comparison behavior. |
| `test_image_profile_can_explicitly_normalize_debug_records` | function | 295 | Verify image profile can explicitly normalize debug records behavior. |
