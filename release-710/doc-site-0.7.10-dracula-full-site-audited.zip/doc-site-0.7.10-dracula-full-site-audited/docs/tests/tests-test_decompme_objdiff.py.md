---
title: tests/test_decompme_objdiff.py
description: Source-derived test reference for tests/test_decompme_objdiff.py in x86decomp
  0.7.10.
---

# `tests/test_decompme_objdiff.py`

- **SHA-256:** `cd8f3acb39d4c6b8c2c563b625e0e73e2fe39994483cb3096a3ac5c87ff70f9d`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_create_local_decompme_packet` | function | 12 | Verify create local decompme packet behavior. |
| `test_manifest_driven_objdiff_adapter` | function | 42 | Verify manifest driven objdiff adapter behavior. |
