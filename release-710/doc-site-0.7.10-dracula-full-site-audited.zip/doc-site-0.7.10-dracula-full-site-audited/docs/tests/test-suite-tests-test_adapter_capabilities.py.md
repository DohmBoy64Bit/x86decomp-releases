---
title: test-suite/tests/test_adapter_capabilities.py
description: Source-derived test reference for test-suite/tests/test_adapter_capabilities.py
  in x86decomp 0.7.10.
---

# `test-suite/tests/test_adapter_capabilities.py`

- **SHA-256:** `1b25ab2ce018c5120b02ae176c9adb8d6d6a0486657beb6d0bd407babab138bf`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_ModelsHandler` | class | 19 | Implement the _ModelsHandler class using its declared base class contract. |
| `test_lm_studio_http_satisfies_openai_capability_without_product_aliasing` | function | 56 | Verify lm studio http satisfies openai capability without product aliasing. |
| `test_non_loopback_http_endpoint_requires_network_opt_in` | function | 90 | Verify non loopback http endpoint requires network opt in. |
| `test_loopback_host_classifier_is_strict` | function | 101 | Verify loopback host classifier is strict. |
