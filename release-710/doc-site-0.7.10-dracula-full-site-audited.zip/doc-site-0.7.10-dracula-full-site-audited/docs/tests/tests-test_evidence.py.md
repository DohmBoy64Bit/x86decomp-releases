---
title: tests/test_evidence.py
description: Source-derived test reference for tests/test_evidence.py in x86decomp
  0.7.10.
---

# `tests/test_evidence.py`

- **SHA-256:** `0b32cba7e0b11589daea1342943dab03f9a2f9ec8e36261ad0818ee3c0f53159`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `EvidenceTests` | class | 12 | Coordinate evidence tests behavior for the current toolkit workflow. |
| `test_three_independent_sources_verify_claim` | function | 14 | Verify three independent sources verify claim behavior. |
| `test_same_group_does_not_verify` | function | 51 | Verify same group does not verify behavior. |
