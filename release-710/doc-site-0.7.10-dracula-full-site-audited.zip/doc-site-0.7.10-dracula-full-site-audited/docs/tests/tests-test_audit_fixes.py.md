---
title: tests/test_audit_fixes.py
description: Source-derived test reference for tests/test_audit_fixes.py in x86decomp
  0.7.10.
---

# `tests/test_audit_fixes.py`

- **SHA-256:** `4991a922981b8fe9e82a31b9b1ccfd9851449ef3d78b1525f244fca07527c2bc`
- **Collected test definitions/classes:** 5

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_optional_toolkit_extras_are_adapter_optional` | function | 15 | Verify optional toolkit extras are represented as optional adapters. |
| `test_service_index_uses_text_content_not_inner_html` | function | 23 | Verify the local service UI avoids project-data insertion through innerHTML. |
| `test_store_decode_json_fields_shared_helper` | function | 32 | Verify shared SQLite row JSON decoding behavior. |
| `test_batch_create_records_secondary_manifest_id_errors` | function | 40 | Verify corrupt manifests preserve the secondary id-read failure reason. |
| `test_no_template_docstring_phrases_remain` | function | 51 | Verify audited Python files no longer contain generated placeholder docstring phrasing. |
