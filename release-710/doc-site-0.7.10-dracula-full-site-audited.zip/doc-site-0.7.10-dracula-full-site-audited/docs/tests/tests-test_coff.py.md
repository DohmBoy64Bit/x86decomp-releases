---
title: tests/test_coff.py
description: Source-derived test reference for tests/test_coff.py in x86decomp 0.7.10.
---

# `tests/test_coff.py`

- **SHA-256:** `0db7135636f4571252ebc19b33c78b736d1c0e552707a4b9f7d0cfdb85b7796a`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_synthetic_coff_round_trip` | function | 7 | Verify synthetic coff round trip behavior. |
| `test_synthetic_coff_relocation` | function | 17 | Verify synthetic coff relocation behavior. |
