---
title: test-suite/tests/test_archive_security.py
description: Source-derived test reference for test-suite/tests/test_archive_security.py
  in x86decomp 0.7.10.
---

# `test-suite/tests/test_archive_security.py`

- **SHA-256:** `8be41d6f5f8e07f9143affe93ea9e6effc7eb287c43ae41e297d966bb9d457d1`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_safe_zip_and_tar_extraction` | function | 17 | Verify safe zip and tar extraction. |
| `test_rejects_traversal_and_links` | function | 40 | Verify rejects traversal and links. |
| `test_release_asset_selection_is_deterministic` | function | 61 | Verify release asset selection is deterministic. |
| `test_download_file_hash_and_size_limit` | function | 74 | Verify download file hash and size limit. |
