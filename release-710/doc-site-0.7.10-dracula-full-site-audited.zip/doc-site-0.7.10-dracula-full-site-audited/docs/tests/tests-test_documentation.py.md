---
title: tests/test_documentation.py
description: Source-derived test reference for tests/test_documentation.py in x86decomp
  0.7.10.
---

# `tests/test_documentation.py`

- **SHA-256:** `0b982a33823ab438968c8a215885adef9fd0953ddb8f40fe66f4a3840bd40eb2`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_release_documents_and_maps_are_current` | function | 10 | Verify release documents and maps are current behavior. |
| `test_test_plan_counts_match_feature_catalog` | function | 32 | Verify test plan counts match feature catalog behavior. |
| `test_four_architecture_artifacts_exist_and_cross_link` | function | 52 | Verify four architecture artifacts exist and cross link behavior. |
