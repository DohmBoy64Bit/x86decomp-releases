---
title: tests/native/test_inventory_and_loops.py
description: Source-derived test reference for tests/native/test_inventory_and_loops.py
  in x86decomp 0.7.10.
---

# `tests/native/test_inventory_and_loops.py`

- **SHA-256:** `f809f5bf1a274bed3ca1456e2ebabdc90e12d8ad9ad17464d5da1e0883baa201`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_native_cli_json_helpers` | function | 18 | Verify native cli json helpers behavior. |
| `test_project_inventory_audit_pe_inventory_reports_and_doctor` | function | 27 | Verify project inventory audit pe inventory reports and doctor behavior. |
| `test_native_list_and_verify_paths` | function | 50 | Verify native list and verify paths behavior. |
