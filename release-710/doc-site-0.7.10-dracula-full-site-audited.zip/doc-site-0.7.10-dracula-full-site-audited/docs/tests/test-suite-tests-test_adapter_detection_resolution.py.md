---
title: test-suite/tests/test_adapter_detection_resolution.py
description: Source-derived test reference for test-suite/tests/test_adapter_detection_resolution.py
  in x86decomp 0.7.10.
---

# `test-suite/tests/test_adapter_detection_resolution.py`

- **SHA-256:** `05f42c285ff1e4e9bab0b9df54726b993ab490d9d66473b8bef6399f68319d1d`
- **Collected test definitions/classes:** 6

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_installed_adapter_never_prompts` | function | 28 | Verify installed adapter never prompts. |
| `test_missing_adapter_prompts_custom_path_then_accepts` | function | 50 | Verify missing adapter prompts custom path then accepts. |
| `test_missing_noninteractive_is_explicit_unresolved` | function | 78 | Verify missing noninteractive is explicit unresolved. |
| `test_environment_and_configured_root_detection` | function | 90 | Verify environment and configured root detection. |
| `test_path_detection_preserves_symlink_argv0` | function | 111 | Verify path detection preserves symlink argv0. |
| `test_missing_python_adapter_accepts_custom_interpreter` | function | 132 | Verify missing python adapter accepts custom interpreter. |
