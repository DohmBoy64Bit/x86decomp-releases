---
title: tests/governance/test_proof_plugin_worker.py
description: Source-derived test reference for tests/governance/test_proof_plugin_worker.py
  in x86decomp 0.7.10.
---

# `tests/governance/test_proof_plugin_worker.py`

- **SHA-256:** `ee8681038c0ae0c7882402f41e3074c4412b73b4b4f7288b20012ebc80086e33`
- **Collected test definitions/classes:** 8

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_proof_ledger_and_bundle` | function | 18 | Verify proof ledger and bundle behavior. |
| `test_proof_bundle_rejects_outside_artifact` | function | 31 | Verify proof bundle rejects outside artifact behavior. |
| `test_plugin_install_doctor_invoke` | function | 46 | Verify plugin install doctor invoke behavior. |
| `test_plugin_rejects_undeclared_capability` | function | 55 | Verify plugin rejects undeclared capability behavior. |
| `test_worker_registry_selection_and_doctor` | function | 61 | Verify worker registry selection and doctor behavior. |
| `test_changeset_round_trip` | function | 69 | Verify changeset round trip behavior. |
| `test_changeset_base_mismatch` | function | 78 | Verify changeset base mismatch behavior. |
| `test_plugin_list_and_proof_inspect` | function | 85 | Verify plugin list and proof inspect behavior. |
