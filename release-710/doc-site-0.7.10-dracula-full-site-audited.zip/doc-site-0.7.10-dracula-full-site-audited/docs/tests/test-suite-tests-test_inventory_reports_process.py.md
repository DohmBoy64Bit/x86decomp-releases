---
title: test-suite/tests/test_inventory_reports_process.py
description: Source-derived test reference for test-suite/tests/test_inventory_reports_process.py
  in x86decomp 0.7.10.
---

# `test-suite/tests/test_inventory_reports_process.py`

- **SHA-256:** `f5774f4c96bd0e229fae61e8fd477d3557655341fdc499313ca10c1911d4836d`
- **Collected test definitions/classes:** 4

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_inventory_catalog_and_public_coverage` | function | 38 | Verify inventory catalog and public coverage. |
| `test_junit_process_logging_and_reports` | function | 63 | Verify junit process logging and reports. |
| `test_suite_schemas_and_catalog_are_valid` | function | 96 | Verify suite schemas and catalog are valid. |
| `test_recursive_inventory_includes_capability_packages_and_nested_schemas` | function | 118 | Verify recursive inventory includes capability packages and nested schemas. |
