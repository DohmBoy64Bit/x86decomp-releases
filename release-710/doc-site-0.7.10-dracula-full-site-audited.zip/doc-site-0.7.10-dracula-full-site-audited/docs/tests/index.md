---
title: Test Source Reference
description: Source-derived test file and test-node coverage for x86decomp 0.7.10.
---

# Test Source Reference

This index covers **61** test source files. It documents collected test definitions but does not claim every optional external adapter was available during the release environment.

| Test source | Test functions/classes | SHA-256 |
| --- | ---: | --- |
| [`test-suite/src/x86decomp_testkit/self_tests/test_adapter_capabilities.py`](test-suite-src-x86decomp_testkit-self_tests-test_adapter_capabilities.py.md) | 4 | `29edcce9190f01a43c81eaa7a38a65e12ff049958a4bf735d2685d329b134fd9` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py`](test-suite-src-x86decomp_testkit-self_tests-test_adapter_detection_resolution.py.md) | 6 | `f5088b0b7ffcea762bf15990d087f76b782ae7d2ad88316aa0f532e5620c5cd3` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py`](test-suite-src-x86decomp_testkit-self_tests-test_archive_security.py.md) | 4 | `c9a85a238d72824ef8e346e340dc2607f0ce75d17c102e8d1fb5812973e6c60a` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py`](test-suite-src-x86decomp_testkit-self_tests-test_cli_and_installation.py.md) | 2 | `a732ea719dcdebc30e0c4a2bdfb75be4c74ebd55ce96ddc99c70faf3a4ac2092` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_config_models.py`](test-suite-src-x86decomp_testkit-self_tests-test_config_models.py.md) | 2 | `f4537a948d0a737075e16a1003b9a8b8e99f8369edc1248c29caba7e140586ae` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py`](test-suite-src-x86decomp_testkit-self_tests-test_inventory_reports_process.py.md) | 4 | `3e2b70c05615592089e98fb5dbd393bbeaae40818df0f09db942bf63bdd13303` |
| [`test-suite/src/x86decomp_testkit/toolkit_tests/test_public_api_contract.py`](test-suite-src-x86decomp_testkit-toolkit_tests-test_public_api_contract.py.md) | 23 | `97af1e6252a3511d32a1814c003477845757298f111fa5787d879fee4d3e96db` |
| [`test-suite/tests/test_adapter_capabilities.py`](test-suite-tests-test_adapter_capabilities.py.md) | 4 | `1b25ab2ce018c5120b02ae176c9adb8d6d6a0486657beb6d0bd407babab138bf` |
| [`test-suite/tests/test_adapter_detection_resolution.py`](test-suite-tests-test_adapter_detection_resolution.py.md) | 6 | `05f42c285ff1e4e9bab0b9df54726b993ab490d9d66473b8bef6399f68319d1d` |
| [`test-suite/tests/test_architecture_maps.py`](test-suite-tests-test_architecture_maps.py.md) | 4 | `dd3528516dba813a78b9b3b5ad1ecd6e657081ad1415d3db93b290f7d4eff3e0` |
| [`test-suite/tests/test_archive_security.py`](test-suite-tests-test_archive_security.py.md) | 4 | `8be41d6f5f8e07f9143affe93ea9e6effc7eb287c43ae41e297d966bb9d457d1` |
| [`test-suite/tests/test_cli_and_installation.py`](test-suite-tests-test_cli_and_installation.py.md) | 2 | `e43c9f01f1a7b540d493fdd1ec499d6de66799e921e648d4f5b336116ae49cb5` |
| [`test-suite/tests/test_config_models.py`](test-suite-tests-test_config_models.py.md) | 2 | `12d805b02082887a8b8af738f377851f37aab0f2a2dd16bca0f3fe8d4de6f7d5` |
| [`test-suite/tests/test_inventory_reports_process.py`](test-suite-tests-test_inventory_reports_process.py.md) | 4 | `f5774f4c96bd0e229fae61e8fd477d3557655341fdc499313ca10c1911d4836d` |
| [`tests/assembly/test_annotation_materialize.py`](tests-assembly-test_annotation_materialize.py.md) | 8 | `6e90b4e325e12eb3b851ca22d4364a19f3cf5257c0f07ac51e057a926d504b82` |
| [`tests/assembly/test_helpers_and_relocations.py`](tests-assembly-test_helpers_and_relocations.py.md) | 3 | `a5a50f7860b8f169441105450065e74a15361ed37c0e5900681b457f20914943` |
| [`tests/assembly/test_pipeline_cli_schemas.py`](tests-assembly-test_pipeline_cli_schemas.py.md) | 8 | `18295390d88a99058b5359457245ce617ed981768004d2e567893a0d30238e42` |
| [`tests/governance/test_core.py`](tests-governance-test_core.py.md) | 17 | `2ebfd3a82a8f7cd6e6cedf5acc24e614c970800b66cc254784f4971a430bfff5` |
| [`tests/governance/test_governance_cli_schemas.py`](tests-governance-test_governance_cli_schemas.py.md) | 5 | `3f4f42481f815ad565a6914f285531f1de81949bc00deac360ac1046e9658a96` |
| [`tests/governance/test_proof_plugin_worker.py`](tests-governance-test_proof_plugin_worker.py.md) | 8 | `ee8681038c0ae0c7882402f41e3074c4412b73b4b4f7288b20012ebc80086e33` |
| [`tests/governance/test_worker_thread_safety.py`](tests-governance-test_worker_thread_safety.py.md) | 2 | `2048ff5db8124a58271d493abfc152e62d7bbc89c176e6d79bace56e7b06917d` |
| [`tests/native/test_cli_schemas.py`](tests-native-test_cli_schemas.py.md) | 4 | `d5b573570bd917ae036e8c200eff630c4b86a8c95b174cb9641e9b7eb997873f` |
| [`tests/native/test_inventory_and_loops.py`](tests-native-test_inventory_and_loops.py.md) | 3 | `f809f5bf1a274bed3ca1456e2ebabdc90e12d8ad9ad17464d5da1e0883baa201` |
| [`tests/native/test_pe_hybrid.py`](tests-native-test_pe_hybrid.py.md) | 4 | `9cc67751b07555ce543712122eff1abb9c9f687fe944b20cc3e8e49040ecfa9d` |
| [`tests/native/test_slots_matching.py`](tests-native-test_slots_matching.py.md) | 4 | `94855914f406923ea02198bd7484d0f9d64ebb271dbe50c8dd54fbf8abca3a63` |
| [`tests/native/test_staging_loop_runtime_windows.py`](tests-native-test_staging_loop_runtime_windows.py.md) | 4 | `cdc2f880f176575abf4e5db1220253592bea5149b9c66ae95d153c1ccd5f2b23` |
| [`tests/reconstruction/test_capsules_security_changesets.py`](tests-reconstruction-test_capsules_security_changesets.py.md) | 4 | `2d777bcb031f015d4c6a585ef90e92b48e48090406f4d7c072203615c7ffe0a0` |
| [`tests/reconstruction/test_cli_schemas_retention.py`](tests-reconstruction-test_cli_schemas_retention.py.md) | 6 | `b6080b626c0bd790f13fa4492cb787730315a42f4ea48b9655718dc43cfa1669` |
| [`tests/reconstruction/test_decomp_acceleration.py`](tests-reconstruction-test_decomp_acceleration.py.md) | 3 | `b446be684115257ad47fd9132319979d563495e7d965e7897ddd391f8bb59f4d` |
| [`tests/reconstruction/test_project_headers_builds.py`](tests-reconstruction-test_project_headers_builds.py.md) | 3 | `2b401fe3f216891e28e3da29520ae5d322b45cb5f75721ebbeb7e42957e835c3` |
| [`tests/reconstruction/test_provenance_abi_tests.py`](tests-reconstruction-test_provenance_abi_tests.py.md) | 3 | `172d0370abc39759bf296824921c2ad7c96089317051ff3fddadc75a34cf2264` |
| [`tests/reconstruction/test_real_project_acceleration.py`](tests-reconstruction-test_real_project_acceleration.py.md) | 3 | `3dd8b6ae8dc6f943896a19d12c82da87811e72335662a825a4a4ff9ebd8ac198` |
| [`tests/test_abi_disassembly.py`](tests-test_abi_disassembly.py.md) | 1 | `91ebeb183e6f9728fff8d8d828615c79506b7b1d2752a0caaf016379aec1c590` |
| [`tests/test_artifacts.py`](tests-test_artifacts.py.md) | 3 | `7c850b2510db574ec42cd3e1c26245717d225e7a8e91dc66794b8772d797bc84` |
| [`tests/test_audit_fixes.py`](tests-test_audit_fixes.py.md) | 5 | `4991a922981b8fe9e82a31b9b1ccfd9851449ef3d78b1525f244fca07527c2bc` |
| [`tests/test_coff.py`](tests-test_coff.py.md) | 2 | `0db7135636f4571252ebc19b33c78b736d1c0e552707a4b9f7d0cfdb85b7796a` |
| [`tests/test_coff_archive.py`](tests-test_coff_archive.py.md) | 3 | `38b8932cc6744db56c6ca164ad1749229f89daccd8e569f797be64b49b126a60` |
| [`tests/test_compiler.py`](tests-test_compiler.py.md) | 2 | `a700c74ef73cc25a268f426b937f9d1a238ee2f0a26ad42333b0b328c58b911e` |
| [`tests/test_decompme_objdiff.py`](tests-test_decompme_objdiff.py.md) | 2 | `cd8f3acb39d4c6b8c2c563b625e0e73e2fe39994483cb3096a3ac5c87ff70f9d` |
| [`tests/test_diffing.py`](tests-test_diffing.py.md) | 3 | `de5433ce73dcb97007481caaed594b8b4f9331828f3ebd60873c784129597bd0` |
| [`tests/test_docstring_audit.py`](tests-test_docstring_audit.py.md) | 3 | `26bcecf2165e1f02518d9ca69e194d74f4b6b0696dfa153d3d622367e390450c` |
| [`tests/test_documentation.py`](tests-test_documentation.py.md) | 3 | `0b982a33823ab438968c8a215885adef9fd0953ddb8f40fe66f4a3840bd40eb2` |
| [`tests/test_dynamic_symbolic.py`](tests-test_dynamic_symbolic.py.md) | 2 | `f664786ae11deadc81c601cf6442f4422b83e3ab3118e75e5384b0a046318be2` |
| [`tests/test_dynamorio.py`](tests-test_dynamorio.py.md) | 2 | `41d1f65aeefadb38e4b937899e801f20a93e495c7933427a2c483d7a6d554fcc` |
| [`tests/test_evidence.py`](tests-test_evidence.py.md) | 3 | `0b32cba7e0b11589daea1342943dab03f9a2f9ec8e36261ad0818ee3c0f53159` |
| [`tests/test_ghidra.py`](tests-test_ghidra.py.md) | 2 | `923c2293e595fec0df1050bb2c3ee598d2341101bb86a68276710e132afb3c87` |
| [`tests/test_integration.py`](tests-test_integration.py.md) | 2 | `91835325b62f0d2d14c0b444e88f6572ff68c70825e4932f94ea60fa4c5408cb` |
| [`tests/test_linker_metadata_corpus.py`](tests-test_linker_metadata_corpus.py.md) | 10 | `8f0ae11983ae7264ab57a796a2f8fe155225fd61194674c7cc08796f681cf015` |
| [`tests/test_local_llm.py`](tests-test_local_llm.py.md) | 9 | `68fce843df5a6b1ec7809824c973321e518d86503d6e93fe04142f9be8437157` |
| [`tests/test_mcp.py`](tests-test_mcp.py.md) | 1 | `508a19efb6d5d7f8f5ba8103a7ec38595f76ca9734a820b8b7d839a1d22dd992` |
| [`tests/test_memory.py`](tests-test_memory.py.md) | 3 | `90e42ba1551ef40809011ffa01a74e4deea641bd897a45163711ddea12dcae4d` |
| [`tests/test_modes_and_db.py`](tests-test_modes_and_db.py.md) | 2 | `84554d4fd263de392d7d3e43471ad0b538672e354b28b1ad639ccbd8f5a60f94` |
| [`tests/test_pdb.py`](tests-test_pdb.py.md) | 2 | `a66327c79f20e3a5c0ee0590777772b5b75fd514abda9f05374e15cd0c8f034f` |
| [`tests/test_pe32.py`](tests-test_pe32.py.md) | 3 | `0566aa1335fa09514110eba2495853f1eb0a06529f033546153e22dbb9a7ba4e` |
| [`tests/test_pe64_patch_hybrid.py`](tests-test_pe64_patch_hybrid.py.md) | 3 | `1c4c7817684d2149bfa82bb3c91f820ae79e81f0f5ea8b82835cb876e8985fba` |
| [`tests/test_production.py`](tests-test_production.py.md) | 22 | `da98cd0e561b0b3ec69afb258be55dd9201b09974c3c63090f0e3fb4cff32bf4` |
| [`tests/test_project.py`](tests-test_project.py.md) | 3 | `51b66c2f0070d17f2c004af56396878c666291e1e8284c5b2e2a0155aa753a67` |
| [`tests/test_release_contract.py`](tests-test_release_contract.py.md) | 9 | `698ceef3b5d7f460b95a12e4c00c2c1bd5e1a7d87c43d8743ff9de1e855804fc` |
| [`tests/test_relink.py`](tests-test_relink.py.md) | 1 | `b3a48a672550ed5392797dbb941829ec301bb24066ab9d35509f7e391fb74b92` |
| [`tests/test_test_bundle.py`](tests-test_test_bundle.py.md) | 5 | `27fd121c8a59200ffcafcfccaa6e01ca3c2bd488680f3209bbe95097686f7061` |
| [`tests/test_workqueue.py`](tests-test_workqueue.py.md) | 1 | `401f98bce8178d0bc2f01a92f5c792044a8f32695868bd0cd04feec743eb56b8` |
