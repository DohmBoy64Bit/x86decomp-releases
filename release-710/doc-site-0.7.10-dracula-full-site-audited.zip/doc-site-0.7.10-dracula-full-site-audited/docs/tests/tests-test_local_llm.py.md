---
title: tests/test_local_llm.py
description: Source-derived test reference for tests/test_local_llm.py in x86decomp
  0.7.10.
---

# `tests/test_local_llm.py`

- **SHA-256:** `68fce843df5a6b1ec7809824c973321e518d86503d6e93fe04142f9be8437157`
- **Collected test definitions/classes:** 9

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_ScriptedHandler` | class | 24 | Coordinate scripted handler behavior for the current toolkit workflow. |
| `test_provider_profiles_and_loopback_policy` | function | 154 | Verify provider profiles and loopback policy behavior. |
| `test_prompt_is_deterministic_and_marks_injected_evidence_untrusted` | function | 170 | Verify prompt is deterministic and marks injected evidence untrusted behavior. |
| `test_openai_generation_and_structured_output_fallback` | function | 183 | Verify openai generation and structured output fallback behavior. |
| `test_ollama_probe_accepts_latest_tag_only_for_ollama` | function | 210 | Verify ollama probe accepts latest tag only for ollama behavior. |
| `test_same_origin_redirect_rejects_cross_origin` | function | 224 | Verify same origin redirect rejects cross origin behavior. |
| `test_exact_byte_match_loop_and_tamper_detection` | function | 236 | Verify exact byte match loop and tamper detection behavior. |
| `test_candidate_contract_rejects_inline_assembly_and_multiple_functions` | function | 269 | Verify candidate contract rejects inline assembly and multiple functions behavior. |
| `test_local_llm_helper_bodies_are_exercised` | function | 285 | Exercise bounded helper paths required by the all-function coverage gate. |
