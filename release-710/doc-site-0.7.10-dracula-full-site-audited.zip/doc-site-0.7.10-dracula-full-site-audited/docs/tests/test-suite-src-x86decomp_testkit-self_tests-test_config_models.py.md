---
title: test-suite/src/x86decomp_testkit/self_tests/test_config_models.py
description: Source-derived test reference for test-suite/src/x86decomp_testkit/self_tests/test_config_models.py
  in x86decomp 0.7.10.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_config_models.py`

- **SHA-256:** `f4537a948d0a737075e16a1003b9a8b8e99f8369edc1248c29caba7e140586ae`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_config_roundtrip_and_relative_resolution` | function | 11 | Verify config roundtrip and relative resolution behavior. |
| `test_status_counts_and_strict_exit_code` | function | 38 | Verify status counts and strict exit code behavior. |
