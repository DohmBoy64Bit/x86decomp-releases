---
title: tests/reconstruction/test_provenance_abi_tests.py
description: Source-derived test reference for tests/reconstruction/test_provenance_abi_tests.py
  in x86decomp 0.7.10.
---

# `tests/reconstruction/test_provenance_abi_tests.py`

- **SHA-256:** `172d0370abc39759bf296824921c2ad7c96089317051ff3fddadc75a34cf2264`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_provenance_round_trip_edit_reconciliation_and_locks` | function | 17 | Verify provenance round trip edit reconciliation and locks behavior. |
| `test_abi_contract_verification_comparison_and_explicit_shim` | function | 34 | Verify abi contract verification comparison and explicit shim behavior. |
| `test_generated_tests_are_evidence_bound_and_counterexamples_promote` | function | 47 | Verify generated tests are evidence bound and counterexamples promote behavior. |
