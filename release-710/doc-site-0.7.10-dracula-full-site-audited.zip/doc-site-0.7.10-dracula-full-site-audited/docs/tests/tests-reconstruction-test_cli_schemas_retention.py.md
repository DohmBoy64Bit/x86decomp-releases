---
title: tests/reconstruction/test_cli_schemas_retention.py
description: Source-derived test reference for tests/reconstruction/test_cli_schemas_retention.py
  in x86decomp 0.7.10.
---

# `tests/reconstruction/test_cli_schemas_retention.py`

- **SHA-256:** `b6080b626c0bd790f13fa4492cb787730315a42f4ea48b9655718dc43cfa1669`
- **Collected test definitions/classes:** 6

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_reconstruction_json_argument_validation` | function | 26 | Verify reconstruction json argument validation behavior. |
| `test_reconstruction_cli_has_complete_project_scale_surface` | function | 34 | Verify reconstruction cli has complete project scale surface behavior. |
| `test_every_reconstruction_leaf_command_parses_help` | function | 45 | Verify every reconstruction leaf command parses help behavior. |
| `test_main_cli_exposes_reconstruction_capabilities` | function | 57 | Verify main cli exposes reconstruction capabilities behavior. |
| `test_all_reconstruction_schemas_are_meta_valid` | function | 72 | Verify all reconstruction schemas are meta valid behavior. |
| `test_governance_capabilities_are_in_the_unified_catalog` | function | 78 | Verify governance capabilities are in the unified catalog behavior. |
