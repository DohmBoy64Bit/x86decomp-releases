---
title: tests/test_mcp.py
description: Source-derived test reference for tests/test_mcp.py in x86decomp 0.7.10.
---

# `tests/test_mcp.py`

- **SHA-256:** `508a19efb6d5d7f8f5ba8103a7ec38595f76ca9734a820b8b7d839a1d22dd992`
- **Collected test definitions/classes:** 1

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_stdio_mcp_and_mutation_journal` | function | 36 | Verify stdio mcp and mutation journal behavior. |
