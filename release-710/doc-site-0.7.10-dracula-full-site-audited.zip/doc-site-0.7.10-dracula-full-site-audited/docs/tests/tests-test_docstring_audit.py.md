---
title: tests/test_docstring_audit.py
description: Source-derived test reference for tests/test_docstring_audit.py in x86decomp
  0.7.10.
---

# `tests/test_docstring_audit.py`

- **SHA-256:** `26bcecf2165e1f02518d9ca69e194d74f4b6b0696dfa153d3d622367e390450c`
- **Collected test definitions/classes:** 3

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_every_python_symbol_has_a_docstring` | function | 36 | Verify every audited module, class, function, and method has a docstring. |
| `test_docstring_audit_report_matches_current_release` | function | 50 | Verify the persisted docstring audit report records complete coverage. |
| `test_command_reference_matches_canonical_surface` | function | 61 | Verify the command reference remains synchronized with the live command surface. |
