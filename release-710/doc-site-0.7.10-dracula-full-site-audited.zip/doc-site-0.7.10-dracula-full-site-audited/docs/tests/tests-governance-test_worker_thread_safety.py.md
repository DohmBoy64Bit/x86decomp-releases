---
title: tests/governance/test_worker_thread_safety.py
description: Source-derived test reference for tests/governance/test_worker_thread_safety.py
  in x86decomp 0.7.10.
---

# `tests/governance/test_worker_thread_safety.py`

- **SHA-256:** `2048ff5db8124a58271d493abfc152e62d7bbc89c176e6d79bace56e7b06917d`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_worker_uses_exec_wrapper_without_thread_unsafe_preexec` | function | 14 | Verify worker uses exec wrapper without thread unsafe preexec behavior. |
| `test_legacy_preexec_compatibility_callback_is_executable` | function | 40 | Retain and directly exercise the 0.4 private callback without forking. |
