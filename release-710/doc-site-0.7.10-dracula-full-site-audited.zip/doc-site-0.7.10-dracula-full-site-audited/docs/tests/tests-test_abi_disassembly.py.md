---
title: tests/test_abi_disassembly.py
description: Source-derived test reference for tests/test_abi_disassembly.py in x86decomp
  0.7.10.
---

# `tests/test_abi_disassembly.py`

- **SHA-256:** `91ebeb183e6f9728fff8d8d828615c79506b7b1d2752a0caaf016379aec1c590`
- **Collected test definitions/classes:** 1

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_stdcall_ret_cleanup` | function | 10 | Verify stdcall ret cleanup behavior. |
