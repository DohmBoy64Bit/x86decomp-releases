---
title: tests/assembly/test_annotation_materialize.py
description: Source-derived test reference for tests/assembly/test_annotation_materialize.py
  in x86decomp 0.7.10.
---

# `tests/assembly/test_annotation_materialize.py`

- **SHA-256:** `6e90b4e325e12eb3b851ca22d4364a19f3cf5257c0f07ac51e057a926d504b82`
- **Collected test definitions/classes:** 8

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_byte_form_is_exact_native_compatibility_output` | function | 34 | Verify byte form is exact native compatibility output behavior. |
| `test_annotation_is_idempotent_and_keeps_bytes` | function | 45 | Verify annotation is idempotent and keeps bytes behavior. |
| `test_x86_external_and_local_calls_roundtrip_exactly` | function | 83 | Verify x86 external and local calls roundtrip exactly behavior. |
| `test_x64_rip_relative_data_reference_roundtrips` | function | 113 | Verify x64 rip relative data reference roundtrips behavior. |
| `test_noncanonical_instruction_falls_back_per_instruction` | function | 132 | Verify noncanonical instruction falls back per instruction behavior. |
| `test_unknown_target_uses_byte_fallback_without_false_claim` | function | 152 | Verify unknown target uses byte fallback without false claim behavior. |
| `test_verify_existing_source_reports_exact_and_mismatch` | function | 170 | Verify verify existing source reports exact and mismatch behavior. |
| `test_undecodable_tail_uses_complete_byte_form_fallback` | function | 203 | Verify undecodable tail uses complete byte form fallback behavior. |
