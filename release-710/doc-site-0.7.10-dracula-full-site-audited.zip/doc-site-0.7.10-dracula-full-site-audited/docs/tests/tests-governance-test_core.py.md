---
title: tests/governance/test_core.py
description: Source-derived test reference for tests/governance/test_core.py in x86decomp
  0.7.10.
---

# `tests/governance/test_core.py`

- **SHA-256:** `2ebfd3a82a8f7cd6e6cedf5acc24e614c970800b66cc254784f4971a430bfff5`
- **Collected test definitions/classes:** 17

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_store_is_additive_and_audit_chain` | function | 26 | Verify store is additive and audit chain behavior. |
| `test_audit_tamper_detected` | function | 39 | Verify audit tamper detected behavior. |
| `test_hypothesis_gate_and_accept` | function | 47 | Verify hypothesis gate and accept behavior. |
| `test_hypothesis_contradiction_blocks_acceptance` | function | 59 | Verify hypothesis contradiction blocks acceptance behavior. |
| `test_hypothesis_dependency_cycle_rejected` | function | 67 | Verify hypothesis dependency cycle rejected behavior. |
| `test_campaign_lifecycle_and_planner` | function | 74 | Verify campaign lifecycle and planner behavior. |
| `test_campaign_budget_blocks` | function | 83 | Verify campaign budget blocks behavior. |
| `test_campaign_branch` | function | 90 | Verify campaign branch behavior. |
| `test_candidate_branch_compare_and_promotion` | function | 97 | Verify candidate branch compare and promotion behavior. |
| `test_candidate_rejects_traversal` | function | 107 | Verify candidate rejects traversal behavior. |
| `test_ddmin_and_counterexample_promotion` | function | 113 | Verify ddmin and counterexample promotion behavior. |
| `test_consensus_conflict_and_resolution` | function | 124 | Verify consensus conflict and resolution behavior. |
| `test_graph_impact` | function | 134 | Verify graph impact behavior. |
| `test_review_lock_resists_automation` | function | 141 | Verify review lock resists automation behavior. |
| `test_family_correlation_is_bounded` | function | 148 | Verify family correlation is bounded behavior. |
| `test_remaining_public_list_snapshot_and_review_paths` | function | 157 | Verify remaining public list snapshot and review paths behavior. |
| `test_family_report_path` | function | 170 | Verify family report path behavior. |
