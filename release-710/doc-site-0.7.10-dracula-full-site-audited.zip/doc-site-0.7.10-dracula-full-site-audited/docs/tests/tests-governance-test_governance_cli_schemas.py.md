---
title: tests/governance/test_governance_cli_schemas.py
description: Source-derived test reference for tests/governance/test_governance_cli_schemas.py
  in x86decomp 0.7.10.
---

# `tests/governance/test_governance_cli_schemas.py`

- **SHA-256:** `3f4f42481f815ad565a6914f285531f1de81949bc00deac360ac1046e9658a96`
- **Collected test definitions/classes:** 5

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_every_governance_schema_meta_validates` | function | 15 | Verify every governance schema meta validates behavior. |
| `test_governance_cli_help_and_init` | function | 23 | Verify governance cli help and init behavior. |
| `test_governance_cli_hypothesis_flow` | function | 31 | Verify governance cli hypothesis flow behavior. |
| `test_contract_helpers_and_cli_json_arg` | function | 40 | Verify contract helpers and cli json arg behavior. |
| `test_all_governance_leaf_commands_parse_help` | function | 56 | Verify all governance leaf commands parse help behavior. |
