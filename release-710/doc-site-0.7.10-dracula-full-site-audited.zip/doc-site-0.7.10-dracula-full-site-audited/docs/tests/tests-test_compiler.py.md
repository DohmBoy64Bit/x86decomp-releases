---
title: tests/test_compiler.py
description: Source-derived test reference for tests/test_compiler.py in x86decomp
  0.7.10.
---

# `tests/test_compiler.py`

- **SHA-256:** `a700c74ef73cc25a268f426b937f9d1a238ee2f0a26ad42333b0b328c58b911e`
- **Collected test definitions/classes:** 2

| Name | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `CompilerTests` | class | 12 | Coordinate compiler tests behavior for the current toolkit workflow. |
| `test_compile_i386_object` | function | 15 | Verify compile i386 object behavior. |
