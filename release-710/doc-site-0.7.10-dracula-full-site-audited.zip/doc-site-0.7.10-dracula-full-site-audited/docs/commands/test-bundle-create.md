---
title: x86decomp test-bundle-create
description: Exact v0.7.10 parser-derived reference for `x86decomp test-bundle-create`.
---

# `x86decomp test-bundle-create`

## Usage

```text
usage: x86decomp test-bundle-create [-h] --artifact ARTIFACT
                                    --authorization AUTHORIZATION
                                    [--name NAME] [--description DESCRIPTION]
                                    [--expected-architecture {x86,x86_64}]
                                    output
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `output` | required · type: `_path` · parser destination: `output` · No help text declared. |
| `--artifact` | required · parser destination: `artifact` · role=path |
| `--authorization` | required · parser destination: `authorization` · No help text declared. |
| `--name` | parser destination: `name` · No help text declared. |
| `--description` | parser destination: `description` · No help text declared. |
| `--expected-architecture` | choices: `x86`, `x86_64` · parser destination: `expected_architecture` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
