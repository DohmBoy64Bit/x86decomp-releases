---
title: x86decomp db-ingest
description: Exact v0.7.10 parser-derived reference for `x86decomp db-ingest`.
---

# `x86decomp db-ingest`

## Usage

```text
usage: x86decomp db-ingest [-h] [--image-base IMAGE_BASE] database artifact
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `database` | required · type: `_path` · parser destination: `database` · No help text declared. |
| `artifact` | required · type: `_path` · parser destination: `artifact` · No help text declared. |
| `--image-base` | type: `_int` · default: `0` · parser destination: `image_base` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
