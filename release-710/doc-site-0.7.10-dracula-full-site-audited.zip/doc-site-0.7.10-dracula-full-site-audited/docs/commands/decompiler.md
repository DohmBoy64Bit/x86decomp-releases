---
title: x86decomp decompiler
description: Exact v0.7.10 parser-derived reference for `x86decomp decompiler`.
---

# `x86decomp decompiler`

Canonical decompiler commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp decompiler [-h] [--project PROJECT] [--actor ACTOR]
                            {cleanup} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `cleanup` | `usage: x86decomp decompiler cleanup [-h] [--compiler COMPILER]
                                    [--language LANGUAGE] [--locals-at-top]
                                    input_file output` | `reconstruction` |

### `x86decomp decompiler cleanup`

```text
usage: x86decomp decompiler cleanup [-h] [--compiler COMPILER]
                                    [--language LANGUAGE] [--locals-at-top]
                                    input_file output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `input_file` | required · parser destination: `input_file` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |
| `--compiler` | default: `'generic'` · parser destination: `compiler` · No help text declared. |
| `--language` | default: `'cpp'` · parser destination: `language` · No help text declared. |
| `--locals-at-top` | nargs: `0` · default: `False` · parser destination: `locals_at_top` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
