---
title: x86decomp match
description: Exact v0.7.10 parser-derived reference for `x86decomp match`.
---

# `x86decomp match`

Canonical match commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp match [-h] [--project PROJECT] [--actor ACTOR]
                       {batch,compare,mismatches,report} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `batch` | `usage: x86decomp match batch [-h] [--policy {exact,trailing-padding}]
                             [--pad-bytes-json PAD_BYTES_JSON]
                             original candidates_json` | `native` |
| `compare` | `usage: x86decomp match compare [-h] [--policy {exact,trailing-padding}]
                               [--pad-bytes-json PAD_BYTES_JSON]
                               [--protected-offsets-json PROTECTED_OFFSETS_JSON]
                               original candidate` | `native` |
| `mismatches` | `usage: x86decomp match mismatches [-h] run_id` | `native` |
| `report` | `usage: x86decomp match report [-h] run_id` | `native` |

### `x86decomp match batch`

```text
usage: x86decomp match batch [-h] [--policy {exact,trailing-padding}]
                             [--pad-bytes-json PAD_BYTES_JSON]
                             original candidates_json
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `original` | required · parser destination: `original` · No help text declared. |
| `candidates_json` | required · parser destination: `candidates_json` · No help text declared. |
| `--policy` | default: `'trailing-padding'` · choices: `exact`, `trailing-padding` · parser destination: `policy` · No help text declared. |
| `--pad-bytes-json` | parser destination: `pad_bytes_json` · No help text declared. |

### `x86decomp match compare`

```text
usage: x86decomp match compare [-h] [--policy {exact,trailing-padding}]
                               [--pad-bytes-json PAD_BYTES_JSON]
                               [--protected-offsets-json PROTECTED_OFFSETS_JSON]
                               original candidate
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `original` | required · parser destination: `original` · No help text declared. |
| `candidate` | required · parser destination: `candidate` · No help text declared. |
| `--policy` | default: `'trailing-padding'` · choices: `exact`, `trailing-padding` · parser destination: `policy` · No help text declared. |
| `--pad-bytes-json` | parser destination: `pad_bytes_json` · No help text declared. |
| `--protected-offsets-json` | parser destination: `protected_offsets_json` · No help text declared. |

### `x86decomp match mismatches`

```text
usage: x86decomp match mismatches [-h] run_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `run_id` | required · parser destination: `run_id` · No help text declared. |

### `x86decomp match report`

```text
usage: x86decomp match report [-h] run_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `run_id` | required · parser destination: `run_id` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
