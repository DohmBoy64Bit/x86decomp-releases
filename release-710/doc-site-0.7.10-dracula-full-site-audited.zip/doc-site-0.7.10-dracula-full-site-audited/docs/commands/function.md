---
title: x86decomp function
description: Exact v0.7.10 parser-derived reference for `x86decomp function`.
---

# `x86decomp function`

Canonical function commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp function [-h] [--project PROJECT] [--actor ACTOR]
                          {classify,discover,reconcile,sort} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `classify` | `usage: x86decomp function classify [-h] [--output OUTPUT] functions_json` | `reconstruction` |
| `discover` | `usage: x86decomp function discover [-h] [--profile {prologue,ret-boundary}]
                                   [--architecture {x86,x86_64}]
                                   [--min-size MIN_SIZE] [--max-size MAX_SIZE]
                                   [--align ALIGN] [--output OUTPUT]
                                   image` | `reconstruction` |
| `reconcile` | `usage: x86decomp function reconcile [-h] [--output OUTPUT]
                                    reports [reports ...]` | `reconstruction` |
| `sort` | `usage: x86decomp function sort [-h] [--key KEY] [--output OUTPUT]
                               functions_json` | `reconstruction` |

### `x86decomp function classify`

```text
usage: x86decomp function classify [-h] [--output OUTPUT] functions_json
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `functions_json` | required · parser destination: `functions_json` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp function discover`

```text
usage: x86decomp function discover [-h] [--profile {prologue,ret-boundary}]
                                   [--architecture {x86,x86_64}]
                                   [--min-size MIN_SIZE] [--max-size MAX_SIZE]
                                   [--align ALIGN] [--output OUTPUT]
                                   image
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `image` | required · parser destination: `image` · No help text declared. |
| `--profile` | default: `'prologue'` · choices: `prologue`, `ret-boundary` · parser destination: `profile` · No help text declared. |
| `--architecture` | default: `'x86'` · choices: `x86`, `x86_64` · parser destination: `architecture` · No help text declared. |
| `--min-size` | type: `int` · default: `1` · parser destination: `min_size` · No help text declared. |
| `--max-size` | type: `int` · default: `1048576` · parser destination: `max_size` · No help text declared. |
| `--align` | type: `int` · default: `1` · parser destination: `align` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp function reconcile`

```text
usage: x86decomp function reconcile [-h] [--output OUTPUT]
                                    reports [reports ...]
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `reports` | required · nargs: `+` · parser destination: `reports` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp function sort`

```text
usage: x86decomp function sort [-h] [--key KEY] [--output OUTPUT]
                               functions_json
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `functions_json` | required · parser destination: `functions_json` · No help text declared. |
| `--key` | default: `'rva'` · parser destination: `key` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
