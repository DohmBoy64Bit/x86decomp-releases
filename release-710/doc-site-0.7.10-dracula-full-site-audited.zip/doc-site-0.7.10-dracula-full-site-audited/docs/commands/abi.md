---
title: x86decomp abi
description: Exact v0.7.10 parser-derived reference for `x86decomp abi`.
---

# `x86decomp abi`

Canonical abi commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp abi [-h] [--project PROJECT] [--actor ACTOR]
                     {compare,export,recover,shim,show,verify} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `compare` | `usage: x86decomp abi compare [-h] left_id right_id` | `reconstruction` |
| `export` | `usage: x86decomp abi export [-h] contract_id output` | `reconstruction` |
| `recover` | `usage: x86decomp abi recover [-h] --evidence-json EVIDENCE_JSON
                             subject_kind subject_id architecture
                             contract_json` | `reconstruction` |
| `shim` | `usage: x86decomp abi shim [-h] [--kind KIND] contract_id source_path` | `reconstruction` |
| `show` | `usage: x86decomp abi show [-h] contract_id` | `reconstruction` |
| `verify` | `usage: x86decomp abi verify [-h] contract_id` | `reconstruction` |

### `x86decomp abi compare`

```text
usage: x86decomp abi compare [-h] left_id right_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `left_id` | required · parser destination: `left_id` · No help text declared. |
| `right_id` | required · parser destination: `right_id` · No help text declared. |

### `x86decomp abi export`

```text
usage: x86decomp abi export [-h] contract_id output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `contract_id` | required · parser destination: `contract_id` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |

### `x86decomp abi recover`

```text
usage: x86decomp abi recover [-h] --evidence-json EVIDENCE_JSON
                             subject_kind subject_id architecture
                             contract_json
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `subject_kind` | required · parser destination: `subject_kind` · No help text declared. |
| `subject_id` | required · parser destination: `subject_id` · No help text declared. |
| `architecture` | required · parser destination: `architecture` · No help text declared. |
| `contract_json` | required · parser destination: `contract_json` · No help text declared. |
| `--evidence-json` | required · parser destination: `evidence_json` · No help text declared. |

### `x86decomp abi shim`

```text
usage: x86decomp abi shim [-h] [--kind KIND] contract_id source_path
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `contract_id` | required · parser destination: `contract_id` · No help text declared. |
| `source_path` | required · parser destination: `source_path` · No help text declared. |
| `--kind` | default: `'wrapped'` · parser destination: `kind` · No help text declared. |

### `x86decomp abi show`

```text
usage: x86decomp abi show [-h] contract_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `contract_id` | required · parser destination: `contract_id` · No help text declared. |

### `x86decomp abi verify`

```text
usage: x86decomp abi verify [-h] contract_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `contract_id` | required · parser destination: `contract_id` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
