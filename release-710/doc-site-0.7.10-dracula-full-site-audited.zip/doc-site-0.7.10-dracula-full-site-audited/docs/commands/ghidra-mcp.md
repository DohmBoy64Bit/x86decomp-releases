---
title: x86decomp ghidra-mcp
description: Exact v0.7.10 parser-derived reference for `x86decomp ghidra-mcp`.
---

# `x86decomp ghidra-mcp`

Canonical ghidra-mcp commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp ghidra-mcp [-h] [--project PROJECT] [--actor ACTOR]
                            {batch-decompile,decompile,functions,probe,sync-names} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `batch-decompile` | `usage: x86decomp ghidra-mcp batch-decompile [-h] [--timeout TIMEOUT]
                                            url addresses output` | `reconstruction` |
| `decompile` | `usage: x86decomp ghidra-mcp decompile [-h] [--timeout TIMEOUT]
                                      [--output OUTPUT]
                                      url address` | `reconstruction` |
| `functions` | `usage: x86decomp ghidra-mcp functions [-h] [--timeout TIMEOUT]
                                      [--output OUTPUT]
                                      url` | `reconstruction` |
| `probe` | `usage: x86decomp ghidra-mcp probe [-h] [--timeout TIMEOUT] [--output OUTPUT]
                                  url` | `reconstruction` |
| `sync-names` | `usage: x86decomp ghidra-mcp sync-names [-h] [--output OUTPUT] names_json` | `reconstruction` |

### `x86decomp ghidra-mcp batch-decompile`

```text
usage: x86decomp ghidra-mcp batch-decompile [-h] [--timeout TIMEOUT]
                                            url addresses output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `url` | required · parser destination: `url` · No help text declared. |
| `addresses` | required · parser destination: `addresses` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |
| `--timeout` | type: `float` · default: `60.0` · parser destination: `timeout` · No help text declared. |

### `x86decomp ghidra-mcp decompile`

```text
usage: x86decomp ghidra-mcp decompile [-h] [--timeout TIMEOUT]
                                      [--output OUTPUT]
                                      url address
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `url` | required · parser destination: `url` · No help text declared. |
| `address` | required · parser destination: `address` · No help text declared. |
| `--timeout` | type: `float` · default: `60.0` · parser destination: `timeout` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp ghidra-mcp functions`

```text
usage: x86decomp ghidra-mcp functions [-h] [--timeout TIMEOUT]
                                      [--output OUTPUT]
                                      url
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `url` | required · parser destination: `url` · No help text declared. |
| `--timeout` | type: `float` · default: `30.0` · parser destination: `timeout` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp ghidra-mcp probe`

```text
usage: x86decomp ghidra-mcp probe [-h] [--timeout TIMEOUT] [--output OUTPUT]
                                  url
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `url` | required · parser destination: `url` · No help text declared. |
| `--timeout` | type: `float` · default: `5.0` · parser destination: `timeout` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp ghidra-mcp sync-names`

```text
usage: x86decomp ghidra-mcp sync-names [-h] [--output OUTPUT] names_json
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `names_json` | required · parser destination: `names_json` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
