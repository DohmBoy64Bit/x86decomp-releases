---
title: x86decomp hybrid
description: Exact v0.7.10 parser-derived reference for `x86decomp hybrid`.
---

# `x86decomp hybrid`

Canonical hybrid commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp hybrid [-h] [--project PROJECT] [--actor ACTOR]
                        {compose,generate,verify} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `compose` | `usage: x86decomp hybrid compose [-h] run_id output` | `native` |
| `generate` | `usage: x86decomp hybrid generate [-h] [--architecture {x86,x86_64}]
                                 [--asm-format {bytes,annotated,mnemonic}]
                                 [--image-base IMAGE_BASE]
                                 [--assembler-command-json ASSEMBLER_COMMAND_JSON]
                                 [--symbol-map SYMBOL_MAP] [--overwrite]
                                 source_project output` | `assembly` |
| `verify` | `usage: x86decomp hybrid verify [-h] composition_id` | `native` |

### `x86decomp hybrid compose`

```text
usage: x86decomp hybrid compose [-h] run_id output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `run_id` | required · parser destination: `run_id` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |

### `x86decomp hybrid generate`

```text
usage: x86decomp hybrid generate [-h] [--architecture {x86,x86_64}]
                                 [--asm-format {bytes,annotated,mnemonic}]
                                 [--image-base IMAGE_BASE]
                                 [--assembler-command-json ASSEMBLER_COMMAND_JSON]
                                 [--symbol-map SYMBOL_MAP] [--overwrite]
                                 source_project output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `source_project` | required · parser destination: `source_project` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |
| `--architecture` | default: `'x86'` · choices: `x86`, `x86_64` · parser destination: `architecture` · No help text declared. |
| `--asm-format` | default: `'bytes'` · choices: `bytes`, `annotated`, `mnemonic` · parser destination: `asm_format` · No help text declared. |
| `--image-base` | type: `_int` · default: `0` · parser destination: `image_base` · No help text declared. |
| `--assembler-command-json` | parser destination: `assembler_command_json` · No help text declared. |
| `--symbol-map` | parser destination: `symbol_map` · No help text declared. |
| `--overwrite` | nargs: `0` · default: `False` · parser destination: `overwrite` · No help text declared. |

### `x86decomp hybrid verify`

```text
usage: x86decomp hybrid verify [-h] composition_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `composition_id` | required · parser destination: `composition_id` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
