---
title: x86decomp source
description: Exact v0.7.10 parser-derived reference for `x86decomp source`.
---

# `x86decomp source`

Canonical source commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp source [-h] [--project PROJECT] [--actor ACTOR]
                        {impact,lock,reconcile,unlock} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `impact` | `usage: x86decomp source impact [-h] path` | `reconstruction` |
| `lock` | `usage: x86decomp source lock [-h] --reason REASON path` | `reconstruction` |
| `reconcile` | `usage: x86decomp source reconcile [-h] [--before-sha256 BEFORE_SHA256]
                                  [--semantic {true,false}]
                                  path` | `reconstruction` |
| `unlock` | `usage: x86decomp source unlock [-h] path` | `reconstruction` |

### `x86decomp source impact`

```text
usage: x86decomp source impact [-h] path
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `path` | required · parser destination: `path` · No help text declared. |

### `x86decomp source lock`

```text
usage: x86decomp source lock [-h] --reason REASON path
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `path` | required · parser destination: `path` · No help text declared. |
| `--reason` | required · parser destination: `reason` · No help text declared. |

### `x86decomp source reconcile`

```text
usage: x86decomp source reconcile [-h] [--before-sha256 BEFORE_SHA256]
                                  [--semantic {true,false}]
                                  path
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `path` | required · parser destination: `path` · No help text declared. |
| `--before-sha256` | parser destination: `before_sha256` · No help text declared. |
| `--semantic` | choices: `true`, `false` · parser destination: `semantic` · No help text declared. |

### `x86decomp source unlock`

```text
usage: x86decomp source unlock [-h] path
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `path` | required · parser destination: `path` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
