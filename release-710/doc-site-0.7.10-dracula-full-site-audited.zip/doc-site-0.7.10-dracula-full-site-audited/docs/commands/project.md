---
title: x86decomp project
description: Exact v0.7.10 parser-derived reference for `x86decomp project`.
---

# `x86decomp project`

Canonical project commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp project [-h] [--project PROJECT] [--actor ACTOR]
                         {check,doctor-paths,explain-boundaries,export,health,init,synthesize-layout} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `check` | `usage: x86decomp project check [-h]` | `assembly` |
| `doctor-paths` | `usage: x86decomp project doctor-paths [-h] [--output OUTPUT] root` | `reconstruction` |
| `explain-boundaries` | `usage: x86decomp project explain-boundaries [-h] module_id` | `reconstruction` |
| `export` | `usage: x86decomp project export [-h] output` | `reconstruction` |
| `health` | `usage: x86decomp project health [-h] [--output OUTPUT]` | `reconstruction` |
| `init` | `usage: x86decomp project init [-h]` | `assembly` |
| `synthesize-layout` | `usage: x86decomp project synthesize-layout [-h] inventory_json` | `reconstruction` |

### `x86decomp project check`

```text
usage: x86decomp project check [-h]
```

### `x86decomp project doctor-paths`

```text
usage: x86decomp project doctor-paths [-h] [--output OUTPUT] root
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `root` | required · parser destination: `root` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp project explain-boundaries`

```text
usage: x86decomp project explain-boundaries [-h] module_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `module_id` | required · parser destination: `module_id` · No help text declared. |

### `x86decomp project export`

```text
usage: x86decomp project export [-h] output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `output` | required · parser destination: `output` · No help text declared. |

### `x86decomp project health`

```text
usage: x86decomp project health [-h] [--output OUTPUT]
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp project init`

```text
usage: x86decomp project init [-h]
```

### `x86decomp project synthesize-layout`

```text
usage: x86decomp project synthesize-layout [-h] inventory_json
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `inventory_json` | required · parser destination: `inventory_json` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
