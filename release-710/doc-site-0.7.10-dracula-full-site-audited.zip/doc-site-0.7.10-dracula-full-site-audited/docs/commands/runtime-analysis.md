---
title: x86decomp runtime-analysis
description: Exact v0.7.10 parser-derived reference for `x86decomp runtime-analysis`.
---

# `x86decomp runtime-analysis`

Canonical runtime-analysis commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp runtime-analysis [-h] [--project PROJECT] [--actor ACTOR]
                                  {identify,match-library,quarantine} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `identify` | `usage: x86decomp runtime-analysis identify [-h] [--output OUTPUT]` | `reconstruction` |
| `match-library` | `usage: x86decomp runtime-analysis match-library [-h] [--output OUTPUT]
                                                library_inventory` | `reconstruction` |
| `quarantine` | `usage: x86decomp runtime-analysis quarantine [-h] [--output OUTPUT]
                                             identification_report` | `reconstruction` |

### `x86decomp runtime-analysis identify`

```text
usage: x86decomp runtime-analysis identify [-h] [--output OUTPUT]
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp runtime-analysis match-library`

```text
usage: x86decomp runtime-analysis match-library [-h] [--output OUTPUT]
                                                library_inventory
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `library_inventory` | required · parser destination: `library_inventory` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp runtime-analysis quarantine`

```text
usage: x86decomp runtime-analysis quarantine [-h] [--output OUTPUT]
                                             identification_report
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `identification_report` | required · parser destination: `identification_report` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
