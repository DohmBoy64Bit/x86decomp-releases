---
title: x86decomp content-put
description: Exact v0.7.10 parser-derived reference for `x86decomp content-put`.
---

# `x86decomp content-put`

## Usage

```text
usage: x86decomp content-put [-h] [--media-type MEDIA_TYPE]
                             [--reference REFERENCE] [--kind KIND]
                             [--owner OWNER]
                             store file
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `store` | required · type: `_path` · parser destination: `store` · No help text declared. |
| `file` | required · type: `_path` · parser destination: `file` · No help text declared. |
| `--media-type` | default: `'application/octet-stream'` · parser destination: `media_type` · No help text declared. |
| `--reference` | parser destination: `reference` · No help text declared. |
| `--kind` | default: `'artifact'` · parser destination: `kind` · No help text declared. |
| `--owner` | default: `'user'` · parser destination: `owner` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
