---
title: x86decomp capsule
description: Exact v0.7.10 parser-derived reference for `x86decomp capsule`.
---

# `x86decomp capsule`

Canonical capsule commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp capsule [-h] [--project PROJECT] [--actor ACTOR]
                         {create,inspect,reproduce,verify} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `create` | `usage: x86decomp capsule create [-h] [--include INCLUDE]
                                [--external-json EXTERNAL_JSON]
                                name output` | `reconstruction` |
| `inspect` | `usage: x86decomp capsule inspect [-h] path` | `reconstruction` |
| `reproduce` | `usage: x86decomp capsule reproduce [-h] path destination` | `reconstruction` |
| `verify` | `usage: x86decomp capsule verify [-h] path` | `reconstruction` |

### `x86decomp capsule create`

```text
usage: x86decomp capsule create [-h] [--include INCLUDE]
                                [--external-json EXTERNAL_JSON]
                                name output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `name` | required · parser destination: `name` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |
| `--include` | default: `[]` · parser destination: `include` · No help text declared. |
| `--external-json` | parser destination: `external_json` · No help text declared. |

### `x86decomp capsule inspect`

```text
usage: x86decomp capsule inspect [-h] path
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `path` | required · parser destination: `path` · No help text declared. |

### `x86decomp capsule reproduce`

```text
usage: x86decomp capsule reproduce [-h] path destination
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `path` | required · parser destination: `path` · No help text declared. |
| `destination` | required · parser destination: `destination` · No help text declared. |

### `x86decomp capsule verify`

```text
usage: x86decomp capsule verify [-h] path
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `path` | required · parser destination: `path` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
