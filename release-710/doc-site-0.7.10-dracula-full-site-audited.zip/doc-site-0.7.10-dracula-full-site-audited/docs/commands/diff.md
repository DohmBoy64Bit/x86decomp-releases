---
title: x86decomp diff
description: Exact v0.7.10 parser-derived reference for `x86decomp diff`.
---

# `x86decomp diff`

Canonical diff commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp diff [-h] [--project PROJECT] [--actor ACTOR] {explain} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `explain` | `usage: x86decomp diff explain [-h] [--source SOURCE] [--output OUTPUT]
                              diff_report` | `reconstruction` |

### `x86decomp diff explain`

```text
usage: x86decomp diff explain [-h] [--source SOURCE] [--output OUTPUT]
                              diff_report
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `diff_report` | required · parser destination: `diff_report` · No help text declared. |
| `--source` | parser destination: `source` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
