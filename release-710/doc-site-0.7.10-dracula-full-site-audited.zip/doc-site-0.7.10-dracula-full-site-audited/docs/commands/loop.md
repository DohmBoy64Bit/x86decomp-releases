---
title: x86decomp loop
description: Exact v0.7.10 parser-derived reference for `x86decomp loop`.
---

# `x86decomp loop`

Canonical loop commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp loop [-h] [--project PROJECT] [--actor ACTOR]
                      {list,run,show} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `list` | `usage: x86decomp loop list [-h]` | `native` |
| `run` | `usage: x86decomp loop run [-h] [--symbol SYMBOL] [--policy POLICY]
                          [--timeout TIMEOUT] [--execute]
                          function_id source compile_command_json candidate
                          original rva slot_size` | `native` |
| `show` | `usage: x86decomp loop show [-h] loop_id` | `native` |

### `x86decomp loop list`

```text
usage: x86decomp loop list [-h]
```

### `x86decomp loop run`

```text
usage: x86decomp loop run [-h] [--symbol SYMBOL] [--policy POLICY]
                          [--timeout TIMEOUT] [--execute]
                          function_id source compile_command_json candidate
                          original rva slot_size
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `function_id` | required · parser destination: `function_id` · No help text declared. |
| `source` | required · parser destination: `source` · No help text declared. |
| `compile_command_json` | required · parser destination: `compile_command_json` · No help text declared. |
| `candidate` | required · parser destination: `candidate` · No help text declared. |
| `original` | required · parser destination: `original` · No help text declared. |
| `rva` | required · parser destination: `rva` · No help text declared. |
| `slot_size` | required · type: `int` · parser destination: `slot_size` · No help text declared. |
| `--symbol` | parser destination: `symbol` · No help text declared. |
| `--policy` | default: `'trailing-padding'` · parser destination: `policy` · No help text declared. |
| `--timeout` | type: `int` · default: `120` · parser destination: `timeout` · No help text declared. |
| `--execute` | nargs: `0` · default: `False` · parser destination: `execute` · No help text declared. |

### `x86decomp loop show`

```text
usage: x86decomp loop show [-h] loop_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `loop_id` | required · parser destination: `loop_id` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
