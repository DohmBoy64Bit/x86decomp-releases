---
title: x86decomp commands
description: Exact v0.7.10 parser-derived reference for `x86decomp commands`.
---

# `x86decomp commands`

## Usage

```text
usage: x86decomp commands [-h]
                          [--group {abi,asm,asset,boundary,build,campaign,candidate,capsule,changeset,class,compiler-rules,consensus,counterexample,decompiler,diff,family,function,game-pattern,ghidra-mcp,graph,headers,hybrid,hypothesis,image-text,library,llm,loop,match,mod,module,pattern,pe,playability,plugin,progress,project,proof,provenance,regression,release-policy,reloc,review,runtime,runtime-analysis,script-port,security,source,source-map,source-stage,staging,subsystem,tests,text-swap,toolchain,triage,type,vtable,windows,worker}]
                          [--owner {governance,reconstruction,native,assembly}]
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--group` | choices: `abi`, `asm`, `asset`, `boundary`, `build`, `campaign`, `candidate`, `capsule`, `changeset`, `class`, `compiler-rules`, `consensus`, `counterexample`, `decompiler`, `diff`, `family`, `function`, `game-pattern`, `ghidra-mcp`, `graph`, `headers`, `hybrid`, `hypothesis`, `image-text`, `library`, `llm`, `loop`, `match`, `mod`, `module`, `pattern`, `pe`, `playability`, `plugin`, `progress`, `project`, `proof`, `provenance`, `regression`, `release-policy`, `reloc`, `review`, `runtime`, `runtime-analysis`, `script-port`, `security`, `source`, `source-map`, `source-stage`, `staging`, `subsystem`, `tests`, `text-swap`, `toolchain`, `triage`, `type`, `vtable`, `windows`, `worker` · parser destination: `group` · No help text declared. |
| `--owner` | choices: `governance`, `reconstruction`, `native`, `assembly` · parser destination: `owner` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
