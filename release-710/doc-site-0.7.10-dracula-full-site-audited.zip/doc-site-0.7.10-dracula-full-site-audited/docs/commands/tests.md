---
title: x86decomp tests
description: Exact v0.7.10 parser-derived reference for `x86decomp tests`.
---

# `x86decomp tests`

Canonical tests commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp tests [-h] [--project PROJECT] [--actor ACTOR]
                       {add,explain,list,promote-counterexample,synthesize} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `add` | `usage: x86decomp tests add [-h] --applicability-json APPLICABILITY_JSON
                           --evidence-json EVIDENCE_JSON
                           name scope_kind scope_id test_kind relative_path
                           content_file` | `reconstruction` |
| `explain` | `usage: x86decomp tests explain [-h] test_id` | `reconstruction` |
| `list` | `usage: x86decomp tests list [-h]` | `reconstruction` |
| `promote-counterexample` | `usage: x86decomp tests promote-counterexample [-h] [--name NAME]
                                              counterexample_id` | `reconstruction` |
| `synthesize` | `usage: x86decomp tests synthesize [-h] [--name NAME] scope_kind scope_id` | `reconstruction` |

### `x86decomp tests add`

```text
usage: x86decomp tests add [-h] --applicability-json APPLICABILITY_JSON
                           --evidence-json EVIDENCE_JSON
                           name scope_kind scope_id test_kind relative_path
                           content_file
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `name` | required · parser destination: `name` · No help text declared. |
| `scope_kind` | required · parser destination: `scope_kind` · No help text declared. |
| `scope_id` | required · parser destination: `scope_id` · No help text declared. |
| `test_kind` | required · parser destination: `test_kind` · No help text declared. |
| `relative_path` | required · parser destination: `relative_path` · No help text declared. |
| `content_file` | required · parser destination: `content_file` · No help text declared. |
| `--applicability-json` | required · parser destination: `applicability_json` · No help text declared. |
| `--evidence-json` | required · parser destination: `evidence_json` · No help text declared. |

### `x86decomp tests explain`

```text
usage: x86decomp tests explain [-h] test_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `test_id` | required · parser destination: `test_id` · No help text declared. |

### `x86decomp tests list`

```text
usage: x86decomp tests list [-h]
```

### `x86decomp tests promote-counterexample`

```text
usage: x86decomp tests promote-counterexample [-h] [--name NAME]
                                              counterexample_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `counterexample_id` | required · parser destination: `counterexample_id` · No help text declared. |
| `--name` | parser destination: `name` · No help text declared. |

### `x86decomp tests synthesize`

```text
usage: x86decomp tests synthesize [-h] [--name NAME] scope_kind scope_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `scope_kind` | required · parser destination: `scope_kind` · No help text declared. |
| `scope_id` | required · parser destination: `scope_id` · No help text declared. |
| `--name` | parser destination: `name` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
