---
title: x86decomp toolchain-register
description: Exact v0.7.10 parser-derived reference for `x86decomp toolchain-register`.
---

# `x86decomp toolchain-register`

## Usage

```text
usage: x86decomp toolchain-register [-h] --executable EXECUTABLE
                                    registry toolchain_id family version
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `registry` | required · type: `_path` · parser destination: `registry` · No help text declared. |
| `toolchain_id` | required · parser destination: `toolchain_id` · No help text declared. |
| `family` | required · parser destination: `family` · No help text declared. |
| `version` | required · parser destination: `version` · No help text declared. |
| `--executable` | required · parser destination: `executable` · role=path |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
