---
title: x86decomp security
description: Exact v0.7.10 parser-derived reference for `x86decomp security`.
---

# `x86decomp security`

Canonical security commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp security [-h] [--project PROJECT] [--actor ACTOR]
                          {finding,policy,report,scan} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `finding` | `usage: x86decomp security finding [-h] --evidence-json EVIDENCE_JSON
                                  rule_id severity subject_id summary` | `reconstruction` |
| `policy` | `usage: x86decomp security policy [-h] name policy_json` | `reconstruction` |
| `report` | `usage: x86decomp security report [-h]` | `reconstruction` |
| `scan` | `usage: x86decomp security scan [-h] observations_json` | `reconstruction` |

### `x86decomp security finding`

```text
usage: x86decomp security finding [-h] --evidence-json EVIDENCE_JSON
                                  rule_id severity subject_id summary
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `rule_id` | required · parser destination: `rule_id` · No help text declared. |
| `severity` | required · parser destination: `severity` · No help text declared. |
| `subject_id` | required · parser destination: `subject_id` · No help text declared. |
| `summary` | required · parser destination: `summary` · No help text declared. |
| `--evidence-json` | required · parser destination: `evidence_json` · No help text declared. |

### `x86decomp security policy`

```text
usage: x86decomp security policy [-h] name policy_json
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `name` | required · parser destination: `name` · No help text declared. |
| `policy_json` | required · parser destination: `policy_json` · No help text declared. |

### `x86decomp security report`

```text
usage: x86decomp security report [-h]
```

### `x86decomp security scan`

```text
usage: x86decomp security scan [-h] observations_json
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `observations_json` | required · parser destination: `observations_json` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
