---
title: x86decomp review
description: Exact v0.7.10 parser-derived reference for `x86decomp review`.
---

# `x86decomp review`

Canonical review commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp review [-h] [--project PROJECT] [--actor ACTOR]
                        {assign,create,decide,list,lock,show} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `assign` | `usage: x86decomp review assign [-h] review_id assignee` | `governance` |
| `create` | `usage: x86decomp review create [-h] [--priority PRIORITY]
                               [--details-json DETAILS_JSON]
                               kind subject_id summary` | `governance` |
| `decide` | `usage: x86decomp review decide [-h] --rationale RATIONALE [--lock]
                               review_id decision` | `governance` |
| `list` | `usage: x86decomp review list [-h] [--status STATUS] [--limit LIMIT]` | `governance` |
| `lock` | `usage: x86decomp review lock [-h] review_id` | `governance` |
| `show` | `usage: x86decomp review show [-h] review_id` | `governance` |

### `x86decomp review assign`

```text
usage: x86decomp review assign [-h] review_id assignee
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `review_id` | required · parser destination: `review_id` · No help text declared. |
| `assignee` | required · parser destination: `assignee` · No help text declared. |

### `x86decomp review create`

```text
usage: x86decomp review create [-h] [--priority PRIORITY]
                               [--details-json DETAILS_JSON]
                               kind subject_id summary
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `kind` | required · parser destination: `kind` · No help text declared. |
| `subject_id` | required · parser destination: `subject_id` · No help text declared. |
| `summary` | required · parser destination: `summary` · No help text declared. |
| `--priority` | type: `int` · default: `50` · parser destination: `priority` · No help text declared. |
| `--details-json` | parser destination: `details_json` · No help text declared. |

### `x86decomp review decide`

```text
usage: x86decomp review decide [-h] --rationale RATIONALE [--lock]
                               review_id decision
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `review_id` | required · parser destination: `review_id` · No help text declared. |
| `decision` | required · parser destination: `decision` · No help text declared. |
| `--rationale` | required · parser destination: `rationale` · No help text declared. |
| `--lock` | nargs: `0` · default: `False` · parser destination: `lock` · No help text declared. |

### `x86decomp review list`

```text
usage: x86decomp review list [-h] [--status STATUS] [--limit LIMIT]
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--status` | parser destination: `status` · No help text declared. |
| `--limit` | type: `int` · default: `100` · parser destination: `limit` · No help text declared. |

### `x86decomp review lock`

```text
usage: x86decomp review lock [-h] review_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `review_id` | required · parser destination: `review_id` · No help text declared. |

### `x86decomp review show`

```text
usage: x86decomp review show [-h] review_id
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `review_id` | required · parser destination: `review_id` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
