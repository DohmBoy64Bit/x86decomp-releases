---
title: x86decomp corpus-generate
description: Exact v0.7.10 parser-derived reference for `x86decomp corpus-generate`.
---

# `x86decomp corpus-generate`

## Usage

```text
usage: x86decomp corpus-generate [-h] [--cases-per-family CASES_PER_FAMILY]
                                 [--seed SEED] [--c-only] [--cpp-only]
                                 [--report REPORT]
                                 output_directory
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `output_directory` | required · type: `_path` · parser destination: `output_directory` · No help text declared. |
| `--cases-per-family` | type: `int` · default: `8` · parser destination: `cases_per_family` · No help text declared. |
| `--seed` | type: `_int` · default: `2262745310` · parser destination: `seed` · No help text declared. |
| `--c-only` | nargs: `0` · default: `False` · parser destination: `c_only` · No help text declared. |
| `--cpp-only` | nargs: `0` · default: `False` · parser destination: `cpp_only` · No help text declared. |
| `--report` | type: `_path` · parser destination: `report` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
