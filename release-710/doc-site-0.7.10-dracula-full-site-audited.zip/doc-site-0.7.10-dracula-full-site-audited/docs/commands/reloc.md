---
title: x86decomp reloc
description: Exact v0.7.10 parser-derived reference for `x86decomp reloc`.
---

# `x86decomp reloc`

Canonical reloc commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp reloc [-h] [--project PROJECT] [--actor ACTOR]
                       {inspect,resolve,supported} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `inspect` | `usage: x86decomp reloc inspect [-h] [--symbol SYMBOL] object` | `assembly` |
| `resolve` | `usage: x86decomp reloc resolve [-h] [--image-base IMAGE_BASE]
                               object symbol base_rva symbol_map output` | `assembly` |
| `supported` | `usage: x86decomp reloc supported [-h]` | `assembly` |

### `x86decomp reloc inspect`

```text
usage: x86decomp reloc inspect [-h] [--symbol SYMBOL] object
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `object` | required · parser destination: `object` · No help text declared. |
| `--symbol` | parser destination: `symbol` · No help text declared. |

### `x86decomp reloc resolve`

```text
usage: x86decomp reloc resolve [-h] [--image-base IMAGE_BASE]
                               object symbol base_rva symbol_map output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `object` | required · parser destination: `object` · No help text declared. |
| `symbol` | required · parser destination: `symbol` · No help text declared. |
| `base_rva` | required · type: `_int` · parser destination: `base_rva` · No help text declared. |
| `symbol_map` | required · parser destination: `symbol_map` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |
| `--image-base` | type: `_int` · default: `0` · parser destination: `image_base` · No help text declared. |

### `x86decomp reloc supported`

```text
usage: x86decomp reloc supported [-h]
```

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
