---
title: x86decomp image-text
description: Exact v0.7.10 parser-derived reference for `x86decomp image-text`.
---

# `x86decomp image-text`

Canonical image-text commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp image-text [-h] [--project PROJECT] [--actor ACTOR]
                            {compose} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `compose` | `usage: x86decomp image-text compose [-h] [--function-list FUNCTION_LIST]
                                    [--fallback-byte FALLBACK_BYTE]
                                    output` | `reconstruction` |

### `x86decomp image-text compose`

```text
usage: x86decomp image-text compose [-h] [--function-list FUNCTION_LIST]
                                    [--fallback-byte FALLBACK_BYTE]
                                    output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `output` | required · parser destination: `output` · No help text declared. |
| `--function-list` | parser destination: `function_list` · No help text declared. |
| `--fallback-byte` | type: `<lambda>` · default: `204` · parser destination: `fallback_byte` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
