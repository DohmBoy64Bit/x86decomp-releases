---
title: x86decomp text-swap
description: Exact v0.7.10 parser-derived reference for `x86decomp text-swap`.
---

# `x86decomp text-swap`

Canonical text-swap commands implemented by the current capability subsystem.

## Usage

```text
usage: x86decomp text-swap [-h] [--project PROJECT] [--actor ACTOR]
                           {build,inject,plan,verify} ...
```

## Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `--project` | default: `'.'` · parser destination: `project` · project root used by the capability implementation (default: current directory) |
| `--actor` | default: `'analyst'` · parser destination: `actor` · No help text declared. |

## Actions

| Action | Usage | Canonical owner |
| --- | --- | --- |
| `build` | `usage: x86decomp text-swap build [-h] --original ORIGINAL
                                 [--section-name SECTION_NAME]
                                 replacement output` | `reconstruction` |
| `inject` | `usage: x86decomp text-swap inject [-h] [--output OUTPUT] plan` | `reconstruction` |
| `plan` | `usage: x86decomp text-swap plan [-h] [--section-name SECTION_NAME]
                                original replacement output` | `reconstruction` |
| `verify` | `usage: x86decomp text-swap verify [-h] [--output OUTPUT] plan image` | `reconstruction` |

### `x86decomp text-swap build`

```text
usage: x86decomp text-swap build [-h] --original ORIGINAL
                                 [--section-name SECTION_NAME]
                                 replacement output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `replacement` | required · parser destination: `replacement` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |
| `--original` | required · parser destination: `original` · No help text declared. |
| `--section-name` | default: `'.text'` · parser destination: `section_name` · No help text declared. |

### `x86decomp text-swap inject`

```text
usage: x86decomp text-swap inject [-h] [--output OUTPUT] plan
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `plan` | required · parser destination: `plan` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

### `x86decomp text-swap plan`

```text
usage: x86decomp text-swap plan [-h] [--section-name SECTION_NAME]
                                original replacement output
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `original` | required · parser destination: `original` · No help text declared. |
| `replacement` | required · parser destination: `replacement` · No help text declared. |
| `output` | required · parser destination: `output` · No help text declared. |
| `--section-name` | default: `'.text'` · parser destination: `section_name` · No help text declared. |

### `x86decomp text-swap verify`

```text
usage: x86decomp text-swap verify [-h] [--output OUTPUT] plan image
```

#### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `plan` | required · parser destination: `plan` · No help text declared. |
| `image` | required · parser destination: `image` · No help text declared. |
| `--output` | parser destination: `output` · No help text declared. |

## Source basis

| Parser owner | Source file | SHA-256 |
| --- | --- | --- |
| toolkit parser | `src/x86decomp/cli.py` | `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8` |
| canonical route catalog | `src/x86decomp/canonical.py` | `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc` |

## Verification boundary

This page is regenerated from the v0.7.10 parser surface. It documents syntax, parser-declared arguments, canonical owners, and source files; it does not claim that optional adapters, target binaries, compiler toolchains, or runtime inputs exist on the reader's machine.
