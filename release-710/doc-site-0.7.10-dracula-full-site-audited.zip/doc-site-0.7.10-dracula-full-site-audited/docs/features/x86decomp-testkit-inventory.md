---
title: x86decomp_testkit.inventory
description: Source-derived module page for x86decomp_testkit.inventory in x86decomp
  0.7.10.
---

# `x86decomp_testkit.inventory`

- **Source path:** `test-suite/src/x86decomp_testkit/inventory.py`
- **SHA-256:** `8e0de0c4c8e4a66f6dbf6e59ea44c0b1eea41d3ed80511dd2bc8eabce79fc4a1`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.inventory` module.
- **AST symbols:** 16

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `PublicSymbol` | class | 16 | Store validated public symbol fields used by toolkit reports and adapters. |
| `symbol_id` | function | 25 | Execute the symbol id operation for the current toolkit workflow. |
| `to_dict` | function | 29 | Return a serializable dictionary representation. |
| `_direct_body_lines` | function | 41 | Support direct body lines processing for internal toolkit callers. |
| `_python_files` | function | 55 | Support python files processing for internal toolkit callers. |
| `_module_name` | function | 63 | Support module name processing for internal toolkit callers. |
| `_discover_symbols` | function | 73 | Support discover symbols processing for internal toolkit callers. |
| `discover_public_symbols` | function | 106 | Discover public symbols for the current toolkit workflow. |
| `discover_all_function_symbols` | function | 111 | Discover all function symbols for the current toolkit workflow. |
| `discover_modules` | function | 116 | Discover modules for the current toolkit workflow. |
| `discover_schemas` | function | 121 | Discover schemas for the current toolkit workflow. |
| `discover_ghidra_scripts` | function | 127 | Discover ghidra scripts for the current toolkit workflow. |
| `discover_cli_commands` | function | 133 | Discover cli commands for the current toolkit workflow. |
| `build_inventory` | function | 154 | Build inventory for the current toolkit workflow. |
| `load_feature_catalog` | function | 169 | Load feature catalog for the current toolkit workflow. |
| `audit_catalog` | function | 177 | Audit catalog for the current toolkit workflow. |
