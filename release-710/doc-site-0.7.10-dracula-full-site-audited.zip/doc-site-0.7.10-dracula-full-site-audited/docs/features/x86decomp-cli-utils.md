---
title: x86decomp.cli_utils
description: Source-derived module page for x86decomp.cli_utils in x86decomp 0.7.10.
---

# `x86decomp.cli_utils`

- **Source path:** `src/x86decomp/cli_utils.py`
- **SHA-256:** `9b51fe87fa1e4b93d5cbae791655451f0c1bf467ea88013aa37fa1176d0c9c97`
- **Module docstring:** Shared command-line JSON parsing and output helpers.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `parse_json_arg` | function | 15 | Parse an optional JSON command argument and return a caller-supplied default. |
| `emit_json` | function | 29 | Print a deterministic JSON representation of a command result. |
