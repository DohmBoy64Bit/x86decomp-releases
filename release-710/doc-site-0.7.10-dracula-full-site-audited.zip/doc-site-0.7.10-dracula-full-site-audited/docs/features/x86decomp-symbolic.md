---
title: x86decomp.symbolic
description: Source-derived module page for x86decomp.symbolic in x86decomp 0.7.10.
---

# `x86decomp.symbolic`

- **Source path:** `src/x86decomp/symbolic.py`
- **SHA-256:** `44313e4a9c3ba6fe819da4bad51d85ac75cc08357dcbe9d0678f8b8792ab3d68`
- **Module docstring:** Bounded symbolic equivalence for small pure x86/x86-64 leaf functions.
- **AST symbols:** 27

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_deps` | function | 18 | Support deps processing for internal toolkit callers. |
| `UnsupportedSymbolicInstruction` | class | 31 | Coordinate unsupported symbolic instruction behavior for the current toolkit workflow. |
| `SymState` | class | 37 | Store validated sym state fields used by toolkit reports and adapters. |
| `clone` | function | 46 | Execute the clone operation for the current toolkit workflow. |
| `Outcome` | class | 59 | Store validated outcome fields used by toolkit reports and adapters. |
| `_aliases` | function | 93 | Support aliases processing for internal toolkit callers. |
| `_read_reg` | function | 98 | Support read reg processing for internal toolkit callers. |
| `_write_reg` | function | 111 | Support write reg processing for internal toolkit callers. |
| `_concrete` | function | 133 | Support concrete processing for internal toolkit callers. |
| `_memory_address` | function | 139 | Support memory address processing for internal toolkit callers. |
| `_read_memory` | function | 159 | Support read memory processing for internal toolkit callers. |
| `_write_memory` | function | 171 | Support write memory processing for internal toolkit callers. |
| `_read_operand` | function | 183 | Support read operand processing for internal toolkit callers. |
| `_write_operand` | function | 196 | Support write operand processing for internal toolkit callers. |
| `_coerce_pair` | function | 209 | Support coerce pair processing for internal toolkit callers. |
| `_set_logic_flags` | function | 219 | Support set logic flags processing for internal toolkit callers. |
| `_set_add_flags` | function | 227 | Support set add flags processing for internal toolkit callers. |
| `_set_sub_flags` | function | 240 | Support set sub flags processing for internal toolkit callers. |
| `_condition` | function | 253 | Support condition processing for internal toolkit callers. |
| `_condition_for_family` | function | 273 | Resolve Jcc, SETcc, and CMOVcc names through the same flag model. |
| `_set_adc_flags` | function | 297 | Support set adc flags processing for internal toolkit callers. |
| `_set_sbb_flags` | function | 314 | Support set sbb flags processing for internal toolkit callers. |
| `_is_sat` | function | 330 | Support is sat processing for internal toolkit callers. |
| `symbolic_execute` | function | 337 | Execute the symbolic execute operation for the current toolkit workflow. |
| `_constraint_formula` | function | 624 | Support constraint formula processing for internal toolkit callers. |
| `bounded_symbolic_compare` | function | 629 | Execute the bounded symbolic compare operation for the current toolkit workflow. |
| `bounded_symbolic_compare_files` | function | 709 | Execute the bounded symbolic compare files operation for the current toolkit workflow. |
