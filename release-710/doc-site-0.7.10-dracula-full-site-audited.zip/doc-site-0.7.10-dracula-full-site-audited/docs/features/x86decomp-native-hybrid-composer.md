---
title: x86decomp.native.hybrid_composer
description: Source-derived module page for x86decomp.native.hybrid_composer in x86decomp
  0.7.10.
---

# `x86decomp.native.hybrid_composer`

- **Source path:** `src/x86decomp/native/hybrid_composer.py`
- **SHA-256:** `07650208ea10d64e9a2dd98312b14b6dd54cca2064effa3693e2e0d00ee71ff7`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.hybrid_composer` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `HybridComposer` | class | 14 | Coordinate hybrid composer behavior for the current toolkit workflow. |
| `__init__` | function | 16 | Initialize the instance with validated constructor state. |
| `compose` | function | 20 | Execute the compose operation for the current toolkit workflow. |
| `verify` | function | 59 | Verify verify for the current toolkit workflow. |
