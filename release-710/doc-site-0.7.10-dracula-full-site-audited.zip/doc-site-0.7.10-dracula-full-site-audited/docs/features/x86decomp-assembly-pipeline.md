---
title: x86decomp.assembly.pipeline
description: Source-derived module page for x86decomp.assembly.pipeline in x86decomp
  0.7.10.
---

# `x86decomp.assembly.pipeline`

- **Source path:** `src/x86decomp/assembly/pipeline.py`
- **SHA-256:** `f9c39a196061a060c62f27790683038c4ab4bf02828656f0bb34f6a4c3274e56`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.assembly.pipeline` module.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_load_json` | function | 26 | Support load json processing for internal toolkit callers. |
| `_resolve_path` | function | 34 | Support resolve path processing for internal toolkit callers. |
| `_function_bytes` | function | 40 | Support function bytes processing for internal toolkit callers. |
| `_symbol_map` | function | 60 | Support symbol map processing for internal toolkit callers. |
| `AssemblyPipeline` | class | 84 | Coordinate assembly pipeline behavior for the current toolkit workflow. |
| `__init__` | function | 86 | Initialize the instance with validated constructor state. |
| `batch` | function | 91 | Execute the batch operation for the current toolkit workflow. |
| `report` | function | 319 | Execute the report operation for the current toolkit workflow. |
| `list_runs` | function | 336 | Execute the list runs operation for the current toolkit workflow. |
