---
title: x86decomp.errors
description: Source-derived module page for x86decomp.errors in x86decomp 0.7.10.
---

# `x86decomp.errors`

- **Source path:** `src/x86decomp/errors.py`
- **SHA-256:** `5bb50a4d169960abdc486866d2e68c894d8c13da401361931d86991ff9f8030d`
- **Module docstring:** Typed errors used by the toolkit.
- **AST symbols:** 5

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `X86DecompError` | class | 4 | Base class for user-facing toolkit errors. |
| `FormatError` | class | 8 | Raised when an input binary or document violates its contract. |
| `ContractError` | class | 12 | Raised when structured data violates a toolkit contract. |
| `VerificationError` | class | 16 | Raised when integrity or evidence verification fails. |
| `ExternalToolError` | class | 20 | Raised when a configured external tool cannot be executed successfully. |
