---
title: x86decomp.governance.hypotheses
description: Source-derived module page for x86decomp.governance.hypotheses in x86decomp
  0.7.10.
---

# `x86decomp.governance.hypotheses`

- **Source path:** `src/x86decomp/governance/hypotheses.py`
- **SHA-256:** `8fe031d32f8bad8b396772ae5ae48ee101e0069a767e6fefab8790ff6a5fce95`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.hypotheses` module.
- **AST symbols:** 14

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `Hypothesis` | class | 38 | Store validated hypothesis fields used by toolkit reports and adapters. |
| `_row_to_hypothesis` | function | 53 | Support row to hypothesis processing for internal toolkit callers. |
| `HypothesisLedger` | class | 70 | Coordinate hypothesis ledger behavior for the current toolkit workflow. |
| `__init__` | function | 72 | Initialize the instance with validated constructor state. |
| `create` | function | 77 | Create create for the current toolkit workflow. |
| `get` | function | 100 | Execute the get operation for the current toolkit workflow. |
| `list` | function | 108 | Execute the list operation for the current toolkit workflow. |
| `add_dependency` | function | 125 | Execute the add dependency operation for the current toolkit workflow. |
| `_has_dependency_cycle` | function | 137 | Support has dependency cycle processing for internal toolkit callers. |
| `attach_evidence` | function | 149 | Execute the attach evidence operation for the current toolkit workflow. |
| `_recalculate_confidence` | function | 180 | Support recalculate confidence processing for internal toolkit callers. |
| `transition` | function | 198 | Execute the transition operation for the current toolkit workflow. |
| `acceptance_gate` | function | 221 | Execute the acceptance gate operation for the current toolkit workflow. |
| `describe` | function | 255 | Execute the describe operation for the current toolkit workflow. |
