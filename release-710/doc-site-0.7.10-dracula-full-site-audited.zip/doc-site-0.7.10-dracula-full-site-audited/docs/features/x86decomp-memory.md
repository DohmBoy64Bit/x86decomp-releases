---
title: x86decomp.memory
description: Source-derived module page for x86decomp.memory in x86decomp 0.7.10.
---

# `x86decomp.memory`

- **Source path:** `src/x86decomp/memory.py`
- **SHA-256:** `127b52aab344329016f75bf176937087932be5d9ab611c8f8badfb6d5b8e27e2`
- **Module docstring:** Append-only, hash-chained project memory.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ProjectMemory` | class | 14 | Coordinate project memory behavior for the current toolkit workflow. |
| `__init__` | function | 16 | Initialize the instance with validated constructor state. |
| `read_events` | function | 26 | Read events for the current toolkit workflow. |
| `append` | function | 44 | Append append for the current toolkit workflow. |
| `verify` | function | 77 | Verify verify for the current toolkit workflow. |
| `require_valid` | function | 96 | Execute the require valid operation for the current toolkit workflow. |
| `render` | function | 102 | Render render for the current toolkit workflow. |
