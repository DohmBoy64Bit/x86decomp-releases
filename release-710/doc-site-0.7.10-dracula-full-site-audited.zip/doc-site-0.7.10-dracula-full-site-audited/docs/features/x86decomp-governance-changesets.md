---
title: x86decomp.governance.changesets
description: Source-derived module page for x86decomp.governance.changesets in x86decomp
  0.7.10.
---

# `x86decomp.governance.changesets`

- **Source path:** `src/x86decomp/governance/changesets.py`
- **SHA-256:** `1294e380f06937649500476ca9c3d41aad674dd71174cc65d2242fda7f8138ef`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.changesets` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ChangeSet` | class | 14 | Portable, append-only governance audit changesets with base-tip conflict checks. |
| `export` | function | 18 | Execute the export operation for the current toolkit workflow. |
| `inspect` | function | 44 | Execute the inspect operation for the current toolkit workflow. |
| `apply` | function | 71 | Execute the apply operation for the current toolkit workflow. |
