---
title: x86decomp.assembly.__init__
description: Source-derived module page for x86decomp.assembly.__init__ in x86decomp
  0.7.10.
---

# `x86decomp.assembly.__init__`

- **Source path:** `src/x86decomp/assembly/__init__.py`
- **SHA-256:** `60dcbf406ebd10f56f155b70ea0657b0d40a2405ef65cf3caa32979fd90ca254`
- **Module docstring:** Relocation-aware assembly materialization capabilities.
- **AST symbols:** 0

No classes or functions were declared in this module.
