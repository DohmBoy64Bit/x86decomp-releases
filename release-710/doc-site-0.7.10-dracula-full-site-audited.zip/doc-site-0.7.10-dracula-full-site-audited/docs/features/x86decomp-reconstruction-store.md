---
title: x86decomp.reconstruction.store
description: Source-derived module page for x86decomp.reconstruction.store in x86decomp
  0.7.10.
---

# `x86decomp.reconstruction.store`

- **Source path:** `src/x86decomp/reconstruction/store.py`
- **SHA-256:** `331d651d8256dca4d586affe3eef5f6f91d3a08baab4e8f079ca75b624532bb1`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.store` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ReconstructionStore` | class | 141 | Project-scale schema layered on the governance store. |
| `initialize` | function | 144 | Initialize initialize for the current toolkit workflow. |
| `check` | function | 155 | Check check for the current toolkit workflow. |
| `decode` | function | 173 | Decode configured JSON columns from a SQLite row. |
