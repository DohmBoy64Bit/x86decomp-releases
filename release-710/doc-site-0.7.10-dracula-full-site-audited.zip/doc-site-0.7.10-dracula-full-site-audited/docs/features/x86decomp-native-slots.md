---
title: x86decomp.native.slots
description: Source-derived module page for x86decomp.native.slots in x86decomp 0.7.10.
---

# `x86decomp.native.slots`

- **Source path:** `src/x86decomp/native/slots.py`
- **SHA-256:** `a4d751d6b0adc193cb36b4847e2d8e5ce242e62b56677c0eb03b72ffd7544582`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.slots` module.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_int` | function | 13 | Support int processing for internal toolkit callers. |
| `inventory_from_project` | function | 25 | Execute the inventory from project operation for the current toolkit workflow. |
| `FunctionSlots` | class | 49 | Coordinate function slots behavior for the current toolkit workflow. |
| `__init__` | function | 51 | Initialize the instance with validated constructor state. |
| `audit` | function | 56 | Audit audit for the current toolkit workflow. |
| `audit_project` | function | 129 | Audit project for the current toolkit workflow. |
| `list` | function | 141 | Execute the list operation for the current toolkit workflow. |
| `show` | function | 151 | Execute the show operation for the current toolkit workflow. |
| `export_fixes` | function | 162 | Execute the export fixes operation for the current toolkit workflow. |
