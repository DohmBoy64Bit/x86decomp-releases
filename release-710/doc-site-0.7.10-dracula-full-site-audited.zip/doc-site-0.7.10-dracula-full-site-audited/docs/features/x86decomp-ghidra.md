---
title: x86decomp.ghidra
description: Source-derived module page for x86decomp.ghidra in x86decomp 0.7.10.
---

# `x86decomp.ghidra`

- **Source path:** `src/x86decomp/ghidra.py`
- **SHA-256:** `a4b9ba54d680ccc858a4dbee991eb2462f2e003a49b28224588e2d4eea615474`
- **Module docstring:** Safe command construction for Ghidra headless analysis.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `build_export_command` | function | 14 | Build export command for the current toolkit workflow. |
| `run_export` | function | 65 | Run export for the current toolkit workflow. |
