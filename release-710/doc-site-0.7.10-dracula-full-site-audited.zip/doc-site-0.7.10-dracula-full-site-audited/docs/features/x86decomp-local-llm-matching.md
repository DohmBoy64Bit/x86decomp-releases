---
title: x86decomp.local_llm.matching
description: Source-derived module page for x86decomp.local_llm.matching in x86decomp
  0.7.10.
---

# `x86decomp.local_llm.matching`

- **Source path:** `src/x86decomp/local_llm/matching.py`
- **SHA-256:** `9b392884b6a186206dd50705b4099157c8073aa77512c5b144a1a358991e8d66`
- **Module docstring:** Local-model C generation and deterministic byte-match verification loop.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_parse_candidate` | function | 35 | Support parse candidate processing for internal toolkit callers. |
| `_prepare_output` | function | 91 | Support prepare output processing for internal toolkit callers. |
| `_feedback_from_compile` | function | 105 | Support feedback from compile processing for internal toolkit callers. |
| `_feedback_from_diff` | function | 116 | Support feedback from diff processing for internal toolkit callers. |
| `generate_candidate` | function | 130 | Generate and validate one uncompiled C proposal. |
| `run_match_loop` | function | 174 | Run bounded local generation, compilation, relocation, and exact comparison. |
| `verify_match_report` | function | 366 | Verify report invariants and every referenced accepted artifact hash. |
