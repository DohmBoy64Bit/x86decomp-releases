---
title: x86decomp.local_llm.prompts
description: Source-derived module page for x86decomp.local_llm.prompts in x86decomp
  0.7.10.
---

# `x86decomp.local_llm.prompts`

- **Source path:** `src/x86decomp/local_llm/prompts.py`
- **SHA-256:** `03aa0e774538d41645426c911742ae8f710df75b7f1b126493428c166a347918`
- **Module docstring:** Deterministic, injection-resistant prompts for C candidate generation.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_text` | function | 15 | Support text processing for internal toolkit callers. |
| `_integer` | function | 31 | Support integer processing for internal toolkit callers. |
| `_resolve_job_path` | function | 38 | Support resolve job path processing for internal toolkit callers. |
| `load_job` | function | 49 | Load and normalize a local-LLM generation/matching job. |
| `_evidence_block` | function | 131 | Support evidence block processing for internal toolkit callers. |
| `build_messages` | function | 146 | Build a deterministic two-message prompt with explicit trust boundaries. |
| `prompt_record` | function | 193 | Execute the prompt record operation for the current toolkit workflow. |
