---
title: x86decomp_testkit.toolkit_tests.test_public_api_contract
description: Source-derived module page for x86decomp_testkit.toolkit_tests.test_public_api_contract
  in x86decomp 0.7.10.
---

# `x86decomp_testkit.toolkit_tests.test_public_api_contract`

- **Source path:** `test-suite/src/x86decomp_testkit/toolkit_tests/test_public_api_contract.py`
- **SHA-256:** `97af1e6252a3511d32a1814c003477845757298f111fa5787d879fee4d3e96db`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.toolkit_tests.test_public_api_contract` module.
- **AST symbols:** 32

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_unified_canonical_entry_point` | function | 75 | Verify unified canonical entry point behavior. |
| `test_abi_contract_loading` | function | 89 | Verify abi contract loading behavior. |
| `test_analysis_database_complete_public_surface` | function | 109 | Verify analysis database complete public surface behavior. |
| `test_angr_public_file_wrappers` | function | 138 | Verify angr wrappers or their explicit optional-dependency error path. |
| `test_benchmark_metrics_and_runner` | function | 165 | Verify benchmark metrics and runner behavior. |
| `test_coff_remaining_value_objects_and_writer` | function | 181 | Verify coff remaining value objects and writer behavior. |
| `test_compiler_lab_with_deterministic_fake_compiler` | function | 200 | Verify compiler lab with deterministic fake compiler behavior. |
| `test_diff_disassembly_and_crosscheck` | function | 236 | Verify diff disassembly and crosscheck behavior. |
| `test_dynamic_file_wrapper_and_spec_loader` | function | 257 | Verify dynamic file wrapper and spec loader behavior. |
| `test_dynamorio_runner_with_fake_subprocess` | function | 281 | Verify dynamorio runner with fake subprocess behavior. |
| `fake_run` | function | 289 | Execute the fake run operation for the current toolkit workflow. |
| `_verified_store` | function | 306 | Support verified store processing for internal toolkit callers. |
| `test_evidence_contradiction_require_verified_and_project_memory` | function | 320 | Verify evidence contradiction require verified and project memory behavior. |
| `test_exe_diff_extract_and_compare` | function | 332 | Verify exe diff extract and compare behavior. |
| `test_ghidra_run_export_success` | function | 344 | Verify ghidra run export success behavior. |
| `test_remaining_value_objects_and_peview` | function | 353 | Verify remaining value objects and peview behavior. |
| `test_service_create_and_run` | function | 371 | Verify service create and run behavior. |
| `test_symbolic_clone_and_file_wrapper` | function | 383 | Verify symbolic clone behavior and the optional symbolic backend error path. |
| `test_toolchain_snapshot_util_contract_and_workqueue` | function | 407 | Verify toolchain snapshot util contract and workqueue behavior. |
| `test_cli_main_executes_public_entrypoint` | function | 430 | Verify cli main executes public entrypoint behavior. |
| `test_streamable_http_mcp_public_methods` | function | 440 | Verify streamable http mcp public methods behavior. |
| `Headers` | class | 444 | Coordinate headers behavior for the current toolkit workflow. |
| `get` | function | 446 | Execute the get operation for the current toolkit workflow. |
| `get_content_type` | function | 450 | Execute the get content type operation for the current toolkit workflow. |
| `Response` | class | 454 | Coordinate response behavior for the current toolkit workflow. |
| `__init__` | function | 458 | Initialize the instance with validated constructor state. |
| `__enter__` | function | 462 | Enter the managed runtime context and return the active resource. |
| `__exit__` | function | 466 | Exit the managed runtime context and release owned resources. |
| `read` | function | 470 | Read read for the current toolkit workflow. |
| `fake_urlopen` | function | 474 | Execute the fake urlopen operation for the current toolkit workflow. |
| `test_private_function_surface_regression` | function | 496 | Exercise the remaining internal function bodies so no defined function is omitted. |
| `test_remaining_current_function_surface` | function | 540 | Verify remaining current function surface behavior. |
