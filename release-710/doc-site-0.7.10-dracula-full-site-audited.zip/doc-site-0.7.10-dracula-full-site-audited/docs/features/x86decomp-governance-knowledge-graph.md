---
title: x86decomp.governance.knowledge_graph
description: Source-derived module page for x86decomp.governance.knowledge_graph in
  x86decomp 0.7.10.
---

# `x86decomp.governance.knowledge_graph`

- **Source path:** `src/x86decomp/governance/knowledge_graph.py`
- **SHA-256:** `ff8866a5a5059e20895b85954cbe6a51a619d1887ea7c66f94cccb4b62ccf204`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.knowledge_graph` module.
- **AST symbols:** 6

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `KnowledgeGraph` | class | 12 | Coordinate knowledge graph behavior for the current toolkit workflow. |
| `__init__` | function | 14 | Initialize the instance with validated constructor state. |
| `upsert_node` | function | 19 | Execute the upsert node operation for the current toolkit workflow. |
| `add_edge` | function | 34 | Execute the add edge operation for the current toolkit workflow. |
| `get_node` | function | 55 | Execute the get node operation for the current toolkit workflow. |
| `impact` | function | 65 | Execute the impact operation for the current toolkit workflow. |
