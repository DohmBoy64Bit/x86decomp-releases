---
title: x86decomp_testkit.self_tests.test_adapter_detection_resolution
description: Source-derived module page for x86decomp_testkit.self_tests.test_adapter_detection_resolution
  in x86decomp 0.7.10.
---

# `x86decomp_testkit.self_tests.test_adapter_detection_resolution`

- **Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py`
- **SHA-256:** `f5088b0b7ffcea762bf15990d087f76b782ae7d2ad88316aa0f532e5620c5cd3`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.self_tests.test_adapter_detection_resolution` module.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_config` | function | 15 | Support config processing for internal toolkit callers. |
| `test_installed_adapter_never_prompts` | function | 22 | Verify installed adapter never prompts behavior. |
| `prompt` | function | 28 | Execute the prompt operation for the current toolkit workflow. |
| `test_missing_adapter_prompts_custom_path_then_accepts` | function | 38 | Verify missing adapter prompts custom path then accepts behavior. |
| `prompt` | function | 48 | Execute the prompt operation for the current toolkit workflow. |
| `test_missing_noninteractive_is_explicit_unresolved` | function | 60 | Verify missing noninteractive is explicit unresolved behavior. |
| `test_environment_and_configured_root_detection` | function | 69 | Verify environment and configured root detection behavior. |
| `test_path_detection_preserves_symlink_argv0` | function | 87 | Verify that adapter detection keeps a symlinked argv0 path when supported. |
| `test_missing_python_adapter_accepts_custom_interpreter` | function | 105 | Verify missing python adapter accepts custom interpreter behavior. |
