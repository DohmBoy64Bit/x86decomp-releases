---
title: x86decomp.reproducibility
description: Source-derived module page for x86decomp.reproducibility in x86decomp
  0.7.10.
---

# `x86decomp.reproducibility`

- **Source path:** `src/x86decomp/reproducibility.py`
- **SHA-256:** `42890412018863aa16c5913570286c5bb71ef865e55a1b8f6de59e4618cab6ed`
- **Module docstring:** Reproducibility manifests and verification.
- **AST symbols:** 3

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_version` | function | 24 | Support version processing for internal toolkit callers. |
| `build_reproduction_manifest` | function | 51 | Build reproduction manifest for the current toolkit workflow. |
| `verify_reproduction_manifest` | function | 120 | Verify reproduction manifest for the current toolkit workflow. |
