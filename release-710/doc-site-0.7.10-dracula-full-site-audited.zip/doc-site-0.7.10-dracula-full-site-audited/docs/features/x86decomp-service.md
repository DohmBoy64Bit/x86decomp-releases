---
title: x86decomp.service
description: Source-derived module page for x86decomp.service in x86decomp 0.7.10.
---

# `x86decomp.service`

- **Source path:** `src/x86decomp/service.py`
- **SHA-256:** `07d1d2b97b4b34432e3a60023f1cc5769e62927bb67e118384b361b23fa402e4`
- **Module docstring:** Optional read-only FastAPI service for project, pipeline, and validation state.
- **AST symbols:** 16

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_json_files` | function | 24 | Support json files processing for internal toolkit callers. |
| `service_snapshot` | function | 39 | Return a read-only, serializable project-control-plane snapshot. |
| `create_app` | function | 78 | Create app for the current toolkit workflow. |
| `health` | function | 89 | Execute the health operation for the current toolkit workflow. |
| `project` | function | 100 | Execute the project operation for the current toolkit workflow. |
| `target_pack` | function | 105 | Execute the target pack operation for the current toolkit workflow. |
| `pipelines` | function | 117 | Execute the pipelines operation for the current toolkit workflow. |
| `convergence` | function | 122 | Execute the convergence operation for the current toolkit workflow. |
| `reproducibility` | function | 127 | Execute the reproducibility operation for the current toolkit workflow. |
| `security` | function | 132 | Execute the security operation for the current toolkit workflow. |
| `functions` | function | 137 | Execute the functions operation for the current toolkit workflow. |
| `workflow` | function | 151 | Execute the workflow operation for the current toolkit workflow. |
| `next_task` | function | 160 | Execute the next task operation for the current toolkit workflow. |
| `reports` | function | 169 | Execute the reports operation for the current toolkit workflow. |
| `index` | function | 174 | Return the read-only browser UI without injecting project data as HTML. |
| `run_service` | function | 200 | Run service for the current toolkit workflow. |
