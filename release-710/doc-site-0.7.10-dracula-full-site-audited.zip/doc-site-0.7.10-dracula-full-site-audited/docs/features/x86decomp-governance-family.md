---
title: x86decomp.governance.family
description: Source-derived module page for x86decomp.governance.family in x86decomp
  0.7.10.
---

# `x86decomp.governance.family`

- **Source path:** `src/x86decomp/governance/family.py`
- **SHA-256:** `e0c94c0fe9db646c135dc0fd949ba5627dda30978465c5e83da85e2afb83379b`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.family` module.
- **AST symbols:** 10

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `BinaryFamilyStore` | class | 12 | Static, content-addressed related-binary correlation. |
| `__init__` | function | 15 | Initialize the instance with validated constructor state. |
| `create` | function | 21 | Create create for the current toolkit workflow. |
| `add` | function | 31 | Execute the add operation for the current toolkit workflow. |
| `_block_fingerprints` | function | 54 | Support block fingerprints processing for internal toolkit callers. |
| `correlate` | function | 60 | Execute the correlate operation for the current toolkit workflow. |
| `get` | function | 83 | Execute the get operation for the current toolkit workflow. |
| `member` | function | 91 | Execute the member operation for the current toolkit workflow. |
| `correlation` | function | 101 | Execute the correlation operation for the current toolkit workflow. |
| `report` | function | 111 | Execute the report operation for the current toolkit workflow. |
