---
title: x86decomp.cpp_recovery
description: Source-derived module page for x86decomp.cpp_recovery in x86decomp 0.7.10.
---

# `x86decomp.cpp_recovery`

- **Source path:** `src/x86decomp/cpp_recovery.py`
- **SHA-256:** `354295c6c6a16f6b8296760d153c824945f8f46bb035e843805d0979c5a55a3e`
- **Module docstring:** Bounded C++ relationship recovery from MSVC metadata and code patterns.
- **AST symbols:** 3

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_function_prefix` | function | 18 | Support function prefix processing for internal toolkit callers. |
| `_adjustor_thunk_candidate` | function | 28 | Support adjustor thunk candidate processing for internal toolkit callers. |
| `recover_cpp_model` | function | 56 | Execute the recover cpp model operation for the current toolkit workflow. |
