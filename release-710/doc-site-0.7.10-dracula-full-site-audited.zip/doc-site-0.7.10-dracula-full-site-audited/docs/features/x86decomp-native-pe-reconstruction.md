---
title: x86decomp.native.pe_reconstruction
description: Source-derived module page for x86decomp.native.pe_reconstruction in
  x86decomp 0.7.10.
---

# `x86decomp.native.pe_reconstruction`

- **Source path:** `src/x86decomp/native/pe_reconstruction.py`
- **SHA-256:** `bbea10165b3b1aed6e6a3a9aa2776296480c729f8a6002471467d4791c71e200`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.pe_reconstruction` module.
- **AST symbols:** 11

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_section_header_records` | function | 19 | Support section header records processing for internal toolkit callers. |
| `plan_patch` | function | 39 | Execute the plan patch operation for the current toolkit workflow. |
| `apply_operations` | function | 57 | Execute the apply operations operation for the current toolkit workflow. |
| `PEReconstruction` | class | 68 | Coordinate p e reconstruction behavior for the current toolkit workflow. |
| `__init__` | function | 70 | Initialize the instance with validated constructor state. |
| `inventory` | function | 74 | Execute the inventory operation for the current toolkit workflow. |
| `export_sections` | function | 79 | Execute the export sections operation for the current toolkit workflow. |
| `export_coff` | function | 94 | Execute the export coff operation for the current toolkit workflow. |
| `create_plan` | function | 108 | Create plan for the current toolkit workflow. |
| `apply_plan` | function | 116 | Execute the apply plan operation for the current toolkit workflow. |
| `text_swap` | function | 128 | Execute the text swap operation for the current toolkit workflow. |
