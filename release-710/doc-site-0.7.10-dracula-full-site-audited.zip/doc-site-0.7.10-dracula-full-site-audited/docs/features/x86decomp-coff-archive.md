---
title: x86decomp.coff_archive
description: Source-derived module page for x86decomp.coff_archive in x86decomp 0.7.10.
---

# `x86decomp.coff_archive`

- **Source path:** `src/x86decomp/coff_archive.py`
- **SHA-256:** `334fc0ec09fc70cb1ec34654cd73ae4e5ba14650fb6afef97791f9cf088459d1`
- **Module docstring:** Bounded Microsoft/Unix COFF archive (``.lib``/``.a``) inspection.
- **AST symbols:** 13

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ArchiveMember` | class | 27 | Store validated archive member fields used by toolkit reports and adapters. |
| `to_dict` | function | 43 | Return a serializable dictionary representation. |
| `CoffArchive` | class | 66 | Store validated coff archive fields used by toolkit reports and adapters. |
| `to_dict` | function | 73 | Return a serializable dictionary representation. |
| `_decimal` | function | 86 | Support decimal processing for internal toolkit callers. |
| `_octal` | function | 97 | Support octal processing for internal toolkit callers. |
| `_long_name` | function | 108 | Support long name processing for internal toolkit callers. |
| `_parse_import_object` | function | 117 | Support parse import object processing for internal toolkit callers. |
| `_cstring_sequence` | function | 155 | Support cstring sequence processing for internal toolkit callers. |
| `_first_linker_symbols` | function | 170 | Support first linker symbols processing for internal toolkit callers. |
| `_second_linker_symbols` | function | 185 | Support second linker symbols processing for internal toolkit callers. |
| `parse_coff_archive_bytes` | function | 213 | Parse coff archive bytes for the current toolkit workflow. |
| `parse_coff_archive` | function | 326 | Parse coff archive for the current toolkit workflow. |
