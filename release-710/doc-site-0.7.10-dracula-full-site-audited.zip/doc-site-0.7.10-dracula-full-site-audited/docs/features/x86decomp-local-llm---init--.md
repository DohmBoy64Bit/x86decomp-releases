---
title: x86decomp.local_llm.__init__
description: Source-derived module page for x86decomp.local_llm.__init__ in x86decomp
  0.7.10.
---

# `x86decomp.local_llm.__init__`

- **Source path:** `src/x86decomp/local_llm/__init__.py`
- **SHA-256:** `471640b8f53e194e4f5f246699cfdabbfc5ba1ff818bed6d060e8348eaf09d25`
- **Module docstring:** Bounded local-model proposal and exact byte-match integration.
- **AST symbols:** 0

No classes or functions were declared in this module.
