---
title: x86decomp.msvc_metadata
description: Source-derived module page for x86decomp.msvc_metadata in x86decomp 0.7.10.
---

# `x86decomp.msvc_metadata`

- **Source path:** `src/x86decomp/msvc_metadata.py`
- **SHA-256:** `00acf48e912266dd7142f7b98ad81f218bfed88f8e5276b1bd80037afb681a12`
- **Module docstring:** Microsoft C++ metadata, unwind, TLS, and initializer recovery.
- **AST symbols:** 41

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `TypeDescriptorRecord` | class | 27 | Store validated type descriptor record fields used by toolkit reports and adapters. |
| `to_dict` | function | 36 | Return a serializable dictionary representation. |
| `BaseClassRecord` | class | 49 | Store validated base class record fields used by toolkit reports and adapters. |
| `to_dict` | function | 61 | Return a serializable dictionary representation. |
| `CompleteObjectLocatorRecord` | class | 79 | Store validated complete object locator record fields used by toolkit reports and adapters. |
| `to_dict` | function | 92 | Return a serializable dictionary representation. |
| `VTableRecord` | class | 109 | Store validated v table record fields used by toolkit reports and adapters. |
| `to_dict` | function | 116 | Return a serializable dictionary representation. |
| `UnwindCodeRecord` | class | 127 | Store validated unwind code record fields used by toolkit reports and adapters. |
| `to_dict` | function | 136 | Return a serializable dictionary representation. |
| `UnwindInfoRecord` | class | 149 | Store validated unwind info record fields used by toolkit reports and adapters. |
| `to_dict` | function | 165 | Return a serializable dictionary representation. |
| `PEView` | class | 184 | Coordinate p e view behavior for the current toolkit workflow. |
| `__init__` | function | 186 | Initialize the instance with validated constructor state. |
| `rva_to_offset` | function | 194 | Execute the rva to offset operation for the current toolkit workflow. |
| `valid_rva` | function | 198 | Execute the valid rva operation for the current toolkit workflow. |
| `read` | function | 206 | Read read for the current toolkit workflow. |
| `u16` | function | 213 | Execute the u16 operation for the current toolkit workflow. |
| `u32` | function | 217 | Execute the u32 operation for the current toolkit workflow. |
| `i32` | function | 221 | Execute the i32 operation for the current toolkit workflow. |
| `u64` | function | 225 | Execute the u64 operation for the current toolkit workflow. |
| `pointer` | function | 229 | Execute the pointer operation for the current toolkit workflow. |
| `va_to_rva` | function | 233 | Execute the va to rva operation for the current toolkit workflow. |
| `encoded_pointer_to_rva` | function | 240 | Encode d pointer to rva for the current toolkit workflow. |
| `c_string` | function | 246 | Execute the c string operation for the current toolkit workflow. |
| `executable_rva` | function | 254 | Execute the executable rva operation for the current toolkit workflow. |
| `readonly_data_sections` | function | 262 | Read only data sections for the current toolkit workflow. |
| `_display_type_name` | function | 273 | Support display type name processing for internal toolkit callers. |
| `scan_type_descriptors` | function | 283 | Execute the scan type descriptors operation for the current toolkit workflow. |
| `_parse_base_class` | function | 317 | Support parse base class processing for internal toolkit callers. |
| `_parse_hierarchy` | function | 353 | Support parse hierarchy processing for internal toolkit callers. |
| `scan_complete_object_locators` | function | 383 | Execute the scan complete object locators operation for the current toolkit workflow. |
| `scan_vtables` | function | 429 | Execute the scan vtables operation for the current toolkit workflow. |
| `_decode_unwind_codes` | function | 483 | Support decode unwind codes processing for internal toolkit callers. |
| `parse_x64_unwind` | function | 542 | Parse x64 unwind for the current toolkit workflow. |
| `parse_safe_seh` | function | 599 | Parse safe seh for the current toolkit workflow. |
| `tls_report` | function | 613 | Execute the tls report operation for the current toolkit workflow. |
| `scan_exception_func_info` | function | 639 | Find structurally plausible MSVC EH3 FuncInfo records. |
| `scan_coff_tls` | function | 693 | Inventory COFF TLS template and callback subsections. |
| `scan_static_initializers` | function | 732 | Execute the scan static initializers operation for the current toolkit workflow. |
| `analyze_msvc_metadata` | function | 786 | Execute the analyze msvc metadata operation for the current toolkit workflow. |
