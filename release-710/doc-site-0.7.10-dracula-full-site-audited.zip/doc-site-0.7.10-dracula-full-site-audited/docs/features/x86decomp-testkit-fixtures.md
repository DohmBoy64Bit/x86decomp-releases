---
title: x86decomp_testkit.fixtures
description: Source-derived module page for x86decomp_testkit.fixtures in x86decomp
  0.7.10.
---

# `x86decomp_testkit.fixtures`

- **Source path:** `test-suite/src/x86decomp_testkit/fixtures.py`
- **SHA-256:** `562e5bfa76c730cc96a2ace5aa92efdbc5514cd797aef4c212554730a70946df`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.fixtures` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `write_json` | function | 10 | Write json for the current toolkit workflow. |
| `build_minimal_pe32` | function | 17 | Build minimal pe32 for the current toolkit workflow. |
| `build_minimal_pe64` | function | 51 | Build minimal pe64 for the current toolkit workflow. |
| `create_common_fixtures` | function | 86 | Create common fixtures for the current toolkit workflow. |
