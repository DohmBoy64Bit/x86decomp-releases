---
title: x86decomp.worker
description: Source-derived module page for x86decomp.worker in x86decomp 0.7.10.
---

# `x86decomp.worker`

- **Source path:** `src/x86decomp/worker.py`
- **SHA-256:** `4ecd317bb9013edb1d0c1b79037ed139d0e240da60703e0b21198b5b131ffe33`
- **Module docstring:** Bounded command workers with explicit isolation and provenance.
- **AST symbols:** 13

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `WorkerLimits` | class | 27 | Store validated worker limits fields used by toolkit reports and adapters. |
| `validate` | function | 35 | Validate validate for the current toolkit workflow. |
| `WorkerRequest` | class | 43 | Store validated worker request fields used by toolkit reports and adapters. |
| `WorkerResult` | class | 56 | Store validated worker result fields used by toolkit reports and adapters. |
| `to_dict` | function | 73 | Return a serializable dictionary representation. |
| `discover_worker_capabilities` | function | 94 | Discover worker capabilities for the current toolkit workflow. |
| `_bounded_environment` | function | 109 | Support bounded environment processing for internal toolkit callers. |
| `_preexec` | function | 145 | Return the legacy resource-limit callback for API compatibility. |
| `apply` | function | 156 | Execute the apply operation for the current toolkit workflow. |
| `_confined_paths` | function | 172 | Support confined paths processing for internal toolkit callers. |
| `_container_command` | function | 189 | Support container command processing for internal toolkit callers. |
| `execute_worker_request` | function | 215 | Execute the execute worker request operation for the current toolkit workflow. |
| `resource_wrapped_command` | function | 253 | Execute the resource wrapped command operation for the current toolkit workflow. |
