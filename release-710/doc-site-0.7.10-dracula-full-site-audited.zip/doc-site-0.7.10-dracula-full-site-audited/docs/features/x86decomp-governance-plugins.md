---
title: x86decomp.governance.plugins
description: Source-derived module page for x86decomp.governance.plugins in x86decomp
  0.7.10.
---

# `x86decomp.governance.plugins`

- **Source path:** `src/x86decomp/governance/plugins.py`
- **SHA-256:** `42547b4341e529b6ba203aba18556b6bb0965e56fbcc43d7160a11675e290c9a`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.plugins` module.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `PluginRegistry` | class | 17 | Coordinate plugin registry behavior for the current toolkit workflow. |
| `__init__` | function | 19 | Initialize the instance with validated constructor state. |
| `validate_manifest` | function | 25 | Validate manifest for the current toolkit workflow. |
| `install` | function | 39 | Execute the install operation for the current toolkit workflow. |
| `get` | function | 57 | Execute the get operation for the current toolkit workflow. |
| `list` | function | 68 | Execute the list operation for the current toolkit workflow. |
| `doctor` | function | 74 | Execute the doctor operation for the current toolkit workflow. |
| `invoke` | function | 85 | Execute the invoke operation for the current toolkit workflow. |
