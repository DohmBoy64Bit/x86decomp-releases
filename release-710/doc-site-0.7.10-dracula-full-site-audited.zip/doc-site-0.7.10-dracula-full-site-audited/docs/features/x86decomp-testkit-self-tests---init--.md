---
title: x86decomp_testkit.self_tests.__init__
description: Source-derived module page for x86decomp_testkit.self_tests.__init__
  in x86decomp 0.7.10.
---

# `x86decomp_testkit.self_tests.__init__`

- **Source path:** `test-suite/src/x86decomp_testkit/self_tests/__init__.py`
- **SHA-256:** `2fdabb54d9fb50db6ec807fffbfad75f6fb167b169a02c667b49d9097540e3a0`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.self_tests` module.
- **AST symbols:** 0

No classes or functions were declared in this module.
