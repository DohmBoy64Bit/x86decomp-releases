---
title: x86decomp_testkit.live_adapters
description: Source-derived module page for x86decomp_testkit.live_adapters in x86decomp
  0.7.10.
---

# `x86decomp_testkit.live_adapters`

- **Source path:** `test-suite/src/x86decomp_testkit/live_adapters.py`
- **SHA-256:** `6516fd582f68338dbdb455c5d910c74055db3d17dd96b55d08841cf111f57d63`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.live_adapters` module.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_path_for` | function | 20 | Support path for processing for internal toolkit callers. |
| `_python_adapter_test` | function | 48 | Support python adapter test processing for internal toolkit callers. |
| `_generic_executable_test` | function | 75 | Support generic executable test processing for internal toolkit callers. |
| `_compiler_test` | function | 100 | Support compiler test processing for internal toolkit callers. |
| `_lld_link_test` | function | 133 | Support lld link test processing for internal toolkit callers. |
| `_ghidra_test` | function | 171 | Support ghidra test processing for internal toolkit callers. |
| `_dynamorio_test` | function | 206 | Support dynamorio test processing for internal toolkit callers. |
| `_objdiff_test` | function | 235 | Support objdiff test processing for internal toolkit callers. |
| `run_live_adapter_tests` | function | 259 | Run live adapter tests for the current toolkit workflow. |
