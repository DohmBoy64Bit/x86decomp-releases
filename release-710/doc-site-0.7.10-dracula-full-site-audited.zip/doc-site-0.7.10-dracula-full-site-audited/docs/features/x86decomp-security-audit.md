---
title: x86decomp.security_audit
description: Source-derived module page for x86decomp.security_audit in x86decomp
  0.7.10.
---

# `x86decomp.security_audit`

- **Source path:** `src/x86decomp/security_audit.py`
- **SHA-256:** `5fc034545bed5fd9ecabc7bef57cb6b0129e67b2f0ba46d468b6b6ac768ffd58`
- **Module docstring:** Release/project security auditing and SBOM generation.
- **AST symbols:** 5

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_secret_findings` | function | 30 | Support secret findings processing for internal toolkit callers. |
| `generate_sbom` | function | 44 | Generate sbom for the current toolkit workflow. |
| `audit_source_tree` | function | 80 | Audit source tree for the current toolkit workflow. |
| `verify_release_manifest` | function | 136 | Verify release manifest for the current toolkit workflow. |
| `run_dependency_vulnerability_audit` | function | 168 | Run an installed pip-audit executable and preserve its exact findings. |
