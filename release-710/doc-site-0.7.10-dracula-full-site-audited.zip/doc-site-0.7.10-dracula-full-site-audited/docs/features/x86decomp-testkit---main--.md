---
title: x86decomp_testkit.__main__
description: Source-derived module page for x86decomp_testkit.__main__ in x86decomp
  0.7.10.
---

# `x86decomp_testkit.__main__`

- **Source path:** `test-suite/src/x86decomp_testkit/__main__.py`
- **SHA-256:** `8049ea31e024fbdc10e22c425b395576481d340e58811ab6fdf39530896ffc98`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.__main__` module.
- **AST symbols:** 0

No classes or functions were declared in this module.
