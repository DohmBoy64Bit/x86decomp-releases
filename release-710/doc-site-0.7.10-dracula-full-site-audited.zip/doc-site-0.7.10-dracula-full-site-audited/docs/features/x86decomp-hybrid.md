---
title: x86decomp.hybrid
description: Source-derived module page for x86decomp.hybrid in x86decomp 0.7.10.
---

# `x86decomp.hybrid`

- **Source path:** `src/x86decomp/hybrid.py`
- **SHA-256:** `c6773b5b03b59a3a02b3e628b229ff32377b4b801046eb4605d79b9bff0f78b1`
- **Module docstring:** Continuously buildable hybrid source-tree generation.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_assembly_bytes` | function | 14 | Support assembly bytes processing for internal toolkit callers. |
| `generate_hybrid_project` | function | 24 | Generate a continuously buildable hybrid tree. |
