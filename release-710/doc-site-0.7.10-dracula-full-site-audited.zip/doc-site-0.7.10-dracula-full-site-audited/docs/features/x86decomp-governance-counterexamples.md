---
title: x86decomp.governance.counterexamples
description: Source-derived module page for x86decomp.governance.counterexamples in
  x86decomp 0.7.10.
---

# `x86decomp.governance.counterexamples`

- **Source path:** `src/x86decomp/governance/counterexamples.py`
- **SHA-256:** `a271d06f33c3569cf9bee6433703a7575b7be39ff363dd8667d60952f6b58a2b`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.counterexamples` module.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `CounterexampleStore` | class | 15 | Coordinate counterexample store behavior for the current toolkit workflow. |
| `__init__` | function | 17 | Initialize the instance with validated constructor state. |
| `add` | function | 23 | Execute the add operation for the current toolkit workflow. |
| `minimize` | function | 42 | Execute the minimize operation for the current toolkit workflow. |
| `promote_to_regression` | function | 68 | Execute the promote to regression operation for the current toolkit workflow. |
| `get` | function | 85 | Execute the get operation for the current toolkit workflow. |
| `list` | function | 97 | Execute the list operation for the current toolkit workflow. |
| `ddmin_bytes` | function | 104 | Delta-debug a byte string while preserving predicate(data) == True. |
