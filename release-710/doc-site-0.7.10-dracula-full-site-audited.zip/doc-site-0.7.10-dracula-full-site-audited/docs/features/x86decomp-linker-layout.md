---
title: x86decomp.linker_layout
description: Source-derived module page for x86decomp.linker_layout in x86decomp 0.7.10.
---

# `x86decomp.linker_layout`

- **Source path:** `src/x86decomp/linker_layout.py`
- **SHA-256:** `695a3353f9f7b93e27e71f6a5ede51882b979997adb6fe47bd53946e87bd73fb`
- **Module docstring:** MSVC linker-map parsing and object contribution layout reconstruction.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `MapSegment` | class | 35 | Store validated map segment fields used by toolkit reports and adapters. |
| `to_dict` | function | 43 | Return a serializable dictionary representation. |
| `MapContribution` | class | 55 | Store validated map contribution fields used by toolkit reports and adapters. |
| `to_dict` | function | 62 | Return a serializable dictionary representation. |
| `MapPublic` | class | 73 | Store validated map public fields used by toolkit reports and adapters. |
| `to_dict` | function | 82 | Return a serializable dictionary representation. |
| `LinkerMap` | class | 95 | Store validated linker map fields used by toolkit reports and adapters. |
| `to_dict` | function | 107 | Return a serializable dictionary representation. |
| `parse_msvc_map_text` | function | 126 | Parse msvc map text for the current toolkit workflow. |
| `parse_msvc_map` | function | 224 | Parse msvc map for the current toolkit workflow. |
| `_normalize_object_key` | function | 232 | Support normalize object key processing for internal toolkit callers. |
| `reconstruct_linker_layout` | function | 240 | Reconstruct linker layout for the current toolkit workflow. |
