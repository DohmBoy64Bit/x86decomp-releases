---
title: x86decomp.image_match
description: Source-derived module page for x86decomp.image_match in x86decomp 0.7.10.
---

# `x86decomp.image_match`

- **Source path:** `src/x86decomp/image_match.py`
- **SHA-256:** `e4a53eae89cdc55df81e579ead9ff5f386d632c0a1ff9dd75e61489348d095ae`
- **Module docstring:** Target-specific whole-image matching and deterministic normalization.
- **AST symbols:** 10

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ByteRange` | class | 21 | Store validated byte range fields used by toolkit reports and adapters. |
| `to_dict` | function | 27 | Return a serializable dictionary representation. |
| `_pe_offsets` | function | 32 | Support pe offsets processing for internal toolkit callers. |
| `derive_layout_profile` | function | 55 | Execute the derive layout profile operation for the current toolkit workflow. |
| `_mask_ranges` | function | 95 | Support mask ranges processing for internal toolkit callers. |
| `_rva_to_file_offset` | function | 105 | Support rva to file offset processing for internal toolkit callers. |
| `_profile_ranges` | function | 116 | Support profile ranges processing for internal toolkit callers. |
| `_apply_rebase` | function | 152 | Support apply rebase processing for internal toolkit callers. |
| `_mismatches` | function | 181 | Support mismatches processing for internal toolkit callers. |
| `compare_whole_images` | function | 195 | Compare whole images for the current toolkit workflow. |
