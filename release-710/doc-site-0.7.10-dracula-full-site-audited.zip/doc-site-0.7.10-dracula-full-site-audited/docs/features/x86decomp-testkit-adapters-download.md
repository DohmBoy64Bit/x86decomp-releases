---
title: x86decomp_testkit.adapters.download
description: Source-derived module page for x86decomp_testkit.adapters.download in
  x86decomp 0.7.10.
---

# `x86decomp_testkit.adapters.download`

- **Source path:** `test-suite/src/x86decomp_testkit/adapters/download.py`
- **SHA-256:** `bbb3501c4b88b0cca08ab67ffd4ada025e2f3c015956e4714383db93187e9641`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.adapters.download` module.
- **AST symbols:** 6

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `platform_key` | function | 20 | Execute the platform key operation for the current toolkit workflow. |
| `github_latest_release` | function | 31 | Execute the github latest release operation for the current toolkit workflow. |
| `select_release_asset` | function | 44 | Select release asset for the current toolkit workflow. |
| `download_file` | function | 60 | Execute the download file operation for the current toolkit workflow. |
| `_safe_destination` | function | 86 | Support safe destination processing for internal toolkit callers. |
| `safe_extract_archive` | function | 98 | Execute the safe extract archive operation for the current toolkit workflow. |
