---
title: x86decomp.reconstruction.semantic_changesets
description: Source-derived module page for x86decomp.reconstruction.semantic_changesets
  in x86decomp 0.7.10.
---

# `x86decomp.reconstruction.semantic_changesets`

- **Source path:** `src/x86decomp/reconstruction/semantic_changesets.py`
- **SHA-256:** `8162c89a2e231164a4c4940804355c123bc6eeae6a1de7234bc2468af80bbeae`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.semantic_changesets` module.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `SemanticChangeSets` | class | 9 | Coordinate semantic change sets behavior for the current toolkit workflow. |
| `__init__` | function | 11 | Initialize the instance with validated constructor state. |
| `create` | function | 14 | Create create for the current toolkit workflow. |
| `get` | function | 20 | Execute the get operation for the current toolkit workflow. |
| `add_operation` | function | 27 | Execute the add operation operation for the current toolkit workflow. |
| `merge` | function | 37 | Execute the merge operation for the current toolkit workflow. |
| `conflicts` | function | 51 | Execute the conflicts operation for the current toolkit workflow. |
| `verify` | function | 54 | Verify verify for the current toolkit workflow. |
| `rebase` | function | 58 | Execute the rebase operation for the current toolkit workflow. |
