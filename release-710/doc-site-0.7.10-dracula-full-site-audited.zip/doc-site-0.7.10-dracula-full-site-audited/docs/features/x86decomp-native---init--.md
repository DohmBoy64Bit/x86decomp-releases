---
title: x86decomp.native.__init__
description: Source-derived module page for x86decomp.native.__init__ in x86decomp
  0.7.10.
---

# `x86decomp.native.__init__`

- **Source path:** `src/x86decomp/native/__init__.py`
- **SHA-256:** `c06bf6b79e240a8ec82b7084a6f50358b49e0c28084ed2cece59bd0f803dfb0d`
- **Module docstring:** Native PE reconstruction and closed-loop matching capabilities.
- **AST symbols:** 0

No classes or functions were declared in this module.
