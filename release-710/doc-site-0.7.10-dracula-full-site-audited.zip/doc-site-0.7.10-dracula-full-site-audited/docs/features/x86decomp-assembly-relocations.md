---
title: x86decomp.assembly.relocations
description: Source-derived module page for x86decomp.assembly.relocations in x86decomp
  0.7.10.
---

# `x86decomp.assembly.relocations`

- **Source path:** `src/x86decomp/assembly/relocations.py`
- **SHA-256:** `bc19a023e373f5a64a2a2ffdcc9835e57fc65bd76ba8c6ca87f1855b0ccb66a1`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.assembly.relocations` module.
- **AST symbols:** 13

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `SymbolAddress` | class | 25 | Store validated symbol address fields used by toolkit reports and adapters. |
| `safe_name` | function | 34 | Execute the safe name operation for the current toolkit workflow. |
| `to_dict` | function | 38 | Return a serializable dictionary representation. |
| `normalize_symbol_map` | function | 49 | Normalize symbol map for the current toolkit workflow. |
| `supported_relocations` | function | 100 | Execute the supported relocations operation for the current toolkit workflow. |
| `_read_addend` | function | 121 | Support read addend processing for internal toolkit callers. |
| `_write_value` | function | 128 | Support write value processing for internal toolkit callers. |
| `_object_symbol_target` | function | 139 | Support object symbol target processing for internal toolkit callers. |
| `_resolve_target` | function | 161 | Support resolve target processing for internal toolkit callers. |
| `_compute_value` | function | 187 | Support compute value processing for internal toolkit callers. |
| `RelocationResolver` | class | 245 | Resolve COFF relocation fields under an explicit original-RVA symbol map. |
| `inspect` | function | 248 | Execute the inspect operation for the current toolkit workflow. |
| `resolve` | function | 269 | Resolve resolve for the current toolkit workflow. |
