---
title: x86decomp_testkit.models
description: Source-derived module page for x86decomp_testkit.models in x86decomp
  0.7.10.
---

# `x86decomp_testkit.models`

- **Source path:** `test-suite/src/x86decomp_testkit/models.py`
- **SHA-256:** `cd3c09bfe5c1f30f8693c64b7a6f9b8ae0f4ce6cff40a82f9b8c42b5a1bea00c`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.models` module.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `Status` | class | 10 | Enumerate supported status values. |
| `AdapterKind` | class | 18 | Enumerate supported adapter kind values. |
| `ProbeResult` | class | 28 | Store validated probe result fields used by toolkit reports and adapters. |
| `to_dict` | function | 38 | Return a serializable dictionary representation. |
| `AdapterSpec` | class | 44 | Store validated adapter spec fields used by toolkit reports and adapters. |
| `TestResult` | class | 66 | Store validated test result fields used by toolkit reports and adapters. |
| `to_dict` | function | 82 | Return a serializable dictionary representation. |
| `RunSummary` | class | 90 | Store validated run summary fields used by toolkit reports and adapters. |
| `counts` | function | 104 | Execute the counts operation for the current toolkit workflow. |
| `exit_code` | function | 111 | Execute the exit code operation for the current toolkit workflow. |
| `to_dict` | function | 120 | Return a serializable dictionary representation. |
| `normalized_path` | function | 140 | Normalize d path for the current toolkit workflow. |
