---
title: x86decomp_testkit.timeutil
description: Source-derived module page for x86decomp_testkit.timeutil in x86decomp
  0.7.10.
---

# `x86decomp_testkit.timeutil`

- **Source path:** `test-suite/src/x86decomp_testkit/timeutil.py`
- **SHA-256:** `32bb1893be8e6d365c6781ac07e4d74bcb24ecea8eb29d35fb449432737ddc43`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.timeutil` module.
- **AST symbols:** 1

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `utc_now` | function | 7 | Execute the utc now operation for the current toolkit workflow. |
