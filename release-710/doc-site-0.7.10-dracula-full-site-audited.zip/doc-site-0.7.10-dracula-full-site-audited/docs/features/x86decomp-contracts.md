---
title: x86decomp.contracts
description: Source-derived module page for x86decomp.contracts in x86decomp 0.7.10.
---

# `x86decomp.contracts`

- **Source path:** `src/x86decomp/contracts.py`
- **SHA-256:** `516d98ec7d1ae79f5ea60a450174a4f4781d71eb169c40fa69f840c55507bbab`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.contracts` module.
- **AST symbols:** 13

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ContractError` | class | 17 | Raised when an input violates a stable project contract. |
| `utc_now` | function | 21 | Execute the utc now operation for the current toolkit workflow. |
| `canonical_json` | function | 26 | Execute the canonical json operation for the current toolkit workflow. |
| `sha256_bytes` | function | 31 | Execute the sha256 bytes operation for the current toolkit workflow. |
| `sha256_file` | function | 36 | Execute the sha256 file operation for the current toolkit workflow. |
| `stable_id` | function | 45 | Execute the stable id operation for the current toolkit workflow. |
| `random_id` | function | 51 | Execute the random id operation for the current toolkit workflow. |
| `validate_id` | function | 56 | Validate id for the current toolkit workflow. |
| `ensure_relative_path` | function | 63 | Execute the ensure relative path operation for the current toolkit workflow. |
| `atomic_write_bytes` | function | 72 | Execute the atomic write bytes operation for the current toolkit workflow. |
| `atomic_write_json` | function | 92 | Execute the atomic write json operation for the current toolkit workflow. |
| `read_json` | function | 97 | Read json for the current toolkit workflow. |
| `dedupe_preserve` | function | 103 | Execute the dedupe preserve operation for the current toolkit workflow. |
