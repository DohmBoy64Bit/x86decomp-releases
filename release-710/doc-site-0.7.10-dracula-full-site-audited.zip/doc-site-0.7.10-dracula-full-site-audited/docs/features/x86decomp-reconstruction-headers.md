---
title: x86decomp.reconstruction.headers
description: Source-derived module page for x86decomp.reconstruction.headers in x86decomp
  0.7.10.
---

# `x86decomp.reconstruction.headers`

- **Source path:** `src/x86decomp/reconstruction/headers.py`
- **SHA-256:** `b578c7a48857ab9da72a1c7103502792a4a919f98ef3e3f4561865b655cc6840`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.headers` module.
- **AST symbols:** 10

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `HeaderManager` | class | 10 | Coordinate header manager behavior for the current toolkit workflow. |
| `__init__` | function | 12 | Initialize the instance with validated constructor state. |
| `create` | function | 15 | Create create for the current toolkit workflow. |
| `declare` | function | 25 | Execute the declare operation for the current toolkit workflow. |
| `include` | function | 36 | Execute the include operation for the current toolkit workflow. |
| `cycles` | function | 44 | Execute the cycles operation for the current toolkit workflow. |
| `visit` | function | 54 | Execute the visit operation for the current toolkit workflow. |
| `show` | function | 64 | Execute the show operation for the current toolkit workflow. |
| `synthesize` | function | 72 | Execute the synthesize operation for the current toolkit workflow. |
| `validate` | function | 84 | Validate validate for the current toolkit workflow. |
