---
title: x86decomp.governance.consensus
description: Source-derived module page for x86decomp.governance.consensus in x86decomp
  0.7.10.
---

# `x86decomp.governance.consensus`

- **Source path:** `src/x86decomp/governance/consensus.py`
- **SHA-256:** `28f7df66867b88b8ee9eb2a9d9f56f90a35b6cd74769d4a74d1df5b3bda132cf`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.consensus` module.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ConsensusEngine` | class | 12 | Coordinate consensus engine behavior for the current toolkit workflow. |
| `__init__` | function | 14 | Initialize the instance with validated constructor state. |
| `record` | function | 19 | Record record for the current toolkit workflow. |
| `scan` | function | 32 | Execute the scan operation for the current toolkit workflow. |
| `conflicts` | function | 75 | Execute the conflicts operation for the current toolkit workflow. |
| `resolve` | function | 79 | Resolve resolve for the current toolkit workflow. |
| `explain` | function | 101 | Execute the explain operation for the current toolkit workflow. |
