---
title: x86decomp_testkit.junit
description: Source-derived module page for x86decomp_testkit.junit in x86decomp 0.7.10.
---

# `x86decomp_testkit.junit`

- **Source path:** `test-suite/src/x86decomp_testkit/junit.py`
- **SHA-256:** `a51e772d766abd7e73cece8c589265dbcd53ab5a5a7f66b7c302d8b95ebdb1c1`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.junit` module.
- **AST symbols:** 1

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `parse_junit` | function | 9 | Parse junit for the current toolkit workflow. |
