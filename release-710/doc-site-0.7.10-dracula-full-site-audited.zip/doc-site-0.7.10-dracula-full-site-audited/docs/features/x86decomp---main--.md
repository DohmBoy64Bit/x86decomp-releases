---
title: x86decomp.__main__
description: Source-derived module page for x86decomp.__main__ in x86decomp 0.7.10.
---

# `x86decomp.__main__`

- **Source path:** `src/x86decomp/__main__.py`
- **SHA-256:** `cd307c2c0d8d783cc42355eb7a64ec5a09987b0c0d63e873ae7adc0c67af2b04`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.__main__` module.
- **AST symbols:** 0

No classes or functions were declared in this module.
