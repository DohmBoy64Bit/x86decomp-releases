---
title: x86decomp.workflow
description: Source-derived module page for x86decomp.workflow in x86decomp 0.7.10.
---

# `x86decomp.workflow`

- **Source path:** `src/x86decomp/workflow.py`
- **SHA-256:** `7f8feb468bf53f4cd1d5bc98cec7da39a21ebab9ee9483284d10052453129553`
- **Module docstring:** Per-function decompilation mode and validation-state management.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `DecompilationMode` | class | 21 | Coordinate decompilation mode behavior for the current toolkit workflow. |
| `SourceStage` | class | 27 | Coordinate source stage behavior for the current toolkit workflow. |
| `MatchingStatus` | class | 36 | Coordinate matching status behavior for the current toolkit workflow. |
| `FunctionalStatus` | class | 49 | Coordinate functional status behavior for the current toolkit workflow. |
| `FunctionWorkflow` | class | 69 | Store validated function workflow fields used by toolkit reports and adapters. |
| `to_dict` | function | 84 | Return a serializable dictionary representation. |
| `from_dict` | function | 101 | Execute the from dict operation for the current toolkit workflow. |
| `_state_path` | function | 133 | Support state path processing for internal toolkit callers. |
| `initialize_function_workflow` | function | 139 | Initialize function workflow for the current toolkit workflow. |
| `load_function_workflow` | function | 170 | Load function workflow for the current toolkit workflow. |
| `save_function_workflow` | function | 178 | Execute the save function workflow operation for the current toolkit workflow. |
| `update_function_workflow` | function | 184 | Update function workflow for the current toolkit workflow. |
