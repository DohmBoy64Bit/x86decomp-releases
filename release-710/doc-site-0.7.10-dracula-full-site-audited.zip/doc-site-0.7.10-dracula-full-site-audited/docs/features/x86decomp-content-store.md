---
title: x86decomp.content_store
description: Source-derived module page for x86decomp.content_store in x86decomp 0.7.10.
---

# `x86decomp.content_store`

- **Source path:** `src/x86decomp/content_store.py`
- **SHA-256:** `3a7dbe29ec407dff4966ae962ea4685141056fb57cfb8dc4ba84145547ec3a41`
- **Module docstring:** Content-addressed immutable artifact storage.
- **AST symbols:** 18

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `StoredArtifact` | class | 22 | Store validated stored artifact fields used by toolkit reports and adapters. |
| `to_dict` | function | 29 | Return a serializable dictionary representation. |
| `display` | function | 31 | Execute the display operation for the current toolkit workflow. |
| `ContentStore` | class | 47 | Immutable SHA-256 store rooted at ``root``. |
| `__init__` | function | 50 | Initialize the instance with validated constructor state. |
| `_paths` | function | 62 | Support paths processing for internal toolkit callers. |
| `_validate_digest` | function | 70 | Support validate digest processing for internal toolkit callers. |
| `_locked` | function | 76 | Cross-process advisory lock using an exclusive lock file. |
| `put_bytes` | function | 98 | Execute the put bytes operation for the current toolkit workflow. |
| `put_file` | function | 132 | Execute the put file operation for the current toolkit workflow. |
| `get` | function | 150 | Execute the get operation for the current toolkit workflow. |
| `read_bytes` | function | 158 | Read bytes for the current toolkit workflow. |
| `add_reference` | function | 166 | Execute the add reference operation for the current toolkit workflow. |
| `remove_reference` | function | 183 | Remove reference for the current toolkit workflow. |
| `referenced_digests` | function | 192 | Execute the referenced digests operation for the current toolkit workflow. |
| `verify` | function | 200 | Verify verify for the current toolkit workflow. |
| `garbage_collect` | function | 232 | Execute the garbage collect operation for the current toolkit workflow. |
| `export_index` | function | 260 | Execute the export index operation for the current toolkit workflow. |
