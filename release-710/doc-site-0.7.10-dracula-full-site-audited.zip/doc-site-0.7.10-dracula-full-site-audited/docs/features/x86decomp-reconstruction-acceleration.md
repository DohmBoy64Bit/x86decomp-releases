---
title: x86decomp.reconstruction.acceleration
description: Source-derived module page for x86decomp.reconstruction.acceleration
  in x86decomp 0.7.10.
---

# `x86decomp.reconstruction.acceleration`

- **Source path:** `src/x86decomp/reconstruction/acceleration.py`
- **SHA-256:** `92c4e549963276a31ce63ab99b54c70d14ad65c864c91a58a53e8ede044820db`
- **Module docstring:** Human-readable decompilation acceleration helpers.
- **AST symbols:** 70

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_safe_rel` | function | 31 | Support safe rel processing for internal toolkit callers. |
| `_read_text_if_exists` | function | 42 | Support read text if exists processing for internal toolkit callers. |
| `_body_ranges` | function | 47 | Support body ranges processing for internal toolkit callers. |
| `_contiguous_single_range` | function | 62 | Support contiguous single range processing for internal toolkit callers. |
| `_read_range_bytes` | function | 73 | Support read range bytes processing for internal toolkit callers. |
| `_read_mnemonics` | function | 92 | Support read mnemonics processing for internal toolkit callers. |
| `_function_name` | function | 124 | Support function name processing for internal toolkit callers. |
| `llm_job_from_function_packet` | function | 133 | Create one local-LLM job from a verified function artifact directory. |
| `llm_job_from_range` | function | 219 | Create one local-LLM job from an explicitly supplied file offset/RVA range. |
| `llm_batch_create` | function | 293 | Execute the llm batch create operation for the current toolkit workflow. |
| `llm_batch_match` | function | 329 | Execute the llm batch match operation for the current toolkit workflow. |
| `candidate_promote` | function | 356 | Execute the candidate promote operation for the current toolkit workflow. |
| `source_map_annotate` | function | 386 | Execute the source map annotate operation for the current toolkit workflow. |
| `source_map_verify` | function | 405 | Execute the source map verify operation for the current toolkit workflow. |
| `module_assign` | function | 423 | Execute the module assign operation for the current toolkit workflow. |
| `module_suggest` | function | 435 | Execute the module suggest operation for the current toolkit workflow. |
| `type_propagate` | function | 454 | Execute the type propagate operation for the current toolkit workflow. |
| `header_synthesize_project` | function | 467 | Execute the header synthesize project operation for the current toolkit workflow. |
| `vtable_recover` | function | 487 | Execute the vtable recover operation for the current toolkit workflow. |
| `class_scaffold` | function | 493 | Execute the class scaffold operation for the current toolkit workflow. |
| `diff_explain` | function | 511 | Execute the diff explain operation for the current toolkit workflow. |
| `triage_next` | function | 526 | Execute the triage next operation for the current toolkit workflow. |
| `playability_smoke_plan` | function | 538 | Execute the playability smoke plan operation for the current toolkit workflow. |
| `asset_inventory` | function | 547 | Execute the asset inventory operation for the current toolkit workflow. |
| `mod_branch_init` | function | 559 | Execute the mod branch init operation for the current toolkit workflow. |
| `regression_compare` | function | 566 | Execute the regression compare operation for the current toolkit workflow. |
| `_json_out` | function | 600 | Support json out processing for internal toolkit callers. |
| `_read_any_text` | function | 607 | Support read any text processing for internal toolkit callers. |
| `_file_report` | function | 615 | Support file report processing for internal toolkit callers. |
| `function_discover` | function | 621 | Discover candidate function entry offsets using architecture profiles. |
| `function_boundary_reconcile` | function | 664 | Execute the function boundary reconcile operation for the current toolkit workflow. |
| `function_list_sort` | function | 687 | Execute the function list sort operation for the current toolkit workflow. |
| `sort_key` | function | 695 | Execute the sort key operation for the current toolkit workflow. |
| `function_list_classify` | function | 708 | Execute the function list classify operation for the current toolkit workflow. |
| `pattern_catalog` | function | 732 | Execute the pattern catalog operation for the current toolkit workflow. |
| `pattern_scan` | function | 738 | Execute the pattern scan operation for the current toolkit workflow. |
| `pattern_generate` | function | 764 | Execute the pattern generate operation for the current toolkit workflow. |
| `pattern_match` | function | 784 | Execute the pattern match operation for the current toolkit workflow. |
| `pattern_promote` | function | 795 | Execute the pattern promote operation for the current toolkit workflow. |
| `image_text_compose` | function | 803 | Execute the image text compose operation for the current toolkit workflow. |
| `_pe_section` | function | 851 | Support pe section processing for internal toolkit callers. |
| `text_swap_plan` | function | 873 | Execute the text swap plan operation for the current toolkit workflow. |
| `text_swap_inject` | function | 885 | Execute the text swap inject operation for the current toolkit workflow. |
| `text_swap_verify` | function | 909 | Execute the text swap verify operation for the current toolkit workflow. |
| `text_swap_build` | function | 921 | Execute the text swap build operation for the current toolkit workflow. |
| `progress_reconcile` | function | 930 | Execute the progress reconcile operation for the current toolkit workflow. |
| `project_health` | function | 950 | Execute the project health operation for the current toolkit workflow. |
| `source_stage_classify` | function | 963 | Execute the source stage classify operation for the current toolkit workflow. |
| `ghidra_mcp_probe` | function | 991 | Execute the ghidra mcp probe operation for the current toolkit workflow. |
| `_json_rpc` | function | 1004 | Support json rpc processing for internal toolkit callers. |
| `ghidra_mcp_functions` | function | 1012 | Execute the ghidra mcp functions operation for the current toolkit workflow. |
| `ghidra_mcp_decompile` | function | 1019 | Execute the ghidra mcp decompile operation for the current toolkit workflow. |
| `ghidra_mcp_batch_decompile` | function | 1026 | Execute the ghidra mcp batch decompile operation for the current toolkit workflow. |
| `ghidra_mcp_sync_names` | function | 1041 | Execute the ghidra mcp sync names operation for the current toolkit workflow. |
| `compiler_rule_learn` | function | 1053 | Execute the compiler rule learn operation for the current toolkit workflow. |
| `compiler_rule_report` | function | 1063 | Execute the compiler rule report operation for the current toolkit workflow. |
| `compiler_compare_flags` | function | 1070 | Execute the compiler compare flags operation for the current toolkit workflow. |
| `runtime_identify` | function | 1080 | Run time identify for the current toolkit workflow. |
| `runtime_quarantine` | function | 1094 | Run time quarantine for the current toolkit workflow. |
| `runtime_match_library` | function | 1105 | Run time match library for the current toolkit workflow. |
| `subsystem_detect` | function | 1112 | Execute the subsystem detect operation for the current toolkit workflow. |
| `state_machine_detect` | function | 1127 | Execute the state machine detect operation for the current toolkit workflow. |
| `project_doctor_paths` | function | 1141 | Execute the project doctor paths operation for the current toolkit workflow. |
| `script_port_audit` | function | 1156 | Execute the script port audit operation for the current toolkit workflow. |
| `toolchain_hash_tree` | function | 1172 | Execute the toolchain hash tree operation for the current toolkit workflow. |
| `toolchain_verify_local` | function | 1180 | Execute the toolchain verify local operation for the current toolkit workflow. |
| `toolchain_redact_package` | function | 1193 | Execute the toolchain redact package operation for the current toolkit workflow. |
| `decompiler_cleanup` | function | 1208 | Execute the decompiler cleanup operation for the current toolkit workflow. |
| `candidate_search` | function | 1230 | Execute the candidate search operation for the current toolkit workflow. |
| `release_goal_moddable_source` | function | 1242 | Execute the release goal moddable source operation for the current toolkit workflow. |
