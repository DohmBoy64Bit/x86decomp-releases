---
title: x86decomp.governance.store
description: Source-derived module page for x86decomp.governance.store in x86decomp
  0.7.10.
---

# `x86decomp.governance.store`

- **Source path:** `src/x86decomp/governance/store.py`
- **SHA-256:** `b1b5ac59b24b5f6da9e3ab02342b8eb7eb40ee3065a3974bef26c9b81f2d0977`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.store` module.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `GovernanceStore` | class | 290 | Transactional governance extension store. |
| `__init__` | function | 297 | Initialize the instance with validated constructor state. |
| `initialize` | function | 302 | Initialize initialize for the current toolkit workflow. |
| `connect` | function | 321 | Execute the connect operation for the current toolkit workflow. |
| `transaction` | function | 332 | Execute the transaction operation for the current toolkit workflow. |
| `audit` | function | 345 | Audit audit for the current toolkit workflow. |
| `verify_audit_chain` | function | 381 | Verify audit chain for the current toolkit workflow. |
| `check` | function | 402 | Check check for the current toolkit workflow. |
