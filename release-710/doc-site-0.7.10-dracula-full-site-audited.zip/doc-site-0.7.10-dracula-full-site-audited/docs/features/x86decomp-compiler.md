---
title: x86decomp.compiler
description: Source-derived module page for x86decomp.compiler in x86decomp 0.7.10.
---

# `x86decomp.compiler`

- **Source path:** `src/x86decomp/compiler.py`
- **SHA-256:** `cd474dd4aa9c3ba80b6e5d1b50df0e2e2d460aae68b30bc63233531e730834bb`
- **Module docstring:** Deterministic external compiler profile execution and cache keys.
- **AST symbols:** 5

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `load_profile` | function | 19 | Load profile for the current toolkit workflow. |
| `_tool_version` | function | 59 | Support tool version processing for internal toolkit callers. |
| `_resolve_executable` | function | 75 | Support resolve executable processing for internal toolkit callers. |
| `compiler_cache_key` | function | 88 | Execute the compiler cache key operation for the current toolkit workflow. |
| `run_compiler_profile` | function | 105 | Run compiler profile for the current toolkit workflow. |
