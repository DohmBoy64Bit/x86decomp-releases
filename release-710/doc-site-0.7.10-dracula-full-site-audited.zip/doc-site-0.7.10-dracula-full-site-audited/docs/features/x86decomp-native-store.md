---
title: x86decomp.native.store
description: Source-derived module page for x86decomp.native.store in x86decomp 0.7.10.
---

# `x86decomp.native.store`

- **Source path:** `src/x86decomp/native/store.py`
- **SHA-256:** `9ad9253394d271e17539008ab2ac520020be60f560e9a83afdd34485222ba889`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.store` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `NativeStore` | class | 74 | Native-PE reconstruction schema layered on current reconstruction data. |
| `initialize` | function | 77 | Initialize initialize for the current toolkit workflow. |
| `check` | function | 95 | Check check for the current toolkit workflow. |
| `decode` | function | 123 | Decode configured JSON columns from a SQLite row. |
