---
title: x86decomp.reconstruction.libraries
description: Source-derived module page for x86decomp.reconstruction.libraries in
  x86decomp 0.7.10.
---

# `x86decomp.reconstruction.libraries`

- **Source path:** `src/x86decomp/reconstruction/libraries.py`
- **SHA-256:** `ae16b90a7305823aca1dc000581ecd593ac57ab97b9b0ed4dc8923ecdc081fb3`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.libraries` module.
- **AST symbols:** 6

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `LibraryRecognition` | class | 8 | Coordinate library recognition behavior for the current toolkit workflow. |
| `__init__` | function | 10 | Initialize the instance with validated constructor state. |
| `identify` | function | 13 | Execute the identify operation for the current toolkit workflow. |
| `get` | function | 21 | Execute the get operation for the current toolkit workflow. |
| `candidates` | function | 26 | Execute the candidates operation for the current toolkit workflow. |
| `disposition` | function | 30 | Execute the disposition operation for the current toolkit workflow. |
