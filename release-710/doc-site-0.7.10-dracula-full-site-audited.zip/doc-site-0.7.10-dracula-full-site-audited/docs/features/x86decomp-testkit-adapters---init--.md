---
title: x86decomp_testkit.adapters.__init__
description: Source-derived module page for x86decomp_testkit.adapters.__init__ in
  x86decomp 0.7.10.
---

# `x86decomp_testkit.adapters.__init__`

- **Source path:** `test-suite/src/x86decomp_testkit/adapters/__init__.py`
- **SHA-256:** `1ddce6290f1b4d3745c163a2473f72888548faf2af70e04f498a11882989df21`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.adapters` module.
- **AST symbols:** 0

No classes or functions were declared in this module.
