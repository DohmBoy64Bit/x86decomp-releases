---
title: x86decomp.integration
description: Source-derived module page for x86decomp.integration in x86decomp 0.7.10.
---

# `x86decomp.integration`

- **Source path:** `src/x86decomp/integration.py`
- **SHA-256:** `1dd501274cd70e4e97ee72667c488439d1cdd651e92a6306995e5c5655b39779`
- **Module docstring:** Manifest-driven integration scenario runner.
- **AST symbols:** 10

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_require_string_list` | function | 24 | Support require string list processing for internal toolkit callers. |
| `_resolve_existing` | function | 33 | Support resolve existing processing for internal toolkit callers. |
| `_parse_stdin` | function | 43 | Support parse stdin processing for internal toolkit callers. |
| `_copy_fixtures` | function | 66 | Support copy fixtures processing for internal toolkit callers. |
| `_substitute_command` | function | 98 | Support substitute command processing for internal toolkit callers. |
| `_bounded_output` | function | 113 | Support bounded output processing for internal toolkit callers. |
| `_run_side` | function | 125 | Support run side processing for internal toolkit callers. |
| `_observe_file` | function | 204 | Support observe file processing for internal toolkit callers. |
| `_compare_stream` | function | 259 | Support compare stream processing for internal toolkit callers. |
| `run_integration_scenarios` | function | 282 | Execute and compare all declared integration scenarios. |
