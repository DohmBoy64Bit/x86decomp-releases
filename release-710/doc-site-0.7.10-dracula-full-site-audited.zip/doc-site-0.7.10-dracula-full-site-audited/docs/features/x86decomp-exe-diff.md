---
title: x86decomp.exe_diff
description: Source-derived module page for x86decomp.exe_diff in x86decomp 0.7.10.
---

# `x86decomp.exe_diff`

- **Source path:** `src/x86decomp/exe_diff.py`
- **SHA-256:** `c6ba882c4efd60db8e9cdf487bc13012257ca0be8f258030657ad87aba66ff48`
- **Module docstring:** Executable-function versus COFF-symbol comparison for matching mode.
- **AST symbols:** 6

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `rva_to_file_offset` | function | 16 | Execute the rva to file offset operation for the current toolkit workflow. |
| `extract_pe_bytes` | function | 33 | Extract pe bytes for the current toolkit workflow. |
| `_masked_copy` | function | 51 | Support masked copy processing for internal toolkit callers. |
| `_candidate_relocation_masks` | function | 61 | Support candidate relocation masks processing for internal toolkit callers. |
| `_pe_base_relocation_masks` | function | 78 | Support pe base relocation masks processing for internal toolkit callers. |
| `compare_pe_function_to_coff_symbol` | function | 89 | Compare pe function to coff symbol for the current toolkit workflow. |
