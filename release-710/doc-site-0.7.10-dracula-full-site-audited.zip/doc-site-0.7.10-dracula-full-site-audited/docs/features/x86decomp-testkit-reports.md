---
title: x86decomp_testkit.reports
description: Source-derived module page for x86decomp_testkit.reports in x86decomp
  0.7.10.
---

# `x86decomp_testkit.reports`

- **Source path:** `test-suite/src/x86decomp_testkit/reports.py`
- **SHA-256:** `b433e8f157f959ba1bcb1d4a1f328fe8d04b28bdde08bfb4f438b39e3d84d8bc`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.reports` module.
- **AST symbols:** 5

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `write_json_report` | function | 12 | Write json report for the current toolkit workflow. |
| `write_adapter_report` | function | 18 | Write adapter report for the current toolkit workflow. |
| `_status_icon` | function | 28 | Support status icon processing for internal toolkit callers. |
| `write_markdown_report` | function | 38 | Write markdown report for the current toolkit workflow. |
| `write_html_report` | function | 108 | Write html report for the current toolkit workflow. |
