---
title: x86decomp.patching
description: Source-derived module page for x86decomp.patching in x86decomp 0.7.10.
---

# `x86decomp.patching`

- **Source path:** `src/x86decomp/patching.py`
- **SHA-256:** `f81a6e2fc12323262049645808778be12227704ee0f0d36eb343e946e56b3822`
- **Module docstring:** Patch-image backend with integrity checks and PE checksum refresh.
- **AST symbols:** 3

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_checksum_offset` | function | 15 | Support checksum offset processing for internal toolkit callers. |
| `calculate_pe_checksum` | function | 25 | Execute the calculate pe checksum operation for the current toolkit workflow. |
| `patch_pe_function` | function | 41 | Execute the patch pe function operation for the current toolkit workflow. |
