---
title: x86decomp.governance.workers
description: Source-derived module page for x86decomp.governance.workers in x86decomp
  0.7.10.
---

# `x86decomp.governance.workers`

- **Source path:** `src/x86decomp/governance/workers.py`
- **SHA-256:** `b41f6fc57502ffc1b070ebe21b125083a9a44bcb20589fec17a31204119f877a`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.workers` module.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `WorkerRegistry` | class | 13 | Coordinate worker registry behavior for the current toolkit workflow. |
| `__init__` | function | 15 | Initialize the instance with validated constructor state. |
| `register` | function | 20 | Execute the register operation for the current toolkit workflow. |
| `get` | function | 35 | Execute the get operation for the current toolkit workflow. |
| `list` | function | 45 | Execute the list operation for the current toolkit workflow. |
| `select` | function | 54 | Select select for the current toolkit workflow. |
| `set_status` | function | 65 | Execute the set status operation for the current toolkit workflow. |
| `doctor` | function | 75 | Execute the doctor operation for the current toolkit workflow. |
