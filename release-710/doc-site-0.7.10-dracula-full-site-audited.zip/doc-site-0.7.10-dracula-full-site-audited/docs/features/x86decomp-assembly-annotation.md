---
title: x86decomp.assembly.annotation
description: Source-derived module page for x86decomp.assembly.annotation in x86decomp
  0.7.10.
---

# `x86decomp.assembly.annotation`

- **Source path:** `src/x86decomp/assembly/annotation.py`
- **SHA-256:** `b124d036b79e6ffa168f1e500717af68c615534f8bb789892f2818c5787bb1cd`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.assembly.annotation` module.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `validate_symbol` | function | 15 | Validate symbol for the current toolkit workflow. |
| `render_byte_assembly` | function | 22 | Render the original compatibility form. This output intentionally preserves byte-form assembly semantics. |
| `parse_byte_directives` | function | 40 | Parse byte directives for the current toolkit workflow. |
| `_chunk_comments` | function | 63 | Support chunk comments processing for internal toolkit callers. |
| `render_annotated_assembly` | function | 74 | Render byte-identical directives with idempotent Capstone comments. |
| `annotate_source` | function | 96 | Execute the annotate source operation for the current toolkit workflow. |
| `byte_directive_lines` | function | 121 | Execute the byte directive lines operation for the current toolkit workflow. |
