---
title: x86decomp_testkit.config
description: Source-derived module page for x86decomp_testkit.config in x86decomp
  0.7.10.
---

# `x86decomp_testkit.config`

- **Source path:** `test-suite/src/x86decomp_testkit/config.py`
- **SHA-256:** `040632f7652257a669121fa9a2729fd5f225123879adb483ee209841181638d5`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.config` module.
- **AST symbols:** 6

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `TestConfig` | class | 15 | Store validated test config fields used by toolkit reports and adapters. |
| `to_dict` | function | 33 | Return a serializable dictionary representation. |
| `from_dict` | function | 55 | Execute the from dict operation for the current toolkit workflow. |
| `resolve` | function | 59 | Resolve resolve for the current toolkit workflow. |
| `load_config` | function | 89 | Load config for the current toolkit workflow. |
| `save_config` | function | 97 | Execute the save config operation for the current toolkit workflow. |
