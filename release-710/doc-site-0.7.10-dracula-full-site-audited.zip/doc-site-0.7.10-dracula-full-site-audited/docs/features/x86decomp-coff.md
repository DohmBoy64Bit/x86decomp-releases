---
title: x86decomp.coff
description: Source-derived module page for x86decomp.coff in x86decomp 0.7.10.
---

# `x86decomp.coff`

- **Source path:** `src/x86decomp/coff.py`
- **SHA-256:** `1fe55bf6f2022a5cc372a1c7c6e48ab0ce8ceec4a3cd3101f7eaf4b9d4b5d378`
- **Module docstring:** Strict COFF object parsing, COMDAT resolution, and deterministic synthesis.
- **AST symbols:** 68

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `relocation_name` | function | 127 | Execute the relocation name operation for the current toolkit workflow. |
| `relocation_width` | function | 133 | Execute the relocation width operation for the current toolkit workflow. |
| `relocation_is_pc_relative` | function | 139 | Execute the relocation is pc relative operation for the current toolkit workflow. |
| `CoffRelocation` | class | 147 | Store validated coff relocation fields used by toolkit reports and adapters. |
| `width` | function | 155 | Execute the width operation for the current toolkit workflow. |
| `to_dict` | function | 159 | Return a serializable dictionary representation. |
| `SectionDefinitionAux` | class | 175 | Store validated section definition aux fields used by toolkit reports and adapters. |
| `selection_name` | function | 185 | Select ion name for the current toolkit workflow. |
| `to_dict` | function | 189 | Return a serializable dictionary representation. |
| `FunctionDefinitionAux` | class | 205 | Store validated function definition aux fields used by toolkit reports and adapters. |
| `to_dict` | function | 212 | Return a serializable dictionary representation. |
| `WeakExternalAux` | class | 224 | Store validated weak external aux fields used by toolkit reports and adapters. |
| `to_dict` | function | 229 | Return a serializable dictionary representation. |
| `FileAux` | class | 241 | Store validated file aux fields used by toolkit reports and adapters. |
| `to_dict` | function | 245 | Return a serializable dictionary representation. |
| `RawAux` | class | 251 | Store validated raw aux fields used by toolkit reports and adapters. |
| `to_dict` | function | 255 | Return a serializable dictionary representation. |
| `CoffSection` | class | 264 | Store validated coff section fields used by toolkit reports and adapters. |
| `is_comdat` | function | 281 | Execute the is comdat operation for the current toolkit workflow. |
| `comdat_selection_name` | function | 286 | Execute the comdat selection name operation for the current toolkit workflow. |
| `alignment_power` | function | 291 | Execute the alignment power operation for the current toolkit workflow. |
| `alignment` | function | 301 | Execute the alignment operation for the current toolkit workflow. |
| `to_dict` | function | 306 | Return a serializable dictionary representation. |
| `CoffSymbol` | class | 332 | Store validated coff symbol fields used by toolkit reports and adapters. |
| `is_function` | function | 344 | Execute the is function operation for the current toolkit workflow. |
| `section_definition` | function | 351 | Execute the section definition operation for the current toolkit workflow. |
| `function_definition` | function | 359 | Execute the function definition operation for the current toolkit workflow. |
| `weak_external` | function | 367 | Execute the weak external operation for the current toolkit workflow. |
| `to_dict` | function | 374 | Return a serializable dictionary representation. |
| `CoffObject` | class | 390 | Store validated coff object fields used by toolkit reports and adapters. |
| `architecture` | function | 403 | Execute the architecture operation for the current toolkit workflow. |
| `section` | function | 411 | Execute the section operation for the current toolkit workflow. |
| `find_symbols` | function | 417 | Execute the find symbols operation for the current toolkit workflow. |
| `symbol_by_index` | function | 424 | Execute the symbol by index operation for the current toolkit workflow. |
| `to_dict` | function | 428 | Return a serializable dictionary representation. |
| `ExtractedSymbol` | class | 447 | Store validated extracted symbol fields used by toolkit reports and adapters. |
| `to_dict` | function | 456 | Return a serializable dictionary representation. |
| `ComdatCandidate` | class | 469 | Store validated comdat candidate fields used by toolkit reports and adapters. |
| `to_dict` | function | 481 | Return a serializable dictionary representation. |
| `ComdatResolution` | class | 498 | Store validated comdat resolution fields used by toolkit reports and adapters. |
| `valid` | function | 505 | Execute the valid operation for the current toolkit workflow. |
| `to_dict` | function | 509 | Return a serializable dictionary representation. |
| `SyntheticSymbolSpec` | class | 521 | Store validated synthetic symbol spec fields used by toolkit reports and adapters. |
| `SyntheticSectionSpec` | class | 532 | Store validated synthetic section spec fields used by toolkit reports and adapters. |
| `_Reader` | class | 544 | Coordinate reader behavior for the current toolkit workflow. |
| `__init__` | function | 546 | Initialize the instance with validated constructor state. |
| `require` | function | 550 | Execute the require operation for the current toolkit workflow. |
| `unpack` | function | 557 | Execute the unpack operation for the current toolkit workflow. |
| `_read_string_table` | function | 564 | Support read string table processing for internal toolkit callers. |
| `_string_at` | function | 579 | Support string at processing for internal toolkit callers. |
| `_decode_symbol_name` | function | 589 | Support decode symbol name processing for internal toolkit callers. |
| `_decode_section_name` | function | 597 | Support decode section name processing for internal toolkit callers. |
| `_parse_header` | function | 605 | Return variant, machine, sections, timestamp, symptr, symcount, |
| `_parse_auxiliary_records` | function | 659 | Support parse auxiliary records processing for internal toolkit callers. |
| `_read_addend` | function | 718 | Support read addend processing for internal toolkit callers. |
| `parse_coff_bytes` | function | 725 | Parse coff bytes for the current toolkit workflow. |
| `parse_coff` | function | 924 | Parse coff for the current toolkit workflow. |
| `extract_symbol` | function | 932 | Extract symbol for the current toolkit workflow. |
| `collect_comdat_candidates` | function | 988 | Execute the collect comdat candidates operation for the current toolkit workflow. |
| `resolve_comdats` | function | 1016 | Resolve COMDAT groups using PE/COFF selection semantics. |
| `_encode_name` | function | 1117 | Support encode name processing for internal toolkit callers. |
| `_section_aux_bytes` | function | 1127 | Support section aux bytes processing for internal toolkit callers. |
| `build_synthetic_coff_object` | function | 1144 | Build a deterministic classic COFF object with multiple sections. |
| `synthetic_symbol_indices` | function | 1261 | Execute the synthetic symbol indices operation for the current toolkit workflow. |
| `build_synthetic_coff` | function | 1273 | Backward-compatible one-section synthetic COFF builder. |
| `build_comdat_coff` | function | 1313 | Build comdat coff for the current toolkit workflow. |
| `write_synthetic_coff` | function | 1379 | Write synthetic coff for the current toolkit workflow. |
| `write_synthetic_coff_object` | function | 1397 | Write synthetic coff object for the current toolkit workflow. |
