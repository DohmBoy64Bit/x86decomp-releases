---
title: x86decomp.analysis_db
description: Source-derived module page for x86decomp.analysis_db in x86decomp 0.7.10.
---

# `x86decomp.analysis_db`

- **Source path:** `src/x86decomp/analysis_db.py`
- **SHA-256:** `583910cb27d192fa35e39b0e4165ffa71ac5a1fd77de1b78843245e525e414fe`
- **Module docstring:** SQLite-backed global symbol, type, reference, and constraint database.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `AnalysisDatabase` | class | 70 | Coordinate analysis database behavior for the current toolkit workflow. |
| `__init__` | function | 72 | Initialize the instance with validated constructor state. |
| `close` | function | 80 | Execute the close operation for the current toolkit workflow. |
| `__enter__` | function | 84 | Enter the managed runtime context and return the active resource. |
| `__exit__` | function | 88 | Exit the managed runtime context and release owned resources. |
| `upsert_entity` | function | 96 | Execute the upsert entity operation for the current toolkit workflow. |
| `add_reference` | function | 126 | Execute the add reference operation for the current toolkit workflow. |
| `add_type_constraint` | function | 145 | Execute the add type constraint operation for the current toolkit workflow. |
| `detect_constraint_conflicts` | function | 167 | Execute the detect constraint conflicts operation for the current toolkit workflow. |
| `accept_constraint` | function | 183 | Execute the accept constraint operation for the current toolkit workflow. |
| `ingest_function_artifact` | function | 196 | Execute the ingest function artifact operation for the current toolkit workflow. |
| `query` | function | 252 | Execute the query operation for the current toolkit workflow. |
