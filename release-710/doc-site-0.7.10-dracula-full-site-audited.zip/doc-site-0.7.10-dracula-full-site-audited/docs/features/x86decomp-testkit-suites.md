---
title: x86decomp_testkit.suites
description: Source-derived module page for x86decomp_testkit.suites in x86decomp
  0.7.10.
---

# `x86decomp_testkit.suites`

- **Source path:** `test-suite/src/x86decomp_testkit/suites.py`
- **SHA-256:** `010c3da7b0b415857c7764b44e39863447e2f4245d68aea69c7513038a80225d`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.suites` module.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_missing` | function | 21 | Support missing processing for internal toolkit callers. |
| `_result` | function | 32 | Support result processing for internal toolkit callers. |
| `run_inventory_tests` | function | 47 | Run inventory tests for the current toolkit workflow. |
| `run_cli_surface_tests` | function | 92 | Run cli surface tests for the current toolkit workflow. |
| `_verify_manifest` | function | 117 | Support verify manifest processing for internal toolkit callers. |
| `_validate_schemas` | function | 146 | Support validate schemas processing for internal toolkit callers. |
| `_validate_java` | function | 164 | Support validate java processing for internal toolkit callers. |
| `_validate_skill` | function | 181 | Support validate skill processing for internal toolkit callers. |
| `run_structural_tests` | function | 202 | Run structural tests for the current toolkit workflow. |
| `run_harness_self_tests` | function | 271 | Run harness self tests for the current toolkit workflow. |
| `run_pytest_and_coverage` | function | 314 | Run pytest and coverage for the current toolkit workflow. |
| `run_packaging_tests` | function | 399 | Run packaging tests for the current toolkit workflow. |
