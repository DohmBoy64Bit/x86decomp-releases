---
title: x86decomp.evidence
description: Source-derived module page for x86decomp.evidence in x86decomp 0.7.10.
---

# `x86decomp.evidence`

- **Source path:** `src/x86decomp/evidence.py`
- **SHA-256:** `5e84e855cf3aa99a089ca44a049786ee37538761fa86b0a3ea988675230818eb`
- **Module docstring:** Evidence store and strict three-independent-source claim verification.
- **AST symbols:** 13

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_validate_id` | function | 17 | Support validate id processing for internal toolkit callers. |
| `EvidenceStore` | class | 25 | Filesystem-backed evidence and claims with deterministic validation rules. |
| `__init__` | function | 28 | Initialize the instance with validated constructor state. |
| `add_evidence` | function | 38 | Execute the add evidence operation for the current toolkit workflow. |
| `get_evidence` | function | 84 | Execute the get evidence operation for the current toolkit workflow. |
| `create_claim` | function | 106 | Create claim for the current toolkit workflow. |
| `get_claim` | function | 138 | Execute the get claim operation for the current toolkit workflow. |
| `save_claim` | function | 161 | Execute the save claim operation for the current toolkit workflow. |
| `attach_evidence` | function | 166 | Execute the attach evidence operation for the current toolkit workflow. |
| `add_contradiction` | function | 177 | Execute the add contradiction operation for the current toolkit workflow. |
| `audit_evidence_integrity` | function | 187 | Audit evidence integrity for the current toolkit workflow. |
| `verify_claim` | function | 210 | Apply the strict verification gate and persist the resulting state. |
| `require_verified` | function | 256 | Execute the require verified operation for the current toolkit workflow. |
