---
title: x86decomp.diffing
description: Source-derived module page for x86decomp.diffing in x86decomp 0.7.10.
---

# `x86decomp.diffing`

- **Source path:** `src/x86decomp/diffing.py`
- **SHA-256:** `e15fdd427ebeee553b08dfedc704d21c7fd4146da984abfef1a77c18846731e7`
- **Module docstring:** Exact byte comparison and transparent similarity reporting.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `compare_bytes` | function | 13 | Compare bytes for the current toolkit workflow. |
| `compare_files` | function | 61 | Compare files for the current toolkit workflow. |
