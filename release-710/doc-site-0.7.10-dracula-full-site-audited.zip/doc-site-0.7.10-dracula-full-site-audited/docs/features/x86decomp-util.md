---
title: x86decomp.util
description: Source-derived module page for x86decomp.util in x86decomp 0.7.10.
---

# `x86decomp.util`

- **Source path:** `src/x86decomp/util.py`
- **SHA-256:** `a31791a06728eb30ecd156b1ab6f57dc3a56197be2ea6fe2043a2903228d9510`
- **Module docstring:** Small, dependency-free utilities shared by all modules.
- **AST symbols:** 13

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `utc_now` | function | 17 | Return a stable RFC 3339 UTC timestamp. |
| `sha256_bytes` | function | 22 | Execute the sha256 bytes operation for the current toolkit workflow. |
| `sha256_file` | function | 27 | Execute the sha256 file operation for the current toolkit workflow. |
| `canonical_json_bytes` | function | 36 | Execute the canonical json bytes operation for the current toolkit workflow. |
| `load_json` | function | 43 | Load and parse JSON content from a filesystem path. |
| `atomic_write_bytes` | function | 49 | Execute the atomic write bytes operation for the current toolkit workflow. |
| `atomic_write_text` | function | 66 | Execute the atomic write text operation for the current toolkit workflow. |
| `write_json` | function | 71 | Write json for the current toolkit workflow. |
| `copy_file_atomic` | function | 77 | Execute the copy file atomic operation for the current toolkit workflow. |
| `ensure_relative_path` | function | 92 | Resolve candidate and reject paths that escape root. |
| `require_mapping` | function | 103 | Execute the require mapping operation for the current toolkit workflow. |
| `require_string` | function | 110 | Execute the require string operation for the current toolkit workflow. |
| `require_int` | function | 118 | Execute the require int operation for the current toolkit workflow. |
