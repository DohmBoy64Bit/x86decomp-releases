---
title: x86decomp.assembly.store
description: Source-derived module page for x86decomp.assembly.store in x86decomp
  0.7.10.
---

# `x86decomp.assembly.store`

- **Source path:** `src/x86decomp/assembly/store.py`
- **SHA-256:** `f55582859e8e038d0bb54549dd9d394919fbd488397bd437399fb59243309205`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.assembly.store` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `AssemblyStore` | class | 49 | Additive relocation-aware assembly schema layered on the current native reconstruction state. |
| `initialize` | function | 52 | Initialize initialize for the current toolkit workflow. |
| `check` | function | 74 | Check check for the current toolkit workflow. |
| `decode` | function | 108 | Decode configured JSON columns from a SQLite row. |
