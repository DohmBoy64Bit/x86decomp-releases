---
title: x86decomp_testkit.process
description: Source-derived module page for x86decomp_testkit.process in x86decomp
  0.7.10.
---

# `x86decomp_testkit.process`

- **Source path:** `test-suite/src/x86decomp_testkit/process.py`
- **SHA-256:** `b1521f7cd16821a086c9eb17f7d680eb11b8c3e903dd8a7fe518553f3873596d`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.process` module.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `run_process_test` | function | 15 | Run process test for the current toolkit workflow. |
| `blocked_result` | function | 91 | Execute the blocked result operation for the current toolkit workflow. |
