---
title: x86decomp.cli
description: Source-derived module page for x86decomp.cli in x86decomp 0.7.10.
---

# `x86decomp.cli`

- **Source path:** `src/x86decomp/cli.py`
- **SHA-256:** `674c6069aa4fcda3240077d81e4c56065db26766d9abf1fa786503be4005edd8`
- **Module docstring:** Command-line interface for all toolkit architecture components.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_print` | function | 81 | Support print processing for internal toolkit callers. |
| `_path` | function | 86 | Support path processing for internal toolkit callers. |
| `_int` | function | 91 | Support int processing for internal toolkit callers. |
| `_json_object` | function | 96 | Support json object processing for internal toolkit callers. |
| `_build_parser` | function | 104 | Support build parser processing for internal toolkit callers. |
| `_mcp_client` | function | 247 | Support mcp client processing for internal toolkit callers. |
| `_run` | function | 259 | Support run processing for internal toolkit callers. |
| `main` | function | 435 | Run the command-line entry point and return its process status. |
