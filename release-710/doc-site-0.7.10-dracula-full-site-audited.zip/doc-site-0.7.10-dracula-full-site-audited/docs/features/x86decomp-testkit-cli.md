---
title: x86decomp_testkit.cli
description: Source-derived module page for x86decomp_testkit.cli in x86decomp 0.7.10.
---

# `x86decomp_testkit.cli`

- **Source path:** `test-suite/src/x86decomp_testkit/cli.py`
- **SHA-256:** `4895bf74207b82a195a590b75db4d454ca5ca8ed0b721cddcd368e3f160ccaed`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.cli` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_path` | function | 17 | Support path processing for internal toolkit callers. |
| `_base_parser` | function | 22 | Build the argparse parser for this command surface. |
| `_load` | function | 61 | Support load processing for internal toolkit callers. |
| `main` | function | 68 | Run the command-line entry point and return its process status. |
