---
title: x86decomp.project_template
description: Source-derived module page for x86decomp.project_template in x86decomp
  0.7.10.
---

# `x86decomp.project_template`

- **Source path:** `src/x86decomp/project_template.py`
- **SHA-256:** `21050aad81e374bafd2400628ea946f8bc3040ddd735d6ea4299b7a33604d589`
- **Module docstring:** Grounded project-template generation from a verified target pack.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_artifact_roles` | function | 20 | Support artifact roles processing for internal toolkit callers. |
| `derive_template_contract` | function | 25 | Derive a target project shape only from recorded facts and decisions. |
| `_write_project_helper` | function | 88 | Support write project helper processing for internal toolkit callers. |
| `materialize_project_template` | function | 133 | Create a deterministic, non-fabricated project working layout. |
