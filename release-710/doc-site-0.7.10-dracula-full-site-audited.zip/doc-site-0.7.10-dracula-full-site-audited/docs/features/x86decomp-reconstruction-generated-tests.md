---
title: x86decomp.reconstruction.generated_tests
description: Source-derived module page for x86decomp.reconstruction.generated_tests
  in x86decomp 0.7.10.
---

# `x86decomp.reconstruction.generated_tests`

- **Source path:** `src/x86decomp/reconstruction/generated_tests.py`
- **SHA-256:** `b8a7365129c9e8c5f7e2f834b5feec8997440f43facdf81ec90b917f1e434e67`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.generated_tests` module.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `GeneratedTests` | class | 9 | Coordinate generated tests behavior for the current toolkit workflow. |
| `__init__` | function | 11 | Initialize the instance with validated constructor state. |
| `add` | function | 14 | Execute the add operation for the current toolkit workflow. |
| `synthesize` | function | 24 | Execute the synthesize operation for the current toolkit workflow. |
| `promote_counterexample` | function | 32 | Execute the promote counterexample operation for the current toolkit workflow. |
| `get` | function | 38 | Execute the get operation for the current toolkit workflow. |
| `list` | function | 43 | Execute the list operation for the current toolkit workflow. |
| `explain` | function | 47 | Execute the explain operation for the current toolkit workflow. |
