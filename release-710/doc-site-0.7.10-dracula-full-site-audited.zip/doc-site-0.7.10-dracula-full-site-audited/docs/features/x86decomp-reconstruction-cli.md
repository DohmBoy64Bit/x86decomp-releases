---
title: x86decomp.reconstruction.cli
description: Source-derived module page for x86decomp.reconstruction.cli in x86decomp
  0.7.10.
---

# `x86decomp.reconstruction.cli`

- **Source path:** `src/x86decomp/reconstruction/cli.py`
- **SHA-256:** `d2ce83a81b37240905df5cc810f467b1403b56cd2241a5aefd5c06b51826d083`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.cli` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_store` | function | 54 | Open the project store requested by parsed command arguments. |
| `build_parser` | function | 58 | Build the argparse parser for this command surface. |
| `dispatch` | function | 271 | Dispatch parsed command arguments to the matching implementation. |
| `main` | function | 449 | Run the command-line entry point and return its process status. |
