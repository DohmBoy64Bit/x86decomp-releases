---
title: x86decomp_testkit.coverage_audit
description: Source-derived module page for x86decomp_testkit.coverage_audit in x86decomp
  0.7.10.
---

# `x86decomp_testkit.coverage_audit`

- **Source path:** `test-suite/src/x86decomp_testkit/coverage_audit.py`
- **SHA-256:** `74a93d93dd429f3920938e9c29d2b59b3607de538577200e8b7f7926a545ca62`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.coverage_audit` module.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_coverage_file` | function | 11 | Support coverage file processing for internal toolkit callers. |
| `audit_public_symbol_execution` | function | 25 | Audit public symbol execution for the current toolkit workflow. |
