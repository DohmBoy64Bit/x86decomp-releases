---
title: x86decomp.decompme
description: Source-derived module page for x86decomp.decompme in x86decomp 0.7.10.
---

# `x86decomp.decompme`

- **Source path:** `src/x86decomp/decompme.py`
- **SHA-256:** `ead409a6bd6d0060631b4bfd849191aa885a6f793968993432b048621a662bf2`
- **Module docstring:** Create local decomp.me-style function packets without uploading data.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_copy_required` | function | 14 | Support copy required processing for internal toolkit callers. |
| `create_decompme_packet` | function | 24 | Build a local, reviewable function packet. |
