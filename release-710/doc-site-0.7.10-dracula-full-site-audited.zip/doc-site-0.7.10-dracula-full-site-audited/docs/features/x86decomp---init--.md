---
title: x86decomp.__init__
description: Source-derived module page for x86decomp.__init__ in x86decomp 0.7.10.
---

# `x86decomp.__init__`

- **Source path:** `src/x86decomp/__init__.py`
- **SHA-256:** `62b0037cb1ffe5d8d779b58a693397fc1717f9ea4d9e77fe8e3339eda2b74da2`
- **Module docstring:** x86decomp-toolkit public package API.
- **AST symbols:** 0

No classes or functions were declared in this module.
