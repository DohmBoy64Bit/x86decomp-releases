---
title: x86decomp_testkit.__init__
description: Source-derived module page for x86decomp_testkit.__init__ in x86decomp
  0.7.10.
---

# `x86decomp_testkit.__init__`

- **Source path:** `test-suite/src/x86decomp_testkit/__init__.py`
- **SHA-256:** `103884a665a36b443a6231030a381c75d81e16da00b27222a0c835596080aed8`
- **Module docstring:** Regression and integration test harness for x86decomp-toolkit.
- **AST symbols:** 0

No classes or functions were declared in this module.
