---
title: x86decomp.native.staging
description: Source-derived module page for x86decomp.native.staging in x86decomp
  0.7.10.
---

# `x86decomp.native.staging`

- **Source path:** `src/x86decomp/native/staging.py`
- **SHA-256:** `f4179ca0b7807241266480760fcfef527054a69be26a08cd7b3d31725b70ddef`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.staging` module.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `StagingBridge` | class | 26 | Coordinate staging bridge behavior for the current toolkit workflow. |
| `__init__` | function | 28 | Initialize the instance with validated constructor state. |
| `scan` | function | 32 | Execute the scan operation for the current toolkit workflow. |
| `generate_context` | function | 45 | Generate context for the current toolkit workflow. |
| `resolve` | function | 65 | Resolve resolve for the current toolkit workflow. |
| `unresolved` | function | 77 | Execute the unresolved operation for the current toolkit workflow. |
| `compile_check` | function | 81 | Execute the compile check operation for the current toolkit workflow. |
