---
title: x86decomp.store_utils
description: Source-derived module page for x86decomp.store_utils in x86decomp 0.7.10.
---

# `x86decomp.store_utils`

- **Source path:** `src/x86decomp/store_utils.py`
- **SHA-256:** `79ca047c185646cc9cd5fb8493b8c4024cab512fbafe2a4687971a7c650113fb`
- **Module docstring:** Shared persistence helpers for SQLite-backed toolkit stores.
- **AST symbols:** 1

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `decode_json_fields` | function | 8 | Return a row dictionary with selected ``*_json`` columns decoded. |
