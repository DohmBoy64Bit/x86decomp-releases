---
title: x86decomp.pe32
description: Source-derived module page for x86decomp.pe32 in x86decomp 0.7.10.
---

# `x86decomp.pe32`

- **Source path:** `src/x86decomp/pe32.py`
- **SHA-256:** `fc6d6223aefbf4bb6730559805a160ffef7cf18684886403e02817052334f0b1`
- **Module docstring:** Strict, dependency-free parser for native x86 PE32 images.
- **AST symbols:** 50

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `DataDirectory` | class | 42 | Store validated data directory fields used by toolkit reports and adapters. |
| `to_dict` | function | 48 | Return a serializable dictionary representation. |
| `Section` | class | 54 | Store validated section fields used by toolkit reports and adapters. |
| `mapped_size` | function | 65 | Execute the mapped size operation for the current toolkit workflow. |
| `to_dict` | function | 69 | Return a serializable dictionary representation. |
| `ImportSymbol` | class | 85 | Store validated import symbol fields used by toolkit reports and adapters. |
| `to_dict` | function | 93 | Return a serializable dictionary representation. |
| `ImportLibrary` | class | 105 | Store validated import library fields used by toolkit reports and adapters. |
| `to_dict` | function | 110 | Return a serializable dictionary representation. |
| `ExportSymbol` | class | 116 | Store validated export symbol fields used by toolkit reports and adapters. |
| `to_dict` | function | 123 | Return a serializable dictionary representation. |
| `BaseRelocation` | class | 135 | Store validated base relocation fields used by toolkit reports and adapters. |
| `to_dict` | function | 140 | Return a serializable dictionary representation. |
| `DebugRecord` | class | 146 | Store validated debug record fields used by toolkit reports and adapters. |
| `to_dict` | function | 157 | Return a serializable dictionary representation. |
| `TLSInfo` | class | 172 | Store validated t l s info fields used by toolkit reports and adapters. |
| `to_dict` | function | 182 | Return a serializable dictionary representation. |
| `ResourceLeaf` | class | 198 | Store validated resource leaf fields used by toolkit reports and adapters. |
| `to_dict` | function | 206 | Return a serializable dictionary representation. |
| `DelayImportLibrary` | class | 219 | Store validated delay import library fields used by toolkit reports and adapters. |
| `to_dict` | function | 226 | Return a serializable dictionary representation. |
| `LoadConfigInfo` | class | 237 | Store validated load config info fields used by toolkit reports and adapters. |
| `to_dict` | function | 254 | Return a serializable dictionary representation. |
| `PE32Image` | class | 275 | Store validated p e32 image fields used by toolkit reports and adapters. |
| `entry_va` | function | 304 | Execute the entry va operation for the current toolkit workflow. |
| `to_dict` | function | 308 | Return a serializable dictionary representation. |
| `_Reader` | class | 348 | Coordinate reader behavior for the current toolkit workflow. |
| `__init__` | function | 350 | Initialize the instance with validated constructor state. |
| `require` | function | 354 | Execute the require operation for the current toolkit workflow. |
| `unpack` | function | 361 | Execute the unpack operation for the current toolkit workflow. |
| `u16` | function | 367 | Execute the u16 operation for the current toolkit workflow. |
| `u32` | function | 371 | Execute the u32 operation for the current toolkit workflow. |
| `u64` | function | 375 | Execute the u64 operation for the current toolkit workflow. |
| `c_string` | function | 379 | Execute the c string operation for the current toolkit workflow. |
| `_rva_to_offset` | function | 389 | Support rva to offset processing for internal toolkit callers. |
| `_directory` | function | 411 | Support directory processing for internal toolkit callers. |
| `_parse_imports` | function | 419 | Support parse imports processing for internal toolkit callers. |
| `_parse_exports` | function | 492 | Support parse exports processing for internal toolkit callers. |
| `_parse_relocations` | function | 559 | Support parse relocations processing for internal toolkit callers. |
| `_parse_debug_records` | function | 593 | Support parse debug records processing for internal toolkit callers. |
| `_parse_tls` | function | 655 | Support parse tls processing for internal toolkit callers. |
| `_parse_resources` | function | 702 | Support parse resources processing for internal toolkit callers. |
| `read_name` | function | 718 | Read name for the current toolkit workflow. |
| `walk` | function | 728 | Execute the walk operation for the current toolkit workflow. |
| `_parse_delay_imports` | function | 770 | Support parse delay imports processing for internal toolkit callers. |
| `to_rva` | function | 791 | Execute the to rva operation for the current toolkit workflow. |
| `_parse_load_config` | function | 831 | Support parse load config processing for internal toolkit callers. |
| `u16_at` | function | 847 | Execute the u16 at operation for the current toolkit workflow. |
| `u32_at` | function | 851 | Execute the u32 at operation for the current toolkit workflow. |
| `parse_pe32` | function | 872 | Parse pe32 for the current toolkit workflow. |
