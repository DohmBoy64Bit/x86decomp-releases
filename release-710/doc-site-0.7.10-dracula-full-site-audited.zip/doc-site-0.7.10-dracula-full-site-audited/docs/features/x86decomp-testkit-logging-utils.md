---
title: x86decomp_testkit.logging_utils
description: Source-derived module page for x86decomp_testkit.logging_utils in x86decomp
  0.7.10.
---

# `x86decomp_testkit.logging_utils`

- **Source path:** `test-suite/src/x86decomp_testkit/logging_utils.py`
- **SHA-256:** `0cbf9084920bee2069ea38f4b3105b913a6ac88d8ce545582f7a319cf40cfbfa`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.logging_utils` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `JsonlEventLogger` | class | 15 | Coordinate jsonl event logger behavior for the current toolkit workflow. |
| `__init__` | function | 17 | Initialize the instance with validated constructor state. |
| `emit` | function | 22 | Execute the emit operation for the current toolkit workflow. |
| `configure_logging` | function | 36 | Execute the configure logging operation for the current toolkit workflow. |
