---
title: x86decomp.angr_backend
description: Source-derived module page for x86decomp.angr_backend in x86decomp 0.7.10.
---

# `x86decomp.angr_backend`

- **Source path:** `src/x86decomp/angr_backend.py`
- **SHA-256:** `65a806874de433e75550e45759ce6ace0bf9fdcfdcf27fb179c3b90f73f9d0be`
- **Module docstring:** Optional angr comparative symbolic execution backend for bounded code blobs.
- **AST symbols:** 11

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_load_angr` | function | 18 | Support load angr processing for internal toolkit callers. |
| `_arch_name` | function | 28 | Support arch name processing for internal toolkit callers. |
| `_summaries` | function | 37 | Support summaries processing for internal toolkit callers. |
| `_counterexample` | function | 113 | Support counterexample processing for internal toolkit callers. |
| `angr_bounded_compare` | function | 132 | Execute the angr bounded compare operation for the current toolkit workflow. |
| `angr_bounded_compare_files` | function | 178 | Execute the angr bounded compare files operation for the current toolkit workflow. |
| `_load_memory_harness` | function | 187 | Support load memory harness processing for internal toolkit callers. |
| `_memory_summaries` | function | 215 | Support memory summaries processing for internal toolkit callers. |
| `_memory_counterexample` | function | 383 | Support memory counterexample processing for internal toolkit callers. |
| `angr_memory_alias_compare` | function | 413 | Execute the angr memory alias compare operation for the current toolkit workflow. |
| `angr_memory_alias_compare_files` | function | 452 | Execute the angr memory alias compare files operation for the current toolkit workflow. |
