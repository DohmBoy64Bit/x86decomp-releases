---
title: x86decomp.dynamorio
description: Source-derived module page for x86decomp.dynamorio in x86decomp 0.7.10.
---

# `x86decomp.dynamorio`

- **Source path:** `src/x86decomp/dynamorio.py`
- **SHA-256:** `8568a98326d91a775f2feec1847e8d3230c58253e1b015c3ee75dcb9b0d8b30d`
- **Module docstring:** DynamoRIO drcov execution and text-log normalization.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `parse_drcov_text` | function | 34 | Parse a drcov ``-dump_text`` log into stable module/block records. |
| `run_drcov_trace` | function | 118 | Execute an authorized program under drcov and normalize produced logs. |
