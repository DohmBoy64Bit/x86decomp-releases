---
title: x86decomp.governance.campaigns
description: Source-derived module page for x86decomp.governance.campaigns in x86decomp
  0.7.10.
---

# `x86decomp.governance.campaigns`

- **Source path:** `src/x86decomp/governance/campaigns.py`
- **SHA-256:** `d605a3e6f607bae80fcedc86f800c94afc07cab70804233a77bc1b2d351e731a`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.campaigns` module.
- **AST symbols:** 17

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `CampaignEngine` | class | 14 | Persistent, deterministic campaign control and next-action planning. |
| `__init__` | function | 17 | Initialize the instance with validated constructor state. |
| `create` | function | 22 | Create create for the current toolkit workflow. |
| `_validate_budget` | function | 44 | Support validate budget processing for internal toolkit callers. |
| `transition` | function | 56 | Execute the transition operation for the current toolkit workflow. |
| `start` | function | 75 | Execute the start operation for the current toolkit workflow. |
| `pause` | function | 79 | Execute the pause operation for the current toolkit workflow. |
| `resume` | function | 83 | Execute the resume operation for the current toolkit workflow. |
| `stop` | function | 87 | Execute the stop operation for the current toolkit workflow. |
| `consume_budget` | function | 91 | Execute the consume budget operation for the current toolkit workflow. |
| `branch` | function | 116 | Execute the branch operation for the current toolkit workflow. |
| `get_branch` | function | 134 | Execute the get branch operation for the current toolkit workflow. |
| `snapshot` | function | 142 | Execute the snapshot operation for the current toolkit workflow. |
| `_decision` | function | 152 | Support decision processing for internal toolkit callers. |
| `plan_next` | function | 158 | Execute the plan next operation for the current toolkit workflow. |
| `get` | function | 191 | Execute the get operation for the current toolkit workflow. |
| `list` | function | 202 | Execute the list operation for the current toolkit workflow. |
