---
title: x86decomp.models
description: Source-derived module page for x86decomp.models in x86decomp 0.7.10.
---

# `x86decomp.models`

- **Source path:** `src/x86decomp/models.py`
- **SHA-256:** `703196ad755b9e7b0059bb551a2e858928c26252e2587a0d3d47be5995750a5b`
- **Module docstring:** Stable enums and dataclasses used by evidence and verification contracts.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `EvidenceKind` | class | 12 | Coordinate evidence kind behavior for the current toolkit workflow. |
| `ClaimState` | class | 23 | Coordinate claim state behavior for the current toolkit workflow. |
| `VerificationStatus` | class | 31 | Coordinate verification status behavior for the current toolkit workflow. |
| `EvidenceItem` | class | 39 | Store validated evidence item fields used by toolkit reports and adapters. |
| `to_dict` | function | 51 | Return a serializable dictionary representation. |
| `Claim` | class | 59 | Store validated claim fields used by toolkit reports and adapters. |
| `to_dict` | function | 72 | Return a serializable dictionary representation. |
