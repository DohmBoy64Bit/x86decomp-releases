---
title: x86decomp.native.cli
description: Source-derived module page for x86decomp.native.cli in x86decomp 0.7.10.
---

# `x86decomp.native.cli`

- **Source path:** `src/x86decomp/native/cli.py`
- **SHA-256:** `3755308d665cec66eaa11cf01f7fd58860427302731f4c3891cc89eaee8db95e`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.cli` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_json_file` | function | 27 | Load and parse JSON content from a filesystem path. |
| `build_parser` | function | 33 | Build the argparse parser for this command surface. |
| `dispatch` | function | 91 | Dispatch parsed command arguments to the matching implementation. |
| `main` | function | 146 | Run the command-line entry point and return its process status. |
