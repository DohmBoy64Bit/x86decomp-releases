---
title: x86decomp.project
description: Source-derived module page for x86decomp.project in x86decomp 0.7.10.
---

# `x86decomp.project`

- **Source path:** `src/x86decomp/project.py`
- **SHA-256:** `7a18a8f58988872f1d61a6a3fc15e39f189433567bd9730b7aa108288e8e92da`
- **Module docstring:** Project initialization, architecture dispatch, and integrity verification.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `initialize_project` | function | 61 | Initialize project for the current toolkit workflow. |
| `_resolve_binary_path` | function | 152 | Support resolve binary path processing for internal toolkit callers. |
| `verify_project` | function | 166 | Verify project for the current toolkit workflow. |
| `require_valid_project` | function | 226 | Execute the require valid project operation for the current toolkit workflow. |
