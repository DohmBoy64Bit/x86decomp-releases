---
title: x86decomp.artifacts
description: Source-derived module page for x86decomp.artifacts in x86decomp 0.7.10.
---

# `x86decomp.artifacts`

- **Source path:** `src/x86decomp/artifacts.py`
- **SHA-256:** `ba1e61fc66c5daf8dd5ec50ded74de9831967a54f533c398b1fbed2abd7f8727`
- **Module docstring:** Function artifact import and validation.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `function_id_from_rva` | function | 16 | Execute the function id from rva operation for the current toolkit workflow. |
| `validate_function_manifest` | function | 23 | Validate function manifest for the current toolkit workflow. |
| `import_function_artifact` | function | 47 | Execute the import function artifact operation for the current toolkit workflow. |
| `verify_function_artifact` | function | 78 | Verify function artifact for the current toolkit workflow. |
