---
title: x86decomp_testkit.self_tests.test_cli_and_installation
description: Source-derived module page for x86decomp_testkit.self_tests.test_cli_and_installation
  in x86decomp 0.7.10.
---

# `x86decomp_testkit.self_tests.test_cli_and_installation`

- **Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py`
- **SHA-256:** `a732ea719dcdebc30e0c4a2bdfb75be4c74ebd55ce96ddc99c70faf3a4ac2092`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.self_tests.test_cli_and_installation` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `test_cli_init_config_catalog_and_missing_config` | function | 15 | Verify cli init config catalog and missing config behavior. |
| `test_install_python_command_and_failure` | function | 25 | Verify install python command and failure behavior. |
| `run_ok` | function | 31 | Run ok for the current toolkit workflow. |
| `run_bad` | function | 40 | Run bad for the current toolkit workflow. |
