---
title: x86decomp.test_bundle
description: Source-derived module page for x86decomp.test_bundle in x86decomp 0.7.10.
---

# `x86decomp.test_bundle`

- **Source path:** `src/x86decomp/test_bundle.py`
- **SHA-256:** `e39fa02455b0bffa5ff85455eaf86bbaad76921df269e3b5cd8c7dc188cb8de3`
- **Module docstring:** Safe, static-only ingestion and analysis of user-supplied test bundles.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `BundleLimits` | class | 49 | Store validated bundle limits fields used by toolkit reports and adapters. |
| `_safe_member_path` | function | 57 | Support safe member path processing for internal toolkit callers. |
| `_is_symlink` | function | 71 | Support is symlink processing for internal toolkit callers. |
| `_validate_archive_infos` | function | 77 | Support validate archive infos processing for internal toolkit callers. |
| `_extract_safely` | function | 107 | Support extract safely processing for internal toolkit callers. |
| `_manifest_artifacts` | function | 139 | Support manifest artifacts processing for internal toolkit callers. |
| `_single_role` | function | 193 | Support single role processing for internal toolkit callers. |
| `create_test_bundle` | function | 201 | Create a deterministic authorized static test bundle. |
| `inspect_test_bundle` | function | 288 | Verify and statically inspect a test bundle without executing its contents. |
