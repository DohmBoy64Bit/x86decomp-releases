---
title: x86decomp_testkit.adapters.detection
description: Source-derived module page for x86decomp_testkit.adapters.detection in
  x86decomp 0.7.10.
---

# `x86decomp_testkit.adapters.detection`

- **Source path:** `test-suite/src/x86decomp_testkit/adapters/detection.py`
- **SHA-256:** `0e2e601a66a26d0789cec226e04eaff565d3ca56f207721393fecd69a3c2245f`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.adapters.detection` module.
- **AST symbols:** 11

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_module_version` | function | 18 | Support module version processing for internal toolkit callers. |
| `_run_version` | function | 38 | Support run version processing for internal toolkit callers. |
| `_windows_executable_suffixes` | function | 56 | Support windows executable suffixes processing for internal toolkit callers. |
| `_prefer_windows_executable` | function | 61 | Support prefer windows executable processing for internal toolkit callers. |
| `_candidate_from_root` | function | 73 | Support candidate from root processing for internal toolkit callers. |
| `_known_windows_msvc_roots` | function | 97 | Support known windows msvc roots processing for internal toolkit callers. |
| `_find_recursive` | function | 125 | Support find recursive processing for internal toolkit callers. |
| `_with_capabilities` | function | 140 | Support with capabilities processing for internal toolkit callers. |
| `_detect_http_endpoint` | function | 153 | Support detect http endpoint processing for internal toolkit callers. |
| `detect_adapter` | function | 174 | Execute the detect adapter operation for the current toolkit workflow. |
| `detect_all` | function | 295 | Execute the detect all operation for the current toolkit workflow. |
