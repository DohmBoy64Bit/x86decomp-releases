---
title: x86decomp.compiler_worker
description: Source-derived module page for x86decomp.compiler_worker in x86decomp
  0.7.10.
---

# `x86decomp.compiler_worker`

- **Source path:** `src/x86decomp/compiler_worker.py`
- **SHA-256:** `587489d60ee4c66870a3fb37ecadfb1f03d675902a5bb7438c066e6e9571cec9`
- **Module docstring:** Isolated compiler-worker facade.
- **AST symbols:** 1

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `run_compiler_worker` | function | 23 | Run compiler worker for the current toolkit workflow. |
