---
title: x86decomp.compiler_lab
description: Source-derived module page for x86decomp.compiler_lab in x86decomp 0.7.10.
---

# `x86decomp.compiler_lab`

- **Source path:** `src/x86decomp/compiler_lab.py`
- **SHA-256:** `7feb0c4fe8f912f3ecd72216a67be512c76e0ab0a80ded41c0a32cc9c7a03b82`
- **Module docstring:** Compiler-profile experiment matrix, caching, ranking, and provenance.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_variant_arguments` | function | 16 | Support variant arguments processing for internal toolkit callers. |
| `run_compiler_lab` | function | 29 | Run compiler lab for the current toolkit workflow. |
