---
title: x86decomp_testkit.adapters.capabilities
description: Source-derived module page for x86decomp_testkit.adapters.capabilities
  in x86decomp 0.7.10.
---

# `x86decomp_testkit.adapters.capabilities`

- **Source path:** `test-suite/src/x86decomp_testkit/adapters/capabilities.py`
- **SHA-256:** `e0ddf047e75550e1a2a0263951f9bc275753d355fa4b096d76d1c89a9da7b756`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.adapters.capabilities` module.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `CapabilityResult` | class | 22 | Store validated capability result fields used by toolkit reports and adapters. |
| `to_dict` | function | 29 | Return a serializable dictionary representation. |
| `host_is_loopback` | function | 34 | Execute the host is loopback operation for the current toolkit workflow. |
| `endpoint_is_allowed` | function | 50 | Execute the endpoint is allowed operation for the current toolkit workflow. |
| `normalize_endpoint` | function | 58 | Normalize endpoint for the current toolkit workflow. |
| `probe_openai_compatible_endpoint` | function | 69 | Execute the probe openai compatible endpoint operation for the current toolkit workflow. |
| `capabilities_from_adapters` | function | 97 | Execute the capabilities from adapters operation for the current toolkit workflow. |
| `capability_map` | function | 129 | Execute the capability map operation for the current toolkit workflow. |
| `write_capability_report` | function | 134 | Write capability report for the current toolkit workflow. |
