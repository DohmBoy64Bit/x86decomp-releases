---
title: x86decomp.assembly.cli
description: Source-derived module page for x86decomp.assembly.cli in x86decomp 0.7.10.
---

# `x86decomp.assembly.cli`

- **Source path:** `src/x86decomp/assembly/cli.py`
- **SHA-256:** `06713b53c7dfcb531b224fa549405e7e34d3d72663eb588bf90e141f524e1545`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.assembly.cli` module.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_json_file` | function | 21 | Load and parse JSON content from a filesystem path. |
| `_json_array` | function | 29 | Support json array processing for internal toolkit callers. |
| `_int` | function | 42 | Support int processing for internal toolkit callers. |
| `_emit` | function | 47 | Support emit processing for internal toolkit callers. |
| `build_parser` | function | 54 | Build the argparse parser for this command surface. |
| `dispatch` | function | 143 | Dispatch parsed command arguments to the matching implementation. |
| `main` | function | 246 | Run the command-line entry point and return its process status. |
