---
title: x86decomp.canonical
description: Source-derived module page for x86decomp.canonical in x86decomp 0.7.10.
---

# `x86decomp.canonical`

- **Source path:** `src/x86decomp/canonical.py`
- **SHA-256:** `61600271365676393a818bf40a285c9623b00229c3edd7b08aae193feba96ebc`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.canonical` module.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_subparsers` | function | 65 | Support subparsers processing for internal toolkit callers. |
| `_source_parsers` | function | 73 | Support source parsers processing for internal toolkit callers. |
| `_group_parsers` | function | 81 | Support group parsers processing for internal toolkit callers. |
| `_leaf_parsers` | function | 90 | Support leaf parsers processing for internal toolkit callers. |
| `_route_owner` | function | 99 | Support route owner processing for internal toolkit callers. |
| `canonical_routes` | function | 120 | Execute the canonical routes operation for the current toolkit workflow. |
| `canonical_groups` | function | 132 | Execute the canonical groups operation for the current toolkit workflow. |
| `command_catalog` | function | 137 | Execute the command catalog operation for the current toolkit workflow. |
| `register_canonical_commands` | function | 161 | Execute the register canonical commands operation for the current toolkit workflow. |
| `dispatch` | function | 205 | Dispatch parsed command arguments to the matching implementation. |
| `build_parser` | function | 215 | Build the argparse parser for this command surface. |
| `main` | function | 226 | Run the command-line entry point and return its process status. |
