---
title: x86decomp.synthetic_corpus
description: Source-derived module page for x86decomp.synthetic_corpus in x86decomp
  0.7.10.
---

# `x86decomp.synthetic_corpus`

- **Source path:** `src/x86decomp/synthetic_corpus.py`
- **SHA-256:** `432382a2bab467462c312306adf333e3151c8a28ae2ece0f4e7f6afd42bc5358`
- **Module docstring:** Deterministic ground-truth source corpus generation.
- **AST symbols:** 15

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_symbol` | function | 25 | Support symbol processing for internal toolkit callers. |
| `_c_arithmetic` | function | 35 | Support c arithmetic processing for internal toolkit callers. |
| `_c_branches` | function | 49 | Support c branches processing for internal toolkit callers. |
| `_c_loop` | function | 66 | Support c loop processing for internal toolkit callers. |
| `_c_switch` | function | 84 | Support c switch processing for internal toolkit callers. |
| `_c_struct_alias` | function | 100 | Support c struct alias processing for internal toolkit callers. |
| `_c_bitfield` | function | 124 | Support c bitfield processing for internal toolkit callers. |
| `_c_float` | function | 144 | Support c float processing for internal toolkit callers. |
| `_c_indirect` | function | 158 | Support c indirect processing for internal toolkit callers. |
| `_cpp_virtual` | function | 170 | Support cpp virtual processing for internal toolkit callers. |
| `_cpp_multiple_inheritance` | function | 194 | Support cpp multiple inheritance processing for internal toolkit callers. |
| `_cpp_exception` | function | 211 | Support cpp exception processing for internal toolkit callers. |
| `_cpp_template` | function | 228 | Support cpp template processing for internal toolkit callers. |
| `generate_synthetic_corpus` | function | 256 | Generate deterministic source cases and a compiler-corpus input manifest. |
| `verify_synthetic_corpus` | function | 344 | Verify synthetic corpus for the current toolkit workflow. |
