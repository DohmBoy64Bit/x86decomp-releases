---
title: x86decomp.reconstruction.capsules
description: Source-derived module page for x86decomp.reconstruction.capsules in x86decomp
  0.7.10.
---

# `x86decomp.reconstruction.capsules`

- **Source path:** `src/x86decomp/reconstruction/capsules.py`
- **SHA-256:** `2e2f3d2c8a5673c7ba22e71738deccd814c5cb951f83515d48ce1547dfac82a6`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.capsules` module.
- **AST symbols:** 6

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `Capsules` | class | 12 | Coordinate capsules behavior for the current toolkit workflow. |
| `__init__` | function | 14 | Initialize the instance with validated constructor state. |
| `create` | function | 17 | Create create for the current toolkit workflow. |
| `inspect` | function | 34 | Execute the inspect operation for the current toolkit workflow. |
| `verify` | function | 39 | Verify verify for the current toolkit workflow. |
| `reproduce` | function | 54 | Execute the reproduce operation for the current toolkit workflow. |
