---
title: x86decomp.governance.cli
description: Source-derived module page for x86decomp.governance.cli in x86decomp
  0.7.10.
---

# `x86decomp.governance.cli`

- **Source path:** `src/x86decomp/governance/cli.py`
- **SHA-256:** `71757504bd67a0c7bdc823bfda82d252aa308d284453ca4f58b6a8d1b293163d`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.cli` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_store` | function | 30 | Open the project store requested by parsed command arguments. |
| `build_parser` | function | 35 | Build the argparse parser for this command surface. |
| `dispatch` | function | 130 | Dispatch parsed command arguments to the matching implementation. |
| `main` | function | 224 | Run the command-line entry point and return its process status. |
