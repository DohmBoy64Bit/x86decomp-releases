---
title: x86decomp.toolchains
description: Source-derived module page for x86decomp.toolchains in x86decomp 0.7.10.
---

# `x86decomp.toolchains`

- **Source path:** `src/x86decomp/toolchains.py`
- **SHA-256:** `5bd47468fa9b0574ba82a60bec59d7e1b221760aa49af27ce49cd033c1bfd622`
- **Module docstring:** User-owned compiler toolchain registry; proprietary binaries are never copied.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `register_toolchain` | function | 12 | Execute the register toolchain operation for the current toolkit workflow. |
| `verify_toolchain` | function | 47 | Verify toolchain for the current toolkit workflow. |
