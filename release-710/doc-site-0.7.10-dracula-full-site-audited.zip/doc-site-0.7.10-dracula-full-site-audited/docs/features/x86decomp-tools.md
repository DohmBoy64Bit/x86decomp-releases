---
title: x86decomp.tools
description: Source-derived module page for x86decomp.tools in x86decomp 0.7.10.
---

# `x86decomp.tools`

- **Source path:** `src/x86decomp/tools.py`
- **SHA-256:** `8ea17b0382ccc5da5cf930dd702d7e0e73109e88a6e6fa1dcbea7e62256363fb`
- **Module docstring:** External-tool discovery and version capture.
- **AST symbols:** 3

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_capture` | function | 22 | Support capture processing for internal toolkit callers. |
| `discover_analyze_headless` | function | 40 | Discover analyze headless for the current toolkit workflow. |
| `snapshot_tools` | function | 61 | Execute the snapshot tools operation for the current toolkit workflow. |
