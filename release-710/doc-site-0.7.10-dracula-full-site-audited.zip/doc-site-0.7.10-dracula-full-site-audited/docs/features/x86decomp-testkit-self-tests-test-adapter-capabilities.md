---
title: x86decomp_testkit.self_tests.test_adapter_capabilities
description: Source-derived module page for x86decomp_testkit.self_tests.test_adapter_capabilities
  in x86decomp 0.7.10.
---

# `x86decomp_testkit.self_tests.test_adapter_capabilities`

- **Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_adapter_capabilities.py`
- **SHA-256:** `29edcce9190f01a43c81eaa7a38a65e12ff049958a4bf735d2685d329b134fd9`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.self_tests.test_adapter_capabilities` module.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_ModelsHandler` | class | 16 | Coordinate models handler behavior for the current toolkit workflow. |
| `do_GET` | function | 18 | Execute the do g e t operation for the current toolkit workflow. |
| `log_message` | function | 31 | Execute the log message operation for the current toolkit workflow. |
| `_config` | function | 36 | Support config processing for internal toolkit callers. |
| `test_lm_studio_http_satisfies_openai_capability_without_product_aliasing` | function | 41 | Verify lm studio http satisfies openai capability without product aliasing behavior. |
| `test_non_loopback_http_endpoint_requires_network_opt_in` | function | 72 | Verify non loopback http endpoint requires network opt in behavior. |
| `test_loopback_host_classifier_is_strict` | function | 80 | Verify loopback host classifier is strict behavior. |
