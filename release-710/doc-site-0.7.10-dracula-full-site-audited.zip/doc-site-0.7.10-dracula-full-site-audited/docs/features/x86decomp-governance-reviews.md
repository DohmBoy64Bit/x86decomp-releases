---
title: x86decomp.governance.reviews
description: Source-derived module page for x86decomp.governance.reviews in x86decomp
  0.7.10.
---

# `x86decomp.governance.reviews`

- **Source path:** `src/x86decomp/governance/reviews.py`
- **SHA-256:** `2d56d02e53a18cf0d8fcf2542d302a30923c06e9d09e4ab62e8a6b3624cbffc8`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.reviews` module.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ReviewQueue` | class | 13 | Coordinate review queue behavior for the current toolkit workflow. |
| `__init__` | function | 15 | Initialize the instance with validated constructor state. |
| `create` | function | 20 | Create create for the current toolkit workflow. |
| `assign` | function | 34 | Execute the assign operation for the current toolkit workflow. |
| `decide` | function | 49 | Execute the decide operation for the current toolkit workflow. |
| `lock` | function | 75 | Execute the lock operation for the current toolkit workflow. |
| `get` | function | 85 | Execute the get operation for the current toolkit workflow. |
| `list` | function | 98 | Execute the list operation for the current toolkit workflow. |
