---
title: x86decomp.native.runtime
description: Source-derived module page for x86decomp.native.runtime in x86decomp
  0.7.10.
---

# `x86decomp.native.runtime`

- **Source path:** `src/x86decomp/native/runtime.py`
- **SHA-256:** `6e43a6f773e0c67ad6eaedd3b8177b5a1f853cd9dd829296eaa952852f3c526d`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.runtime` module.
- **AST symbols:** 6

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `RuntimeValidation` | class | 15 | Coordinate runtime validation behavior for the current toolkit workflow. |
| `__init__` | function | 17 | Initialize the instance with validated constructor state. |
| `validate_image` | function | 21 | Validate image for the current toolkit workflow. |
| `launch` | function | 34 | Execute the launch operation for the current toolkit workflow. |
| `map_crash` | function | 50 | Execute the map crash operation for the current toolkit workflow. |
| `_record` | function | 57 | Support record processing for internal toolkit callers. |
