---
title: x86decomp.governance.__init__
description: Source-derived module page for x86decomp.governance.__init__ in x86decomp
  0.7.10.
---

# `x86decomp.governance.__init__`

- **Source path:** `src/x86decomp/governance/__init__.py`
- **SHA-256:** `a0483ba8e8314f9c9ba3a8387147195d183c6c7a47b067e2f6a92354f6612c00`
- **Module docstring:** Evidence governance and convergence capabilities.
- **AST symbols:** 0

No classes or functions were declared in this module.
