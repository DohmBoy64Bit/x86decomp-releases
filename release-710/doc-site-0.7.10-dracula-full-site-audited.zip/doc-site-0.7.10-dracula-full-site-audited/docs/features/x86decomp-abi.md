---
title: x86decomp.abi
description: Source-derived module page for x86decomp.abi in x86decomp 0.7.10.
---

# `x86decomp.abi`

- **Source path:** `src/x86decomp/abi.py`
- **SHA-256:** `262520e2ad900c65f75520d0965926f2b9229456520c82900f0d6a50791d9f4b`
- **Module docstring:** Explicit x86 ABI contracts and bounded static compatibility checks.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `CallingConvention` | class | 15 | Coordinate calling convention behavior for the current toolkit workflow. |
| `FloatMode` | class | 25 | Coordinate float mode behavior for the current toolkit workflow. |
| `ABIContract` | class | 35 | Store validated a b i contract fields used by toolkit reports and adapters. |
| `from_dict` | function | 49 | Execute the from dict operation for the current toolkit workflow. |
| `optional_nonnegative` | function | 61 | Execute the optional nonnegative operation for the current toolkit workflow. |
| `load_abi_contract` | function | 92 | Load abi contract for the current toolkit workflow. |
| `analyze_abi` | function | 97 | Execute the analyze abi operation for the current toolkit workflow. |
| `validate_abi` | function | 160 | Validate abi for the current toolkit workflow. |
