---
title: x86decomp.ground_truth
description: Source-derived module page for x86decomp.ground_truth in x86decomp 0.7.10.
---

# `x86decomp.ground_truth`

- **Source path:** `src/x86decomp/ground_truth.py`
- **SHA-256:** `8e4ada1866c092d9594a5478abc51ee6d17de7cb2a344e8e29e7115906ab4eef`
- **Module docstring:** Reproducible compiler/version ground-truth corpus builder.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_resolve_executable` | function | 24 | Support resolve executable processing for internal toolkit callers. |
| `_version` | function | 37 | Support version processing for internal toolkit callers. |
| `_expand_flag_matrix` | function | 48 | Support expand flag matrix processing for internal toolkit callers. |
| `build_ground_truth_corpus` | function | 75 | Build ground truth corpus for the current toolkit workflow. |
| `verify_ground_truth_corpus` | function | 195 | Verify ground truth corpus for the current toolkit workflow. |
| `compare_ground_truth_corpora` | function | 216 | Compare successful corpus builds across compiler/version reports. |
| `create_builtin_manifest` | function | 298 | Create builtin manifest for the current toolkit workflow. |
