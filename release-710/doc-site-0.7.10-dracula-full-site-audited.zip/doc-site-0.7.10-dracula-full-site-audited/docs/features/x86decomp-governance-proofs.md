---
title: x86decomp.governance.proofs
description: Source-derived module page for x86decomp.governance.proofs in x86decomp
  0.7.10.
---

# `x86decomp.governance.proofs`

- **Source path:** `src/x86decomp/governance/proofs.py`
- **SHA-256:** `b51e67cd6eb1ff9f52833e347d8688ad51eb770b6f5c6f9a0baabd10da42fb58`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.proofs` module.
- **AST symbols:** 13

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ProofLedger` | class | 20 | Coordinate proof ledger behavior for the current toolkit workflow. |
| `__init__` | function | 22 | Initialize the instance with validated constructor state. |
| `create_obligation` | function | 27 | Create obligation for the current toolkit workflow. |
| `add_result` | function | 40 | Execute the add result operation for the current toolkit workflow. |
| `obligation` | function | 56 | Execute the obligation operation for the current toolkit workflow. |
| `result` | function | 68 | Execute the result operation for the current toolkit workflow. |
| `evaluate` | function | 78 | Execute the evaluate operation for the current toolkit workflow. |
| `ProofBundle` | class | 86 | Deterministic, path-safe, independently verifiable proof package. |
| `_zip_info` | function | 90 | Support zip info processing for internal toolkit callers. |
| `export` | function | 98 | Execute the export operation for the current toolkit workflow. |
| `_validate_member` | function | 140 | Support validate member processing for internal toolkit callers. |
| `verify` | function | 147 | Verify verify for the current toolkit workflow. |
| `inspect` | function | 193 | Execute the inspect operation for the current toolkit workflow. |
