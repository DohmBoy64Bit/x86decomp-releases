---
title: x86decomp.native.windows_tools
description: Source-derived module page for x86decomp.native.windows_tools in x86decomp
  0.7.10.
---

# `x86decomp.native.windows_tools`

- **Source path:** `src/x86decomp/native/windows_tools.py`
- **SHA-256:** `b7faf19779e497b1338a585113dfc053663d02ea92d3630a78d6c57660d01cfe`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.windows_tools` module.
- **AST symbols:** 6

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `discover_ghidra_launcher` | function | 14 | Discover ghidra launcher for the current toolkit workflow. |
| `write_response_file` | function | 30 | Write response file for the current toolkit workflow. |
| `quote` | function | 33 | Execute the quote operation for the current toolkit workflow. |
| `WindowsTools` | class | 41 | Coordinate windows tools behavior for the current toolkit workflow. |
| `__init__` | function | 43 | Initialize the instance with validated constructor state. |
| `doctor` | function | 47 | Execute the doctor operation for the current toolkit workflow. |
