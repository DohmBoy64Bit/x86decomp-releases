---
title: x86decomp_testkit.self_tests.test_inventory_reports_process
description: Source-derived module page for x86decomp_testkit.self_tests.test_inventory_reports_process
  in x86decomp 0.7.10.
---

# `x86decomp_testkit.self_tests.test_inventory_reports_process`

- **Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py`
- **SHA-256:** `3e2b70c05615592089e98fb5dbd393bbeaae40818df0f09db942bf63bdd13303`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.self_tests.test_inventory_reports_process` module.
- **AST symbols:** 5

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_mini_toolkit` | function | 16 | Support mini toolkit processing for internal toolkit callers. |
| `test_inventory_catalog_and_public_coverage` | function | 32 | Verify inventory catalog and public coverage behavior. |
| `test_junit_process_logging_and_reports` | function | 54 | Verify junit process logging and reports behavior. |
| `test_suite_schemas_and_catalog_are_valid` | function | 84 | Verify suite schemas and catalog are valid behavior. |
| `test_recursive_inventory_includes_capability_packages_and_nested_schemas` | function | 103 | Verify recursive inventory includes capability packages and nested schemas behavior. |
