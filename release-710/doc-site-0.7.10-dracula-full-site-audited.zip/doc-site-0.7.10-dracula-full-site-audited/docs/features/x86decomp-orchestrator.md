---
title: x86decomp.orchestrator
description: Source-derived module page for x86decomp.orchestrator in x86decomp 0.7.10.
---

# `x86decomp.orchestrator`

- **Source path:** `src/x86decomp/orchestrator.py`
- **SHA-256:** `fab775aab1d71a2fa1a728147b8792302350689496896caa3a1936a502dbdfd7`
- **Module docstring:** Durable, resumable pipeline orchestration.
- **AST symbols:** 28

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `JobState` | class | 32 | Coordinate job state behavior for the current toolkit workflow. |
| `PipelineStage` | class | 87 | Store validated pipeline stage fields used by toolkit reports and adapters. |
| `from_dict` | function | 102 | Execute the from dict operation for the current toolkit workflow. |
| `strings` | function | 112 | Execute the strings operation for the current toolkit workflow. |
| `PipelineManifest` | class | 157 | Store validated pipeline manifest fields used by toolkit reports and adapters. |
| `load` | function | 164 | Load load for the current toolkit workflow. |
| `Orchestrator` | class | 193 | Coordinate orchestrator behavior for the current toolkit workflow. |
| `__init__` | function | 195 | Initialize the instance with validated constructor state. |
| `close` | function | 226 | Execute the close operation for the current toolkit workflow. |
| `__enter__` | function | 230 | Enter the managed runtime context and return the active resource. |
| `__exit__` | function | 234 | Exit the managed runtime context and release owned resources. |
| `_transaction` | function | 238 | Support transaction processing for internal toolkit callers. |
| `register` | function | 242 | Execute the register operation for the current toolkit workflow. |
| `_idempotency_key` | function | 284 | Support idempotency key processing for internal toolkit callers. |
| `_event` | function | 309 | Support event processing for internal toolkit callers. |
| `_completed_result_is_intact` | function | 316 | Verify materialized outputs before reusing a succeeded job. |
| `_materialize_outputs` | function | 341 | Support materialize outputs processing for internal toolkit callers. |
| `_dependency_states` | function | 376 | Support dependency states processing for internal toolkit callers. |
| `run` | function | 387 | Run run for the current toolkit workflow. |
| `_set_state` | function | 420 | Support set state processing for internal toolkit callers. |
| `_run_stage` | function | 436 | Support run stage processing for internal toolkit callers. |
| `cancellation_requested` | function | 515 | Execute the cancellation requested operation for the current toolkit workflow. |
| `recover_stale_jobs` | function | 547 | Reset only RUNNING jobs whose durable heartbeat is older than the bound. |
| `cancel` | function | 592 | Execute the cancel operation for the current toolkit workflow. |
| `retry` | function | 612 | Execute the retry operation for the current toolkit workflow. |
| `_update_pipeline_status` | function | 638 | Support update pipeline status processing for internal toolkit callers. |
| `status` | function | 655 | Execute the status operation for the current toolkit workflow. |
| `create_default_pipeline` | function | 687 | Generate a concrete pipeline for the current project. |
