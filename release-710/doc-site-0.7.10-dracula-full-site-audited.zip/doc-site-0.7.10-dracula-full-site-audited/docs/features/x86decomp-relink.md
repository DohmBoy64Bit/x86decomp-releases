---
title: x86decomp.relink
description: Source-derived module page for x86decomp.relink in x86decomp 0.7.10.
---

# `x86decomp.relink`

- **Source path:** `src/x86decomp/relink.py`
- **SHA-256:** `b4ea5875ec158515fc1a9408a7c1b46845e605cb2e8f4ea9548bc6b052d76cbd`
- **Module docstring:** Manifest-driven full-image relink backend.
- **AST symbols:** 1

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `run_full_relink` | function | 23 | Run full relink for the current toolkit workflow. |
