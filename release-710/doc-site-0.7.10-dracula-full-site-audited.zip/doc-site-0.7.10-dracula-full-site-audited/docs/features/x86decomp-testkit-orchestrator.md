---
title: x86decomp_testkit.orchestrator
description: Source-derived module page for x86decomp_testkit.orchestrator in x86decomp
  0.7.10.
---

# `x86decomp_testkit.orchestrator`

- **Source path:** `test-suite/src/x86decomp_testkit/orchestrator.py`
- **SHA-256:** `5f99094a835bc81db82694f10972870b96644966531d9930359ae3319298b3a4`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.orchestrator` module.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `package_root` | function | 26 | Execute the package root operation for the current toolkit workflow. |
| `suite_root` | function | 31 | Execute the suite root operation for the current toolkit workflow. |
| `feature_catalog_path` | function | 38 | Execute the feature catalog path operation for the current toolkit workflow. |
| `run_all` | function | 43 | Run all for the current toolkit workflow. |
