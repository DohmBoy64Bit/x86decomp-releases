---
title: x86decomp.assembly.materialize
description: Source-derived module page for x86decomp.assembly.materialize in x86decomp
  0.7.10.
---

# `x86decomp.assembly.materialize`

- **Source path:** `src/x86decomp/assembly/materialize.py`
- **SHA-256:** `fc6ebc3aff941f6664c7e3b83b874401a86a1a1fc9608a587486046607b686a1`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.assembly.materialize` module.
- **AST symbols:** 16

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `AssemblerError` | class | 21 | Assembler failure with source line numbers retained for focused fallback. |
| `__init__` | function | 24 | Initialize the instance with validated constructor state. |
| `InstructionCandidate` | class | 31 | Store validated instruction candidate fields used by toolkit reports and adapters. |
| `end` | function | 43 | Execute the end operation for the current toolkit workflow. |
| `_capstone` | function | 48 | Support capstone processing for internal toolkit callers. |
| `_safe_symbol` | function | 58 | Support safe symbol processing for internal toolkit callers. |
| `_preferred_addresses` | function | 63 | Support preferred addresses processing for internal toolkit callers. |
| `_replace_address_token` | function | 81 | Support replace address token processing for internal toolkit callers. |
| `_instruction_candidates` | function | 94 | Support instruction candidates processing for internal toolkit callers. |
| `_render_source_with_line_map` | function | 190 | Support render source with line map processing for internal toolkit callers. |
| `_render_source` | function | 225 | Support render source processing for internal toolkit callers. |
| `discover_assembler` | function | 244 | Discover assembler for the current toolkit workflow. |
| `assemble_coff` | function | 268 | Execute the assemble coff operation for the current toolkit workflow. |
| `_unit_for_offset` | function | 321 | Support unit for offset processing for internal toolkit callers. |
| `verify_existing_source` | function | 326 | Assemble an existing source file and verify its resolved bytes exactly. |
| `materialize_function` | function | 384 | Materialize readable assembly and prove exact bytes, falling back per instruction. |
