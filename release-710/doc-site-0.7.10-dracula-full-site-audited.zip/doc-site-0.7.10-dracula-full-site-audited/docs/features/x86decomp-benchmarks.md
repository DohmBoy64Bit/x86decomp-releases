---
title: x86decomp.benchmarks
description: Source-derived module page for x86decomp.benchmarks in x86decomp 0.7.10.
---

# `x86decomp.benchmarks`

- **Source path:** `src/x86decomp/benchmarks.py`
- **SHA-256:** `495856330b73b3f9635160d77cea6d4e67ef6c7a9e8db14b908aa2c4ade3acf1`
- **Module docstring:** Ground-truth corpus runner and decomposed benchmark metrics.
- **AST symbols:** 3

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `classification_metrics` | function | 17 | Execute the classification metrics operation for the current toolkit workflow. |
| `_resolve` | function | 35 | Support resolve processing for internal toolkit callers. |
| `run_benchmark_corpus` | function | 42 | Run benchmark corpus for the current toolkit workflow. |
