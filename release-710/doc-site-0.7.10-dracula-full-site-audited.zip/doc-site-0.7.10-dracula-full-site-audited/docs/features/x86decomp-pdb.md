---
title: x86decomp.pdb
description: Source-derived module page for x86decomp.pdb in x86decomp 0.7.10.
---

# `x86decomp.pdb`

- **Source path:** `src/x86decomp/pdb.py`
- **SHA-256:** `cafd35f8251e24a91b6b01e36d651ef28b698fac11266a47c7daf9b5e9bd6179`
- **Module docstring:** Bounded MSF 7.0 / PDB inventory and PE identity correlation.
- **AST symbols:** 24

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_require` | function | 29 | Support require processing for internal toolkit callers. |
| `_u16` | function | 35 | Support u16 processing for internal toolkit callers. |
| `_u32` | function | 41 | Support u32 processing for internal toolkit callers. |
| `_cstring` | function | 47 | Support cstring processing for internal toolkit callers. |
| `_align4` | function | 57 | Support align4 processing for internal toolkit callers. |
| `PDBStream` | class | 63 | Store validated p d b stream fields used by toolkit reports and adapters. |
| `to_dict` | function | 70 | Return a serializable dictionary representation. |
| `PDBFile` | class | 81 | Store validated p d b file fields used by toolkit reports and adapters. |
| `to_dict` | function | 97 | Return a serializable dictionary representation. |
| `_MSF` | class | 129 | Coordinate m s f behavior for the current toolkit workflow. |
| `__init__` | function | 131 | Initialize the instance with validated constructor state. |
| `_block` | function | 159 | Support block processing for internal toolkit callers. |
| `_parse_directory` | function | 166 | Support parse directory processing for internal toolkit callers. |
| `stream` | function | 199 | Execute the stream operation for the current toolkit workflow. |
| `_parse_info` | function | 209 | Support parse info processing for internal toolkit callers. |
| `_parse_tpi` | function | 228 | Support parse tpi processing for internal toolkit callers. |
| `_parse_modules` | function | 276 | Support parse modules processing for internal toolkit callers. |
| `_parse_source_info` | function | 341 | Support parse source info processing for internal toolkit callers. |
| `_parse_section_contributions` | function | 390 | Support parse section contributions processing for internal toolkit callers. |
| `_parse_section_map` | function | 421 | Support parse section map processing for internal toolkit callers. |
| `_parse_dbi` | function | 453 | Support parse dbi processing for internal toolkit callers. |
| `_correlate_pe` | function | 566 | Support correlate pe processing for internal toolkit callers. |
| `parse_pdb_bytes` | function | 598 | Parse pdb bytes for the current toolkit workflow. |
| `parse_pdb` | function | 635 | Parse pdb for the current toolkit workflow. |
