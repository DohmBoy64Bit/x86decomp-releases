---
title: x86decomp_testkit.adapters.catalog
description: Source-derived module page for x86decomp_testkit.adapters.catalog in
  x86decomp 0.7.10.
---

# `x86decomp_testkit.adapters.catalog`

- **Source path:** `test-suite/src/x86decomp_testkit/adapters/catalog.py`
- **SHA-256:** `171feae0e00a5729a0dcb3f5f877bc2c7479e4560841217a1e8e478025dc672f`
- **Module docstring:** Provide the installed test-suite implementation for the `x86decomp_testkit.adapters.catalog` module.
- **AST symbols:** 1

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `adapter_catalog` | function | 7 | Execute the adapter catalog operation for the current toolkit workflow. |
