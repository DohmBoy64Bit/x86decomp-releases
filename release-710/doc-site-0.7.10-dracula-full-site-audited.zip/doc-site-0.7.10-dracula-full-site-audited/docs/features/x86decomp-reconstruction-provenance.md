---
title: x86decomp.reconstruction.provenance
description: Source-derived module page for x86decomp.reconstruction.provenance in
  x86decomp 0.7.10.
---

# `x86decomp.reconstruction.provenance`

- **Source path:** `src/x86decomp/reconstruction/provenance.py`
- **SHA-256:** `b769842f4ca5cdb45620fa14806c011fef749bdc2d0beb7716b41f50a8d518be`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.provenance` module.
- **AST symbols:** 11

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ProvenanceLedger` | class | 11 | Coordinate provenance ledger behavior for the current toolkit workflow. |
| `__init__` | function | 13 | Initialize the instance with validated constructor state. |
| `record` | function | 16 | Record record for the current toolkit workflow. |
| `get` | function | 27 | Execute the get operation for the current toolkit workflow. |
| `source` | function | 32 | Execute the source operation for the current toolkit workflow. |
| `binary` | function | 39 | Execute the binary operation for the current toolkit workflow. |
| `lock` | function | 45 | Execute the lock operation for the current toolkit workflow. |
| `unlock` | function | 52 | Execute the unlock operation for the current toolkit workflow. |
| `reconcile` | function | 58 | Execute the reconcile operation for the current toolkit workflow. |
| `impact` | function | 74 | Execute the impact operation for the current toolkit workflow. |
| `export` | function | 78 | Execute the export operation for the current toolkit workflow. |
