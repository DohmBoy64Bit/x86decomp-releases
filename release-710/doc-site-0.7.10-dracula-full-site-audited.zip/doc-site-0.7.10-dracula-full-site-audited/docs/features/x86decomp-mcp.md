---
title: x86decomp.mcp
description: Source-derived module page for x86decomp.mcp in x86decomp 0.7.10.
---

# `x86decomp.mcp`

- **Source path:** `src/x86decomp/mcp.py`
- **SHA-256:** `061836293bf188b96de9dca62dfda3710fd51c313a5eff738224eed135fd5e59`
- **Module docstring:** MCP 2025-06-18 client and evidence-gated Ghidra mutation journal.
- **AST symbols:** 27

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `MCPTool` | class | 23 | Store validated m c p tool fields used by toolkit reports and adapters. |
| `StdioMCPClient` | class | 30 | Coordinate stdio m c p client behavior for the current toolkit workflow. |
| `__init__` | function | 32 | Initialize the instance with validated constructor state. |
| `_send` | function | 49 | Support send processing for internal toolkit callers. |
| `_request` | function | 56 | Support request processing for internal toolkit callers. |
| `initialize` | function | 84 | Initialize initialize for the current toolkit workflow. |
| `_ensure_initialized` | function | 98 | Support ensure initialized processing for internal toolkit callers. |
| `list_tools` | function | 103 | Execute the list tools operation for the current toolkit workflow. |
| `call_tool` | function | 123 | Execute the call tool operation for the current toolkit workflow. |
| `close` | function | 128 | Execute the close operation for the current toolkit workflow. |
| `__enter__` | function | 142 | Enter the managed runtime context and return the active resource. |
| `__exit__` | function | 146 | Exit the managed runtime context and release owned resources. |
| `StreamableHTTPMCPClient` | class | 151 | Coordinate streamable h t t p m c p client behavior for the current toolkit workflow. |
| `__init__` | function | 153 | Initialize the instance with validated constructor state. |
| `_request` | function | 163 | Support request processing for internal toolkit callers. |
| `_notify` | function | 198 | Support notify processing for internal toolkit callers. |
| `initialize` | function | 208 | Initialize initialize for the current toolkit workflow. |
| `_ensure_initialized` | function | 215 | Support ensure initialized processing for internal toolkit callers. |
| `list_tools` | function | 220 | Execute the list tools operation for the current toolkit workflow. |
| `call_tool` | function | 226 | Execute the call tool operation for the current toolkit workflow. |
| `close` | function | 231 | Streamable HTTP has no persistent local process to close. |
| `is_probable_mutation` | function | 241 | Execute the is probable mutation operation for the current toolkit workflow. |
| `GhidraMCPGateway` | class | 247 | Separates read calls from hash-approved mutation transactions. |
| `__init__` | function | 250 | Initialize the instance with validated constructor state. |
| `read` | function | 258 | Read read for the current toolkit workflow. |
| `propose_mutation` | function | 266 | Execute the propose mutation operation for the current toolkit workflow. |
| `commit_mutation` | function | 293 | Execute the commit mutation operation for the current toolkit workflow. |
