---
title: x86decomp.governance.candidates
description: Source-derived module page for x86decomp.governance.candidates in x86decomp
  0.7.10.
---

# `x86decomp.governance.candidates`

- **Source path:** `src/x86decomp/governance/candidates.py`
- **SHA-256:** `68a8097e14ed00cfc4887bff181118924ac51afa4976c454ee8d7ee4863565e5`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.governance.candidates` module.
- **AST symbols:** 10

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `CandidateStore` | class | 15 | Coordinate candidate store behavior for the current toolkit workflow. |
| `__init__` | function | 17 | Initialize the instance with validated constructor state. |
| `create` | function | 23 | Create create for the current toolkit workflow. |
| `_clone_files` | function | 41 | Support clone files processing for internal toolkit callers. |
| `add_file` | function | 51 | Execute the add file operation for the current toolkit workflow. |
| `record_evaluation` | function | 83 | Record evaluation for the current toolkit workflow. |
| `compare` | function | 99 | Compare compare for the current toolkit workflow. |
| `transition` | function | 122 | Execute the transition operation for the current toolkit workflow. |
| `get` | function | 147 | Execute the get operation for the current toolkit workflow. |
| `list` | function | 163 | Execute the list operation for the current toolkit workflow. |
