---
title: x86decomp.objdiff_adapter
description: Source-derived module page for x86decomp.objdiff_adapter in x86decomp
  0.7.10.
---

# `x86decomp.objdiff_adapter`

- **Source path:** `src/x86decomp/objdiff_adapter.py`
- **SHA-256:** `a8e9ce06780f783f2ad9c6e50cf106fd0ecc1b82052d39fbbeeb1f40632a7d4b`
- **Module docstring:** Version-agnostic, manifest-driven objdiff CLI integration.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_resolve_executable` | function | 24 | Support resolve executable processing for internal toolkit callers. |
| `run_objdiff_manifest` | function | 39 | Run objdiff manifest for the current toolkit workflow. |
