---
title: x86decomp.native.matching
description: Source-derived module page for x86decomp.native.matching in x86decomp
  0.7.10.
---

# `x86decomp.native.matching`

- **Source path:** `src/x86decomp/native/matching.py`
- **SHA-256:** `4fbc421f01f6f432c888d431a243b4ba4f5166977a5f47adcafcc01d11cd0565`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.matching` module.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `rva_to_file_offset` | function | 16 | Execute the rva to file offset operation for the current toolkit workflow. |
| `extract_candidate` | function | 27 | Extract candidate for the current toolkit workflow. |
| `compare_function_bytes` | function | 36 | Compare function bytes for the current toolkit workflow. |
| `FunctionMatching` | class | 81 | Coordinate function matching behavior for the current toolkit workflow. |
| `__init__` | function | 83 | Initialize the instance with validated constructor state. |
| `batch` | function | 87 | Execute the batch operation for the current toolkit workflow. |
| `report` | function | 153 | Execute the report operation for the current toolkit workflow. |
| `mismatches` | function | 164 | Execute the mismatches operation for the current toolkit workflow. |
