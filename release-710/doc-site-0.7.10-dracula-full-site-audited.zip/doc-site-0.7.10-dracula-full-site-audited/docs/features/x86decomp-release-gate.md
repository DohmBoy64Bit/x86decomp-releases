---
title: x86decomp.release_gate
description: Source-derived module page for x86decomp.release_gate in x86decomp 0.7.10.
---

# `x86decomp.release_gate`

- **Source path:** `src/x86decomp/release_gate.py`
- **SHA-256:** `381121856f0ce249fe7e268be5f57d20bc6b7bc31b05c26b4056796629bce9c7`
- **Module docstring:** Target release acceptance gate.
- **AST symbols:** 4

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_workflow_gate` | function | 31 | Support workflow gate processing for internal toolkit callers. |
| `_claim_gate` | function | 65 | Support claim gate processing for internal toolkit callers. |
| `_pipeline_gate` | function | 79 | Support pipeline gate processing for internal toolkit callers. |
| `evaluate_release_gate` | function | 94 | Execute the evaluate release gate operation for the current toolkit workflow. |
