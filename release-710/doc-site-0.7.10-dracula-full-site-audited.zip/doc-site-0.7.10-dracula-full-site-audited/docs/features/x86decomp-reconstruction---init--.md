---
title: x86decomp.reconstruction.__init__
description: Source-derived module page for x86decomp.reconstruction.__init__ in x86decomp
  0.7.10.
---

# `x86decomp.reconstruction.__init__`

- **Source path:** `src/x86decomp/reconstruction/__init__.py`
- **SHA-256:** `52313d0bee948e0909b7dbad630958a9631187f643927aa9b604acf3184599c8`
- **Module docstring:** Project-scale reconstruction and proof-carrying source capabilities.
- **AST symbols:** 0

No classes or functions were declared in this module.
