---
title: x86decomp.local_llm.profiles
description: Source-derived module page for x86decomp.local_llm.profiles in x86decomp
  0.7.10.
---

# `x86decomp.local_llm.profiles`

- **Source path:** `src/x86decomp/local_llm/profiles.py`
- **SHA-256:** `6d956f6d013147c86d2ca4ff16d110b648871c7f78e31bb7426d268995521da2`
- **Module docstring:** Provider profiles for bounded local-model inference.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `provider_catalog` | function | 73 | Return the immutable built-in provider preset catalog. |
| `_normalized_base_url` | function | 89 | Support normalized base url processing for internal toolkit callers. |
| `is_loopback_host` | function | 106 | Return whether a hostname is an explicit local loopback identity. |
| `resolved_addresses_are_loopback` | function | 117 | Resolve a host and require every result to be loopback. |
| `create_profile` | function | 139 | Create and persist a validated provider profile. |
| `load_profile` | function | 179 | Load profile for the current toolkit workflow. |
| `validate_profile` | function | 187 | Validate and normalize a local-model profile. |
| `public_profile` | function | 248 | Return report-safe profile metadata without secret values. |
