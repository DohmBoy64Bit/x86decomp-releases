---
title: x86decomp.reconstruction.project_layout
description: Source-derived module page for x86decomp.reconstruction.project_layout
  in x86decomp 0.7.10.
---

# `x86decomp.reconstruction.project_layout`

- **Source path:** `src/x86decomp/reconstruction/project_layout.py`
- **SHA-256:** `b9143acf55abf6b8a4018e130cb249d146d1d04c0edebe8a8ad396ea8c76bc20`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.project_layout` module.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ProjectLayout` | class | 11 | Coordinate project layout behavior for the current toolkit workflow. |
| `__init__` | function | 13 | Initialize the instance with validated constructor state. |
| `create_module` | function | 17 | Create module for the current toolkit workflow. |
| `add_member` | function | 28 | Execute the add member operation for the current toolkit workflow. |
| `create_translation_unit` | function | 38 | Create translation unit for the current toolkit workflow. |
| `add_translation_unit_member` | function | 51 | Execute the add translation unit member operation for the current toolkit workflow. |
| `synthesize` | function | 61 | Deterministically group inventory records by explicit object/library/source hints. |
| `show_module` | function | 80 | Execute the show module operation for the current toolkit workflow. |
| `show_translation_unit` | function | 89 | Execute the show translation unit operation for the current toolkit workflow. |
| `list_modules` | function | 98 | Execute the list modules operation for the current toolkit workflow. |
| `explain_boundaries` | function | 103 | Execute the explain boundaries operation for the current toolkit workflow. |
| `export` | function | 108 | Execute the export operation for the current toolkit workflow. |
