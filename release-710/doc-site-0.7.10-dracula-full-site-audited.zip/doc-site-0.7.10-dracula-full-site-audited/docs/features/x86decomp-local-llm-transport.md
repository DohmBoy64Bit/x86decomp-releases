---
title: x86decomp.local_llm.transport
description: Source-derived module page for x86decomp.local_llm.transport in x86decomp
  0.7.10.
---

# `x86decomp.local_llm.transport`

- **Source path:** `src/x86decomp/local_llm/transport.py`
- **SHA-256:** `040da7a261eb8b5c012cf2e3f7b303231666d5054ab449c34df11b69f5275990`
- **Module docstring:** Dependency-free HTTP transports for supported local-model servers.
- **AST symbols:** 16

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ModelResponse` | class | 20 | Store validated model response fields used by toolkit reports and adapters. |
| `_SameOriginRedirectHandler` | class | 28 | Coordinate same origin redirect handler behavior for the current toolkit workflow. |
| `redirect_request` | function | 30 | Execute the redirect request operation for the current toolkit workflow. |
| `_endpoint` | function | 41 | Support endpoint processing for internal toolkit callers. |
| `_opener` | function | 46 | Support opener processing for internal toolkit callers. |
| `_headers` | function | 55 | Support headers processing for internal toolkit callers. |
| `_read_json_response` | function | 68 | Support read json response processing for internal toolkit callers. |
| `_request_json` | function | 92 | Support request json processing for internal toolkit callers. |
| `_model_ids` | function | 110 | Support model ids processing for internal toolkit callers. |
| `_ollama_model_matches` | function | 133 | Support ollama model matches processing for internal toolkit callers. |
| `probe_profile` | function | 142 | Probe a provider's model-list endpoint without generating text. |
| `_candidate_schema` | function | 160 | Support candidate schema processing for internal toolkit callers. |
| `_openai_body` | function | 175 | Support openai body processing for internal toolkit callers. |
| `_ollama_body` | function | 196 | Support ollama body processing for internal toolkit callers. |
| `_extract_content` | function | 212 | Support extract content processing for internal toolkit callers. |
| `chat` | function | 229 | Generate one bounded response, retrying once without structured mode when unsupported. |
