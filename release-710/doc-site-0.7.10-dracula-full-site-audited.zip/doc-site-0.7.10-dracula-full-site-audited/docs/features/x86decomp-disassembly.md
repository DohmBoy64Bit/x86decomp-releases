---
title: x86decomp.disassembly
description: Source-derived module page for x86decomp.disassembly in x86decomp 0.7.10.
---

# `x86decomp.disassembly`

- **Source path:** `src/x86decomp/disassembly.py`
- **SHA-256:** `7beb7f66049ca498017a9180be738f35d1dea545e04bb8d6e69747f0e14e3754`
- **Module docstring:** Independent Capstone-backed x86/x86-64 decoding and normalization.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_capstone` | function | 14 | Support capstone processing for internal toolkit callers. |
| `InstructionRecord` | class | 27 | Store validated instruction record fields used by toolkit reports and adapters. |
| `to_dict` | function | 39 | Return a serializable dictionary representation. |
| `_is_known_address` | function | 55 | Support is known address processing for internal toolkit callers. |
| `decode_instructions` | function | 60 | Decode instructions for the current toolkit workflow. |
| `control_flow_edges` | function | 149 | Execute the control flow edges operation for the current toolkit workflow. |
| `compare_instruction_streams` | function | 163 | Compare instruction streams for the current toolkit workflow. |
| `cross_check_ghidra_instructions` | function | 226 | Execute the cross check ghidra instructions operation for the current toolkit workflow. |
