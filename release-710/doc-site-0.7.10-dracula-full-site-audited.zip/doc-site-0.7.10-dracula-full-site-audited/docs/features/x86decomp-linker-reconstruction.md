---
title: x86decomp.linker_reconstruction
description: Source-derived module page for x86decomp.linker_reconstruction in x86decomp
  0.7.10.
---

# `x86decomp.linker_reconstruction`

- **Source path:** `src/x86decomp/linker_reconstruction.py`
- **SHA-256:** `e2485c40df661dea95be2a879a8a91ff185ed25b859d8683c969e922cf1dc79c`
- **Module docstring:** Evidence-driven linker reconstruction plans.
- **AST symbols:** 2

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `build_linker_reconstruction_plan` | function | 21 | Build linker reconstruction plan for the current toolkit workflow. |
| `write_relink_manifest_from_plan` | function | 146 | Write relink manifest from plan for the current toolkit workflow. |
