---
title: x86decomp.dynamic
description: Source-derived module page for x86decomp.dynamic in x86decomp 0.7.10.
---

# `x86decomp.dynamic`

- **Source path:** `src/x86decomp/dynamic.py`
- **SHA-256:** `9b3cd201a5701bf48b73edd9e1a1984d4c6550d116e1a5b603453270c34ea4a8`
- **Module docstring:** Bounded differential execution using Unicorn.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_unicorn` | function | 21 | Support unicorn processing for internal toolkit callers. |
| `_align_down` | function | 33 | Support align down processing for internal toolkit callers. |
| `_align_up` | function | 38 | Support align up processing for internal toolkit callers. |
| `MemoryRegion` | class | 44 | Store validated memory region fields used by toolkit reports and adapters. |
| `ExecutionSpec` | class | 52 | Store validated execution spec fields used by toolkit reports and adapters. |
| `load_execution_spec` | function | 69 | Load execution spec for the current toolkit workflow. |
| `_register_map` | function | 157 | Support register map processing for internal toolkit callers. |
| `_map_region` | function | 175 | Support map region processing for internal toolkit callers. |
| `execute_code` | function | 188 | Execute the execute code operation for the current toolkit workflow. |
| `code_hook` | function | 232 | Execute the code hook operation for the current toolkit workflow. |
| `differential_validate` | function | 290 | Execute the differential validate operation for the current toolkit workflow. |
| `differential_validate_files` | function | 339 | Execute the differential validate files operation for the current toolkit workflow. |
