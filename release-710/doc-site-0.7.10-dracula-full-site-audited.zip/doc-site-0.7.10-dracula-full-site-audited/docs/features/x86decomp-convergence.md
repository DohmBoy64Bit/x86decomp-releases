---
title: x86decomp.convergence
description: Source-derived module page for x86decomp.convergence in x86decomp 0.7.10.
---

# `x86decomp.convergence`

- **Source path:** `src/x86decomp/convergence.py`
- **SHA-256:** `fdc0f36afb90be8d0a8724878be24d104a662e1f4515850516810894228d1725`
- **Module docstring:** Target-specific whole-image convergence analysis.
- **AST symbols:** 3

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_section_kind` | function | 20 | Support section kind processing for internal toolkit callers. |
| `analyze_image_convergence` | function | 36 | Execute the analyze image convergence operation for the current toolkit workflow. |
| `append_convergence_history` | function | 167 | Append convergence history for the current toolkit workflow. |
