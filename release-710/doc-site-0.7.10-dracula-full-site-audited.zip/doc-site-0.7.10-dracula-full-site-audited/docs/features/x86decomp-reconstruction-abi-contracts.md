---
title: x86decomp.reconstruction.abi_contracts
description: Source-derived module page for x86decomp.reconstruction.abi_contracts
  in x86decomp 0.7.10.
---

# `x86decomp.reconstruction.abi_contracts`

- **Source path:** `src/x86decomp/reconstruction/abi_contracts.py`
- **SHA-256:** `3eb4e79869758ec544c5534c94f9a92fae194044d9900b1cf0b9b7674b3107ac`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.abi_contracts` module.
- **AST symbols:** 8

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ABIContracts` | class | 11 | Coordinate a b i contracts behavior for the current toolkit workflow. |
| `__init__` | function | 13 | Initialize the instance with validated constructor state. |
| `recover` | function | 16 | Execute the recover operation for the current toolkit workflow. |
| `get` | function | 32 | Execute the get operation for the current toolkit workflow. |
| `verify` | function | 37 | Verify verify for the current toolkit workflow. |
| `compare` | function | 44 | Compare compare for the current toolkit workflow. |
| `export` | function | 48 | Execute the export operation for the current toolkit workflow. |
| `shim` | function | 51 | Execute the shim operation for the current toolkit workflow. |
