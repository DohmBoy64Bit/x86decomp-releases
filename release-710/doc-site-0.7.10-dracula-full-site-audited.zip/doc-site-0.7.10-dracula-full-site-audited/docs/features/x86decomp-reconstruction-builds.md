---
title: x86decomp.reconstruction.builds
description: Source-derived module page for x86decomp.reconstruction.builds in x86decomp
  0.7.10.
---

# `x86decomp.reconstruction.builds`

- **Source path:** `src/x86decomp/reconstruction/builds.py`
- **SHA-256:** `395b66ef66d18e32b6ad17909ed8d1cc1cb2d3268ac9ce816e2aa9747e0d74ac`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.builds` module.
- **AST symbols:** 12

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `BuildManager` | class | 11 | Coordinate build manager behavior for the current toolkit workflow. |
| `__init__` | function | 13 | Initialize the instance with validated constructor state. |
| `create` | function | 16 | Create create for the current toolkit workflow. |
| `add_target` | function | 25 | Execute the add target operation for the current toolkit workflow. |
| `add_variant` | function | 34 | Execute the add variant operation for the current toolkit workflow. |
| `show` | function | 42 | Execute the show operation for the current toolkit workflow. |
| `show_target` | function | 49 | Execute the show target operation for the current toolkit workflow. |
| `show_variant` | function | 56 | Execute the show variant operation for the current toolkit workflow. |
| `generate` | function | 62 | Generate generate for the current toolkit workflow. |
| `validate` | function | 82 | Validate validate for the current toolkit workflow. |
| `compare_modes` | function | 93 | Compare modes for the current toolkit workflow. |
| `matrix` | function | 98 | Execute the matrix operation for the current toolkit workflow. |
