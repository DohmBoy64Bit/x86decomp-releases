---
title: x86decomp.reconstruction.security
description: Source-derived module page for x86decomp.reconstruction.security in x86decomp
  0.7.10.
---

# `x86decomp.reconstruction.security`

- **Source path:** `src/x86decomp/reconstruction/security.py`
- **SHA-256:** `3d131ae1f0702c631202a51639b85b53843a7394c7bb331e2364e53404fe1fa0`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.reconstruction.security` module.
- **AST symbols:** 7

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `SecurityReview` | class | 9 | Coordinate security review behavior for the current toolkit workflow. |
| `__init__` | function | 11 | Initialize the instance with validated constructor state. |
| `finding` | function | 14 | Execute the finding operation for the current toolkit workflow. |
| `get` | function | 22 | Execute the get operation for the current toolkit workflow. |
| `scan` | function | 27 | Execute the scan operation for the current toolkit workflow. |
| `policy` | function | 35 | Execute the policy operation for the current toolkit workflow. |
| `report` | function | 41 | Execute the report operation for the current toolkit workflow. |
