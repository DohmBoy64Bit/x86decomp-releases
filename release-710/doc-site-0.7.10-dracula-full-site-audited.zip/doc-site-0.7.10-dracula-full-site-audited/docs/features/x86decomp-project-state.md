---
title: x86decomp.project_state
description: Source-derived module page for x86decomp.project_state in x86decomp 0.7.10.
---

# `x86decomp.project_state`

- **Source path:** `src/x86decomp/project_state.py`
- **SHA-256:** `4c5fd958cd1008f9791d46f8ef8b0ee51765a8a9bdeed8a60244e94d5f9ecbe3`
- **Module docstring:** Transactional project-state database, migrations, backup, and recovery.
- **AST symbols:** 21

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ProjectCheck` | class | 70 | Store validated project check fields used by toolkit reports and adapters. |
| `to_dict` | function | 78 | Return a serializable dictionary representation. |
| `ProjectStateDatabase` | class | 89 | Coordinate project state database behavior for the current toolkit workflow. |
| `__init__` | function | 91 | Initialize the instance with validated constructor state. |
| `close` | function | 109 | Execute the close operation for the current toolkit workflow. |
| `__enter__` | function | 113 | Enter the managed runtime context and return the active resource. |
| `__exit__` | function | 117 | Exit the managed runtime context and release owned resources. |
| `transaction` | function | 122 | Execute the transaction operation for the current toolkit workflow. |
| `integrity_check` | function | 133 | Execute the integrity check operation for the current toolkit workflow. |
| `record_migration` | function | 138 | Record migration for the current toolkit workflow. |
| `snapshot` | function | 159 | Execute the snapshot operation for the current toolkit workflow. |
| `upsert_artifact_reference` | function | 181 | Execute the upsert artifact reference operation for the current toolkit workflow. |
| `artifact_digests` | function | 190 | Execute the artifact digests operation for the current toolkit workflow. |
| `state_database_path` | function | 195 | Execute the state database path operation for the current toolkit workflow. |
| `create_project_backup` | function | 200 | Create a deterministic gzip tar backup without following symlinks. |
| `_migration_2_to_3` | function | 235 | Support migration 2 to 3 processing for internal toolkit callers. |
| `migrate_project` | function | 267 | Execute the migrate project operation for the current toolkit workflow. |
| `check_project_state` | function | 330 | Check project state for the current toolkit workflow. |
| `repair_project_state` | function | 370 | Repair only reconstructible indexes; never rewrite evidence or binaries. |
| `project_gc` | function | 400 | Execute the project gc operation for the current toolkit workflow. |
| `restore_project_backup` | function | 407 | Safely restore a project backup into an empty destination. |
