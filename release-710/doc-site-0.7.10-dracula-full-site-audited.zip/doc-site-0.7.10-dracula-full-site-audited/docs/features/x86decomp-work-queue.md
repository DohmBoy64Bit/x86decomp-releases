---
title: x86decomp.work_queue
description: Source-derived module page for x86decomp.work_queue in x86decomp 0.7.10.
---

# `x86decomp.work_queue`

- **Source path:** `src/x86decomp/work_queue.py`
- **SHA-256:** `0faf02ac6c5e6871728c3a81bf0737d189b5ba0b44c76335403b015c11c71d09`
- **Module docstring:** Evidence-gated human/AI work queue with validator acceptance rules.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `WorkQueue` | class | 35 | Coordinate work queue behavior for the current toolkit workflow. |
| `__init__` | function | 37 | Initialize the instance with validated constructor state. |
| `close` | function | 45 | Execute the close operation for the current toolkit workflow. |
| `create` | function | 49 | Create create for the current toolkit workflow. |
| `get` | function | 73 | Execute the get operation for the current toolkit workflow. |
| `claim` | function | 84 | Execute the claim operation for the current toolkit workflow. |
| `propose` | function | 94 | Execute the propose operation for the current toolkit workflow. |
| `record_validator` | function | 107 | Record validator for the current toolkit workflow. |
| `next` | function | 122 | Execute the next operation for the current toolkit workflow. |
