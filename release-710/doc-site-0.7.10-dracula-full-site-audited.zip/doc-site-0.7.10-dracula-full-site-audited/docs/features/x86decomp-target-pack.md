---
title: x86decomp.target_pack
description: Source-derived module page for x86decomp.target_pack in x86decomp 0.7.10.
---

# `x86decomp.target_pack`

- **Source path:** `src/x86decomp/target_pack.py`
- **SHA-256:** `dda033d5a0b6d2b9aafb9e05d71c37b97d1161ba64bf84e2a21925f826f3f12f`
- **Module docstring:** Target-pack inference, validation, and project-template generation.
- **AST symbols:** 9

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `SupportingArtifact` | class | 30 | Store validated supporting artifact fields used by toolkit reports and adapters. |
| `to_dict` | function | 37 | Return a serializable dictionary representation. |
| `_toml_string` | function | 42 | Support toml string processing for internal toolkit callers. |
| `_write_target_toml` | function | 47 | Support write target toml processing for internal toolkit callers. |
| `_safe_artifact` | function | 90 | Support safe artifact processing for internal toolkit callers. |
| `infer_target_pack` | function | 98 | Execute the infer target pack operation for the current toolkit workflow. |
| `load_target_pack` | function | 308 | Load target pack for the current toolkit workflow. |
| `verify_target_pack` | function | 320 | Verify target pack for the current toolkit workflow. |
| `generate_project_from_target_pack` | function | 351 | Generate project from target pack for the current toolkit workflow. |
