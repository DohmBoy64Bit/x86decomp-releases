---
title: x86decomp.harness_generator
description: Source-derived module page for x86decomp.harness_generator in x86decomp
  0.7.10.
---

# `x86decomp.harness_generator`

- **Source path:** `src/x86decomp/harness_generator.py`
- **SHA-256:** `a5d1bf5ac1fc22d34e2975ee93d73e021345d641ef883bc2bd3e2b9638179fe4`
- **Module docstring:** Generate bounded differential-execution harnesses from explicit ABI facts.
- **AST symbols:** 3

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `_deterministic_word` | function | 17 | Support deterministic word processing for internal toolkit callers. |
| `generate_execution_harness` | function | 23 | Generate execution harness for the current toolkit workflow. |
| `generate_execution_harness_from_files` | function | 141 | Generate execution harness from files for the current toolkit workflow. |
