---
title: x86decomp.pe
description: Source-derived module page for x86decomp.pe in x86decomp 0.7.10.
---

# `x86decomp.pe`

- **Source path:** `src/x86decomp/pe.py`
- **SHA-256:** `60eea17b8b492ad0ee468f3291a3c72b0864edf7e5b916d4dfdc7e8acc73b86b`
- **Module docstring:** Architecture-dispatching PE parser with PE32+ x86-64 support.
- **AST symbols:** 19

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `TLS64Info` | class | 43 | Store validated t l s64 info fields used by toolkit reports and adapters. |
| `to_dict` | function | 53 | Return a serializable dictionary representation. |
| `RuntimeFunction` | class | 67 | Store validated runtime function fields used by toolkit reports and adapters. |
| `to_dict` | function | 73 | Return a serializable dictionary representation. |
| `PE64Image` | class | 83 | Store validated p e64 image fields used by toolkit reports and adapters. |
| `entry_va` | function | 113 | Execute the entry va operation for the current toolkit workflow. |
| `to_dict` | function | 117 | Return a serializable dictionary representation. |
| `_parse_imports64` | function | 158 | Support parse imports64 processing for internal toolkit callers. |
| `_parse_tls64` | function | 192 | Support parse tls64 processing for internal toolkit callers. |
| `_parse_delay_imports64` | function | 214 | Support parse delay imports64 processing for internal toolkit callers. |
| `to_rva` | function | 227 | Execute the to rva operation for the current toolkit workflow. |
| `_parse_load_config64` | function | 258 | Support parse load config64 processing for internal toolkit callers. |
| `u16` | function | 266 | Execute the u16 operation for the current toolkit workflow. |
| `u32` | function | 269 | Execute the u32 operation for the current toolkit workflow. |
| `u64` | function | 272 | Execute the u64 operation for the current toolkit workflow. |
| `_parse_runtime_functions` | function | 283 | Support parse runtime functions processing for internal toolkit callers. |
| `parse_pe64` | function | 294 | Parse pe64 for the current toolkit workflow. |
| `inspect_pe_kind` | function | 370 | Execute the inspect pe kind operation for the current toolkit workflow. |
| `parse_pe` | function | 383 | Parse pe for the current toolkit workflow. |
