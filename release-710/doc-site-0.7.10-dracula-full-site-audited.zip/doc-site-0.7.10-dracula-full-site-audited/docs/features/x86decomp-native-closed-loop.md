---
title: x86decomp.native.closed_loop
description: Source-derived module page for x86decomp.native.closed_loop in x86decomp
  0.7.10.
---

# `x86decomp.native.closed_loop`

- **Source path:** `src/x86decomp/native/closed_loop.py`
- **SHA-256:** `8ca0f2b6adb455f6a3adcfbe88a9d1f536ed28ac13d7cea3048db214a507d831`
- **Module docstring:** Provide the current runtime implementation for the `x86decomp.native.closed_loop` module.
- **AST symbols:** 5

## Symbols

| Symbol | Kind | Line | Docstring summary |
| --- | --- | ---: | --- |
| `ClosedLoop` | class | 14 | Coordinate closed loop behavior for the current toolkit workflow. |
| `__init__` | function | 16 | Initialize the instance with validated constructor state. |
| `run` | function | 20 | Run run for the current toolkit workflow. |
| `show` | function | 41 | Execute the show operation for the current toolkit workflow. |
| `list` | function | 48 | Execute the list operation for the current toolkit workflow. |
