---
title: 'Schema: schemas/native/staging-symbol.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/native/staging-symbol.schema.json.
---

# `schemas/native/staging-symbol.schema.json`

- **SHA-256:** `44b3ce02db0758435f6a230a9ad37bd00c3a6308bf71761836050e5c90c6c4d0`
- **Title:** x86decomp staging-symbol
- **Type:** `object`
- **Properties:** 4
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `declaration` | `string` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `symbol_kind` | `string` | yes | No description declared. |
| `symbol_name` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.invalid/schemas/native/staging-symbol.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "declaration": {
      "type": "string"
    },
    "status": {
      "enum": [
        "proposed",
        "accepted",
        "rejected"
      ]
    },
    "symbol_kind": {
      "type": "string"
    },
    "symbol_name": {
      "type": "string"
    }
  },
  "required": [
    "symbol_name",
    "symbol_kind",
    "declaration",
    "status"
  ],
  "title": "x86decomp staging-symbol",
  "type": "object"
}
```
