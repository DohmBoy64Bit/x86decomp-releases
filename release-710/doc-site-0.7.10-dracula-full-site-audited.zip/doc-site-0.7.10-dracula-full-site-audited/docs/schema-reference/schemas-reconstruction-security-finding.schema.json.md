---
title: 'Schema: schemas/reconstruction/security-finding.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/reconstruction/security-finding.schema.json.
---

# `schemas/reconstruction/security-finding.schema.json`

- **SHA-256:** `9a4f8a220e2e2d1d7dbc8116968bf2752d57a5725e18673faf59a192ace1826e`
- **Title:** Security finding
- **Type:** `object`
- **Properties:** 7
- **Required fields:** 7
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `evidence` | `array` | yes | No description declared. |
| `finding_id` | `string` | yes | No description declared. |
| `rule_id` | `string` | yes | No description declared. |
| `severity` | `unspecified` | yes | No description declared. |
| `status` | `string` | yes | No description declared. |
| `subject_id` | `string` | yes | No description declared. |
| `summary` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.dev/schemas/reconstruction/security-finding.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "evidence": {
      "items": {
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "finding_id": {
      "pattern": "^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$",
      "type": "string"
    },
    "rule_id": {
      "type": "string"
    },
    "severity": {
      "enum": [
        "informational",
        "low",
        "medium",
        "high",
        "critical"
      ]
    },
    "status": {
      "type": "string"
    },
    "subject_id": {
      "type": "string"
    },
    "summary": {
      "type": "string"
    }
  },
  "required": [
    "finding_id",
    "rule_id",
    "severity",
    "subject_id",
    "summary",
    "evidence",
    "status"
  ],
  "title": "Security finding",
  "type": "object"
}
```
