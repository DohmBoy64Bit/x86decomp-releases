---
title: 'Schema: schemas/memory-event.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/memory-event.schema.json.
---

# `schemas/memory-event.schema.json`

- **SHA-256:** `d2f38971ac7dda92dda0564bb77bb4858160b5a342476d36fe52238eb5289e74`
- **Title:** x86decomp project memory event
- **Type:** `object`
- **Properties:** 11
- **Required fields:** 11
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `actor` | `string` | yes | No description declared. |
| `category` | `string` | yes | No description declared. |
| `details` | `object` | yes | No description declared. |
| `event_hash` | `string` | yes | No description declared. |
| `evidence_ids` | `array` | yes | No description declared. |
| `id` | `string` | yes | No description declared. |
| `previous_hash` | `['string', 'null']` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `sequence` | `integer` | yes | No description declared. |
| `summary` | `string` | yes | No description declared. |
| `timestamp` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:memory-event:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "actor": {
      "minLength": 1,
      "type": "string"
    },
    "category": {
      "minLength": 1,
      "type": "string"
    },
    "details": {
      "type": "object"
    },
    "event_hash": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "evidence_ids": {
      "items": {
        "type": "string"
      },
      "type": "array",
      "uniqueItems": true
    },
    "id": {
      "pattern": "^mem-[0-9a-f]{16}$",
      "type": "string"
    },
    "previous_hash": {
      "pattern": "^[0-9a-f]{64}$",
      "type": [
        "string",
        "null"
      ]
    },
    "schema_version": {
      "const": 1
    },
    "sequence": {
      "minimum": 1,
      "type": "integer"
    },
    "summary": {
      "minLength": 1,
      "type": "string"
    },
    "timestamp": {
      "format": "date-time",
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "id",
    "sequence",
    "timestamp",
    "actor",
    "category",
    "summary",
    "details",
    "evidence_ids",
    "previous_hash",
    "event_hash"
  ],
  "title": "x86decomp project memory event",
  "type": "object"
}
```
