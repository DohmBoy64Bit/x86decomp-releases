---
title: 'Schema: schemas/symbolic-memory-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/symbolic-memory-report.schema.json.
---

# `schemas/symbolic-memory-report.schema.json`

- **SHA-256:** `5e17dedb1bedf6581662f4cced118e40b8075957a161daea2abfab778d0298ba`
- **Title:** Bounded angr symbolic memory-alias comparison
- **Type:** `object`
- **Properties:** 11
- **Required fields:** 9
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `candidate_execution` | `object` | yes | No description declared. |
| `candidate_sha256` | `string` | no | No description declared. |
| `equivalent_within_completed_model` | `boolean` | yes | No description declared. |
| `harness` | `object` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `scope_statement` | `string` | yes | No description declared. |
| `target_execution` | `object` | yes | No description declared. |
| `target_sha256` | `string` | no | No description declared. |
| `universal_equivalence_claimed` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:symbolic-memory-report:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "candidate_execution": {
      "type": "object"
    },
    "candidate_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "equivalent_within_completed_model": {
      "type": "boolean"
    },
    "harness": {
      "type": "object"
    },
    "kind": {
      "const": "angr_memory_alias_comparison"
    },
    "schema_version": {
      "const": 1
    },
    "scope_statement": {
      "minLength": 1,
      "type": "string"
    },
    "target_execution": {
      "type": "object"
    },
    "target_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "universal_equivalence_claimed": {
      "const": false
    }
  },
  "required": [
    "schema_version",
    "kind",
    "architecture",
    "harness",
    "target_execution",
    "candidate_execution",
    "equivalent_within_completed_model",
    "scope_statement",
    "universal_equivalence_claimed"
  ],
  "title": "Bounded angr symbolic memory-alias comparison",
  "type": "object"
}
```
