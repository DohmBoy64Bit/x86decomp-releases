---
title: 'Schema: schemas/claim.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/claim.schema.json.
---

# `schemas/claim.schema.json`

- **SHA-256:** `362341adcb81640a7839c77d37d7203b911e7e79655be6c0ab4115f460609532`
- **Title:** x86decomp claim
- **Type:** `object`
- **Properties:** 10
- **Required fields:** 10
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `contradiction_ids` | `array` | yes | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `evidence_ids` | `array` | yes | No description declared. |
| `id` | `string` | yes | No description declared. |
| `notes` | `array` | yes | No description declared. |
| `object` | `string` | yes | No description declared. |
| `predicate` | `string` | yes | No description declared. |
| `state` | `unspecified` | yes | No description declared. |
| `subject` | `string` | yes | No description declared. |
| `updated_at` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:claim:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "contradiction_ids": {
      "items": {
        "type": "string"
      },
      "type": "array",
      "uniqueItems": true
    },
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "evidence_ids": {
      "items": {
        "type": "string"
      },
      "type": "array",
      "uniqueItems": true
    },
    "id": {
      "pattern": "^[a-z0-9][a-z0-9._:-]{2,127}$",
      "type": "string"
    },
    "notes": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "object": {
      "minLength": 1,
      "type": "string"
    },
    "predicate": {
      "minLength": 1,
      "type": "string"
    },
    "state": {
      "enum": [
        "proposed",
        "corroborated",
        "verified",
        "rejected"
      ]
    },
    "subject": {
      "minLength": 1,
      "type": "string"
    },
    "updated_at": {
      "format": "date-time",
      "type": "string"
    }
  },
  "required": [
    "id",
    "subject",
    "predicate",
    "object",
    "state",
    "evidence_ids",
    "contradiction_ids",
    "notes",
    "created_at",
    "updated_at"
  ],
  "title": "x86decomp claim",
  "type": "object"
}
```
