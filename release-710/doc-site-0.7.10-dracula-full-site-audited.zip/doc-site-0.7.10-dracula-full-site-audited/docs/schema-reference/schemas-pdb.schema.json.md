---
title: 'Schema: schemas/pdb.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/pdb.schema.json.
---

# `schemas/pdb.schema.json`

- **SHA-256:** `850bbf885fa040ac4601dc4d93c2fb4b3afda1dd86612a0d8866a34bacf07008`
- **Title:** x86decomp bounded PDB/MSF inventory
- **Type:** `object`
- **Properties:** 13
- **Required fields:** 13
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `dbi` | `['object', 'null']` | yes | No description declared. |
| `format` | `unspecified` | yes | No description declared. |
| `ipi` | `['object', 'null']` | yes | No description declared. |
| `pdb_info` | `['object', 'null']` | yes | No description declared. |
| `pe_match` | `['object', 'null']` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `scope` | `object` | yes | No description declared. |
| `source_path` | `['string', 'null']` | yes | No description declared. |
| `source_sha256` | `string` | yes | No description declared. |
| `stream_count` | `integer` | yes | No description declared. |
| `streams` | `array` | yes | No description declared. |
| `superblock` | `object` | yes | No description declared. |
| `tpi` | `['object', 'null']` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:pdb:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "dbi": {
      "type": [
        "object",
        "null"
      ]
    },
    "format": {
      "const": "PDB_MSF_7_00"
    },
    "ipi": {
      "type": [
        "object",
        "null"
      ]
    },
    "pdb_info": {
      "type": [
        "object",
        "null"
      ]
    },
    "pe_match": {
      "type": [
        "object",
        "null"
      ]
    },
    "schema_version": {
      "const": 1
    },
    "scope": {
      "additionalProperties": false,
      "properties": {
        "codeview_symbol_records_fully_parsed": {
          "const": false
        },
        "codeview_type_records_fully_parsed": {
          "const": false
        },
        "dbi_modules_sources_contributions_parsed": {
          "type": "boolean"
        },
        "msf_directory_parsed": {
          "type": "boolean"
        },
        "pdb_identity_parsed": {
          "type": "boolean"
        },
        "tpi_ipi_headers_parsed": {
          "type": "boolean"
        }
      },
      "required": [
        "msf_directory_parsed",
        "pdb_identity_parsed",
        "tpi_ipi_headers_parsed",
        "dbi_modules_sources_contributions_parsed",
        "codeview_type_records_fully_parsed",
        "codeview_symbol_records_fully_parsed"
      ],
      "type": "object"
    },
    "source_path": {
      "type": [
        "string",
        "null"
      ]
    },
    "source_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "stream_count": {
      "minimum": 0,
      "type": "integer"
    },
    "streams": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "blocks": {
            "items": {
              "minimum": 0,
              "type": "integer"
            },
            "type": "array"
          },
          "index": {
            "minimum": 0,
            "type": "integer"
          },
          "sha256": {
            "pattern": "^[0-9a-f]{64}$",
            "type": [
              "string",
              "null"
            ]
          },
          "size": {
            "minimum": 0,
            "type": [
              "integer",
              "null"
            ]
          }
        },
        "required": [
          "index",
          "size",
          "blocks",
          "sha256"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "superblock": {
      "additionalProperties": false,
      "properties": {
        "block_map_address": {
          "minimum": 0,
          "type": "integer"
        },
        "block_size": {
          "enum": [
            512,
            1024,
            2048,
            4096
          ]
        },
        "directory_bytes": {
          "minimum": 0,
          "type": "integer"
        },
        "free_block_map_block": {
          "enum": [
            1,
            2
          ]
        },
        "number_of_blocks": {
          "minimum": 1,
          "type": "integer"
        }
      },
      "required": [
        "block_size",
        "free_block_map_block",
        "number_of_blocks",
        "directory_bytes",
        "block_map_address"
      ],
      "type": "object"
    },
    "tpi": {
      "type": [
        "object",
        "null"
      ]
    }
  },
  "required": [
    "schema_version",
    "format",
    "source_path",
    "source_sha256",
    "superblock",
    "stream_count",
    "streams",
    "pdb_info",
    "tpi",
    "ipi",
    "dbi",
    "pe_match",
    "scope"
  ],
  "title": "x86decomp bounded PDB/MSF inventory",
  "type": "object"
}
```
