---
title: 'Schema: schemas/assembly/relocation-resolution.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/assembly/relocation-resolution.schema.json.
---

# `schemas/assembly/relocation-resolution.schema.json`

- **SHA-256:** `55a4af489c3e529239acf34d4d49c12ff38775cff95d98d2a317ca2f1ec3e1f4`
- **Title:** v0.7.10 COFF relocation resolution
- **Type:** `object`
- **Properties:** 8
- **Required fields:** 8
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `base_rva` | `integer` | yes | No description declared. |
| `exact_match` | `boolean` | yes | No description declared. |
| `object` | `string` | yes | No description declared. |
| `relocations` | `array` | yes | No description declared. |
| `resolved_count` | `integer` | yes | No description declared. |
| `symbol` | `string` | yes | No description declared. |
| `unresolved_count` | `integer` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/assembly/relocation-resolution.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "base_rva": {
      "minimum": 0,
      "type": "integer"
    },
    "exact_match": {
      "type": "boolean"
    },
    "object": {
      "minLength": 1,
      "type": "string"
    },
    "relocations": {
      "items": {
        "additionalProperties": true,
        "properties": {
          "offset": {
            "minimum": 0,
            "type": "integer"
          },
          "status": {
            "enum": [
              "resolved",
              "unresolved"
            ]
          },
          "type": {
            "type": "string"
          }
        },
        "required": [
          "offset",
          "type",
          "status"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "resolved_count": {
      "minimum": 0,
      "type": "integer"
    },
    "symbol": {
      "minLength": 1,
      "type": "string"
    },
    "unresolved_count": {
      "minimum": 0,
      "type": "integer"
    }
  },
  "required": [
    "object",
    "symbol",
    "architecture",
    "base_rva",
    "resolved_count",
    "unresolved_count",
    "relocations",
    "exact_match"
  ],
  "title": "v0.7.10 COFF relocation resolution",
  "type": "object"
}
```
