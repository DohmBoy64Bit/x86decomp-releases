---
title: 'Schema: schemas/reproduction.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/reproduction.schema.json.
---

# `schemas/reproduction.schema.json`

- **SHA-256:** `aea350be271c7795406a2dd55096775e9d0b531215e05f43b75a9c6b5bd98281`
- **Title:** urn:x86decomp:schema:reproduction:1
- **Type:** `object`
- **Properties:** 13
- **Required fields:** 6
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `binary` | `object` | yes | No description declared. |
| `content_store` | `['object', 'null']` | no | No description declared. |
| `created_at` | `string` | no | No description declared. |
| `critical_files` | `array` | yes | No description declared. |
| `host` | `object` | no | No description declared. |
| `limitations` | `array` | no | No description declared. |
| `project_check` | `object` | no | No description declared. |
| `project_id` | `string` | yes | No description declared. |
| `project_schema_version` | `integer` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `target_pack_check` | `['object', 'null']` | no | No description declared. |
| `toolkit_release` | `string` | no | No description declared. |
| `tools` | `object` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:reproduction:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "binary": {
      "type": "object"
    },
    "content_store": {
      "type": [
        "object",
        "null"
      ]
    },
    "created_at": {
      "type": "string"
    },
    "critical_files": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "host": {
      "type": "object"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "project_check": {
      "type": "object"
    },
    "project_id": {
      "type": "string"
    },
    "project_schema_version": {
      "type": "integer"
    },
    "schema_version": {
      "const": 1
    },
    "target_pack_check": {
      "type": [
        "object",
        "null"
      ]
    },
    "toolkit_release": {
      "type": "string"
    },
    "tools": {
      "type": "object"
    }
  },
  "required": [
    "schema_version",
    "project_id",
    "project_schema_version",
    "binary",
    "critical_files",
    "tools"
  ],
  "type": "object"
}
```
