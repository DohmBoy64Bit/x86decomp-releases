---
title: 'Schema: schemas/compiler-lab.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/compiler-lab.schema.json.
---

# `schemas/compiler-lab.schema.json`

- **SHA-256:** `37bc55f945daffc31844a78c2b4788191f501589303826a6cee207c5c4717506`
- **Title:** Compiler experiment matrix
- **Type:** `object`
- **Properties:** 8
- **Required fields:** 2
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `cache_root` | `string` | no | No description declared. |
| `matrix` | `object` | no | No description declared. |
| `max_experiments` | `integer` | no | No description declared. |
| `output_name` | `string` | no | No description declared. |
| `output_root` | `string` | no | No description declared. |
| `profiles` | `array` | yes | No description declared. |
| `source` | `string` | yes | No description declared. |
| `target` | `unspecified` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:compiler-lab:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "cache_root": {
      "type": "string"
    },
    "matrix": {
      "additionalProperties": false,
      "properties": {
        "axes": {
          "additionalProperties": {
            "items": {
              "type": "string"
            },
            "minItems": 1,
            "type": "array"
          },
          "type": "object"
        }
      },
      "type": "object"
    },
    "max_experiments": {
      "minimum": 1,
      "type": "integer"
    },
    "output_name": {
      "type": "string"
    },
    "output_root": {
      "type": "string"
    },
    "profiles": {
      "items": {
        "type": "string"
      },
      "minItems": 1,
      "type": "array"
    },
    "source": {
      "type": "string"
    },
    "target": {
      "oneOf": [
        {
          "additionalProperties": false,
          "properties": {
            "kind": {
              "const": "pe_function"
            },
            "pe": {
              "type": "string"
            },
            "rva": {
              "minimum": 0,
              "type": "integer"
            },
            "size": {
              "minimum": 1,
              "type": "integer"
            },
            "symbol": {
              "type": "string"
            }
          },
          "required": [
            "kind",
            "pe",
            "rva",
            "size",
            "symbol"
          ],
          "type": "object"
        },
        {
          "additionalProperties": false,
          "properties": {
            "kind": {
              "const": "file"
            },
            "path": {
              "type": "string"
            }
          },
          "required": [
            "kind",
            "path"
          ],
          "type": "object"
        },
        {
          "maxProperties": 0,
          "type": "object"
        }
      ]
    }
  },
  "required": [
    "source",
    "profiles"
  ],
  "title": "Compiler experiment matrix",
  "type": "object"
}
```
