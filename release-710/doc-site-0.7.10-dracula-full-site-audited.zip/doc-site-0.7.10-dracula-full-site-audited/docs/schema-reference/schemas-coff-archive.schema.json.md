---
title: 'Schema: schemas/coff-archive.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/coff-archive.schema.json.
---

# `schemas/coff-archive.schema.json`

- **SHA-256:** `5f5a43f1ce6ae1221df24107f7b9db057156731736ff4aad5c81c93a73abaab3`
- **Title:** x86decomp COFF Archive Inspection
- **Type:** `object`
- **Properties:** 7
- **Required fields:** 7
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `format` | `unspecified` | yes | No description declared. |
| `linker_symbols` | `array` | yes | No description declared. |
| `member_count` | `integer` | yes | No description declared. |
| `members` | `array` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `source_path` | `['string', 'null']` | yes | No description declared. |
| `source_sha256` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:coff-archive:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "format": {
      "const": "coff_archive"
    },
    "linker_symbols": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "linker_member_index": {
            "minimum": 0,
            "type": "integer"
          },
          "member_header_offset": {
            "minimum": 0,
            "type": "integer"
          },
          "name": {
            "type": "string"
          }
        },
        "required": [
          "name",
          "member_header_offset",
          "linker_member_index"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "member_count": {
      "minimum": 0,
      "type": "integer"
    },
    "members": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "coff": {
            "type": "object"
          },
          "data_offset": {
            "minimum": 0,
            "type": "integer"
          },
          "group_id": {
            "type": [
              "integer",
              "null"
            ]
          },
          "header_offset": {
            "minimum": 0,
            "type": "integer"
          },
          "import_object": {
            "type": "object"
          },
          "index": {
            "minimum": 0,
            "type": "integer"
          },
          "kind": {
            "enum": [
              "linker_member",
              "longnames",
              "coff_object",
              "import_object",
              "unknown"
            ]
          },
          "mode": {
            "type": [
              "integer",
              "null"
            ]
          },
          "name": {
            "type": "string"
          },
          "sha256": {
            "pattern": "^[0-9a-f]{64}$",
            "type": "string"
          },
          "size": {
            "minimum": 0,
            "type": "integer"
          },
          "timestamp": {
            "type": [
              "integer",
              "null"
            ]
          },
          "user_id": {
            "type": [
              "integer",
              "null"
            ]
          }
        },
        "required": [
          "index",
          "header_offset",
          "data_offset",
          "name",
          "size",
          "timestamp",
          "user_id",
          "group_id",
          "mode",
          "kind",
          "sha256"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "schema_version": {
      "const": 1
    },
    "source_path": {
      "type": [
        "string",
        "null"
      ]
    },
    "source_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "format",
    "source_path",
    "source_sha256",
    "member_count",
    "members",
    "linker_symbols"
  ],
  "title": "x86decomp COFF Archive Inspection",
  "type": "object"
}
```
