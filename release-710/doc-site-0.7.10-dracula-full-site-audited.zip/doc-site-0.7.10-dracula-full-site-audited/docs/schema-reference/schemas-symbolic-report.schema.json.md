---
title: 'Schema: schemas/symbolic-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/symbolic-report.schema.json.
---

# `schemas/symbolic-report.schema.json`

- **SHA-256:** `cc596ec7c42bc74e7810dbf52bf50cba2d17375e9438f0a3fcbb3dae67a88e29`
- **Title:** Bounded symbolic comparison report
- **Type:** `object`
- **Properties:** 3
- **Required fields:** 3
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `equivalent_within_model` | `boolean` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `scope_statement` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:symbolic-report:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "equivalent_within_model": {
      "type": "boolean"
    },
    "schema_version": {
      "const": 1
    },
    "scope_statement": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "equivalent_within_model",
    "scope_statement"
  ],
  "title": "Bounded symbolic comparison report",
  "type": "object"
}
```
