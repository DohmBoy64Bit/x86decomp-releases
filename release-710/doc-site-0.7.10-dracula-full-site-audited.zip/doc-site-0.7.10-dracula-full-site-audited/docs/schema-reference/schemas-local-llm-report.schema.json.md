---
title: 'Schema: schemas/local-llm/report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/local-llm/report.schema.json.
---

# `schemas/local-llm/report.schema.json`

- **SHA-256:** `d61c0308354431848f281d3c62cd32b39c9d61277492bee480a02276e5ad6ac0`
- **Title:** Local LLM exact byte-match report
- **Type:** `object`
- **Properties:** 13
- **Required fields:** 13
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `accepted` | `unspecified` | yes | No description declared. |
| `attempt_count` | `integer` | yes | No description declared. |
| `attempt_limit` | `integer` | yes | No description declared. |
| `attempts` | `array` | yes | No description declared. |
| `claim` | `string` | yes | No description declared. |
| `compiler_profile` | `object` | yes | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `job` | `object` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `limitations` | `array` | yes | No description declared. |
| `profile` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/local-llm/report.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "allOf": [
    {
      "else": {
        "properties": {
          "accepted": {
            "type": "null"
          }
        }
      },
      "if": {
        "properties": {
          "status": {
            "const": "byte_matched"
          }
        }
      },
      "then": {
        "properties": {
          "accepted": {
            "type": "object"
          }
        }
      }
    }
  ],
  "properties": {
    "accepted": {
      "oneOf": [
        {
          "type": "null"
        },
        {
          "properties": {
            "attempt": {
              "minimum": 1,
              "type": "integer"
            },
            "byte_identical": {
              "const": true
            },
            "object": {
              "type": "string"
            },
            "object_sha256": {
              "pattern": "^[0-9a-f]{64}$",
              "type": "string"
            },
            "resolved_bytes": {
              "type": "string"
            },
            "resolved_sha256": {
              "pattern": "^[0-9a-f]{64}$",
              "type": "string"
            },
            "source": {
              "type": "string"
            },
            "source_sha256": {
              "pattern": "^[0-9a-f]{64}$",
              "type": "string"
            },
            "target_sha256": {
              "pattern": "^[0-9a-f]{64}$",
              "type": "string"
            },
            "unresolved_relocations": {
              "const": 0
            }
          },
          "required": [
            "attempt",
            "source",
            "source_sha256",
            "object",
            "object_sha256",
            "resolved_bytes",
            "resolved_sha256",
            "target_sha256",
            "byte_identical",
            "unresolved_relocations"
          ],
          "type": "object"
        }
      ]
    },
    "attempt_count": {
      "maximum": 32,
      "minimum": 0,
      "type": "integer"
    },
    "attempt_limit": {
      "maximum": 32,
      "minimum": 1,
      "type": "integer"
    },
    "attempts": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "claim": {
      "type": "string"
    },
    "compiler_profile": {
      "type": "object"
    },
    "created_at": {
      "type": "string"
    },
    "job": {
      "type": "object"
    },
    "kind": {
      "const": "local_llm_byte_match"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "profile": {
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "status": {
      "enum": [
        "byte_matched",
        "blocked",
        "exhausted"
      ]
    }
  },
  "required": [
    "schema_version",
    "kind",
    "created_at",
    "status",
    "profile",
    "compiler_profile",
    "job",
    "attempt_limit",
    "attempt_count",
    "attempts",
    "accepted",
    "claim",
    "limitations"
  ],
  "title": "Local LLM exact byte-match report",
  "type": "object"
}
```
