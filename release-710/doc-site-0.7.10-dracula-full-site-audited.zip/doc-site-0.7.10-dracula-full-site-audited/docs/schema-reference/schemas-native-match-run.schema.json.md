---
title: 'Schema: schemas/native/match-run.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/native/match-run.schema.json.
---

# `schemas/native/match-run.schema.json`

- **SHA-256:** `7afbfb42c5995ff375a050c93bb119ce50f2a761220c610f2c1622f082c23fb5`
- **Title:** x86decomp match-run
- **Type:** `object`
- **Properties:** 2
- **Required fields:** 2
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `comparison_policy` | `unspecified` | yes | No description declared. |
| `original_path` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.invalid/schemas/native/match-run.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "comparison_policy": {
      "enum": [
        "exact",
        "trailing-padding"
      ]
    },
    "original_path": {
      "type": "string"
    }
  },
  "required": [
    "original_path",
    "comparison_policy"
  ],
  "title": "x86decomp match-run",
  "type": "object"
}
```
