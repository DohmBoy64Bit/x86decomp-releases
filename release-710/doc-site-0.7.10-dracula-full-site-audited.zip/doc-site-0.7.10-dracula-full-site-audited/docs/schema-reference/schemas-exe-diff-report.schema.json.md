---
title: 'Schema: schemas/exe-diff-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/exe-diff-report.schema.json.
---

# `schemas/exe-diff-report.schema.json`

- **SHA-256:** `3bfb70b7158750523074f638ff5955cc519097a37543f9f097909f4576373b50`
- **Title:** PE function to COFF symbol comparison
- **Type:** `object`
- **Properties:** 14
- **Required fields:** 8
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | no | No description declared. |
| `classification` | `unspecified` | yes | No description declared. |
| `coff` | `object` | yes | No description declared. |
| `created_at` | `string` | no | No description declared. |
| `instruction_comparison` | `['object', 'null']` | no | No description declared. |
| `instruction_comparison_error` | `['string', 'null']` | no | No description declared. |
| `kind` | `unspecified` | no | No description declared. |
| `limitations` | `array` | no | No description declared. |
| `normalization_masks` | `array` | yes | No description declared. |
| `normalized_byte_comparison` | `object` | yes | No description declared. |
| `pe` | `object` | yes | No description declared. |
| `raw_byte_comparison` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `semantic_equivalence_claimed` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:exe-diff-report:2",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "classification": {
      "enum": [
        "byte_matched",
        "relocation_normalized_match",
        "instruction_similar",
        "mismatch"
      ]
    },
    "coff": {
      "type": "object"
    },
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "instruction_comparison": {
      "type": [
        "object",
        "null"
      ]
    },
    "instruction_comparison_error": {
      "type": [
        "string",
        "null"
      ]
    },
    "kind": {
      "const": "pe_function_vs_coff_symbol"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "normalization_masks": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "normalized_byte_comparison": {
      "type": "object"
    },
    "pe": {
      "type": "object"
    },
    "raw_byte_comparison": {
      "type": "object"
    },
    "schema_version": {
      "const": 2
    },
    "semantic_equivalence_claimed": {
      "const": false
    }
  },
  "required": [
    "schema_version",
    "classification",
    "pe",
    "coff",
    "normalization_masks",
    "raw_byte_comparison",
    "normalized_byte_comparison",
    "semantic_equivalence_claimed"
  ],
  "title": "PE function to COFF symbol comparison",
  "type": "object"
}
```
