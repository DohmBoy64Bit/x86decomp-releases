---
title: 'Schema: schemas/native/hybrid-composition.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/native/hybrid-composition.schema.json.
---

# `schemas/native/hybrid-composition.schema.json`

- **SHA-256:** `feb6682c1aa1ed0a3bc3c06230ce27f006641d96238050151ad22584eb02cb9d`
- **Title:** x86decomp hybrid-composition
- **Type:** `object`
- **Properties:** 4
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `fallback_count` | `integer` | yes | No description declared. |
| `output` | `string` | yes | No description declared. |
| `promoted_count` | `integer` | yes | No description declared. |
| `run_id` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.invalid/schemas/native/hybrid-composition.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "fallback_count": {
      "minimum": 0,
      "type": "integer"
    },
    "output": {
      "type": "string"
    },
    "promoted_count": {
      "minimum": 0,
      "type": "integer"
    },
    "run_id": {
      "type": "string"
    }
  },
  "required": [
    "run_id",
    "output",
    "promoted_count",
    "fallback_count"
  ],
  "title": "x86decomp hybrid-composition",
  "type": "object"
}
```
