---
title: 'Schema: schemas/local-llm/candidate.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/local-llm/candidate.schema.json.
---

# `schemas/local-llm/candidate.schema.json`

- **SHA-256:** `cadff624248794b1841a55fd49f2f980658a442d046530c183ec0c89d44d99ab`
- **Title:** Local LLM C proposal response
- **Type:** `object`
- **Properties:** 4
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `assumptions` | `array` | yes | No description declared. |
| `c_source` | `string` | yes | No description declared. |
| `rationale` | `string` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/local-llm/candidate.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "assumptions": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "c_source": {
      "type": "string"
    },
    "rationale": {
      "minLength": 1,
      "type": "string"
    },
    "status": {
      "enum": [
        "proposed",
        "blocked"
      ]
    }
  },
  "required": [
    "status",
    "c_source",
    "assumptions",
    "rationale"
  ],
  "title": "Local LLM C proposal response",
  "type": "object"
}
```
