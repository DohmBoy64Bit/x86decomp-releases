---
title: 'Schema: schemas/objdiff-manifest.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/objdiff-manifest.schema.json.
---

# `schemas/objdiff-manifest.schema.json`

- **SHA-256:** `2fe8f65399749687b2890cc643f474c0b8de221e90f6ae5013ce0d8b46590360`
- **Title:** objdiff external invocation manifest
- **Type:** `object`
- **Properties:** 12
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `arguments` | `array` | yes | No description declared. |
| `candidate` | `string` | yes | No description declared. |
| `environment` | `object` | no | No description declared. |
| `executable` | `string` | no | No description declared. |
| `inherit_environment` | `boolean` | no | No description declared. |
| `output` | `string` | no | No description declared. |
| `output_format` | `unspecified` | no | No description declared. |
| `require_output` | `boolean` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `success_exit_codes` | `array` | no | No description declared. |
| `target` | `string` | yes | No description declared. |
| `timeout_seconds` | `integer` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:objdiff-manifest:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "arguments": {
      "items": {
        "type": "string"
      },
      "minItems": 1,
      "type": "array"
    },
    "candidate": {
      "minLength": 1,
      "type": "string"
    },
    "environment": {
      "additionalProperties": {
        "type": "string"
      },
      "type": "object"
    },
    "executable": {
      "minLength": 1,
      "type": "string"
    },
    "inherit_environment": {
      "type": "boolean"
    },
    "output": {
      "minLength": 1,
      "type": "string"
    },
    "output_format": {
      "enum": [
        "json",
        "text"
      ]
    },
    "require_output": {
      "type": "boolean"
    },
    "schema_version": {
      "const": 1
    },
    "success_exit_codes": {
      "items": {
        "type": "integer"
      },
      "minItems": 1,
      "type": "array"
    },
    "target": {
      "minLength": 1,
      "type": "string"
    },
    "timeout_seconds": {
      "minimum": 1,
      "type": "integer"
    }
  },
  "required": [
    "schema_version",
    "target",
    "candidate",
    "arguments"
  ],
  "title": "objdiff external invocation manifest",
  "type": "object"
}
```
