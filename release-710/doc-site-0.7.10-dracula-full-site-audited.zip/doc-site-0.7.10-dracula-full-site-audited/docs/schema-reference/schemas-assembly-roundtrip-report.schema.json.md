---
title: 'Schema: schemas/assembly/roundtrip-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/assembly/roundtrip-report.schema.json.
---

# `schemas/assembly/roundtrip-report.schema.json`

- **SHA-256:** `8b931b7257911cb049122ad566b9913a950afe129602be58a36bf10ae774c8b3`
- **Title:** v0.7.10 mnemonic round-trip report
- **Type:** `object`
- **Properties:** 10
- **Required fields:** 9
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `classification` | `unspecified` | yes | No description declared. |
| `exact_match` | `boolean` | yes | No description declared. |
| `input_sha256` | `string` | yes | No description declared. |
| `object` | `string` | yes | No description declared. |
| `resolved_sha256` | `string` | yes | No description declared. |
| `rva` | `integer` | yes | No description declared. |
| `semantic_equivalence_claimed` | `unspecified` | no | No description declared. |
| `source` | `string` | yes | No description declared. |
| `symbol` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/assembly/roundtrip-report.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "classification": {
      "enum": [
        "exact",
        "mismatch"
      ]
    },
    "exact_match": {
      "type": "boolean"
    },
    "input_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "object": {
      "minLength": 1,
      "type": "string"
    },
    "resolved_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "rva": {
      "minimum": 0,
      "type": "integer"
    },
    "semantic_equivalence_claimed": {
      "const": false
    },
    "source": {
      "minLength": 1,
      "type": "string"
    },
    "symbol": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "source",
    "object",
    "symbol",
    "rva",
    "architecture",
    "input_sha256",
    "resolved_sha256",
    "exact_match",
    "classification"
  ],
  "title": "v0.7.10 mnemonic round-trip report",
  "type": "object"
}
```
