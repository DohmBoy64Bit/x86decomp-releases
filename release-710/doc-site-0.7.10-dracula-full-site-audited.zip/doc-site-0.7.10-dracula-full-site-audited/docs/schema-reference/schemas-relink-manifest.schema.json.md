---
title: 'Schema: schemas/relink-manifest.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/relink-manifest.schema.json.
---

# `schemas/relink-manifest.schema.json`

- **SHA-256:** `ca2b77b7be6b562589e841753a9afa8c6baf1fc7cf8c703409c90fc56507e890`
- **Title:** Manifest-driven full relink
- **Type:** `object`
- **Properties:** 9
- **Required fields:** 7
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `arguments` | `array` | yes | No description declared. |
| `environment` | `object` | yes | No description declared. |
| `inherit_environment` | `boolean` | no | No description declared. |
| `linker` | `string` | yes | No description declared. |
| `objects` | `array` | yes | No description declared. |
| `output` | `string` | yes | No description declared. |
| `reference_image` | `string` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `timeout_seconds` | `integer` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:relink-manifest:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "arguments": {
      "contains": {
        "pattern": "\\{output\\}"
      },
      "items": {
        "type": "string"
      },
      "minItems": 1,
      "type": "array"
    },
    "environment": {
      "additionalProperties": {
        "type": "string"
      },
      "type": "object"
    },
    "inherit_environment": {
      "type": "boolean"
    },
    "linker": {
      "minLength": 1,
      "type": "string"
    },
    "objects": {
      "items": {
        "type": "string"
      },
      "minItems": 1,
      "type": "array"
    },
    "output": {
      "minLength": 1,
      "type": "string"
    },
    "reference_image": {
      "type": "string"
    },
    "schema_version": {
      "const": 1
    },
    "timeout_seconds": {
      "minimum": 1,
      "type": "integer"
    }
  },
  "required": [
    "schema_version",
    "linker",
    "objects",
    "output",
    "arguments",
    "environment",
    "timeout_seconds"
  ],
  "title": "Manifest-driven full relink",
  "type": "object"
}
```
