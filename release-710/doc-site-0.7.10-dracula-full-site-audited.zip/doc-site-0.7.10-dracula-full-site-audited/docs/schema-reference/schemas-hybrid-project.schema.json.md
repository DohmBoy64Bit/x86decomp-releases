---
title: 'Schema: schemas/hybrid-project.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/hybrid-project.schema.json.
---

# `schemas/hybrid-project.schema.json`

- **SHA-256:** `c72692b4469f7ba92b2945968974d495371e2c0f03ad438c970418c3ce31d9b0`
- **Title:** Continuously buildable hybrid project
- **Type:** `object`
- **Properties:** 6
- **Required fields:** 6
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `build` | `object` | yes | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `functions` | `array` | yes | No description declared. |
| `project_root` | `string` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:hybrid-project:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "build": {
      "additionalProperties": false,
      "properties": {
        "kind": {
          "type": "string"
        },
        "object_count": {
          "minimum": 0,
          "type": "integer"
        }
      },
      "required": [
        "kind",
        "object_count"
      ],
      "type": "object"
    },
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "functions": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "active_build_form": {
            "enum": [
              "assembly",
              "matched_source",
              "functional_source"
            ]
          },
          "assembly": {
            "type": "string"
          },
          "function_id": {
            "type": "string"
          },
          "rva": {
            "type": "integer"
          },
          "source_of_truth": {
            "type": "string"
          },
          "staging_source": {
            "type": [
              "string",
              "null"
            ]
          },
          "symbol": {
            "type": "string"
          }
        },
        "required": [
          "function_id",
          "rva",
          "symbol",
          "assembly",
          "active_build_form",
          "source_of_truth"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "project_root": {
      "type": "string"
    },
    "schema_version": {
      "const": 1
    }
  },
  "required": [
    "schema_version",
    "created_at",
    "project_root",
    "architecture",
    "functions",
    "build"
  ],
  "title": "Continuously buildable hybrid project",
  "type": "object"
}
```
