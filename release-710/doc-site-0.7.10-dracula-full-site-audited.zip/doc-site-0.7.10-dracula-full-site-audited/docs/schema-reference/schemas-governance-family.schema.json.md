---
title: 'Schema: schemas/governance/family.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/governance/family.schema.json.
---

# `schemas/governance/family.schema.json`

- **SHA-256:** `cd02347eefe68396b21d7ec5af6ef9c1554dd4715e962e302ece657cb0b851ed`
- **Title:** binary family report
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `correlations` | `array` | yes | No description declared. |
| `family_id` | `string` | yes | No description declared. |
| `members` | `array` | yes | No description declared. |
| `name` | `string` | yes | No description declared. |
| `non_claims` | `array` | yes | No description declared. |

## Raw schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "correlations": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "family_id": {
      "type": "string"
    },
    "members": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "name": {
      "type": "string"
    },
    "non_claims": {
      "items": {
        "type": "string"
      },
      "type": "array"
    }
  },
  "required": [
    "family_id",
    "name",
    "members",
    "correlations",
    "non_claims"
  ],
  "title": "binary family report",
  "type": "object"
}
```
