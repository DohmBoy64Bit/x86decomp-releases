---
title: 'Schema: schemas/governance/changeset.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/governance/changeset.schema.json.
---

# `schemas/governance/changeset.schema.json`

- **SHA-256:** `6788b90056dbf46cdaaaab292bdc6c3102e20ff47c790f131b47c15d08f5cbd3`
- **Title:** changeset manifest
- **Type:** `object`
- **Properties:** 6
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `base_event_hash` | `['string', 'null']` | yes | No description declared. |
| `changeset_id` | `string` | yes | No description declared. |
| `created_at` | `string` | no | No description declared. |
| `event_count` | `integer` | yes | No description declared. |
| `format` | `unspecified` | yes | No description declared. |
| `tip_event_hash` | `['string', 'null']` | yes | No description declared. |

## Raw schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "base_event_hash": {
      "type": [
        "string",
        "null"
      ]
    },
    "changeset_id": {
      "type": "string"
    },
    "created_at": {
      "type": "string"
    },
    "event_count": {
      "minimum": 0,
      "type": "integer"
    },
    "format": {
      "const": "x86decomp-governance-changeset-v1"
    },
    "tip_event_hash": {
      "type": [
        "string",
        "null"
      ]
    }
  },
  "required": [
    "format",
    "changeset_id",
    "base_event_hash",
    "tip_event_hash",
    "event_count"
  ],
  "title": "changeset manifest",
  "type": "object"
}
```
