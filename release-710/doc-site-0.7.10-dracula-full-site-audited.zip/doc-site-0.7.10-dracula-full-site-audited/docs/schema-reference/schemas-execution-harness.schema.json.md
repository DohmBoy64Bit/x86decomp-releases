---
title: 'Schema: schemas/execution-harness.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/execution-harness.schema.json.
---

# `schemas/execution-harness.schema.json`

- **SHA-256:** `2ec27dc202dcf7ab923c646c71e30769b0c18527aaf2e6ba44e70536574e4f68`
- **Title:** Bounded Unicorn execution harness
- **Type:** `object`
- **Properties:** 13
- **Required fields:** 1
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `code_base` | `integer` | no | No description declared. |
| `max_instructions` | `integer` | no | No description declared. |
| `memory` | `array` | no | No description declared. |
| `observe_memory` | `array` | no | No description declared. |
| `observe_registers` | `array` | no | No description declared. |
| `registers` | `object` | no | No description declared. |
| `sentinel_address` | `integer` | no | No description declared. |
| `stack_arguments_hex` | `string` | no | No description declared. |
| `stack_base` | `integer` | no | No description declared. |
| `stack_size` | `integer` | no | No description declared. |
| `stubs` | `object` | no | No description declared. |
| `timeout_ms` | `integer` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:execution-harness:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "code_base": {
      "minimum": 1,
      "type": "integer"
    },
    "max_instructions": {
      "minimum": 1,
      "type": "integer"
    },
    "memory": {
      "items": {
        "properties": {
          "address": {
            "minimum": 0,
            "type": "integer"
          },
          "data_hex": {
            "pattern": "^(?:[0-9a-fA-F]{2})*$",
            "type": "string"
          },
          "size": {
            "minimum": 1,
            "type": "integer"
          }
        },
        "required": [
          "address"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "observe_memory": {
      "items": {
        "properties": {
          "address": {
            "minimum": 0,
            "type": "integer"
          },
          "size": {
            "minimum": 1,
            "type": "integer"
          }
        },
        "required": [
          "address",
          "size"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "observe_registers": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "registers": {
      "additionalProperties": {
        "type": "integer"
      },
      "type": "object"
    },
    "sentinel_address": {
      "minimum": 1,
      "type": "integer"
    },
    "stack_arguments_hex": {
      "pattern": "^(?:[0-9a-fA-F]{2})*$",
      "type": "string"
    },
    "stack_base": {
      "minimum": 1,
      "type": "integer"
    },
    "stack_size": {
      "minimum": 4096,
      "type": "integer"
    },
    "stubs": {
      "additionalProperties": {
        "additionalProperties": {
          "type": "integer"
        },
        "type": "object"
      },
      "type": "object"
    },
    "timeout_ms": {
      "minimum": 1,
      "type": "integer"
    }
  },
  "required": [
    "architecture"
  ],
  "title": "Bounded Unicorn execution harness",
  "type": "object"
}
```
