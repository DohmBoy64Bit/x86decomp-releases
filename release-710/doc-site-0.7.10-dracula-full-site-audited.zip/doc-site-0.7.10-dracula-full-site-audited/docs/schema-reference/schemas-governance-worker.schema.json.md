---
title: 'Schema: schemas/governance/worker.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/governance/worker.schema.json.
---

# `schemas/governance/worker.schema.json`

- **SHA-256:** `ca8f6768a4c7dfe89e80f2107c4bb43badde4d01d3ec6947ff001c9b207b403c`
- **Title:** worker profile
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 3
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `capabilities` | `object` | yes | No description declared. |
| `endpoint` | `['string', 'null']` | no | No description declared. |
| `environment_sha256` | `['string', 'null']` | no | No description declared. |
| `name` | `string` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "capabilities": {
      "minProperties": 1,
      "type": "object"
    },
    "endpoint": {
      "type": [
        "string",
        "null"
      ]
    },
    "environment_sha256": {
      "pattern": "^[a-f0-9]{64}$",
      "type": [
        "string",
        "null"
      ]
    },
    "name": {
      "type": "string"
    },
    "status": {
      "enum": [
        "active",
        "draining",
        "offline",
        "unhealthy"
      ]
    }
  },
  "required": [
    "name",
    "status",
    "capabilities"
  ],
  "title": "worker profile",
  "type": "object"
}
```
