---
title: 'Schema: schemas/assembly/symbol-map.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/assembly/symbol-map.schema.json.
---

# `schemas/assembly/symbol-map.schema.json`

- **SHA-256:** `f97c7d13405a4934af50a4eb8341a74601f1d398d323715b4788b9b1d748b43a`
- **Title:** v0.7.10 original-RVA symbol map
- **Type:** `object`
- **Properties:** 0
- **Required fields:** 0
- **Definitions:** 0

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/assembly/symbol-map.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": {
    "oneOf": [
      {
        "minimum": 0,
        "type": "integer"
      },
      {
        "pattern": "^(0[xX][0-9a-fA-F]+|[0-9]+)$",
        "type": "string"
      },
      {
        "additionalProperties": false,
        "properties": {
          "kind": {
            "type": "string"
          },
          "rva": {
            "oneOf": [
              {
                "minimum": 0,
                "type": "integer"
              },
              {
                "pattern": "^(0[xX][0-9a-fA-F]+|[0-9]+)$",
                "type": "string"
              }
            ]
          },
          "section_index": {
            "oneOf": [
              {
                "type": "null"
              },
              {
                "minimum": 1,
                "type": "integer"
              }
            ]
          },
          "section_rva": {
            "oneOf": [
              {
                "type": "null"
              },
              {
                "minimum": 0,
                "type": "integer"
              },
              {
                "pattern": "^(0[xX][0-9a-fA-F]+|[0-9]+)$",
                "type": "string"
              }
            ]
          }
        },
        "required": [
          "rva"
        ],
        "type": "object"
      }
    ]
  },
  "title": "v0.7.10 original-RVA symbol map",
  "type": "object"
}
```
