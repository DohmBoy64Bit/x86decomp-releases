---
title: 'Schema: schemas/compiler-profile.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/compiler-profile.schema.json.
---

# `schemas/compiler-profile.schema.json`

- **SHA-256:** `6903f160acf5cfb8329567efbdd2da82b9f171705971e9842afcae21a4a4f844`
- **Title:** x86decomp compiler profile
- **Type:** `object`
- **Properties:** 14
- **Required fields:** 9
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `arguments` | `array` | yes | No description declared. |
| `command_prefix` | `array` | no | No description declared. |
| `description` | `string` | yes | No description declared. |
| `environment` | `object` | yes | No description declared. |
| `executable` | `string` | yes | No description declared. |
| `family` | `['string', 'null']` | no | No description declared. |
| `id` | `string` | yes | No description declared. |
| `inherit_environment` | `boolean` | no | No description declared. |
| `language` | `unspecified` | yes | No description declared. |
| `output_kind` | `unspecified` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `timeout_seconds` | `integer` | yes | No description declared. |
| `version` | `['string', 'null']` | no | No description declared. |
| `version_arguments` | `array` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:compiler-profile:2",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "arguments": {
      "allOf": [
        {
          "contains": {
            "pattern": "\\{source\\}"
          }
        },
        {
          "contains": {
            "pattern": "\\{output\\}"
          }
        }
      ],
      "items": {
        "type": "string"
      },
      "minItems": 2,
      "type": "array"
    },
    "command_prefix": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "description": {
      "minLength": 1,
      "type": "string"
    },
    "environment": {
      "additionalProperties": {
        "type": "string"
      },
      "type": "object"
    },
    "executable": {
      "minLength": 1,
      "type": "string"
    },
    "family": {
      "type": [
        "string",
        "null"
      ]
    },
    "id": {
      "minLength": 1,
      "type": "string"
    },
    "inherit_environment": {
      "type": "boolean"
    },
    "language": {
      "enum": [
        "c",
        "c++",
        "assembly"
      ]
    },
    "output_kind": {
      "enum": [
        "relocatable_object",
        "executable",
        "assembly",
        "binary"
      ]
    },
    "schema_version": {
      "const": 2
    },
    "timeout_seconds": {
      "minimum": 1,
      "type": "integer"
    },
    "version": {
      "type": [
        "string",
        "null"
      ]
    },
    "version_arguments": {
      "items": {
        "type": "string"
      },
      "type": "array"
    }
  },
  "required": [
    "schema_version",
    "id",
    "description",
    "executable",
    "language",
    "output_kind",
    "timeout_seconds",
    "arguments",
    "environment"
  ],
  "title": "x86decomp compiler profile",
  "type": "object"
}
```
