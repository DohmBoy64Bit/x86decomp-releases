---
title: 'Schema: schemas/image-profile.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/image-profile.schema.json.
---

# `schemas/image-profile.schema.json`

- **SHA-256:** `5916e3589fb77876a26861ccfea7dfbfbf4b9c55e92243ed66dae4270dad70d7`
- **Title:** Target-specific PE image layout profile
- **Type:** `object`
- **Properties:** 9
- **Required fields:** 6
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `entry_rva` | `integer` | no | No description declared. |
| `image_base` | `integer` | no | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `normalization` | `object` | yes | No description declared. |
| `reference_sha256` | `string` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `section_order` | `array` | yes | No description declared. |
| `sections` | `array` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:image-profile:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "entry_rva": {
      "minimum": 0,
      "type": "integer"
    },
    "image_base": {
      "minimum": 0,
      "type": "integer"
    },
    "kind": {
      "const": "target_specific_image_profile"
    },
    "normalization": {
      "additionalProperties": false,
      "properties": {
        "certificate_directory_entry": {
          "type": "boolean"
        },
        "checksum": {
          "type": "boolean"
        },
        "coff_timestamp": {
          "type": "boolean"
        },
        "debug_directory_records": {
          "type": "boolean"
        },
        "extra_ranges": {
          "items": {
            "additionalProperties": false,
            "properties": {
              "end": {
                "minimum": 0,
                "type": "integer"
              },
              "reason": {
                "type": "string"
              },
              "start": {
                "minimum": 0,
                "type": "integer"
              }
            },
            "required": [
              "start",
              "end",
              "reason"
            ],
            "type": "object"
          },
          "type": "array"
        },
        "rebase_candidate": {
          "type": "boolean"
        }
      },
      "required": [
        "coff_timestamp",
        "checksum",
        "certificate_directory_entry",
        "debug_directory_records",
        "rebase_candidate",
        "extra_ranges"
      ],
      "type": "object"
    },
    "reference_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "schema_version": {
      "const": 1
    },
    "section_order": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "sections": {
      "items": {
        "type": "object"
      },
      "type": "array"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "reference_sha256",
    "architecture",
    "section_order",
    "normalization"
  ],
  "title": "Target-specific PE image layout profile",
  "type": "object"
}
```
