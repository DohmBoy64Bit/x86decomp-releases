---
title: 'Schema: schemas/project.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/project.schema.json.
---

# `schemas/project.schema.json`

- **SHA-256:** `4ab19d9064e8d249fdd545d1fa183920902d6afbe647d004ddd571a208295b0b`
- **Title:** x86decomp project (schema versions 1, 2, and 3)
- **Type:** `object`
- **Properties:** 21
- **Required fields:** 10
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `analysis_database` | `string` | no | No description declared. |
| `architecture` | `unspecified` | no | No description declared. |
| `binary` | `object` | yes | No description declared. |
| `content_store` | `string` | no | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `default_modes` | `unspecified` | no | No description declared. |
| `evidence_root` | `string` | yes | No description declared. |
| `function_root` | `string` | yes | No description declared. |
| `memory_ledger` | `string` | yes | No description declared. |
| `orchestration_root` | `string` | no | No description declared. |
| `program_manifest` | `string` | yes | No description declared. |
| `project_id` | `string` | yes | No description declared. |
| `project_state_database` | `string` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `supported_scope` | `unspecified` | yes | No description declared. |
| `target_id` | `string` | no | No description declared. |
| `target_pack` | `string` | no | No description declared. |
| `template_kind` | `unspecified` | no | No description declared. |
| `toolkit_release` | `string` | no | No description declared. |
| `work_queue` | `string` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:project:3",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "allOf": [
    {
      "if": {
        "properties": {
          "schema_version": {
            "const": 1
          }
        },
        "required": [
          "schema_version"
        ]
      },
      "then": {
        "properties": {
          "project_id": {
            "pattern": "^x86d-[0-9a-f]{16}-[0-9a-f]{8}$"
          },
          "supported_scope": {
            "const": "native Windows PE32 x86"
          }
        }
      }
    },
    {
      "if": {
        "properties": {
          "schema_version": {
            "enum": [
              2,
              3
            ]
          }
        },
        "required": [
          "schema_version"
        ]
      },
      "then": {
        "required": [
          "architecture",
          "default_modes",
          "analysis_database",
          "work_queue"
        ]
      }
    },
    {
      "if": {
        "properties": {
          "schema_version": {
            "const": 3
          }
        },
        "required": [
          "schema_version"
        ]
      },
      "then": {
        "required": [
          "project_state_database",
          "content_store",
          "target_pack",
          "orchestration_root",
          "toolkit_release"
        ]
      }
    }
  ],
  "properties": {
    "analysis_database": {
      "minLength": 1,
      "type": "string"
    },
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "binary": {
      "additionalProperties": false,
      "properties": {
        "name": {
          "minLength": 1,
          "type": "string"
        },
        "path": {
          "minLength": 1,
          "type": "string"
        },
        "sha256": {
          "pattern": "^[0-9a-f]{64}$",
          "type": "string"
        },
        "size": {
          "minimum": 1,
          "type": "integer"
        },
        "source_kind": {
          "enum": [
            "copied",
            "external_reference"
          ]
        }
      },
      "required": [
        "name",
        "source_kind",
        "path",
        "sha256",
        "size"
      ],
      "type": "object"
    },
    "content_store": {
      "minLength": 1,
      "type": "string"
    },
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "default_modes": {
      "const": [
        "matching",
        "functional"
      ]
    },
    "evidence_root": {
      "minLength": 1,
      "type": "string"
    },
    "function_root": {
      "minLength": 1,
      "type": "string"
    },
    "memory_ledger": {
      "minLength": 1,
      "type": "string"
    },
    "orchestration_root": {
      "minLength": 1,
      "type": "string"
    },
    "program_manifest": {
      "minLength": 1,
      "type": "string"
    },
    "project_id": {
      "pattern": "^(?:x86d|x64d)-[0-9a-f]{16}-[0-9a-f]{8}$",
      "type": "string"
    },
    "project_state_database": {
      "minLength": 1,
      "type": "string"
    },
    "schema_version": {
      "enum": [
        1,
        2,
        3
      ]
    },
    "status": {
      "enum": [
        "initialized",
        "analyzing",
        "active",
        "archived"
      ]
    },
    "supported_scope": {
      "enum": [
        "native Windows PE32 x86",
        "native Windows PE32+ x86-64"
      ]
    },
    "target_id": {
      "minLength": 1,
      "type": "string"
    },
    "target_pack": {
      "minLength": 1,
      "type": "string"
    },
    "template_kind": {
      "enum": [
        "matching",
        "functional",
        "hybrid"
      ]
    },
    "toolkit_release": {
      "pattern": "^[0-9]+\\.[0-9]+\\.[0-9]+$",
      "type": "string"
    },
    "work_queue": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "project_id",
    "created_at",
    "supported_scope",
    "binary",
    "program_manifest",
    "memory_ledger",
    "function_root",
    "evidence_root",
    "status"
  ],
  "title": "x86decomp project (schema versions 1, 2, and 3)",
  "type": "object"
}
```
