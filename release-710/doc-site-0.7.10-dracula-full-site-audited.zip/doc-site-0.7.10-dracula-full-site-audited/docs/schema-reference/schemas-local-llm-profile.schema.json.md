---
title: 'Schema: schemas/local-llm/profile.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/local-llm/profile.schema.json.
---

# `schemas/local-llm/profile.schema.json`

- **SHA-256:** `dc3ed501bada8be1896567c329fd550ad843059786ed07bbae6ef3063fdfe3ee`
- **Title:** Local LLM provider profile
- **Type:** `object`
- **Properties:** 17
- **Required fields:** 17
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `allow_remote` | `boolean` | yes | No description declared. |
| `api_key_env` | `['string', 'null']` | yes | No description declared. |
| `base_url` | `string` | yes | No description declared. |
| `chat_path` | `string` | yes | No description declared. |
| `headers` | `object` | yes | No description declared. |
| `id` | `string` | yes | No description declared. |
| `max_response_bytes` | `integer` | yes | No description declared. |
| `max_tokens` | `integer` | yes | No description declared. |
| `model` | `string` | yes | No description declared. |
| `models_path` | `string` | yes | No description declared. |
| `protocol` | `unspecified` | yes | No description declared. |
| `provider` | `unspecified` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `structured_output` | `unspecified` | yes | No description declared. |
| `temperature` | `number` | yes | No description declared. |
| `timeout_seconds` | `integer` | yes | No description declared. |
| `verify_tls` | `boolean` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/local-llm/profile.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "allow_remote": {
      "type": "boolean"
    },
    "api_key_env": {
      "minLength": 1,
      "type": [
        "string",
        "null"
      ]
    },
    "base_url": {
      "format": "uri",
      "pattern": "^https?://",
      "type": "string"
    },
    "chat_path": {
      "pattern": "^/",
      "type": "string"
    },
    "headers": {
      "additionalProperties": {
        "type": "string"
      },
      "type": "object"
    },
    "id": {
      "maxLength": 256,
      "minLength": 1,
      "type": "string"
    },
    "max_response_bytes": {
      "maximum": 67108864,
      "minimum": 1024,
      "type": "integer"
    },
    "max_tokens": {
      "maximum": 1000000,
      "minimum": 1,
      "type": "integer"
    },
    "model": {
      "minLength": 1,
      "type": "string"
    },
    "models_path": {
      "pattern": "^/",
      "type": "string"
    },
    "protocol": {
      "enum": [
        "openai-chat",
        "ollama-chat"
      ]
    },
    "provider": {
      "enum": [
        "lm-studio",
        "ollama",
        "llama.cpp",
        "vllm",
        "localai",
        "openai-compatible"
      ]
    },
    "schema_version": {
      "const": 1
    },
    "structured_output": {
      "enum": [
        "openai-json-schema",
        "ollama-json-schema",
        "none"
      ]
    },
    "temperature": {
      "maximum": 2,
      "minimum": 0,
      "type": "number"
    },
    "timeout_seconds": {
      "maximum": 3600,
      "minimum": 1,
      "type": "integer"
    },
    "verify_tls": {
      "type": "boolean"
    }
  },
  "required": [
    "schema_version",
    "id",
    "provider",
    "protocol",
    "base_url",
    "models_path",
    "chat_path",
    "structured_output",
    "model",
    "temperature",
    "max_tokens",
    "timeout_seconds",
    "max_response_bytes",
    "verify_tls",
    "allow_remote",
    "api_key_env",
    "headers"
  ],
  "title": "Local LLM provider profile",
  "type": "object"
}
```
