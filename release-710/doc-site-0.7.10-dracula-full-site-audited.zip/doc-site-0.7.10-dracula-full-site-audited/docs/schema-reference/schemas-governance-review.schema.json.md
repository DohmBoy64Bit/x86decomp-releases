---
title: 'Schema: schemas/governance/review.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/governance/review.schema.json.
---

# `schemas/governance/review.schema.json`

- **SHA-256:** `280cfe7963adcdcbbb3a1fde01b921cad82751d2240a4fcdaa9b9543db071bc2`
- **Title:** review item
- **Type:** `object`
- **Properties:** 7
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `details` | `object` | no | No description declared. |
| `kind` | `string` | yes | No description declared. |
| `locked` | `boolean` | no | No description declared. |
| `priority` | `integer` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `subject_id` | `string` | yes | No description declared. |
| `summary` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "details": {
      "type": "object"
    },
    "kind": {
      "type": "string"
    },
    "locked": {
      "type": "boolean"
    },
    "priority": {
      "maximum": 100,
      "minimum": 0,
      "type": "integer"
    },
    "status": {
      "enum": [
        "open",
        "assigned",
        "accepted",
        "rejected",
        "needs_evidence",
        "superseded"
      ]
    },
    "subject_id": {
      "type": "string"
    },
    "summary": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "kind",
    "subject_id",
    "priority",
    "status",
    "summary"
  ],
  "title": "review item",
  "type": "object"
}
```
