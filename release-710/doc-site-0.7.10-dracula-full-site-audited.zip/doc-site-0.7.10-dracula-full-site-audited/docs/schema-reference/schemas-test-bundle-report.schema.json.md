---
title: 'Schema: schemas/test-bundle-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/test-bundle-report.schema.json.
---

# `schemas/test-bundle-report.schema.json`

- **SHA-256:** `482f5b618cd46eb5e815392f2655bb9fe4f3683e1f5122b8f7ab0ea69f8a2820`
- **Title:** x86decomp Static Test Bundle Report
- **Type:** `object`
- **Properties:** 12
- **Required fields:** 10
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `analyses` | `object` | yes | No description declared. |
| `archive` | `object` | yes | No description declared. |
| `artifacts` | `array` | yes | No description declared. |
| `bundle` | `object` | yes | No description declared. |
| `created_at` | `string` | no | No description declared. |
| `errors` | `array` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `limitations` | `array` | no | No description declared. |
| `passed` | `boolean` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `static_analysis_only` | `unspecified` | yes | No description declared. |
| `supplied_code_executed` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:test-bundle-report:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "analyses": {
      "type": "object"
    },
    "archive": {
      "type": "object"
    },
    "artifacts": {
      "type": "array"
    },
    "bundle": {
      "type": "object"
    },
    "created_at": {
      "type": "string"
    },
    "errors": {
      "type": "array"
    },
    "kind": {
      "const": "static_test_bundle_report"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "passed": {
      "type": "boolean"
    },
    "schema_version": {
      "const": 1
    },
    "static_analysis_only": {
      "const": true
    },
    "supplied_code_executed": {
      "const": false
    }
  },
  "required": [
    "schema_version",
    "kind",
    "archive",
    "bundle",
    "artifacts",
    "analyses",
    "errors",
    "static_analysis_only",
    "supplied_code_executed",
    "passed"
  ],
  "title": "x86decomp Static Test Bundle Report",
  "type": "object"
}
```
