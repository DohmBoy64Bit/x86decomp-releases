---
title: 'Schema: schemas/abi-contract.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/abi-contract.schema.json.
---

# `schemas/abi-contract.schema.json`

- **SHA-256:** `536e89f5ab760329f3799138b17c8a321170fc1fc729528d97b7f75d4af96c76`
- **Title:** x86decomp ABI contract
- **Type:** `object`
- **Properties:** 10
- **Required fields:** 2
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `callee_stack_cleanup` | `['integer', 'null']` | no | No description declared. |
| `convention` | `unspecified` | yes | No description declared. |
| `floating_point` | `unspecified` | no | No description declared. |
| `register_arguments` | `array` | no | No description declared. |
| `return_registers` | `array` | no | No description declared. |
| `stack_argument_bytes` | `['integer', 'null']` | no | No description declared. |
| `structure_return` | `boolean` | no | No description declared. |
| `this_register` | `['string', 'null']` | no | No description declared. |
| `variadic` | `boolean` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:abi-contract:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "callee_stack_cleanup": {
      "minimum": 0,
      "type": [
        "integer",
        "null"
      ]
    },
    "convention": {
      "enum": [
        "cdecl",
        "stdcall",
        "thiscall",
        "fastcall",
        "vectorcall",
        "unknown"
      ]
    },
    "floating_point": {
      "enum": [
        "x87",
        "sse",
        "mixed",
        "none",
        "unknown"
      ]
    },
    "register_arguments": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "return_registers": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "stack_argument_bytes": {
      "minimum": 0,
      "type": [
        "integer",
        "null"
      ]
    },
    "structure_return": {
      "type": "boolean"
    },
    "this_register": {
      "type": [
        "string",
        "null"
      ]
    },
    "variadic": {
      "type": "boolean"
    }
  },
  "required": [
    "architecture",
    "convention"
  ],
  "title": "x86decomp ABI contract",
  "type": "object"
}
```
