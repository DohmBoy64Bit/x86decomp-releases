---
title: 'Schema: schemas/governance/proof-bundle.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/governance/proof-bundle.schema.json.
---

# `schemas/governance/proof-bundle.schema.json`

- **SHA-256:** `5a3d2a10a3b6fbefe7c8506518e9d6f86d99581355e562241eb8473769d63dea`
- **Title:** proof bundle manifest
- **Type:** `object`
- **Properties:** 4
- **Required fields:** 3
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `audit_tip` | `['string', 'null']` | no | No description declared. |
| `files` | `object` | yes | No description declared. |
| `format` | `unspecified` | yes | No description declared. |
| `release` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "audit_tip": {
      "type": [
        "string",
        "null"
      ]
    },
    "files": {
      "additionalProperties": {
        "additionalProperties": false,
        "properties": {
          "sha256": {
            "pattern": "^[a-f0-9]{64}$",
            "type": "string"
          },
          "size": {
            "minimum": 0,
            "type": "integer"
          }
        },
        "required": [
          "sha256",
          "size"
        ],
        "type": "object"
      },
      "type": "object"
    },
    "format": {
      "const": "x86decomp-proof-bundle-v1"
    },
    "release": {
      "const": "0.7.10"
    }
  },
  "required": [
    "format",
    "release",
    "files"
  ],
  "title": "proof bundle manifest",
  "type": "object"
}
```
