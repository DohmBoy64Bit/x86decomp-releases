---
title: 'Schema: schemas/decompme-packet.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/decompme-packet.schema.json.
---

# `schemas/decompme-packet.schema.json`

- **SHA-256:** `65cd0a5d3197e6de85ec46c8eb372a387102192d9341ee252a7f40ca83b91704`
- **Title:** Local decomp.me-style function packet
- **Type:** `object`
- **Properties:** 9
- **Required fields:** 9
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `created_at` | `string` | yes | No description declared. |
| `files` | `array` | yes | No description declared. |
| `function_id` | `string` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `limitations` | `array` | yes | No description declared. |
| `output_directory` | `string` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `source_artifact` | `string` | yes | No description declared. |
| `uploaded` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:decompme-packet:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "created_at": {
      "type": "string"
    },
    "files": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "path": {
            "type": "string"
          },
          "sha256": {
            "pattern": "^[0-9a-f]{64}$",
            "type": "string"
          },
          "size": {
            "minimum": 0,
            "type": "integer"
          }
        },
        "required": [
          "path",
          "sha256",
          "size"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "function_id": {
      "pattern": "^pe-rva:[0-9A-Fa-f]{8}$",
      "type": "string"
    },
    "kind": {
      "const": "local_decompme_function_packet"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "output_directory": {
      "type": "string"
    },
    "schema_version": {
      "const": 1
    },
    "source_artifact": {
      "type": "string"
    },
    "uploaded": {
      "const": false
    }
  },
  "required": [
    "schema_version",
    "created_at",
    "kind",
    "function_id",
    "source_artifact",
    "output_directory",
    "files",
    "uploaded",
    "limitations"
  ],
  "title": "Local decomp.me-style function packet",
  "type": "object"
}
```
