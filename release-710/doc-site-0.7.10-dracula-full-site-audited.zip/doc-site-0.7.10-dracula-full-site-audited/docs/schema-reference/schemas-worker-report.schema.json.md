---
title: 'Schema: schemas/worker-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/worker-report.schema.json.
---

# `schemas/worker-report.schema.json`

- **SHA-256:** `f4fee8d629c5e963519a4f5ab25c4bb0856592421ee218fe7d047b5ebe089b3c`
- **Title:** urn:x86decomp:schema:worker-report:1
- **Type:** `object`
- **Properties:** 15
- **Required fields:** 7
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `command` | `array` | yes | No description declared. |
| `duration_seconds` | `number` | no | No description declared. |
| `error` | `['string', 'null']` | no | No description declared. |
| `input_hashes` | `object` | yes | No description declared. |
| `isolation` | `unspecified` | yes | No description declared. |
| `isolation_strength` | `string` | yes | No description declared. |
| `output_hashes` | `object` | yes | No description declared. |
| `returncode` | `['integer', 'null']` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `started_at` | `string` | no | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `stderr_path` | `string` | no | No description declared. |
| `stderr_truncated` | `boolean` | no | No description declared. |
| `stdout_path` | `string` | no | No description declared. |
| `stdout_truncated` | `boolean` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:worker-report:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "command": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "duration_seconds": {
      "minimum": 0,
      "type": "number"
    },
    "error": {
      "type": [
        "string",
        "null"
      ]
    },
    "input_hashes": {
      "additionalProperties": {
        "type": "string"
      },
      "type": "object"
    },
    "isolation": {
      "enum": [
        "local_bounded",
        "container"
      ]
    },
    "isolation_strength": {
      "type": "string"
    },
    "output_hashes": {
      "additionalProperties": {
        "type": "string"
      },
      "type": "object"
    },
    "returncode": {
      "type": [
        "integer",
        "null"
      ]
    },
    "schema_version": {
      "const": 1
    },
    "started_at": {
      "type": "string"
    },
    "status": {
      "enum": [
        "passed",
        "failed",
        "error",
        "timeout"
      ]
    },
    "stderr_path": {
      "type": "string"
    },
    "stderr_truncated": {
      "type": "boolean"
    },
    "stdout_path": {
      "type": "string"
    },
    "stdout_truncated": {
      "type": "boolean"
    }
  },
  "required": [
    "schema_version",
    "status",
    "command",
    "isolation",
    "isolation_strength",
    "input_hashes",
    "output_hashes"
  ],
  "type": "object"
}
```
