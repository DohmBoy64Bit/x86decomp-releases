---
title: 'Schema: schemas/image-match-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/image-match-report.schema.json.
---

# `schemas/image-match-report.schema.json`

- **SHA-256:** `f81f81c2581b2941b9a3850aa2d296957e1d14de2ad3d8ee92839b34ccfadc23`
- **Title:** Target-specific whole-image match report
- **Type:** `object`
- **Properties:** 12
- **Required fields:** 10
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `candidate` | `object` | yes | No description declared. |
| `classification` | `unspecified` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `normalized_match` | `boolean` | yes | No description declared. |
| `normalized_mismatch_count` | `integer` | no | No description declared. |
| `profile` | `object` | yes | No description declared. |
| `raw_exact_match` | `boolean` | yes | No description declared. |
| `raw_mismatch_count` | `integer` | no | No description declared. |
| `reference` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `sections` | `array` | yes | No description declared. |
| `universal_equivalence_claimed` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:image-match-report:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "candidate": {
      "type": "object"
    },
    "classification": {
      "enum": [
        "byte_identical",
        "profile_normalized_match",
        "different"
      ]
    },
    "kind": {
      "const": "target_specific_whole_image_match"
    },
    "normalized_match": {
      "type": "boolean"
    },
    "normalized_mismatch_count": {
      "minimum": 0,
      "type": "integer"
    },
    "profile": {
      "type": "object"
    },
    "raw_exact_match": {
      "type": "boolean"
    },
    "raw_mismatch_count": {
      "minimum": 0,
      "type": "integer"
    },
    "reference": {
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "sections": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "universal_equivalence_claimed": {
      "const": false
    }
  },
  "required": [
    "schema_version",
    "kind",
    "reference",
    "candidate",
    "profile",
    "raw_exact_match",
    "normalized_match",
    "sections",
    "classification",
    "universal_equivalence_claimed"
  ],
  "title": "Target-specific whole-image match report",
  "type": "object"
}
```
