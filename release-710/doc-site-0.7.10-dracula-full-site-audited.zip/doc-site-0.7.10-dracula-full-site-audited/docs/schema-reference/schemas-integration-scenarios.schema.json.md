---
title: 'Schema: schemas/integration-scenarios.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/integration-scenarios.schema.json.
---

# `schemas/integration-scenarios.schema.json`

- **SHA-256:** `60799068b8df90e7d457415f6e08fa236a0620630ddab2641dec2ff8bac6e43e`
- **Title:** Integration scenario manifest
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 4
- **Definitions:** 1

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `captured_output_limit` | `integer` | no | No description declared. |
| `execution` | `object` | yes | No description declared. |
| `name` | `string` | yes | No description declared. |
| `scenarios` | `array` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$defs": {
    "process": {
      "additionalProperties": false,
      "properties": {
        "artifact": {
          "minLength": 1,
          "type": "string"
        },
        "command": {
          "items": {
            "type": "string"
          },
          "minItems": 1,
          "type": "array"
        },
        "environment": {
          "additionalProperties": {
            "type": "string"
          },
          "type": "object"
        },
        "inherit_environment": {
          "type": "boolean"
        }
      },
      "required": [
        "artifact",
        "command"
      ],
      "type": "object"
    }
  },
  "$id": "urn:x86decomp:schema:integration-scenarios:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "captured_output_limit": {
      "minimum": 1,
      "type": "integer"
    },
    "execution": {
      "additionalProperties": false,
      "allOf": [
        {
          "if": {
            "properties": {
              "mode": {
                "const": "host_explicit"
              }
            }
          },
          "then": {
            "properties": {
              "acknowledge_untrusted_code_risk": {
                "const": true
              }
            },
            "required": [
              "acknowledge_untrusted_code_risk"
            ]
          }
        },
        {
          "if": {
            "properties": {
              "mode": {
                "const": "external_wrapper"
              }
            }
          },
          "then": {
            "required": [
              "command_prefix"
            ]
          }
        }
      ],
      "properties": {
        "acknowledge_untrusted_code_risk": {
          "type": "boolean"
        },
        "command_prefix": {
          "items": {
            "type": "string"
          },
          "minItems": 1,
          "type": "array"
        },
        "mode": {
          "enum": [
            "host_explicit",
            "external_wrapper"
          ]
        }
      },
      "required": [
        "mode"
      ],
      "type": "object"
    },
    "name": {
      "minLength": 1,
      "type": "string"
    },
    "scenarios": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "candidate": {
            "$ref": "#/$defs/process"
          },
          "fixtures": {
            "items": {
              "additionalProperties": false,
              "properties": {
                "destination": {
                  "minLength": 1,
                  "type": "string"
                },
                "source": {
                  "minLength": 1,
                  "type": "string"
                }
              },
              "required": [
                "source",
                "destination"
              ],
              "type": "object"
            },
            "type": "array"
          },
          "id": {
            "minLength": 1,
            "type": "string"
          },
          "observations": {
            "additionalProperties": false,
            "properties": {
              "exit_code": {
                "type": "boolean"
              },
              "files": {
                "items": {
                  "additionalProperties": false,
                  "properties": {
                    "mode": {
                      "enum": [
                        "sha256",
                        "bytes",
                        "text"
                      ]
                    },
                    "optional": {
                      "type": "boolean"
                    },
                    "path": {
                      "minLength": 1,
                      "type": "string"
                    }
                  },
                  "required": [
                    "path"
                  ],
                  "type": "object"
                },
                "type": "array"
              },
              "stderr": {
                "enum": [
                  "ignore",
                  "exact",
                  "sha256"
                ]
              },
              "stdout": {
                "enum": [
                  "ignore",
                  "exact",
                  "sha256"
                ]
              }
            },
            "type": "object"
          },
          "stdin": {
            "additionalProperties": false,
            "oneOf": [
              {
                "required": [
                  "text"
                ]
              },
              {
                "required": [
                  "base64"
                ]
              },
              {
                "required": [
                  "file"
                ]
              }
            ],
            "properties": {
              "base64": {
                "type": "string"
              },
              "file": {
                "type": "string"
              },
              "text": {
                "type": "string"
              }
            },
            "type": "object"
          },
          "target": {
            "$ref": "#/$defs/process"
          },
          "timeout_seconds": {
            "minimum": 1,
            "type": "integer"
          }
        },
        "required": [
          "id",
          "target",
          "candidate",
          "observations"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "schema_version": {
      "const": 1
    }
  },
  "required": [
    "schema_version",
    "name",
    "execution",
    "scenarios"
  ],
  "title": "Integration scenario manifest",
  "type": "object"
}
```
