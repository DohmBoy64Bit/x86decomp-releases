---
title: 'Schema: schemas/verification.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/verification.schema.json.
---

# `schemas/verification.schema.json`

- **SHA-256:** `a70e3422e6b0bec967695257c7b66d44f17a0cfe3f15d99799eb1c038ccb7fa0`
- **Title:** x86decomp byte verification report
- **Type:** `object`
- **Properties:** 13
- **Required fields:** 13
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `candidate_sha256` | `string` | yes | No description declared. |
| `candidate_size` | `integer` | yes | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `equal` | `boolean` | yes | No description declared. |
| `matching_prefix_bytes` | `integer` | yes | No description declared. |
| `matching_suffix_bytes` | `integer` | yes | No description declared. |
| `mismatch_report_truncated` | `boolean` | yes | No description declared. |
| `reported_mismatches` | `array` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `semantic_equivalence_claimed` | `unspecified` | yes | No description declared. |
| `sequence_similarity` | `number` | yes | No description declared. |
| `target_sha256` | `string` | yes | No description declared. |
| `target_size` | `integer` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:verification:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "candidate_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "candidate_size": {
      "minimum": 0,
      "type": "integer"
    },
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "equal": {
      "type": "boolean"
    },
    "matching_prefix_bytes": {
      "minimum": 0,
      "type": "integer"
    },
    "matching_suffix_bytes": {
      "minimum": 0,
      "type": "integer"
    },
    "mismatch_report_truncated": {
      "type": "boolean"
    },
    "reported_mismatches": {
      "type": "array"
    },
    "schema_version": {
      "const": 1
    },
    "semantic_equivalence_claimed": {
      "const": false
    },
    "sequence_similarity": {
      "maximum": 1,
      "minimum": 0,
      "type": "number"
    },
    "target_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "target_size": {
      "minimum": 0,
      "type": "integer"
    }
  },
  "required": [
    "schema_version",
    "created_at",
    "equal",
    "target_size",
    "candidate_size",
    "target_sha256",
    "candidate_sha256",
    "matching_prefix_bytes",
    "matching_suffix_bytes",
    "sequence_similarity",
    "reported_mismatches",
    "mismatch_report_truncated",
    "semantic_equivalence_claimed"
  ],
  "title": "x86decomp byte verification report",
  "type": "object"
}
```
