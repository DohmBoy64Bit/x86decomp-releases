---
title: 'Schema: schemas/reconstruction/abi-contract.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/reconstruction/abi-contract.schema.json.
---

# `schemas/reconstruction/abi-contract.schema.json`

- **SHA-256:** `d2286943caed629e873a4107fcceb21f18b0759cfebd17b71f761af14e68e016`
- **Title:** ABI contract
- **Type:** `object`
- **Properties:** 6
- **Required fields:** 6
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `contract` | `object` | yes | No description declared. |
| `contract_id` | `string` | yes | No description declared. |
| `evidence` | `array` | yes | No description declared. |
| `subject_id` | `string` | yes | No description declared. |
| `subject_kind` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.dev/schemas/reconstruction/abi-contract.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "contract": {
      "type": "object"
    },
    "contract_id": {
      "pattern": "^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$",
      "type": "string"
    },
    "evidence": {
      "items": {
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "subject_id": {
      "minLength": 1,
      "type": "string"
    },
    "subject_kind": {
      "enum": [
        "function",
        "module",
        "library",
        "executable",
        "interface"
      ]
    }
  },
  "required": [
    "contract_id",
    "subject_kind",
    "subject_id",
    "architecture",
    "contract",
    "evidence"
  ],
  "title": "ABI contract",
  "type": "object"
}
```
