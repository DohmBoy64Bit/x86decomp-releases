---
title: 'Schema: schemas/drcov-trace.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/drcov-trace.schema.json.
---

# `schemas/drcov-trace.schema.json`

- **SHA-256:** `aedc8ab92612b4b325552d3de98da9d04e2e4c3aa2bb2ab319e20f85616cfe7f`
- **Title:** Normalized DynamoRIO drcov text trace
- **Type:** `object`
- **Properties:** 10
- **Required fields:** 8
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `basic_blocks` | `array` | yes | No description declared. |
| `drcov_flavor` | `['string', 'null']` | no | No description declared. |
| `drcov_version` | `string` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `module_table_version` | `['integer', 'null']` | no | No description declared. |
| `modules` | `array` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `source` | `string` | yes | No description declared. |
| `source_sha256` | `string` | yes | No description declared. |
| `unique_basic_blocks` | `integer` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:drcov-trace:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "basic_blocks": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "drcov_flavor": {
      "type": [
        "string",
        "null"
      ]
    },
    "drcov_version": {
      "type": "string"
    },
    "kind": {
      "const": "dynamorio_drcov_text"
    },
    "module_table_version": {
      "type": [
        "integer",
        "null"
      ]
    },
    "modules": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "schema_version": {
      "const": 1
    },
    "source": {
      "type": "string"
    },
    "source_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "unique_basic_blocks": {
      "minimum": 0,
      "type": "integer"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "source",
    "source_sha256",
    "drcov_version",
    "modules",
    "basic_blocks",
    "unique_basic_blocks"
  ],
  "title": "Normalized DynamoRIO drcov text trace",
  "type": "object"
}
```
