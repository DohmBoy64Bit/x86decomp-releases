---
title: 'Schema: schemas/target-decisions.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/target-decisions.schema.json.
---

# `schemas/target-decisions.schema.json`

- **SHA-256:** `647192549c5e079a02e597648a0d3d2ade5078866f869b7e0da34324b5976ed6`
- **Title:** Operator-confirmed target decisions
- **Type:** `object`
- **Properties:** 7
- **Required fields:** 7
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `allow_host_execution` | `boolean` | yes | No description declared. |
| `compiler_family` | `string` | yes | No description declared. |
| `compiler_version` | `string` | yes | No description declared. |
| `linker_family` | `string` | yes | No description declared. |
| `preferred_mode` | `unspecified` | yes | No description declared. |
| `source_language` | `unspecified` | yes | No description declared. |
| `target_description` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:target-decisions:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "allow_host_execution": {
      "type": "boolean"
    },
    "compiler_family": {
      "minLength": 1,
      "type": "string"
    },
    "compiler_version": {
      "minLength": 1,
      "type": "string"
    },
    "linker_family": {
      "minLength": 1,
      "type": "string"
    },
    "preferred_mode": {
      "enum": [
        "matching",
        "functional",
        "both"
      ]
    },
    "source_language": {
      "enum": [
        "unknown",
        "c",
        "c++",
        "mixed"
      ]
    },
    "target_description": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "preferred_mode",
    "compiler_family",
    "compiler_version",
    "linker_family",
    "source_language",
    "allow_host_execution",
    "target_description"
  ],
  "title": "Operator-confirmed target decisions",
  "type": "object"
}
```
