---
title: 'Schema: schemas/reconstruction/capsule.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/reconstruction/capsule.schema.json.
---

# `schemas/reconstruction/capsule.schema.json`

- **SHA-256:** `56f2d1b36a191f1ab2403e47932f665b1e9afa31a7c009444c4d02d3639be10c`
- **Title:** Reconstruction capsule manifest
- **Type:** `object`
- **Properties:** 4
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `external_requirements` | `array` | yes | No description declared. |
| `members` | `array` | yes | No description declared. |
| `schema` | `unspecified` | yes | No description declared. |
| `toolkit_version` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.dev/schemas/reconstruction/capsule.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "external_requirements": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "members": {
      "items": {
        "properties": {
          "path": {
            "type": "string"
          },
          "sha256": {
            "pattern": "^[0-9a-f]{64}$",
            "type": "string"
          },
          "size": {
            "minimum": 0,
            "type": "integer"
          }
        },
        "required": [
          "path",
          "sha256",
          "size"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "schema": {
      "const": "x86decomp.capsule.v1"
    },
    "toolkit_version": {
      "const": "0.7.10"
    }
  },
  "required": [
    "schema",
    "toolkit_version",
    "members",
    "external_requirements"
  ],
  "title": "Reconstruction capsule manifest",
  "type": "object"
}
```
