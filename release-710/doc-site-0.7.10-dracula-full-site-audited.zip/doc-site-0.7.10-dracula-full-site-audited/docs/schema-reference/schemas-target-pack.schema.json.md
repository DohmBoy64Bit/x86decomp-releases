---
title: 'Schema: schemas/target-pack.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/target-pack.schema.json.
---

# `schemas/target-pack.schema.json`

- **SHA-256:** `867b89f3738ff1310340d078c5ae530f0087277e96cd00106fa1275cd0bcc954`
- **Title:** urn:x86decomp:schema:target-pack:1
- **Type:** `object`
- **Properties:** 12
- **Required fields:** 12
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `artifacts` | `array` | yes | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `decisions` | `object` | yes | No description declared. |
| `default_modes` | `unspecified` | yes | No description declared. |
| `image_kind` | `unspecified` | yes | No description declared. |
| `name` | `string` | yes | No description declared. |
| `primary_image` | `string` | yes | No description declared. |
| `primary_sha256` | `string` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `scope` | `object` | yes | No description declared. |
| `target_id` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:target-pack:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "artifacts": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "path": {
            "minLength": 1,
            "type": "string"
          },
          "role": {
            "minLength": 1,
            "type": "string"
          },
          "sha256": {
            "pattern": "^[0-9a-f]{64}$",
            "type": "string"
          },
          "size": {
            "minimum": 1,
            "type": "integer"
          }
        },
        "required": [
          "role",
          "path",
          "sha256",
          "size"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "decisions": {
      "type": "object"
    },
    "default_modes": {
      "const": [
        "matching",
        "functional"
      ]
    },
    "image_kind": {
      "enum": [
        "exe",
        "dll"
      ]
    },
    "name": {
      "minLength": 1,
      "type": "string"
    },
    "primary_image": {
      "minLength": 1,
      "type": "string"
    },
    "primary_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "schema_version": {
      "const": 1
    },
    "scope": {
      "type": "object"
    },
    "target_id": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "target_id",
    "name",
    "created_at",
    "architecture",
    "image_kind",
    "primary_image",
    "primary_sha256",
    "default_modes",
    "scope",
    "decisions",
    "artifacts"
  ],
  "type": "object"
}
```
