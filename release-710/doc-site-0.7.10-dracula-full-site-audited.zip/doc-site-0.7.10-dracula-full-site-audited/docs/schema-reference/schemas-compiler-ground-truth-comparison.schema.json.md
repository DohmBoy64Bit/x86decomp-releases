---
title: 'Schema: schemas/compiler-ground-truth-comparison.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/compiler-ground-truth-comparison.schema.json.
---

# `schemas/compiler-ground-truth-comparison.schema.json`

- **SHA-256:** `1ea55d940c62d4e60487f74ac4d9756e4ff4c7cb2c39c9dd629b1d4150646dfb`
- **Title:** Compiler/version ground-truth corpus comparison
- **Type:** `object`
- **Properties:** 6
- **Required fields:** 6
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `comparisons` | `array` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `reports` | `array` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `semantic_equivalence_claimed` | `unspecified` | yes | No description declared. |
| `summary` | `object` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:compiler-ground-truth-comparison:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "comparisons": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "kind": {
      "const": "compiler_ground_truth_comparison"
    },
    "reports": {
      "items": {
        "type": "object"
      },
      "minItems": 2,
      "type": "array"
    },
    "schema_version": {
      "const": 1
    },
    "semantic_equivalence_claimed": {
      "const": false
    },
    "summary": {
      "type": "object"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "reports",
    "comparisons",
    "summary",
    "semantic_equivalence_claimed"
  ],
  "title": "Compiler/version ground-truth corpus comparison",
  "type": "object"
}
```
