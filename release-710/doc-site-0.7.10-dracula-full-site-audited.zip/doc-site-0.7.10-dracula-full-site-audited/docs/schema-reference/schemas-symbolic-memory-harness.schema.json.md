---
title: 'Schema: schemas/symbolic-memory-harness.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/symbolic-memory-harness.schema.json.
---

# `schemas/symbolic-memory-harness.schema.json`

- **SHA-256:** `e7ce53b843c172758fc086503e040cd1c60a3836f528b2c8396a7e77ab7c200a`
- **Title:** Bounded symbolic memory and alias harness
- **Type:** `object`
- **Properties:** 11
- **Required fields:** 2
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `alias_constraints` | `array` | no | No description declared. |
| `alias_slots` | `integer` | no | No description declared. |
| `architecture` | `unspecified` | yes | No description declared. |
| `input_registers` | `array` | no | No description declared. |
| `max_paths` | `integer` | no | No description declared. |
| `max_steps` | `integer` | no | No description declared. |
| `observe_memory` | `array` | no | No description declared. |
| `output_registers` | `array` | no | No description declared. |
| `regions` | `array` | yes | No description declared. |
| `slot_stride` | `integer` | no | No description declared. |
| `stack_argument_words` | `integer` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:symbolic-memory-harness:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "alias_constraints": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "left": {
            "type": "string"
          },
          "relation": {
            "enum": [
              "equal",
              "distinct",
              "disjoint",
              "may_alias"
            ]
          },
          "right": {
            "type": "string"
          }
        },
        "required": [
          "left",
          "right",
          "relation"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "alias_slots": {
      "maximum": 32,
      "minimum": 1,
      "type": "integer"
    },
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "input_registers": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "max_paths": {
      "minimum": 1,
      "type": "integer"
    },
    "max_steps": {
      "minimum": 1,
      "type": "integer"
    },
    "observe_memory": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "output_registers": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "regions": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "alignment": {
            "minimum": 1,
            "type": "integer"
          },
          "initial": {
            "type": "string"
          },
          "name": {
            "minLength": 1,
            "type": "string"
          },
          "pointer_register": {
            "minLength": 1,
            "type": "string"
          },
          "size": {
            "maximum": 1048576,
            "minimum": 1,
            "type": "integer"
          }
        },
        "required": [
          "name",
          "pointer_register",
          "size"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "slot_stride": {
      "minimum": 1,
      "type": "integer"
    },
    "stack_argument_words": {
      "minimum": 0,
      "type": "integer"
    }
  },
  "required": [
    "architecture",
    "regions"
  ],
  "title": "Bounded symbolic memory and alias harness",
  "type": "object"
}
```
