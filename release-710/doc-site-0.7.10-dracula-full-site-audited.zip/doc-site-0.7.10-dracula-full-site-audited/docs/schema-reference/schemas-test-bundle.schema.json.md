---
title: 'Schema: schemas/test-bundle.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/test-bundle.schema.json.
---

# `schemas/test-bundle.schema.json`

- **SHA-256:** `398d162a3ccc9e3bd1e984af67efbfaf12a840f4013b406c0cf8d150f490deab`
- **Title:** x86decomp Authorized Static Test Bundle
- **Type:** `object`
- **Properties:** 6
- **Required fields:** 3
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `artifacts` | `array` | yes | No description declared. |
| `authorization` | `object` | yes | No description declared. |
| `description` | `string` | no | No description declared. |
| `expected_architecture` | `unspecified` | no | No description declared. |
| `name` | `string` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:test-bundle:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "artifacts": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "description": {
            "type": "string"
          },
          "path": {
            "minLength": 1,
            "type": "string"
          },
          "role": {
            "enum": [
              "primary_image",
              "reference_image",
              "candidate_image",
              "pdb",
              "linker_map",
              "coff_object",
              "static_library",
              "source",
              "compiler_profile",
              "image_profile",
              "documentation"
            ]
          },
          "sha256": {
            "pattern": "^[0-9a-fA-F]{64}$",
            "type": "string"
          }
        },
        "required": [
          "path",
          "role"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "authorization": {
      "additionalProperties": false,
      "properties": {
        "owner_or_authorized": {
          "const": true
        },
        "statement": {
          "minLength": 1,
          "type": "string"
        }
      },
      "required": [
        "owner_or_authorized",
        "statement"
      ],
      "type": "object"
    },
    "description": {
      "type": "string"
    },
    "expected_architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "name": {
      "minLength": 1,
      "type": "string"
    },
    "schema_version": {
      "const": 1
    }
  },
  "required": [
    "schema_version",
    "authorization",
    "artifacts"
  ],
  "title": "x86decomp Authorized Static Test Bundle",
  "type": "object"
}
```
