---
title: 'Schema: schemas/native/function-slot.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/native/function-slot.schema.json.
---

# `schemas/native/function-slot.schema.json`

- **SHA-256:** `61bb10550455068b1c58073dfb30939aea8095cefbd775abab4d044efe9a2914`
- **Title:** x86decomp function-slot
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `body_size` | `integer` | yes | No description declared. |
| `classification` | `unspecified` | yes | No description declared. |
| `function_id` | `string` | yes | No description declared. |
| `rva` | `integer` | yes | No description declared. |
| `slot_size` | `integer` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.invalid/schemas/native/function-slot.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "body_size": {
      "minimum": 1,
      "type": "integer"
    },
    "classification": {
      "enum": [
        "exact",
        "padded",
        "overlap",
        "invalid-range"
      ]
    },
    "function_id": {
      "minLength": 1,
      "type": "string"
    },
    "rva": {
      "minimum": 0,
      "type": "integer"
    },
    "slot_size": {
      "type": "integer"
    }
  },
  "required": [
    "function_id",
    "rva",
    "body_size",
    "slot_size",
    "classification"
  ],
  "title": "x86decomp function-slot",
  "type": "object"
}
```
