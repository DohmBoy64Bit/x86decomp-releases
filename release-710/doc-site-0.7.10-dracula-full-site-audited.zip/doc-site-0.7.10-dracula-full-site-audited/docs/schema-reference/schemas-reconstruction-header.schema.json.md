---
title: 'Schema: schemas/reconstruction/header.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/reconstruction/header.schema.json.
---

# `schemas/reconstruction/header.schema.json`

- **SHA-256:** `c878f851e64b11db9e0dad34785d5ef3ba3baa753e380af72f554fe44529a850`
- **Title:** Recovered header contract
- **Type:** `object`
- **Properties:** 4
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `declarations` | `array` | yes | No description declared. |
| `header_id` | `string` | yes | No description declared. |
| `path` | `string` | yes | No description declared. |
| `visibility` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.dev/schemas/reconstruction/header.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "declarations": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "header_id": {
      "pattern": "^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$",
      "type": "string"
    },
    "path": {
      "pattern": ".*\\.(h|hpp|hh)$",
      "type": "string"
    },
    "visibility": {
      "enum": [
        "public",
        "private",
        "internal"
      ]
    }
  },
  "required": [
    "header_id",
    "path",
    "visibility",
    "declarations"
  ],
  "title": "Recovered header contract",
  "type": "object"
}
```
