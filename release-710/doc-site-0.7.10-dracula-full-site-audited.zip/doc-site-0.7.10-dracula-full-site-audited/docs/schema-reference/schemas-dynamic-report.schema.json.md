---
title: 'Schema: schemas/dynamic-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/dynamic-report.schema.json.
---

# `schemas/dynamic-report.schema.json`

- **SHA-256:** `1af7c179c9d4fedbf542c098eab126d556fc8345a464176d211640f391effce0`
- **Title:** Bounded Unicorn differential report
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `candidate` | `object` | yes | No description declared. |
| `equivalent_for_harness` | `boolean` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `scope_statement` | `string` | yes | No description declared. |
| `target` | `object` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:dynamic-report:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "candidate": {
      "type": "object"
    },
    "equivalent_for_harness": {
      "type": "boolean"
    },
    "schema_version": {
      "const": 1
    },
    "scope_statement": {
      "minLength": 1,
      "type": "string"
    },
    "target": {
      "type": "object"
    }
  },
  "required": [
    "schema_version",
    "equivalent_for_harness",
    "target",
    "candidate",
    "scope_statement"
  ],
  "title": "Bounded Unicorn differential report",
  "type": "object"
}
```
