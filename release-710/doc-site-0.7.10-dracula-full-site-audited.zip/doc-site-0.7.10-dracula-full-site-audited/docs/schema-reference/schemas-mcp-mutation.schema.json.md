---
title: 'Schema: schemas/mcp-mutation.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/mcp-mutation.schema.json.
---

# `schemas/mcp-mutation.schema.json`

- **SHA-256:** `64335798160269133e880d823f14de7f0cb4f2dafbf0c47526e24fb9fb16ea29`
- **Title:** Evidence-gated MCP mutation
- **Type:** `object`
- **Properties:** 10
- **Required fields:** 8
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `approval_hash` | `string` | yes | No description declared. |
| `arguments` | `object` | yes | No description declared. |
| `committed_at` | `string` | no | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `evidence_ids` | `array` | yes | No description declared. |
| `rationale` | `string` | yes | No description declared. |
| `result` | `object` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `tool` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:mcp-mutation:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "approval_hash": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "arguments": {
      "type": "object"
    },
    "committed_at": {
      "format": "date-time",
      "type": "string"
    },
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "evidence_ids": {
      "items": {
        "type": "string"
      },
      "minItems": 1,
      "type": "array",
      "uniqueItems": true
    },
    "rationale": {
      "minLength": 1,
      "type": "string"
    },
    "result": {
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "status": {
      "enum": [
        "proposed",
        "committed"
      ]
    },
    "tool": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "created_at",
    "tool",
    "arguments",
    "rationale",
    "evidence_ids",
    "status",
    "approval_hash"
  ],
  "title": "Evidence-gated MCP mutation",
  "type": "object"
}
```
