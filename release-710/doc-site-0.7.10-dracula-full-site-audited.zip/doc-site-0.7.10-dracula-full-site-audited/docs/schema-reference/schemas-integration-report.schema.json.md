---
title: 'Schema: schemas/integration-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/integration-report.schema.json.
---

# `schemas/integration-report.schema.json`

- **SHA-256:** `4732a3a8f4038739f46c7b7b74b20999c68d9f637bac783a53b03eee91e91d1a`
- **Title:** Bounded integration comparison report
- **Type:** `object`
- **Properties:** 8
- **Required fields:** 10
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `all_scenarios_equivalent` | `boolean` | yes | No description declared. |
| `failed_count` | `integer` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `limitations` | `array` | yes | No description declared. |
| `passed_count` | `integer` | yes | No description declared. |
| `scenario_count` | `integer` | yes | No description declared. |
| `scenarios` | `array` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:integration-report:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "all_scenarios_equivalent": {
      "type": "boolean"
    },
    "failed_count": {
      "minimum": 0,
      "type": "integer"
    },
    "kind": {
      "const": "integration_scenarios"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "minItems": 1,
      "type": "array"
    },
    "passed_count": {
      "minimum": 0,
      "type": "integer"
    },
    "scenario_count": {
      "minimum": 1,
      "type": "integer"
    },
    "scenarios": {
      "minItems": 1,
      "type": "array"
    },
    "schema_version": {
      "const": 1
    }
  },
  "required": [
    "schema_version",
    "created_at",
    "kind",
    "execution",
    "scenario_count",
    "passed_count",
    "failed_count",
    "all_scenarios_equivalent",
    "scenarios",
    "limitations"
  ],
  "title": "Bounded integration comparison report",
  "type": "object"
}
```
