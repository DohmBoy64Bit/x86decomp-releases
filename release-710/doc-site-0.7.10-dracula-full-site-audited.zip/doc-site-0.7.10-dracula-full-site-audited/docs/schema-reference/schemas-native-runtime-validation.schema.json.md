---
title: 'Schema: schemas/native/runtime-validation.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/native/runtime-validation.schema.json.
---

# `schemas/native/runtime-validation.schema.json`

- **SHA-256:** `f314d1ae2b72314a6ebf6c6d2905a8eb2f314498f256f567e01ae08622da90f3`
- **Title:** x86decomp runtime-validation
- **Type:** `object`
- **Properties:** 4
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `checks` | `object` | yes | No description declared. |
| `image_path` | `string` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `validation_kind` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.invalid/schemas/native/runtime-validation.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "checks": {
      "type": "object"
    },
    "image_path": {
      "type": "string"
    },
    "status": {
      "enum": [
        "passed",
        "failed",
        "blocked"
      ]
    },
    "validation_kind": {
      "type": "string"
    }
  },
  "required": [
    "image_path",
    "validation_kind",
    "status",
    "checks"
  ],
  "title": "x86decomp runtime-validation",
  "type": "object"
}
```
