---
title: 'Schema: schemas/native/loop-run.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/native/loop-run.schema.json.
---

# `schemas/native/loop-run.schema.json`

- **SHA-256:** `de5d1a277444c3ea53ae0c4860d1a7978b478893fb893cf4c1ba1fca4a11b038`
- **Title:** x86decomp loop-run
- **Type:** `object`
- **Properties:** 4
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `candidate_path` | `string` | yes | No description declared. |
| `compile_command` | `array` | yes | No description declared. |
| `function_id` | `string` | yes | No description declared. |
| `source_path` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.invalid/schemas/native/loop-run.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "candidate_path": {
      "type": "string"
    },
    "compile_command": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "function_id": {
      "type": "string"
    },
    "source_path": {
      "type": "string"
    }
  },
  "required": [
    "function_id",
    "source_path",
    "compile_command",
    "candidate_path"
  ],
  "title": "x86decomp loop-run",
  "type": "object"
}
```
