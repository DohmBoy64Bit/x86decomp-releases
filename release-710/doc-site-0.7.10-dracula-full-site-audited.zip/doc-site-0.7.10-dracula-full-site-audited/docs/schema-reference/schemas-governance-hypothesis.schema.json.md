---
title: 'Schema: schemas/governance/hypothesis.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/governance/hypothesis.schema.json.
---

# `schemas/governance/hypothesis.schema.json`

- **SHA-256:** `1013bee5c093d4cf0e619dbcdc52a2b2ff79c0b768da9c699ad0483bfc283a83`
- **Title:** hypothesis
- **Type:** `object`
- **Properties:** 7
- **Required fields:** 6
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `confidence` | `number` | yes | No description declared. |
| `locked` | `boolean` | no | No description declared. |
| `origin` | `string` | yes | No description declared. |
| `scope_id` | `string` | yes | No description declared. |
| `scope_kind` | `string` | yes | No description declared. |
| `state` | `unspecified` | yes | No description declared. |
| `statement` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "confidence": {
      "maximum": 1,
      "minimum": 0,
      "type": "number"
    },
    "locked": {
      "type": "boolean"
    },
    "origin": {
      "minLength": 1,
      "type": "string"
    },
    "scope_id": {
      "minLength": 1,
      "type": "string"
    },
    "scope_kind": {
      "minLength": 1,
      "type": "string"
    },
    "state": {
      "enum": [
        "proposed",
        "scheduled",
        "testing",
        "supported",
        "contradicted",
        "accepted",
        "rejected",
        "superseded",
        "blocked"
      ]
    },
    "statement": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "statement",
    "scope_kind",
    "scope_id",
    "state",
    "confidence",
    "origin"
  ],
  "title": "hypothesis",
  "type": "object"
}
```
