---
title: 'Schema: schemas/dependency-audit.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/dependency-audit.schema.json.
---

# `schemas/dependency-audit.schema.json`

- **SHA-256:** `2eef4097789050d846536b406ccd7b9e8e639467bdf1ca530045fcc6050c8ee2`
- **Title:** x86decomp dependency vulnerability audit
- **Type:** `object`
- **Properties:** 12
- **Required fields:** 11
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `created_at` | `string` | yes | No description declared. |
| `dependency_count` | `integer` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `passed` | `boolean` | yes | No description declared. |
| `raw_report` | `unspecified` | yes | No description declared. |
| `return_code` | `integer` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `stderr` | `string` | no | No description declared. |
| `tool` | `string` | yes | No description declared. |
| `tool_sha256` | `string` | yes | No description declared. |
| `vulnerabilities` | `array` | yes | No description declared. |
| `vulnerability_count` | `integer` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:dependency-audit:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "created_at": {
      "type": "string"
    },
    "dependency_count": {
      "minimum": 0,
      "type": "integer"
    },
    "kind": {
      "const": "python_dependency_vulnerability_audit"
    },
    "passed": {
      "type": "boolean"
    },
    "raw_report": {},
    "return_code": {
      "enum": [
        0,
        1
      ],
      "type": "integer"
    },
    "schema_version": {
      "const": 1
    },
    "stderr": {
      "type": "string"
    },
    "tool": {
      "type": "string"
    },
    "tool_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "vulnerabilities": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "vulnerability_count": {
      "minimum": 0,
      "type": "integer"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "created_at",
    "tool",
    "tool_sha256",
    "return_code",
    "dependency_count",
    "vulnerability_count",
    "vulnerabilities",
    "passed",
    "raw_report"
  ],
  "title": "x86decomp dependency vulnerability audit",
  "type": "object"
}
```
