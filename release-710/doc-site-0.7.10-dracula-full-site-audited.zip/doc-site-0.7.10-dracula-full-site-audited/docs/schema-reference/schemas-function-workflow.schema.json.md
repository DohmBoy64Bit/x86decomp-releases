---
title: 'Schema: schemas/function-workflow.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/function-workflow.schema.json.
---

# `schemas/function-workflow.schema.json`

- **SHA-256:** `972f7c4fef555a4653a57cad04f1dedb186cc70a6c59de7e674645b30c240351`
- **Title:** x86decomp per-function workflow
- **Type:** `object`
- **Properties:** 11
- **Required fields:** 9
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `active_candidate` | `['string', 'null']` | no | No description declared. |
| `blockers` | `array` | yes | No description declared. |
| `compiler_profile` | `['string', 'null']` | no | No description declared. |
| `function_id` | `string` | yes | No description declared. |
| `functional_status` | `unspecified` | yes | No description declared. |
| `matching_status` | `unspecified` | yes | No description declared. |
| `reports` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `selected_modes` | `array` | yes | No description declared. |
| `source_stage` | `unspecified` | yes | No description declared. |
| `updated_at` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:function-workflow:2",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "active_candidate": {
      "type": [
        "string",
        "null"
      ]
    },
    "blockers": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "compiler_profile": {
      "type": [
        "string",
        "null"
      ]
    },
    "function_id": {
      "pattern": "^pe-rva:[0-9a-f]{8}$",
      "type": "string"
    },
    "functional_status": {
      "enum": [
        "not_started",
        "decompiled",
        "compiles",
        "abi_compatible",
        "differentially_validated",
        "symbolically_bounded",
        "integration_validated",
        "blocked"
      ]
    },
    "matching_status": {
      "enum": [
        "not_started",
        "decompiled",
        "compiles",
        "abi_compatible",
        "instruction_similar",
        "byte_matched",
        "image_integrated",
        "full_relink_validated",
        "blocked"
      ]
    },
    "reports": {
      "additionalProperties": {
        "type": "string"
      },
      "type": "object"
    },
    "schema_version": {
      "const": 2
    },
    "selected_modes": {
      "items": {
        "enum": [
          "matching",
          "functional"
        ]
      },
      "minItems": 1,
      "type": "array",
      "uniqueItems": true
    },
    "source_stage": {
      "enum": [
        "original_bytes",
        "generated_assembly",
        "decompiler_candidate",
        "human_candidate",
        "accepted_source"
      ]
    },
    "updated_at": {
      "format": "date-time",
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "function_id",
    "selected_modes",
    "source_stage",
    "matching_status",
    "functional_status",
    "reports",
    "blockers",
    "updated_at"
  ],
  "title": "x86decomp per-function workflow",
  "type": "object"
}
```
