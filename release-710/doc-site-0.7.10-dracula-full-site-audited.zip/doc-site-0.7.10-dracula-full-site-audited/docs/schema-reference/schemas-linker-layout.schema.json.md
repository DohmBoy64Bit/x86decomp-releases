---
title: 'Schema: schemas/linker-layout.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/linker-layout.schema.json.
---

# `schemas/linker-layout.schema.json`

- **SHA-256:** `a8faf6022c8b70e04c3375d47a480b9a811e72edd55ea7e0ec4e80a77a8ca934`
- **Title:** Linker layout reconstruction report
- **Type:** `object`
- **Properties:** 9
- **Required fields:** 6
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `comdat_resolution` | `['object', 'null']` | no | No description declared. |
| `complete_original_layout_claimed` | `boolean` | no | No description declared. |
| `contributions` | `array` | yes | No description declared. |
| `image` | `object` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `map` | `object` | yes | No description declared. |
| `object_order_evidenced` | `boolean` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `unresolved` | `array` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:linker-layout:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "comdat_resolution": {
      "type": [
        "object",
        "null"
      ]
    },
    "complete_original_layout_claimed": {
      "type": "boolean"
    },
    "contributions": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "image": {
      "type": "object"
    },
    "kind": {
      "const": "linker_layout_reconstruction"
    },
    "map": {
      "type": "object"
    },
    "object_order_evidenced": {
      "type": "boolean"
    },
    "schema_version": {
      "const": 1
    },
    "unresolved": {
      "items": {
        "type": "string"
      },
      "type": "array"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "image",
    "map",
    "contributions",
    "unresolved"
  ],
  "title": "Linker layout reconstruction report",
  "type": "object"
}
```
