---
title: 'Schema: schemas/cpp-recovery.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/cpp-recovery.schema.json.
---

# `schemas/cpp-recovery.schema.json`

- **SHA-256:** `9eda5eb04cdd6404ed82077dab0b1f2668f3682b33f864fec3c7348439515d8a`
- **Title:** urn:x86decomp:schema:cpp-recovery:1
- **Type:** `object`
- **Properties:** 12
- **Required fields:** 8
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `adjustor_thunk_candidates` | `array` | yes | No description declared. |
| `claims` | `object` | yes | No description declared. |
| `classes` | `array` | yes | No description declared. |
| `counts` | `object` | yes | No description declared. |
| `created_at` | `string` | no | No description declared. |
| `image` | `['object', 'null']` | no | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `limitations` | `array` | yes | No description declared. |
| `metadata_source` | `string` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `static_initializer_order_evidence` | `array` | no | No description declared. |
| `vtable_groups` | `array` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:cpp-recovery:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "adjustor_thunk_candidates": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "claims": {
      "type": "object"
    },
    "classes": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "counts": {
      "type": "object"
    },
    "created_at": {
      "type": "string"
    },
    "image": {
      "type": [
        "object",
        "null"
      ]
    },
    "kind": {
      "const": "bounded_cpp_recovery"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "metadata_source": {
      "type": "string"
    },
    "schema_version": {
      "const": 1
    },
    "static_initializer_order_evidence": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "vtable_groups": {
      "items": {
        "type": "object"
      },
      "type": "array"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "classes",
    "vtable_groups",
    "adjustor_thunk_candidates",
    "counts",
    "claims",
    "limitations"
  ],
  "type": "object"
}
```
