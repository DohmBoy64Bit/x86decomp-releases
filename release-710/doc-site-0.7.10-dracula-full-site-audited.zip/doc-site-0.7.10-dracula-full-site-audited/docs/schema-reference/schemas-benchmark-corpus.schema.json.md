---
title: 'Schema: schemas/benchmark-corpus.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/benchmark-corpus.schema.json.
---

# `schemas/benchmark-corpus.schema.json`

- **SHA-256:** `0081dd4d038287641f14ccd228dd0e824bff8bd3745f8251aaa0a94c1c61e36c`
- **Title:** Ground-truth benchmark corpus
- **Type:** `object`
- **Properties:** 3
- **Required fields:** 3
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `cases` | `array` | yes | No description declared. |
| `name` | `string` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:benchmark-corpus:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "cases": {
      "items": {
        "additionalProperties": true,
        "properties": {
          "human_interventions": {
            "minimum": 0,
            "type": "integer"
          },
          "id": {
            "type": "string"
          },
          "kind": {
            "enum": [
              "byte_pair",
              "pe_coff",
              "dynamic",
              "symbolic",
              "integration",
              "discovery_metrics"
            ]
          }
        },
        "required": [
          "id",
          "kind"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "name": {
      "minLength": 1,
      "type": "string"
    },
    "schema_version": {
      "const": 1
    }
  },
  "required": [
    "schema_version",
    "name",
    "cases"
  ],
  "title": "Ground-truth benchmark corpus",
  "type": "object"
}
```
