---
title: 'Schema: schemas/governance/plugin.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/governance/plugin.schema.json.
---

# `schemas/governance/plugin.schema.json`

- **SHA-256:** `1fb5e12f5c8eb5408dea6372c5442273b1694559dc9c09784bbca4309dbf5fd2`
- **Title:** plugin manifest
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `api_version` | `unspecified` | yes | No description declared. |
| `capabilities` | `array` | yes | No description declared. |
| `executable` | `string` | yes | No description declared. |
| `name` | `string` | yes | No description declared. |
| `version` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "api_version": {
      "const": "1"
    },
    "capabilities": {
      "items": {
        "minLength": 1,
        "type": "string"
      },
      "minItems": 1,
      "type": "array",
      "uniqueItems": true
    },
    "executable": {
      "minLength": 1,
      "type": "string"
    },
    "name": {
      "minLength": 1,
      "type": "string"
    },
    "version": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "name",
    "version",
    "api_version",
    "executable",
    "capabilities"
  ],
  "title": "plugin manifest",
  "type": "object"
}
```
