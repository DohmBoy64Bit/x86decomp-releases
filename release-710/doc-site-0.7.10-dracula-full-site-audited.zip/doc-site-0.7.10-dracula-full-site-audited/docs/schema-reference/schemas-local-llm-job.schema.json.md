---
title: 'Schema: schemas/local-llm/job.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/local-llm/job.schema.json.
---

# `schemas/local-llm/job.schema.json`

- **SHA-256:** `6ac68b5f4f22855154f8ec09e599c7caa3ce12d117fb125a0bae8e4dce0197a8`
- **Title:** Local LLM C generation and byte-match job
- **Type:** `object`
- **Properties:** 16
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `abi` | `object` | no | No description declared. |
| `architecture` | `unspecified` | yes | No description declared. |
| `base_rva` | `integer` | no | No description declared. |
| `evidence` | `object` | no | No description declared. |
| `function_name` | `string` | yes | No description declared. |
| `id` | `string` | yes | No description declared. |
| `image_base` | `integer` | no | No description declared. |
| `max_attempts` | `integer` | no | No description declared. |
| `mnemonics` | `string` | no | No description declared. |
| `mnemonics_file` | `string` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `section_placements` | `object` | no | No description declared. |
| `symbol` | `string` | no | No description declared. |
| `symbol_map` | `unspecified` | no | No description declared. |
| `target_bytes_file` | `string` | no | No description declared. |
| `target_bytes_hex` | `string` | no | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/local-llm/job.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "allOf": [
    {
      "oneOf": [
        {
          "not": {
            "required": [
              "mnemonics_file"
            ]
          },
          "required": [
            "mnemonics"
          ]
        },
        {
          "not": {
            "required": [
              "mnemonics"
            ]
          },
          "required": [
            "mnemonics_file"
          ]
        }
      ]
    },
    {
      "oneOf": [
        {
          "not": {
            "required": [
              "target_bytes_file"
            ]
          },
          "required": [
            "target_bytes_hex"
          ]
        },
        {
          "not": {
            "required": [
              "target_bytes_hex"
            ]
          },
          "required": [
            "target_bytes_file"
          ]
        }
      ]
    }
  ],
  "properties": {
    "abi": {
      "type": "object"
    },
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "base_rva": {
      "minimum": 0,
      "type": "integer"
    },
    "evidence": {
      "additionalProperties": false,
      "properties": {
        "analyst_notes": {
          "type": "string"
        },
        "decompiler_c": {
          "type": "string"
        },
        "pcode": {
          "type": "string"
        },
        "references": {
          "type": "string"
        }
      },
      "type": "object"
    },
    "function_name": {
      "minLength": 1,
      "type": "string"
    },
    "id": {
      "minLength": 1,
      "type": "string"
    },
    "image_base": {
      "minimum": 0,
      "type": "integer"
    },
    "max_attempts": {
      "maximum": 32,
      "minimum": 1,
      "type": "integer"
    },
    "mnemonics": {
      "minLength": 1,
      "type": "string"
    },
    "mnemonics_file": {
      "minLength": 1,
      "type": "string"
    },
    "schema_version": {
      "const": 1
    },
    "section_placements": {
      "type": "object"
    },
    "symbol": {
      "minLength": 1,
      "type": "string"
    },
    "symbol_map": {
      "oneOf": [
        {
          "type": "object"
        },
        {
          "items": {
            "type": "object"
          },
          "type": "array"
        }
      ]
    },
    "target_bytes_file": {
      "minLength": 1,
      "type": "string"
    },
    "target_bytes_hex": {
      "minLength": 2,
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "id",
    "function_name",
    "architecture"
  ],
  "title": "Local LLM C generation and byte-match job",
  "type": "object"
}
```
