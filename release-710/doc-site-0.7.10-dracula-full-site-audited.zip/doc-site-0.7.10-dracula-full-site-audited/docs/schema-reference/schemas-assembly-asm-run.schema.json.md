---
title: 'Schema: schemas/assembly/asm-run.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/assembly/asm-run.schema.json.
---

# `schemas/assembly/asm-run.schema.json`

- **SHA-256:** `77eb22965fc181eea78db723ac4b8ecc0cfd9de4e15c69db73fcd8eff2135a39`
- **Title:** v0.7.10 assembly run
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `asm_format` | `unspecified` | yes | No description declared. |
| `run_id` | `string` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `summary` | `object` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/assembly/asm-run.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "asm_format": {
      "enum": [
        "bytes",
        "annotated",
        "mnemonic"
      ]
    },
    "run_id": {
      "minLength": 1,
      "type": "string"
    },
    "status": {
      "enum": [
        "running",
        "completed",
        "failed"
      ]
    },
    "summary": {
      "type": "object"
    }
  },
  "required": [
    "run_id",
    "asm_format",
    "architecture",
    "status",
    "summary"
  ],
  "title": "v0.7.10 assembly run",
  "type": "object"
}
```
