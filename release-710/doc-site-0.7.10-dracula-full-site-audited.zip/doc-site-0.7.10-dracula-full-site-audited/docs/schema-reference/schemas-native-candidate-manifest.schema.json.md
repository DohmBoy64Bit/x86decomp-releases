---
title: 'Schema: schemas/native/candidate-manifest.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/native/candidate-manifest.schema.json.
---

# `schemas/native/candidate-manifest.schema.json`

- **SHA-256:** `d3bad2e693b4b7d6e1c230d9e03ff775298273523c8b562d3b78400c13313029`
- **Title:** x86decomp candidate-manifest
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `candidate_path` | `string` | yes | No description declared. |
| `function_id` | `string` | yes | No description declared. |
| `rva` | `unspecified` | yes | No description declared. |
| `slot_size` | `integer` | yes | No description declared. |
| `symbol` | `['string', 'null']` | no | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.invalid/schemas/native/candidate-manifest.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "candidate_path": {
      "type": "string"
    },
    "function_id": {
      "type": "string"
    },
    "rva": {
      "oneOf": [
        {
          "type": "integer"
        },
        {
          "type": "string"
        }
      ]
    },
    "slot_size": {
      "minimum": 1,
      "type": "integer"
    },
    "symbol": {
      "type": [
        "string",
        "null"
      ]
    }
  },
  "required": [
    "function_id",
    "rva",
    "slot_size",
    "candidate_path"
  ],
  "title": "x86decomp candidate-manifest",
  "type": "object"
}
```
