---
title: 'Schema: schemas/evidence.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/evidence.schema.json.
---

# `schemas/evidence.schema.json`

- **SHA-256:** `5c5199ae9f480dbbb28eb3ebd889a53a46c08535cabf346d3a0bf04f4a4aa7bd`
- **Title:** x86decomp evidence item
- **Type:** `object`
- **Properties:** 9
- **Required fields:** 9
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `assertion` | `string` | yes | No description declared. |
| `digest_sha256` | `['string', 'null']` | yes | No description declared. |
| `id` | `string` | yes | No description declared. |
| `independent_group` | `string` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `locator` | `string` | yes | No description declared. |
| `metadata` | `object` | yes | No description declared. |
| `observed_at` | `string` | yes | No description declared. |
| `source` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:evidence:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "assertion": {
      "minLength": 1,
      "type": "string"
    },
    "digest_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": [
        "string",
        "null"
      ]
    },
    "id": {
      "pattern": "^[a-z0-9][a-z0-9._:-]{2,127}$",
      "type": "string"
    },
    "independent_group": {
      "minLength": 1,
      "type": "string"
    },
    "kind": {
      "enum": [
        "binary_bytes",
        "static_analysis",
        "dynamic_trace",
        "compiler_output",
        "debug_symbol",
        "external_document",
        "human_review"
      ]
    },
    "locator": {
      "minLength": 1,
      "type": "string"
    },
    "metadata": {
      "type": "object"
    },
    "observed_at": {
      "format": "date-time",
      "type": "string"
    },
    "source": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "id",
    "kind",
    "source",
    "locator",
    "assertion",
    "independent_group",
    "digest_sha256",
    "observed_at",
    "metadata"
  ],
  "title": "x86decomp evidence item",
  "type": "object"
}
```
