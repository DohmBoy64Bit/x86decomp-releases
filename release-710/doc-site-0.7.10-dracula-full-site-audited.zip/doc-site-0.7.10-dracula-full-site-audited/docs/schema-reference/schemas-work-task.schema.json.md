---
title: 'Schema: schemas/work-task.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/work-task.schema.json.
---

# `schemas/work-task.schema.json`

- **SHA-256:** `36794b2e24e785918a28d8bd7f5fedd100c090ed64030c71eefa0a8c933b92c9`
- **Title:** Validator-gated work item
- **Type:** `object`
- **Properties:** 14
- **Required fields:** 12
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `assignee` | `['string', 'null']` | no | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `evidence_ids` | `array` | yes | No description declared. |
| `function_id` | `string` | yes | No description declared. |
| `id` | `string` | yes | No description declared. |
| `instructions` | `string` | yes | No description declared. |
| `kind` | `string` | yes | No description declared. |
| `mode` | `unspecified` | yes | No description declared. |
| `priority` | `integer` | yes | No description declared. |
| `proposal` | `['object', 'null']` | no | No description declared. |
| `required_validators` | `array` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `updated_at` | `string` | yes | No description declared. |
| `validator_results` | `object` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:work-task:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "assignee": {
      "type": [
        "string",
        "null"
      ]
    },
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "evidence_ids": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "function_id": {
      "pattern": "^pe-rva:[0-9a-f]{8}$",
      "type": "string"
    },
    "id": {
      "pattern": "^task-[0-9a-f]{32}$",
      "type": "string"
    },
    "instructions": {
      "minLength": 1,
      "type": "string"
    },
    "kind": {
      "type": "string"
    },
    "mode": {
      "enum": [
        "matching",
        "functional"
      ]
    },
    "priority": {
      "type": "integer"
    },
    "proposal": {
      "type": [
        "object",
        "null"
      ]
    },
    "required_validators": {
      "items": {
        "type": "string"
      },
      "minItems": 1,
      "type": "array",
      "uniqueItems": true
    },
    "status": {
      "enum": [
        "queued",
        "claimed",
        "proposed",
        "validating",
        "accepted",
        "rejected",
        "blocked"
      ]
    },
    "updated_at": {
      "format": "date-time",
      "type": "string"
    },
    "validator_results": {
      "additionalProperties": {
        "properties": {
          "passed": {
            "type": "boolean"
          },
          "recorded_at": {
            "format": "date-time",
            "type": "string"
          },
          "report_path": {
            "type": "string"
          }
        },
        "required": [
          "report_path",
          "passed",
          "recorded_at"
        ],
        "type": "object"
      },
      "type": "object"
    }
  },
  "required": [
    "id",
    "function_id",
    "mode",
    "kind",
    "status",
    "priority",
    "instructions",
    "required_validators",
    "validator_results",
    "evidence_ids",
    "created_at",
    "updated_at"
  ],
  "title": "Validator-gated work item",
  "type": "object"
}
```
