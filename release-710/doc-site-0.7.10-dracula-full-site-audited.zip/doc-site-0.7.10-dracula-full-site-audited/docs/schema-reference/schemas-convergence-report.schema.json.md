---
title: 'Schema: schemas/convergence-report.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/convergence-report.schema.json.
---

# `schemas/convergence-report.schema.json`

- **SHA-256:** `ace195921a16f72366e2920e6e2ce4e464b51f665d4d12ff5117dbea49119185`
- **Title:** urn:x86decomp:schema:convergence-report:1
- **Type:** `object`
- **Properties:** 14
- **Required fields:** 10
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `candidate_sha256` | `string` | yes | No description declared. |
| `complete` | `boolean` | yes | No description declared. |
| `created_at` | `string` | no | No description declared. |
| `delta_from_previous` | `['object', 'null']` | no | No description declared. |
| `image_match` | `object` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `limitations` | `array` | no | No description declared. |
| `next_actions` | `array` | yes | No description declared. |
| `normalized_complete` | `boolean` | yes | No description declared. |
| `reference_sha256` | `string` | yes | No description declared. |
| `root_cause_claimed` | `unspecified` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `sections` | `array` | yes | No description declared. |
| `totals` | `object` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:convergence-report:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "candidate_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "complete": {
      "type": "boolean"
    },
    "created_at": {
      "type": "string"
    },
    "delta_from_previous": {
      "type": [
        "object",
        "null"
      ]
    },
    "image_match": {
      "type": "object"
    },
    "kind": {
      "const": "image_convergence_report"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "next_actions": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "normalized_complete": {
      "type": "boolean"
    },
    "reference_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "root_cause_claimed": {
      "const": false
    },
    "schema_version": {
      "const": 1
    },
    "sections": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "totals": {
      "type": "object"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "reference_sha256",
    "candidate_sha256",
    "image_match",
    "totals",
    "sections",
    "next_actions",
    "complete",
    "normalized_complete"
  ],
  "type": "object"
}
```
