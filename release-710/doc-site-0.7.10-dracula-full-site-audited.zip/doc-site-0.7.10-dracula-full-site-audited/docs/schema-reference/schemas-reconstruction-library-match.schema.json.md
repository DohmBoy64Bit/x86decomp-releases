---
title: 'Schema: schemas/reconstruction/library-match.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/reconstruction/library-match.schema.json.
---

# `schemas/reconstruction/library-match.schema.json`

- **SHA-256:** `cdf8967118c99e0f1d224829f1e3067a2b9db50f31ca945db68a3cec61b0f36e`
- **Title:** Static library recognition candidate
- **Type:** `object`
- **Properties:** 7
- **Required fields:** 6
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `confidence` | `number` | yes | No description declared. |
| `disposition` | `unspecified` | yes | No description declared. |
| `evidence` | `array` | yes | No description declared. |
| `library_name` | `string` | yes | No description declared. |
| `match_id` | `string` | yes | No description declared. |
| `subject_id` | `string` | yes | No description declared. |
| `version_range` | `['string', 'null']` | no | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.dev/schemas/reconstruction/library-match.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "confidence": {
      "maximum": 1,
      "minimum": 0,
      "type": "number"
    },
    "disposition": {
      "enum": [
        "proposed",
        "accepted",
        "externalized",
        "reconstruct",
        "rejected"
      ]
    },
    "evidence": {
      "items": {
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "library_name": {
      "type": "string"
    },
    "match_id": {
      "pattern": "^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$",
      "type": "string"
    },
    "subject_id": {
      "type": "string"
    },
    "version_range": {
      "type": [
        "string",
        "null"
      ]
    }
  },
  "required": [
    "match_id",
    "subject_id",
    "library_name",
    "confidence",
    "evidence",
    "disposition"
  ],
  "title": "Static library recognition candidate",
  "type": "object"
}
```
