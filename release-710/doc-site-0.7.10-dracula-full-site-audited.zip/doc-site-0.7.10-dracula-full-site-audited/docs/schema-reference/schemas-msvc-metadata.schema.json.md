---
title: 'Schema: schemas/msvc-metadata.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/msvc-metadata.schema.json.
---

# `schemas/msvc-metadata.schema.json`

- **SHA-256:** `84d0b6bc880ab47954f951a4eed4db317c14ee33ed5cdbe0ee098ce61c1d6273`
- **Title:** Bounded MSVC metadata analysis report
- **Type:** `object`
- **Properties:** 8
- **Required fields:** 8
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `exceptions` | `object` | yes | No description declared. |
| `image` | `object` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `rtti` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `source_level_recovery_claimed` | `unspecified` | yes | No description declared. |
| `static_initializers` | `object` | yes | No description declared. |
| `tls` | `['object', 'null']` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:msvc-metadata:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "exceptions": {
      "type": "object"
    },
    "image": {
      "type": "object"
    },
    "kind": {
      "const": "msvc_metadata_analysis"
    },
    "rtti": {
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "source_level_recovery_claimed": {
      "const": false
    },
    "static_initializers": {
      "type": "object"
    },
    "tls": {
      "type": [
        "object",
        "null"
      ]
    }
  },
  "required": [
    "schema_version",
    "kind",
    "image",
    "rtti",
    "exceptions",
    "tls",
    "static_initializers",
    "source_level_recovery_claimed"
  ],
  "title": "Bounded MSVC metadata analysis report",
  "type": "object"
}
```
