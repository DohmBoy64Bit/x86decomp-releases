---
title: 'Schema: schemas/reconstruction/translation-unit.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/reconstruction/translation-unit.schema.json.
---

# `schemas/reconstruction/translation-unit.schema.json`

- **SHA-256:** `ea17fb7bfec69c8e9e3eb5d14179194acece94ba90d5e0ad76c5f3e653dca642`
- **Title:** Translation unit hypothesis
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `confidence` | `number` | yes | No description declared. |
| `evidence` | `array` | yes | No description declared. |
| `language` | `unspecified` | yes | No description declared. |
| `source_path` | `string` | yes | No description declared. |
| `unit_id` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.dev/schemas/reconstruction/translation-unit.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "confidence": {
      "maximum": 1,
      "minimum": 0,
      "type": "number"
    },
    "evidence": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "language": {
      "enum": [
        "c",
        "cpp",
        "asm",
        "resource"
      ]
    },
    "source_path": {
      "minLength": 1,
      "type": "string"
    },
    "unit_id": {
      "pattern": "^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$",
      "type": "string"
    }
  },
  "required": [
    "unit_id",
    "source_path",
    "language",
    "confidence",
    "evidence"
  ],
  "title": "Translation unit hypothesis",
  "type": "object"
}
```
