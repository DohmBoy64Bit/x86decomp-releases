---
title: 'Schema: schemas/execution-harness-generated.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/execution-harness-generated.schema.json.
---

# `schemas/execution-harness-generated.schema.json`

- **SHA-256:** `7ba43bfcb6b5b8736d784112af5531e1a890630e379eb2c345f15442c18a2c6d`
- **Title:** urn:x86decomp:schema:execution-harness-generated:1
- **Type:** `object`
- **Properties:** 17
- **Required fields:** 16
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `code_base` | `integer` | yes | No description declared. |
| `created_at` | `string` | no | No description declared. |
| `generation` | `object` | yes | No description declared. |
| `limitations` | `array` | yes | No description declared. |
| `max_instructions` | `integer` | yes | No description declared. |
| `memory` | `array` | yes | No description declared. |
| `observe_memory` | `array` | yes | No description declared. |
| `observe_registers` | `array` | yes | No description declared. |
| `registers` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `sentinel_address` | `integer` | yes | No description declared. |
| `stack_arguments_hex` | `string` | yes | No description declared. |
| `stack_base` | `integer` | yes | No description declared. |
| `stack_size` | `integer` | yes | No description declared. |
| `stubs` | `object` | yes | No description declared. |
| `timeout_ms` | `integer` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:execution-harness-generated:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "code_base": {
      "minimum": 1,
      "type": "integer"
    },
    "created_at": {
      "type": "string"
    },
    "generation": {
      "type": "object"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "max_instructions": {
      "minimum": 1,
      "type": "integer"
    },
    "memory": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "observe_memory": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "observe_registers": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "registers": {
      "additionalProperties": {
        "type": "integer"
      },
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "sentinel_address": {
      "minimum": 1,
      "type": "integer"
    },
    "stack_arguments_hex": {
      "pattern": "^(?:[0-9a-fA-F]{2})*$",
      "type": "string"
    },
    "stack_base": {
      "minimum": 1,
      "type": "integer"
    },
    "stack_size": {
      "minimum": 1,
      "type": "integer"
    },
    "stubs": {
      "type": "object"
    },
    "timeout_ms": {
      "minimum": 1,
      "type": "integer"
    }
  },
  "required": [
    "schema_version",
    "architecture",
    "code_base",
    "stack_base",
    "stack_size",
    "sentinel_address",
    "max_instructions",
    "timeout_ms",
    "registers",
    "stack_arguments_hex",
    "memory",
    "observe_registers",
    "observe_memory",
    "stubs",
    "generation",
    "limitations"
  ],
  "type": "object"
}
```
