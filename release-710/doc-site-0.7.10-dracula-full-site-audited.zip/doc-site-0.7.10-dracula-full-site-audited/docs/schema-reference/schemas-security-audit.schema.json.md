---
title: 'Schema: schemas/security-audit.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/security-audit.schema.json.
---

# `schemas/security-audit.schema.json`

- **SHA-256:** `d62a14bd5c6d796dd52aee929ccfdf8e1265f825167070c8ffd680321a00b637`
- **Title:** urn:x86decomp:schema:security-audit:1
- **Type:** `object`
- **Properties:** 11
- **Required fields:** 8
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `created_at` | `string` | no | No description declared. |
| `file_count` | `integer` | yes | No description declared. |
| `findings` | `array` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `limitations` | `array` | no | No description declared. |
| `passed` | `boolean` | yes | No description declared. |
| `root` | `string` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `severity_counts` | `object` | yes | No description declared. |
| `total_bytes` | `integer` | no | No description declared. |
| `vulnerability_database_checked` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:security-audit:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "created_at": {
      "type": "string"
    },
    "file_count": {
      "minimum": 0,
      "type": "integer"
    },
    "findings": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "kind": {
      "const": "source_security_audit"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "passed": {
      "type": "boolean"
    },
    "root": {
      "type": "string"
    },
    "schema_version": {
      "const": 1
    },
    "severity_counts": {
      "type": "object"
    },
    "total_bytes": {
      "minimum": 0,
      "type": "integer"
    },
    "vulnerability_database_checked": {
      "const": false
    }
  },
  "required": [
    "schema_version",
    "kind",
    "root",
    "file_count",
    "findings",
    "severity_counts",
    "passed",
    "vulnerability_database_checked"
  ],
  "type": "object"
}
```
