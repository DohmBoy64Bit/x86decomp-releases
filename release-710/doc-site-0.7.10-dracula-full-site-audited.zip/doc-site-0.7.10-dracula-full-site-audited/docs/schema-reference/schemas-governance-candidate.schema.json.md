---
title: 'Schema: schemas/governance/candidate.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/governance/candidate.schema.json.
---

# `schemas/governance/candidate.schema.json`

- **SHA-256:** `db23f94af8b37ebdfff2798c271a0ef02ea9d77aae83fa8c8ebdab3d2f55ad67`
- **Title:** candidate
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 3
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `branch_name` | `string` | yes | No description declared. |
| `evaluations` | `array` | no | No description declared. |
| `files` | `array` | no | No description declared. |
| `objective` | `object` | yes | No description declared. |
| `state` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "branch_name": {
      "minLength": 1,
      "type": "string"
    },
    "evaluations": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "files": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "objective": {
      "type": "object"
    },
    "state": {
      "enum": [
        "active",
        "evaluating",
        "supported",
        "promoted",
        "discarded",
        "blocked"
      ]
    }
  },
  "required": [
    "branch_name",
    "state",
    "objective"
  ],
  "title": "candidate",
  "type": "object"
}
```
