---
title: 'Schema: schemas/comdat-resolution.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/comdat-resolution.schema.json.
---

# `schemas/comdat-resolution.schema.json`

- **SHA-256:** `01fd177dfa983202ca8770e7985aa623e166fd22c20fdecc1d3d37f9cbfe0aae`
- **Title:** COFF COMDAT resolution report
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `conflicts` | `array` | yes | No description declared. |
| `discarded` | `array` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `valid` | `boolean` | yes | No description declared. |
| `winners` | `array` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:comdat-resolution:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "conflicts": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "discarded": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "schema_version": {
      "const": 1
    },
    "valid": {
      "type": "boolean"
    },
    "winners": {
      "items": {
        "type": "object"
      },
      "type": "array"
    }
  },
  "required": [
    "schema_version",
    "valid",
    "winners",
    "discarded",
    "conflicts"
  ],
  "title": "COFF COMDAT resolution report",
  "type": "object"
}
```
