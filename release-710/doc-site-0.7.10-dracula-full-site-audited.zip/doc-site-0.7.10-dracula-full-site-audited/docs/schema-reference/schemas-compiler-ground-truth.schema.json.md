---
title: 'Schema: schemas/compiler-ground-truth.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/compiler-ground-truth.schema.json.
---

# `schemas/compiler-ground-truth.schema.json`

- **SHA-256:** `1f8d15358ce71168a0f7c4d61ba7ad9db1ef12b534b27444bdda1f77f96392a2`
- **Title:** Compiler ground-truth corpus manifest
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 3
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `cases` | `array` | yes | No description declared. |
| `compilers` | `array` | yes | No description declared. |
| `flag_matrix` | `object` | no | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `timeout_seconds` | `integer` | no | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:compiler-ground-truth:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "cases": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "arguments": {
            "items": {
              "type": "string"
            },
            "type": "array"
          },
          "compilers": {
            "items": {
              "type": "string"
            },
            "type": "array"
          },
          "flag_matrix": {
            "type": "object"
          },
          "id": {
            "type": "string"
          },
          "output_name": {
            "type": "string"
          },
          "source": {
            "type": "string"
          }
        },
        "required": [
          "id",
          "source"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "compilers": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "base_args": {
            "items": {
              "type": "string"
            },
            "type": "array"
          },
          "environment": {
            "additionalProperties": {
              "type": "string"
            },
            "type": "object"
          },
          "executable": {
            "type": "string"
          },
          "id": {
            "type": "string"
          },
          "inherit_environment": {
            "type": "boolean"
          },
          "version_args": {
            "items": {
              "type": "string"
            },
            "type": "array"
          }
        },
        "required": [
          "id",
          "executable",
          "base_args"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "flag_matrix": {
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "timeout_seconds": {
      "minimum": 1,
      "type": "integer"
    }
  },
  "required": [
    "schema_version",
    "compilers",
    "cases"
  ],
  "title": "Compiler ground-truth corpus manifest",
  "type": "object"
}
```
