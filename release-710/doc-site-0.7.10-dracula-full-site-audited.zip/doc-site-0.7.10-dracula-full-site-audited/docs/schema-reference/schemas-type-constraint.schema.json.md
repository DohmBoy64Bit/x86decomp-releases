---
title: 'Schema: schemas/type-constraint.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/type-constraint.schema.json.
---

# `schemas/type-constraint.schema.json`

- **SHA-256:** `f98328b457deccc685ea8be764507320d5ff94deddb366e47c5018a678baa59d`
- **Title:** Type/ABI constraint record
- **Type:** `object`
- **Properties:** 8
- **Required fields:** 5
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `confidence` | `['number', 'null']` | no | No description declared. |
| `constraint_id` | `integer` | no | No description declared. |
| `evidence_id` | `['string', 'null']` | no | No description declared. |
| `object_value` | `string` | yes | No description declared. |
| `provenance` | `string` | yes | No description declared. |
| `relation` | `string` | yes | No description declared. |
| `status` | `unspecified` | yes | No description declared. |
| `subject_entity` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:type-constraint:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "confidence": {
      "maximum": 1,
      "minimum": 0,
      "type": [
        "number",
        "null"
      ]
    },
    "constraint_id": {
      "minimum": 1,
      "type": "integer"
    },
    "evidence_id": {
      "type": [
        "string",
        "null"
      ]
    },
    "object_value": {
      "minLength": 1,
      "type": "string"
    },
    "provenance": {
      "minLength": 1,
      "type": "string"
    },
    "relation": {
      "minLength": 1,
      "type": "string"
    },
    "status": {
      "enum": [
        "candidate",
        "accepted",
        "rejected"
      ]
    },
    "subject_entity": {
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "subject_entity",
    "relation",
    "object_value",
    "provenance",
    "status"
  ],
  "title": "Type/ABI constraint record",
  "type": "object"
}
```
