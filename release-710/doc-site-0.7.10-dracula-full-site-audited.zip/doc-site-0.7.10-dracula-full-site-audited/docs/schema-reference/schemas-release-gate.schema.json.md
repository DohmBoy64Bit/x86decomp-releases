---
title: 'Schema: schemas/release-gate.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/release-gate.schema.json.
---

# `schemas/release-gate.schema.json`

- **SHA-256:** `50e1f5a6cb46b67f833c881a7f025be5c7c047c1f23c3607608488afe17256cd`
- **Title:** urn:x86decomp:schema:release-gate:1
- **Type:** `object`
- **Properties:** 9
- **Required fields:** 9
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `checks` | `object` | yes | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `failures` | `array` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `passed` | `boolean` | yes | No description declared. |
| `project_root` | `string` | yes | No description declared. |
| `requirements` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `truth_statement` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:release-gate:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "checks": {
      "type": "object"
    },
    "created_at": {
      "type": "string"
    },
    "failures": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "kind": {
      "const": "target_release_gate"
    },
    "passed": {
      "type": "boolean"
    },
    "project_root": {
      "type": "string"
    },
    "requirements": {
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "truth_statement": {
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "created_at",
    "project_root",
    "checks",
    "requirements",
    "failures",
    "passed",
    "truth_statement"
  ],
  "type": "object"
}
```
