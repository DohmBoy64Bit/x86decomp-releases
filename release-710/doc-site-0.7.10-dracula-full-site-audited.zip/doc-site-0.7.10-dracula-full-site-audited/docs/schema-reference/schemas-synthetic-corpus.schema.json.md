---
title: 'Schema: schemas/synthetic-corpus.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/synthetic-corpus.schema.json.
---

# `schemas/synthetic-corpus.schema.json`

- **SHA-256:** `3c05d2c0a766021805afdd306d6a08068af6a24cdb0adb82fb3eca4d0f1d7c7d`
- **Title:** Deterministic synthetic source corpus
- **Type:** `object`
- **Properties:** 9
- **Required fields:** 9
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `case_count` | `integer` | yes | No description declared. |
| `cases` | `array` | yes | No description declared. |
| `cases_per_family` | `integer` | yes | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `families` | `array` | yes | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `seed` | `integer` | yes | No description declared. |
| `truth_scope` | `object` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:synthetic-corpus:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "case_count": {
      "minimum": 1,
      "type": "integer"
    },
    "cases": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "family": {
            "minLength": 1,
            "type": "string"
          },
          "generator": {
            "minLength": 1,
            "type": "string"
          },
          "id": {
            "pattern": "^[A-Za-z_][A-Za-z0-9_]*$",
            "type": "string"
          },
          "language": {
            "enum": [
              "c",
              "c++"
            ]
          },
          "seed": {
            "minimum": 0,
            "type": "integer"
          },
          "source": {
            "minLength": 1,
            "type": "string"
          },
          "source_sha256": {
            "pattern": "^[0-9a-f]{64}$",
            "type": "string"
          }
        },
        "required": [
          "id",
          "family",
          "language",
          "seed",
          "source",
          "source_sha256",
          "generator"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "cases_per_family": {
      "maximum": 10000,
      "minimum": 1,
      "type": "integer"
    },
    "created_at": {
      "type": "string"
    },
    "families": {
      "items": {
        "additionalProperties": false,
        "properties": {
          "language": {
            "enum": [
              "c",
              "c++"
            ]
          },
          "name": {
            "minLength": 1,
            "type": "string"
          }
        },
        "required": [
          "language",
          "name"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "kind": {
      "const": "synthetic_source_corpus"
    },
    "schema_version": {
      "const": 1
    },
    "seed": {
      "minimum": 0,
      "type": "integer"
    },
    "truth_scope": {
      "additionalProperties": false,
      "properties": {
        "binary_equivalence_claimed": {
          "const": false
        },
        "compiler_execution_performed": {
          "const": false
        },
        "original_source_recovery_claimed": {
          "const": false
        },
        "source_generation_reproducible": {
          "const": true
        }
      },
      "required": [
        "source_generation_reproducible",
        "compiler_execution_performed",
        "binary_equivalence_claimed",
        "original_source_recovery_claimed"
      ],
      "type": "object"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "created_at",
    "seed",
    "cases_per_family",
    "families",
    "case_count",
    "cases",
    "truth_scope"
  ],
  "title": "Deterministic synthetic source corpus",
  "type": "object"
}
```
