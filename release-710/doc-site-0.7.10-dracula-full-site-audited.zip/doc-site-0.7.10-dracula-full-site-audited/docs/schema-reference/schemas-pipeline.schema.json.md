---
title: 'Schema: schemas/pipeline.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/pipeline.schema.json.
---

# `schemas/pipeline.schema.json`

- **SHA-256:** `a9b7b790fb6c877370a4c61ecbdf0f92eac13d9aba389cc0ab8d8723aee92ca6`
- **Title:** urn:x86decomp:schema:pipeline:1
- **Type:** `object`
- **Properties:** 5
- **Required fields:** 4
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `created_at` | `string` | no | No description declared. |
| `pipeline_id` | `string` | yes | No description declared. |
| `project_root` | `string` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `stages` | `array` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:pipeline:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "created_at": {
      "format": "date-time",
      "type": "string"
    },
    "pipeline_id": {
      "minLength": 1,
      "type": "string"
    },
    "project_root": {
      "minLength": 1,
      "type": "string"
    },
    "schema_version": {
      "const": 1
    },
    "stages": {
      "items": {
        "additionalProperties": false,
        "allOf": [
          {
            "if": {
              "properties": {
                "kind": {
                  "const": "command"
                }
              }
            },
            "then": {
              "required": [
                "command"
              ]
            }
          },
          {
            "if": {
              "properties": {
                "kind": {
                  "const": "evidence_gate"
                }
              }
            },
            "then": {
              "required": [
                "evidence_claim_ids"
              ]
            }
          }
        ],
        "properties": {
          "command": {
            "items": {
              "minLength": 1,
              "type": "string"
            },
            "minItems": 1,
            "type": "array"
          },
          "container_image": {
            "type": [
              "string",
              "null"
            ]
          },
          "depends_on": {
            "items": {
              "type": "string"
            },
            "type": "array",
            "uniqueItems": true
          },
          "environment": {
            "additionalProperties": {
              "type": "string"
            },
            "type": "object"
          },
          "evidence_claim_ids": {
            "items": {
              "type": "string"
            },
            "type": "array",
            "uniqueItems": true
          },
          "id": {
            "pattern": "^[A-Za-z0-9_-]+$",
            "type": "string"
          },
          "inputs": {
            "items": {
              "type": "string"
            },
            "type": "array",
            "uniqueItems": true
          },
          "isolation": {
            "enum": [
              "local_bounded",
              "container"
            ]
          },
          "kind": {
            "enum": [
              "command",
              "evidence_gate"
            ]
          },
          "limits": {
            "additionalProperties": {
              "minimum": 1,
              "type": "integer"
            },
            "type": "object"
          },
          "outputs": {
            "items": {
              "type": "string"
            },
            "type": "array",
            "uniqueItems": true
          }
        },
        "required": [
          "id",
          "kind"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    }
  },
  "required": [
    "schema_version",
    "pipeline_id",
    "project_root",
    "stages"
  ],
  "type": "object"
}
```
