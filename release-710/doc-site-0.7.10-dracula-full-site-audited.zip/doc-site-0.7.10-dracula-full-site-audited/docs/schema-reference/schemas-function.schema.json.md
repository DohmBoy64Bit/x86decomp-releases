---
title: 'Schema: schemas/function.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/function.schema.json.
---

# `schemas/function.schema.json`

- **SHA-256:** `00c65be77cc237df28a9112019c07019f88f38072ceb329907adc88bcfc34704`
- **Title:** x86decomp Ghidra function artifact (schema versions 1 and 2)
- **Type:** `object`
- **Properties:** 19
- **Required fields:** 11
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `artifacts` | `object` | no | No description declared. |
| `body_ranges` | `array` | yes | No description declared. |
| `calling_convention` | `['string', 'null']` | yes | No description declared. |
| `decompile_completed` | `boolean` | no | No description declared. |
| `decompile_error` | `['string', 'null']` | no | No description declared. |
| `entry` | `string` | yes | No description declared. |
| `entry_rva` | `integer` | yes | No description declared. |
| `functional_status` | `unspecified` | no | No description declared. |
| `id` | `string` | yes | No description declared. |
| `is_thunk` | `boolean` | no | No description declared. |
| `matching_status` | `unspecified` | no | No description declared. |
| `name` | `string` | yes | No description declared. |
| `name_source` | `string` | yes | No description declared. |
| `parameters` | `array` | yes | No description declared. |
| `qualified_name` | `string` | no | No description declared. |
| `return_type` | `string` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `selected_modes` | `array` | no | No description declared. |
| `signature` | `string` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:function:2",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "allOf": [
    {
      "if": {
        "properties": {
          "schema_version": {
            "const": 2
          }
        },
        "required": [
          "schema_version"
        ]
      },
      "then": {
        "properties": {
          "body_ranges": {
            "items": {
              "additionalProperties": false
            }
          },
          "parameters": {
            "items": {
              "additionalProperties": false,
              "properties": {
                "name": {
                  "type": "string"
                },
                "ordinal": {
                  "type": "integer"
                },
                "storage": {
                  "type": "string"
                },
                "type": {
                  "type": "string"
                }
              },
              "required": [
                "ordinal",
                "name",
                "type",
                "storage"
              ],
              "type": "object"
            }
          }
        },
        "required": [
          "selected_modes",
          "matching_status",
          "functional_status",
          "is_thunk",
          "decompile_completed",
          "decompile_error",
          "artifacts"
        ]
      }
    }
  ],
  "properties": {
    "artifacts": {
      "additionalProperties": false,
      "properties": {
        "decompiler_c": {
          "minLength": 1,
          "type": "string"
        },
        "decompiler_tree": {
          "minLength": 1,
          "type": "string"
        },
        "high_pcode": {
          "minLength": 1,
          "type": "string"
        },
        "instructions": {
          "minLength": 1,
          "type": "string"
        },
        "raw_pcode": {
          "minLength": 1,
          "type": "string"
        },
        "references": {
          "minLength": 1,
          "type": "string"
        }
      },
      "required": [
        "decompiler_c",
        "decompiler_tree",
        "high_pcode",
        "raw_pcode",
        "instructions",
        "references"
      ],
      "type": "object"
    },
    "body_ranges": {
      "items": {
        "properties": {
          "end_inclusive": {
            "type": "string"
          },
          "end_rva": {
            "minimum": 1,
            "type": "integer"
          },
          "file": {
            "pattern": "^ranges/[^/]+\\.bin$",
            "type": "string"
          },
          "size": {
            "minimum": 1,
            "type": "integer"
          },
          "start": {
            "type": "string"
          },
          "start_rva": {
            "minimum": 0,
            "type": "integer"
          }
        },
        "required": [
          "start",
          "end_inclusive",
          "start_rva",
          "end_rva",
          "size",
          "file"
        ],
        "type": "object"
      },
      "minItems": 1,
      "type": "array"
    },
    "calling_convention": {
      "type": [
        "string",
        "null"
      ]
    },
    "decompile_completed": {
      "type": "boolean"
    },
    "decompile_error": {
      "type": [
        "string",
        "null"
      ]
    },
    "entry": {
      "minLength": 1,
      "type": "string"
    },
    "entry_rva": {
      "maximum": 4294967295,
      "minimum": 0,
      "type": "integer"
    },
    "functional_status": {
      "enum": [
        "not_started",
        "decompiled",
        "compiles",
        "abi_compatible",
        "differentially_validated",
        "symbolically_bounded",
        "integration_validated",
        "blocked"
      ]
    },
    "id": {
      "pattern": "^pe-rva:[0-9a-f]{8}$",
      "type": "string"
    },
    "is_thunk": {
      "type": "boolean"
    },
    "matching_status": {
      "enum": [
        "not_started",
        "decompiled",
        "compiles",
        "abi_compatible",
        "instruction_similar",
        "byte_matched",
        "image_integrated",
        "full_relink_validated",
        "blocked"
      ]
    },
    "name": {
      "minLength": 1,
      "type": "string"
    },
    "name_source": {
      "minLength": 1,
      "type": "string"
    },
    "parameters": {
      "type": "array"
    },
    "qualified_name": {
      "type": "string"
    },
    "return_type": {
      "type": "string"
    },
    "schema_version": {
      "enum": [
        1,
        2
      ]
    },
    "selected_modes": {
      "items": {
        "enum": [
          "matching",
          "functional"
        ]
      },
      "minItems": 1,
      "type": "array",
      "uniqueItems": true
    },
    "signature": {
      "type": "string"
    }
  },
  "required": [
    "schema_version",
    "id",
    "entry",
    "entry_rva",
    "name",
    "name_source",
    "calling_convention",
    "signature",
    "return_type",
    "body_ranges",
    "parameters"
  ],
  "title": "x86decomp Ghidra function artifact (schema versions 1 and 2)",
  "type": "object"
}
```
