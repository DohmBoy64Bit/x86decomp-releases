---
title: 'Schema: schemas/linker-reconstruction-plan.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/linker-reconstruction-plan.schema.json.
---

# `schemas/linker-reconstruction-plan.schema.json`

- **SHA-256:** `1d6fadf9737abed4d02cc90d3859898785edf62d3909c39fe893c8841c57f504`
- **Title:** urn:x86decomp:schema:linker-reconstruction-plan:1
- **Type:** `object`
- **Properties:** 17
- **Required fields:** 11
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `archives` | `array` | no | No description declared. |
| `comdat_resolution` | `object` | yes | No description declared. |
| `complete_original_link_command_claimed` | `unspecified` | no | No description declared. |
| `created_at` | `string` | no | No description declared. |
| `kind` | `unspecified` | yes | No description declared. |
| `libraries` | `array` | no | No description declared. |
| `limitations` | `array` | no | No description declared. |
| `linker` | `string` | no | No description declared. |
| `map` | `object` | yes | No description declared. |
| `objects` | `array` | yes | No description declared. |
| `placements` | `array` | yes | No description declared. |
| `ready_for_relink` | `boolean` | yes | No description declared. |
| `reference_image` | `object` | yes | No description declared. |
| `relink_manifest` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `sections` | `array` | yes | No description declared. |
| `unresolved` | `array` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:linker-reconstruction-plan:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": {
    "archives": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "comdat_resolution": {
      "type": "object"
    },
    "complete_original_link_command_claimed": {
      "const": false
    },
    "created_at": {
      "type": "string"
    },
    "kind": {
      "const": "linker_reconstruction_plan"
    },
    "libraries": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "limitations": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "linker": {
      "type": "string"
    },
    "map": {
      "type": "object"
    },
    "objects": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "placements": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "ready_for_relink": {
      "type": "boolean"
    },
    "reference_image": {
      "type": "object"
    },
    "relink_manifest": {
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "sections": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "unresolved": {
      "items": {
        "type": "string"
      },
      "type": "array"
    }
  },
  "required": [
    "schema_version",
    "kind",
    "reference_image",
    "map",
    "objects",
    "sections",
    "placements",
    "comdat_resolution",
    "relink_manifest",
    "unresolved",
    "ready_for_relink"
  ],
  "type": "object"
}
```
