---
title: 'Schema: schemas/assembly/asm-function.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/assembly/asm-function.schema.json.
---

# `schemas/assembly/asm-function.schema.json`

- **SHA-256:** `77a4651ffb4cc081c0696fed32ef81a5291908cf54fa1af356d5912388dadefc`
- **Title:** v0.7.10 function assembly result
- **Type:** `object`
- **Properties:** 14
- **Required fields:** 8
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `byte_escape_count` | `integer` | no | No description declared. |
| `classification` | `unspecified` | yes | No description declared. |
| `exact_match` | `boolean` | yes | No description declared. |
| `format` | `unspecified` | yes | No description declared. |
| `function_id` | `string` | yes | No description declared. |
| `input_sha256` | `string` | yes | No description declared. |
| `instruction_count` | `integer` | no | No description declared. |
| `mnemonic_count` | `integer` | no | No description declared. |
| `relocation_count` | `integer` | no | No description declared. |
| `resolved_relocation_count` | `integer` | no | No description declared. |
| `rva` | `integer` | yes | No description declared. |
| `source_sha256` | `string` | yes | No description declared. |
| `symbol` | `string` | yes | No description declared. |
| `unresolved_relocation_count` | `integer` | no | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.local/schemas/assembly/asm-function.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "byte_escape_count": {
      "minimum": 0,
      "type": "integer"
    },
    "classification": {
      "enum": [
        "byte-form",
        "annotated-byte-form",
        "fully-mnemonic",
        "mixed-mnemonic-byte",
        "byte-form-fallback"
      ]
    },
    "exact_match": {
      "type": "boolean"
    },
    "format": {
      "enum": [
        "bytes",
        "annotated",
        "mnemonic"
      ]
    },
    "function_id": {
      "minLength": 1,
      "type": "string"
    },
    "input_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "instruction_count": {
      "minimum": 0,
      "type": "integer"
    },
    "mnemonic_count": {
      "minimum": 0,
      "type": "integer"
    },
    "relocation_count": {
      "minimum": 0,
      "type": "integer"
    },
    "resolved_relocation_count": {
      "minimum": 0,
      "type": "integer"
    },
    "rva": {
      "minimum": 0,
      "type": "integer"
    },
    "source_sha256": {
      "pattern": "^[0-9a-f]{64}$",
      "type": "string"
    },
    "symbol": {
      "minLength": 1,
      "type": "string"
    },
    "unresolved_relocation_count": {
      "minimum": 0,
      "type": "integer"
    }
  },
  "required": [
    "function_id",
    "symbol",
    "rva",
    "format",
    "classification",
    "exact_match",
    "input_sha256",
    "source_sha256"
  ],
  "title": "v0.7.10 function assembly result",
  "type": "object"
}
```
