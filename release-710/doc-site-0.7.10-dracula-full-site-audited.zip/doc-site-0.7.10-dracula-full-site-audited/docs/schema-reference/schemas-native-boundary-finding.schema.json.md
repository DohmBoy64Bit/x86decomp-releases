---
title: 'Schema: schemas/native/boundary-finding.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/native/boundary-finding.schema.json.
---

# `schemas/native/boundary-finding.schema.json`

- **SHA-256:** `58d723eee6c5c374f78dcac68a23be5d0b60c6f002c3e8285d307eef496e74fc`
- **Title:** x86decomp boundary-finding
- **Type:** `object`
- **Properties:** 3
- **Required fields:** 3
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `finding_kind` | `string` | yes | No description declared. |
| `function_id` | `string` | yes | No description declared. |
| `severity` | `unspecified` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "https://x86decomp.invalid/schemas/native/boundary-finding.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "finding_kind": {
      "type": "string"
    },
    "function_id": {
      "type": "string"
    },
    "severity": {
      "enum": [
        "info",
        "warning",
        "error"
      ]
    }
  },
  "required": [
    "function_id",
    "finding_kind",
    "severity"
  ],
  "title": "x86decomp boundary-finding",
  "type": "object"
}
```
