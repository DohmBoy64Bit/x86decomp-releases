---
title: 'Schema: schemas/project-template.schema.json'
description: Current 0.7.10 JSON Schema reference for schemas/project-template.schema.json.
---

# `schemas/project-template.schema.json`

- **SHA-256:** `1bf881ea328d3a6c00d727c0cbe1e47763726e70362a085354178add994458ce`
- **Title:** Grounded x86decomp project-template contract
- **Type:** `object`
- **Properties:** 13
- **Required fields:** 11
- **Definitions:** 0

## Properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `unspecified` | yes | No description declared. |
| `artifact_roles` | `array` | yes | No description declared. |
| `blockers` | `array` | yes | No description declared. |
| `created_at` | `string` | yes | No description declared. |
| `functional` | `object` | yes | No description declared. |
| `image_kind` | `unspecified` | yes | No description declared. |
| `matching` | `object` | yes | No description declared. |
| `schema_version` | `unspecified` | yes | No description declared. |
| `selected_modes` | `array` | yes | No description declared. |
| `source_language_candidates` | `array` | no | No description declared. |
| `source_language_decision` | `string` | no | No description declared. |
| `target_id` | `string` | yes | No description declared. |
| `truth_policy` | `object` | yes | No description declared. |

## Raw schema

```json
{
  "$id": "urn:x86decomp:schema:project-template:1",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": true,
  "properties": {
    "architecture": {
      "enum": [
        "x86",
        "x86_64"
      ]
    },
    "artifact_roles": {
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "blockers": {
      "items": {
        "required": [
          "area",
          "fact",
          "reason"
        ],
        "type": "object"
      },
      "type": "array"
    },
    "created_at": {
      "type": "string"
    },
    "functional": {
      "type": "object"
    },
    "image_kind": {
      "enum": [
        "exe",
        "dll"
      ]
    },
    "matching": {
      "type": "object"
    },
    "schema_version": {
      "const": 1
    },
    "selected_modes": {
      "items": {
        "enum": [
          "matching",
          "functional"
        ]
      },
      "minItems": 1,
      "type": "array",
      "uniqueItems": true
    },
    "source_language_candidates": {
      "items": {
        "type": "object"
      },
      "type": "array"
    },
    "source_language_decision": {
      "type": "string"
    },
    "target_id": {
      "minLength": 1,
      "type": "string"
    },
    "truth_policy": {
      "properties": {
        "compiler_inferred_without_evidence": {
          "const": false
        },
        "generated_source_claimed": {
          "const": false
        },
        "linker_inferred_without_evidence": {
          "const": false
        },
        "unknowns_preserved": {
          "const": true
        }
      },
      "required": [
        "generated_source_claimed",
        "compiler_inferred_without_evidence",
        "linker_inferred_without_evidence",
        "unknowns_preserved"
      ],
      "type": "object"
    }
  },
  "required": [
    "schema_version",
    "created_at",
    "target_id",
    "architecture",
    "image_kind",
    "selected_modes",
    "matching",
    "functional",
    "artifact_roles",
    "blockers",
    "truth_policy"
  ],
  "title": "Grounded x86decomp project-template contract",
  "type": "object"
}
```
