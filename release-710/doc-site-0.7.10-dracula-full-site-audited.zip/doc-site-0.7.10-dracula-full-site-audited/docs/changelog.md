---
title: Changelog
description: Active release notes for x86decomp 0.7.10.
---

# Changelog

## 0.7.10

- Synchronized the Dracula MkDocs documentation site to the 0.7.10 audit-fix release bundle.
- Added audit-fix evidence pages for CR-079-001 through CR-079-011.
- Regenerated source coverage, schema reference, parser-derived command pages, source-module pages, function index, test-source reference pages, search metadata, sitemap, and docsite verification artifacts.
- Preserved the explicit validation boundary: segmented tests and targeted checks passed; the single-process monolithic pytest invocation is not claimed.
