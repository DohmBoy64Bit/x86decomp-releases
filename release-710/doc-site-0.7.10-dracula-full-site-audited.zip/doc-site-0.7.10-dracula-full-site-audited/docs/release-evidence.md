---
title: Release Evidence
description: Current release-evidence boundary for x86decomp 0.7.10.
---

# Release Evidence

The current site is synchronized to the v0.7.10 audit-fix release bundle. The release evidence pages intentionally distinguish verified checks from the monolithic pytest invocation that was not claimed.

| Evidence | Page |
| --- | --- |
| Verification summary | [verification.md](verification.md) |
| Source coverage | [source-coverage.md](source-coverage.md) |
| Docstring audit | [release-artifacts/DOCSTRING_AUDIT_0.7.10.md](release-artifacts/DOCSTRING_AUDIT_0.7.10.md) |
| Audit-fix report | [release-artifacts/AUDIT_FIX_REPORT_0.7.10.md](release-artifacts/AUDIT_FIX_REPORT_0.7.10.md) |
| Command reference | [release-artifacts/COMMAND_REFERENCE_0.7.10.md](release-artifacts/COMMAND_REFERENCE_0.7.10.md) |
| Schemas | [schemas.md](schemas.md) |
| Tests | [tests/index.md](tests/index.md) |
