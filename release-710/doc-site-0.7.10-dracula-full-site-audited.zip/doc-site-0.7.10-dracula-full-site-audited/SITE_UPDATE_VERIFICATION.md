# x86decomp 0.7.10 doc-site update verification

- Status: **PASS**
- Markdown pages: **508**
- Markdown hash entries: **508**
- Built HTML pages: **514**
- Source manifest entries: **446**
- Root commands: **166**
- Canonical groups/routes: **59 / 239**
- Schemas: **97**
- Python modules/symbols indexed from `src` and `test-suite/src`: **147 / 1296**
- Test sources: **61**
- Markdown hash verifier: **PASS**
- End-user site verifier: **PASS**
- Full docsite audit: **PASS, 0 errors**
