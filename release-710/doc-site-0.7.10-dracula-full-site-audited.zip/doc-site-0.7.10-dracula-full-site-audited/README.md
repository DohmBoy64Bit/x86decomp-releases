# x86decomp 0.7.10 Dracula documentation site

This site is synchronized to the x86decomp-toolkit 0.7.10 audit-fix release bundle.

Generated and verified content includes parser-derived command pages, schema pages, source coverage, module/function pages, test references, release evidence, search metadata, and sitemap output.
