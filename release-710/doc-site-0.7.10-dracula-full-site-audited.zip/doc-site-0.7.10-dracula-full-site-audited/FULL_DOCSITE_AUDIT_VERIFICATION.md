# x86decomp 0.7.10 full docsite audit verification

- Status: **PASS**
- Error count: **0**
- Markdown pages: **508**
- Markdown hash entries: **508**
- Built HTML pages: **514**
- Root commands: **166**
- Canonical groups: **59**
- Canonical routes: **239**
- Schemas: **97**
- Source manifest entries: **446**
- Root manifest entries: **446**
- Test-suite manifest entries: **63**
- Python modules documented from `src` and `test-suite/src`: **147**
- AST symbols indexed from `src` and `test-suite/src`: **1296**
- Test sources: **61**

The machine-readable audit is in `FULL_DOCSITE_AUDIT_VERIFICATION.json`.
