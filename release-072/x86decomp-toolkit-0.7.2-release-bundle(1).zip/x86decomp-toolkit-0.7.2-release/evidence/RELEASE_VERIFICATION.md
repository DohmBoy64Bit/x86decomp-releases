# x86decomp-toolkit v0.7.2 release verification

This is a clean v0.7.2 rebuild from the verified v0.7.1 source baseline. It restores the Unified Canonical CLI release and produces a fresh bundle; it is not claimed to be byte-identical to the previously lost archive.

## Release surface

- 33 canonical capability groups and 173 canonical leaf routes.
- 144 root parser choices, including the complete retained v0.7.1 command surface.
- All `v050`, `v060`, `v070`, and `v071` bridges and standalone executables remain functional.
- Canonical routes delegate to retained implementations; no duplicate business-logic plane was introduced.
- Byte-form assembly remains the compatibility default. Annotated and mnemonic forms remain additive.
- No feature, command implementation, schema, workflow, or compatibility path was removed.

## Regression and coverage gates

- Integrated collection: **285 passed, 0 failed, 0 skipped**.
- Independently repeated verifier collection: **43 passed, 0 failed, 0 skipped**.
- Comprehensive harness: **198 PASS, 0 FAIL, 0 ERROR, 7 BLOCKED**.
- Function-body execution: **518/518** retained functions/methods.
- Statement coverage: **79.21%** against a 70% floor.
- Branch coverage: **54.11%** against a 50% floor.

The blocked integrations were container-runtime, dynamorio, ghidra, llvm-readobj, msvc, objdiff, pip-audit. They were unavailable on the release host, remained explicit, and were not skipped or counted as passes.

## Packaging gates

The toolkit wheel/sdist, standalone test-suite wheel/sdist, and deterministic source ZIP were built from the sealed source. The toolkit sdist and source ZIP both passed `make verify`; the independently built test-suite sdist passed all 43 verifier tests in its intended sidecar layout. A clean virtual environment installed the toolkit wheel with `full`, `pe`, and `dev` extras plus the test-suite wheel, all entry points were probed, `pip check` passed, and the installed wheel's embedded v0.7.2 upgrader completed a transactional v0.7.1→v0.7.2 upgrade with 285 staged tests followed by 43 independently repeated tests.

The combined `full` extra now uses the Z3 4.13.0.0 version required by angr/claripy, resolving the inherited impossible dependency combination without changing the standalone `symbolic` extra.

## Interpretation

These gates establish the release, packaging, compatibility, and declared bounded-validation contracts. They do not claim original-source recovery or universal behavioral equivalence.
