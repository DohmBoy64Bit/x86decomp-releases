---
title: x86decomp claim-contradict
description: Parser-derived command reference page for `claim-contradict`.
---

# `x86decomp claim-contradict`

Source: `0.7.11` parser surface.

This root command is a direct parser entry point, compatibility command, or non-canonical helper command. It is counted in the root command surface and intentionally not double-counted as a canonical route when it aliases another command family.

## Parser help

```text
usage: x86decomp claim-contradict [-h] project claim_id evidence_id

positional arguments:
  project
  claim_id
  evidence_id

options:
  -h, --help   show this help message and exit
```
