---
title: x86decomp crosscheck-ghidra
description: Parser-derived command reference page for `crosscheck-ghidra`.
---

# `x86decomp crosscheck-ghidra`

Source: `0.7.11` parser surface.

This root command is a direct parser entry point, compatibility command, or non-canonical helper command. It is counted in the root command surface and intentionally not double-counted as a canonical route when it aliases another command family.

## Parser help

```text
usage: x86decomp crosscheck-ghidra [-h] --base BASE
                                   [--architecture {x86,x86_64}]
                                   [--report REPORT]
                                   instructions_jsonl code

positional arguments:
  instructions_jsonl
  code

options:
  -h, --help            show this help message and exit
  --base BASE
  --architecture {x86,x86_64}
  --report REPORT
```
