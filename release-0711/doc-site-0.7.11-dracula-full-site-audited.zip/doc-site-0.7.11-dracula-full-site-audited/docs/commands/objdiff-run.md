---
title: x86decomp objdiff-run
description: Parser-derived command reference page for `objdiff-run`.
---

# `x86decomp objdiff-run`

Source: `0.7.11` parser surface.

This root command is a direct parser entry point, compatibility command, or non-canonical helper command. It is counted in the root command surface and intentionally not double-counted as a canonical route when it aliases another command family.

## Parser help

```text
usage: x86decomp objdiff-run [-h] [--report REPORT] manifest

positional arguments:
  manifest

options:
  -h, --help       show this help message and exit
  --report REPORT
```
