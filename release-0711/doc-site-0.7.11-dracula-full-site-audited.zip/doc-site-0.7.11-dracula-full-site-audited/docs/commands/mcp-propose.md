---
title: x86decomp mcp-propose
description: Parser-derived command reference page for `mcp-propose`.
---

# `x86decomp mcp-propose`

Source: `0.7.11` parser surface.

This root command is a direct parser entry point, compatibility command, or non-canonical helper command. It is counted in the root command surface and intentionally not double-counted as a canonical route when it aliases another command family.

## Parser help

```text
usage: x86decomp mcp-propose [-h] [--url URL] [--command-json COMMAND_JSON]
                             --allow-tool ALLOW_TOOL --rationale RATIONALE
                             --evidence EVIDENCE
                             project tool arguments

positional arguments:
  project
  tool
  arguments

options:
  -h, --help            show this help message and exit
  --url URL
  --command-json COMMAND_JSON
  --allow-tool ALLOW_TOOL
  --rationale RATIONALE
  --evidence EVIDENCE
```
