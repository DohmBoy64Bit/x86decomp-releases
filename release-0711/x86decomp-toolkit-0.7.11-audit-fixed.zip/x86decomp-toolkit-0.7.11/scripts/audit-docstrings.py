#!/usr/bin/env python3
"""Generate the release docstring coverage and quality audit reports."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
RELEASE = "0.7.11"
PYTHON_ROOTS = (
    ROOT / "src",
    ROOT / "tests",
    ROOT / "test-suite" / "src",
    ROOT / "test-suite" / "tests",
    ROOT / "scripts",
    ROOT / "ghidra_scripts",
)
IGNORED_PARTS = {"build", "dist", ".pytest_cache", "__pycache__"}
TEMPLATE_PHRASES = (
    "for the current toolkit workflow.",
    "processing for internal toolkit callers.",
)


def python_files() -> list[Path]:
    """Return every release-controlled Python source file in audit scope."""
    result: list[Path] = []
    for base in PYTHON_ROOTS:
        if not base.exists():
            continue
        for path in sorted(base.rglob("*.py")):
            if any(part in IGNORED_PARTS for part in path.relative_to(ROOT).parts):
                continue
            result.append(path)
    return result


def sha256(path: Path) -> str:
    """Return the SHA-256 digest for one audited source file."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit() -> dict[str, Any]:
    """Inspect docstring presence and the two audited quality failure patterns."""
    totals = {"modules": 0, "classes": 0, "functions": 0}
    present = {"modules": 0, "classes": 0, "functions": 0}
    missing: list[str] = []
    template: list[str] = []
    repeated: list[str] = []
    files = python_files()
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=relative)
        totals["modules"] += 1
        if ast.get_docstring(tree) is None:
            missing.append(f"{relative}:<module>")
        else:
            present["modules"] += 1
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                category = "classes"
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                category = "functions"
            else:
                continue
            totals[category] += 1
            doc = ast.get_docstring(node) or ""
            key = f"{relative}:{node.lineno}:{node.name}"
            if doc:
                present[category] += 1
            else:
                missing.append(key)
            if any(phrase in doc for phrase in TEMPLATE_PHRASES):
                template.append(key)
            words = re.findall(r"[A-Za-z]+", doc.splitlines()[0].lower() if doc else "")
            if len(words) >= 2 and words[0] == words[1]:
                repeated.append(key)
    return {
        "release": RELEASE,
        "generated_at": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "scope": [path.relative_to(ROOT).as_posix() for path in PYTHON_ROOTS],
        "audited_file_count": len(files),
        "audited_files_sha256": {
            path.relative_to(ROOT).as_posix(): sha256(path) for path in files
        },
        "python_docstring_coverage": {
            "modules_total": totals["modules"],
            "modules_with_docstrings": present["modules"],
            "classes_total": totals["classes"],
            "classes_with_docstrings": present["classes"],
            "functions_total": totals["functions"],
            "functions_with_docstrings": present["functions"],
        },
        "missing_docstrings": missing,
        "quality_checks": {
            "template_phrase_occurrences": len(template),
            "template_phrase_symbols": template,
            "repeated_leading_verb_occurrences": len(repeated),
            "repeated_leading_verb_symbols": repeated,
        },
        "passed": not missing and not template and not repeated,
    }


def render_markdown(report: dict[str, Any]) -> str:
    """Render a concise human-readable companion to the JSON audit."""
    coverage = report["python_docstring_coverage"]
    quality = report["quality_checks"]
    status = "PASS" if report["passed"] else "FAIL"
    return f"""# Docstring audit — {report['release']}

Status: **{status}**

Generated: `{report['generated_at']}`

- Python files audited: {report['audited_file_count']}
- Modules with docstrings: {coverage['modules_with_docstrings']} / {coverage['modules_total']}
- Classes with docstrings: {coverage['classes_with_docstrings']} / {coverage['classes_total']}
- Functions and methods with docstrings: {coverage['functions_with_docstrings']} / {coverage['functions_total']}
- Missing docstrings: {len(report['missing_docstrings'])}
- Audited template phrases: {quality['template_phrase_occurrences']}
- Repeated leading-verb stubs: {quality['repeated_leading_verb_occurrences']}

The JSON companion records a SHA-256 digest for every audited Python file so the result can be
recomputed against the exact source state.
"""


def main() -> int:
    """Write JSON and Markdown reports and fail when any audited check fails."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, default=ROOT / f"DOCSTRING_AUDIT_{RELEASE}.json")
    parser.add_argument("--markdown", type=Path, default=ROOT / f"DOCSTRING_AUDIT_{RELEASE}.md")
    args = parser.parse_args()
    report = audit()
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    args.markdown.write_text(render_markdown(report), encoding="utf-8")
    print(json.dumps({
        "passed": report["passed"],
        "audited_file_count": report["audited_file_count"],
        "missing_docstrings": len(report["missing_docstrings"]),
        "template_phrase_occurrences": report["quality_checks"]["template_phrase_occurrences"],
        "repeated_leading_verb_occurrences": report["quality_checks"]["repeated_leading_verb_occurrences"],
    }, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
