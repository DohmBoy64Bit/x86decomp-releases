# Verified facts used by this package

Checked on 2026-07-09.

## N64Recomp

- Upstream N64Recomp describes itself as a tool that statically recompiles N64 games into native executables.
- Upstream build instructions require CMake 3.20 or newer, a C++20-capable compiler, and recursive submodules.
- N64Recomp code generation is not a complete port runtime by itself. A project still needs host runtime integration.

Source: https://github.com/N64Recomp/N64Recomp

## N64ModernRuntime

- N64ModernRuntime is the runtime layer used by traditional ports and recompilations of N64 games.
- Its two core libraries are `ultramodern` and `librecomp`.

Source: https://github.com/N64Recomp/N64ModernRuntime

## Splat

- The active binary splitting tool package is `splat64`.
- The documented install line is `python3 -m pip install -U splat64[mips]`.
- The `mips` optional dependency group is required for N64, PSX, PS2, and PSP platforms.

Source: https://github.com/ethteck/splat

## Podman on Windows

- Podman runs on Windows with a native CLI plus a Podman-managed Linux guest machine.
- `podman machine init` initializes the Linux virtual machine.
- `podman machine start` starts that virtual machine.

Sources: https://podman.io/docs/installation, https://docs.podman.io/en/latest/markdown/podman-machine-init.1.html, https://docs.podman.io/en/stable/markdown/podman-machine-start.1.html

## Windows debugging

- Microsoft Debugging Tools for Windows can be installed from the Windows SDK, WDK, or as a standalone SDK feature selection.
- CDB is the Microsoft Console Debugger and is one of the command-line debuggers in Debugging Tools for Windows.

Source: https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/debugger-download-tools

## MSYS2 and uv

- MSYS2 provides native Windows builds for tools including GCC, CPython, and CMake, using the Pacman package manager.
- uv supports Windows installation through its standalone installer and WinGet.

Sources: https://www.msys2.org/, https://docs.astral.sh/uv/getting-started/installation/
