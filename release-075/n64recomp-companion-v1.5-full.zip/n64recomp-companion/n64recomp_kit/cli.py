from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .batch import run_batch
from .config import create_config, format_validation, validate_config
from .doctor import doctor, format_doctor
from .cdb import discover_cdb, format_cdb_probe, write_cdb_evidence
from .elf import format_elf_info, inspect_elf
from .elf_build import build_elf_from_splat, emit_elf_build_helpers
from .recomp import format_summary, run_recomp, summarize_output
from .rom import convert_to_z64, format_rom_info, inspect_rom
from .splat import create_splat_config, run_splat_config
from .matching import emit_matching_configure, run_configure_min
from .runtime_template import generate_runtime_project
from .toolchain import discover_mips_toolchains, format_toolchains, smoke_test_mips_toolchain
from .workspace import format_workspace_scan, init_function_ledger, init_project_state, scan_workspace
from .util import parse_int, print_json, write_json


def _add_json(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true", help="print machine-readable JSON")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="n64recomp-kit", description="Companion tools for N64Recomp workflows")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("doctor", help="check local, Windows, Podman, Splat, CDB, and MIPS tool availability")
    p.add_argument("--n64recomp", help="path to N64Recomp binary")
    p.add_argument("--root", default=".", help="project root used to discover CDB wrappers")
    _add_json(p)

    p = sub.add_parser("rom-info", help="inspect an N64 ROM header")
    p.add_argument("rom")
    _add_json(p)

    p = sub.add_parser("convert-rom", help="convert .n64/.v64 byte order to .z64")
    p.add_argument("input")
    p.add_argument("output")
    p.add_argument("--overwrite", action="store_true")
    _add_json(p)

    p = sub.add_parser("elf-info", help="inspect an ELF32 file")
    p.add_argument("elf")
    _add_json(p)
    p = sub.add_parser("workspace-status", help="classify a project as matching-decomp or N64Recomp track and phase")
    p.add_argument("--root", default=".", help="project root to inspect")
    _add_json(p)

    p = sub.add_parser("init-state", help="write N64_PROJECT_STATE.md for repeatable long-running sessions")
    p.add_argument("--root", default=".")
    p.add_argument("--overwrite", action="store_true")

    p = sub.add_parser("init-ledger", help="write docs/function_ledger.md with evidence columns")
    p.add_argument("--root", default=".")
    p.add_argument("--overwrite", action="store_true")

    p = sub.add_parser("emit-matching-configure", help="write an assembly-only configure.py for first ROM match attempts")
    p.add_argument("--root", default=".")
    p.add_argument("--game", required=True, help="game slug used for build output and linker script names")
    p.add_argument("--overwrite", action="store_true")
    _add_json(p)

    p = sub.add_parser("matching-build", help="run a generated assembly-only configure.py")
    p.add_argument("--root", default=".")
    p.add_argument("--clean", action="store_true")
    p.add_argument("--build", action="store_true")
    p.add_argument("--diff", action="store_true")
    p.add_argument("--timeout", type=int)
    p.add_argument("--report", default="matching-build-report.json")
    _add_json(p)

    p = sub.add_parser("emit-elf-build", help="write Windows/Python helper scripts for building the Splat ELF")
    p.add_argument("--root", default=".")
    p.add_argument("--overwrite", action="store_true")
    _add_json(p)

    p = sub.add_parser("build-elf", help="assemble/link Splat output into the ELF consumed by N64Recomp")
    p.add_argument("--config", required=True, help="Splat YAML config with elf_path and ld_script_path")
    p.add_argument("--root", default=".", help="project root used to resolve relative Splat paths")
    p.add_argument("--prefix", help="MIPS toolchain prefix, such as mips-linux-gnu-")
    p.add_argument("--profile", choices=["asm-only", "gnu-c"], default="asm-only")
    p.add_argument("--clean", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--timeout", type=int)
    p.add_argument("--report", default="elf-build-report.json")
    p.add_argument("--asflag", action="append", default=[], help="extra assembler flag; may be repeated")
    p.add_argument("--cflag", action="append", default=[], help="extra C/C++ compiler flag; may be repeated")
    p.add_argument("--ldflag", action="append", default=[], help="extra linker flag; may be repeated")
    _add_json(p)

    p = sub.add_parser("cdb-info", help="locate cdb.exe and project CDB PowerShell wrappers")
    p.add_argument("--root", default=".")
    _add_json(p)

    p = sub.add_parser("cdb-evidence", help="write a CDB trace evidence note after a wrapper run")
    p.add_argument("--output", required=True)
    p.add_argument("--wrapper", required=True)
    p.add_argument("--target", required=True)
    p.add_argument("--result", required=True, choices=["HIT", "BYPASS", "ABORT", "INCONCLUSIVE"])
    p.add_argument("--breakpoint", action="append", default=[])
    p.add_argument("--summary", required=True)
    p.add_argument("--overwrite", action="store_true")



    p = sub.add_parser("new-runtime-project", help="generate a Windows CMake starter with RT64, RmlUi, LunaSVG, and FreeType wiring")
    p.add_argument("--output", required=True, help="directory to create or update")
    p.add_argument("--name", required=True, help="project display name")
    p.add_argument("--window-title", help="window title shown by the SDL starter app")
    p.add_argument("--overwrite", action="store_true")
    _add_json(p)

    p = sub.add_parser("init", help="write a concrete N64Recomp TOML config")
    p.add_argument("--config", required=True, help="output TOML path")
    p.add_argument("--entrypoint", help="entrypoint integer, decimal or 0x hex")
    p.add_argument("--elf", help="ELF input path")
    p.add_argument("--rom", help="ROM input path for symbol-file mode")
    p.add_argument("--symbols", help="N64Recomp symbols TOML path for symbol-file mode")
    p.add_argument("--output-func-path", default="RecompiledFuncs")
    p.add_argument("--relocatable-sections-path")
    p.add_argument("--single-file-output", action="store_true")
    p.add_argument("--functions-per-output-file", type=int, default=50)
    p.add_argument("--recomp-include", default='#include "recomp.h"')
    p.add_argument("--overwrite", action="store_true")

    p = sub.add_parser("check-config", help="validate an N64Recomp TOML config")
    p.add_argument("config")
    p.add_argument("--allow-missing-paths", action="store_true")
    _add_json(p)

    p = sub.add_parser("run", help="validate and run N64Recomp")
    p.add_argument("config")
    p.add_argument("--n64recomp", help="path to N64Recomp binary")
    p.add_argument("--clean-output", action="store_true")
    p.add_argument("--timeout", type=int)
    p.add_argument("--allow-missing-paths", action="store_true")
    p.add_argument("--report", default="recomp-report.json")
    _add_json(p)

    p = sub.add_parser("summarize-output", help="summarize generated recompilation output")
    p.add_argument("path")
    p.add_argument("--largest", type=int, default=10)
    _add_json(p)


    p = sub.add_parser("toolchain-info", help="discover open MIPS cross toolchains")
    p.add_argument("--prefix", help="probe only this prefix, such as mips-linux-gnu-")
    _add_json(p)

    p = sub.add_parser("mips-smoke", help="assemble and link a tiny MIPS ELF with the discovered toolchain")
    p.add_argument("--prefix", help="toolchain prefix, such as mips-linux-gnu-")
    p.add_argument("--output-dir", default="build/mips-smoke")
    p.add_argument("--vram", default="0x80000400")
    _add_json(p)

    p = sub.add_parser("splat-init", help="write a concrete Splat YAML config for a normalized .z64 ROM")
    p.add_argument("--config", required=True, help="output splat.yaml path")
    p.add_argument("--rom", required=True, help="normalized big-endian .z64 ROM path")
    p.add_argument("--basename", required=True, help="short project basename used by Splat outputs")
    p.add_argument("--compiler", default="IDO")
    p.add_argument("--code-start", default="0x1000")
    p.add_argument("--vram", default="0x80000400")
    p.add_argument("--end", help="exclusive ROM end offset, default is ROM size")
    p.add_argument("--overwrite", action="store_true")
    _add_json(p)

    p = sub.add_parser("splat-run", help="run Splat on an existing YAML config and write a report")
    p.add_argument("config")
    p.add_argument("--splat", help="path to splat command")
    p.add_argument("--cwd", help="working directory for Splat")
    p.add_argument("--timeout", type=int)
    p.add_argument("--report", default="splat-report.json")
    _add_json(p)

    p = sub.add_parser("batch", help="batch-check or batch-run several configs")
    p.add_argument("manifest")
    p.add_argument("--mode", choices=["check", "run"], default="check")
    p.add_argument("--n64recomp", help="path to N64Recomp binary")
    p.add_argument("--clean-output", action="store_true")
    p.add_argument("--timeout", type=int)
    p.add_argument("--allow-missing-paths", action="store_true")
    p.add_argument("--report", default="batch-report.json")
    _add_json(p)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            data = doctor(n64recomp=args.n64recomp, root=args.root)
            print_json(data) if args.json else print(format_doctor(data))
            return 0 if data["n64recomp"]["available"] else 2
        if args.command == "rom-info":
            info = inspect_rom(args.rom)
            print_json(info.to_dict()) if args.json else print(format_rom_info(info))
            return 0
        if args.command == "convert-rom":
            data = convert_to_z64(args.input, args.output, overwrite=args.overwrite)
            print_json(data) if args.json else print(f"Wrote {data['output']} ({data['source_byte_order']} -> z64-big-endian)")
            return 0
        if args.command == "elf-info":
            info = inspect_elf(args.elf)
            print_json(info.to_dict()) if args.json else print(format_elf_info(info))
            return 0
        if args.command == "workspace-status":
            scan = scan_workspace(args.root)
            print_json(scan.to_dict()) if args.json else print(format_workspace_scan(scan))
            return 0
        if args.command == "init-state":
            out = init_project_state(args.root, overwrite=args.overwrite)
            print(f"Wrote {out}")
            return 0
        if args.command == "init-ledger":
            out = init_function_ledger(args.root, overwrite=args.overwrite)
            print(f"Wrote {out}")
            return 0
        if args.command == "emit-matching-configure":
            report = emit_matching_configure(args.root, game=args.game, overwrite=args.overwrite)
            print_json(report.to_dict()) if args.json else print(f"Wrote {report.path}")
            return 0
        if args.command == "matching-build":
            report = run_configure_min(args.root, clean=args.clean, build=args.build, diff=args.diff, timeout=args.timeout)
            write_json(args.report, report)
            if args.json:
                print_json(report)
            else:
                print(f"Status: {'ok' if report['ok'] else 'failed'}")
                print(f"Report: {args.report}")
            return 0 if report["ok"] else 1
        if args.command == "emit-elf-build":
            report = emit_elf_build_helpers(args.root, overwrite=args.overwrite)
            if args.json:
                print_json(report)
            else:
                print("Wrote ELF build helpers:")
                for path in report["files"]:
                    print(f"  {path}")
            return 0
        if args.command == "build-elf":
            report_obj = build_elf_from_splat(
                args.config,
                root_path=args.root,
                prefix=args.prefix,
                profile=args.profile,
                dry_run=args.dry_run,
                clean=args.clean,
                timeout=args.timeout,
                extra_asflags=args.asflag,
                extra_cflags=args.cflag,
                extra_ldflags=args.ldflag,
            )
            report = report_obj.to_dict()
            write_json(args.report, report)
            if args.json:
                print_json(report)
            else:
                print(f"Status: {'ok' if report['ok'] else 'failed'}")
                print(f"Dry run: {report['dry_run']}")
                print(f"ELF    : {report['paths']['elf_path']}")
                print(f"Objects: {report['object_count']}")
                print(f"Report : {args.report}")
            return 0 if report["ok"] else 1
        if args.command == "cdb-info":
            probe = discover_cdb(args.root)
            print_json(probe.to_dict()) if args.json else print(format_cdb_probe(probe))
            return 0 if probe.available else 2
        if args.command == "cdb-evidence":
            out = write_cdb_evidence(
                args.output,
                wrapper=args.wrapper,
                target=args.target,
                result=args.result,
                breakpoints=args.breakpoint,
                summary=args.summary,
                overwrite=args.overwrite,
            )
            print(f"Wrote {out}")
            return 0

        if args.command == "new-runtime-project":
            report = generate_runtime_project(args.output, name=args.name, window_title=args.window_title, overwrite=args.overwrite)
            if args.json:
                print_json(report.to_dict())
            else:
                print(f"Wrote runtime starter: {report.root}")
                print(f"Files: {len(report.files)}")
            return 0
        if args.command == "init":
            entrypoint = parse_int(args.entrypoint) if args.entrypoint else None
            out = create_config(
                args.config,
                entrypoint=entrypoint,
                elf_path=args.elf,
                rom_path=args.rom,
                symbols_file_path=args.symbols,
                output_func_path=args.output_func_path,
                relocatable_sections_path=args.relocatable_sections_path,
                single_file_output=args.single_file_output,
                functions_per_output_file=args.functions_per_output_file,
                recomp_include=args.recomp_include,
                overwrite=args.overwrite,
            )
            print(f"Wrote {out}")
            return 0
        if args.command == "check-config":
            result = validate_config(args.config, allow_missing_paths=args.allow_missing_paths)
            print_json(result.to_dict()) if args.json else print(format_validation(result))
            return 0 if result.ok else 1
        if args.command == "run":
            report = run_recomp(
                args.config,
                n64recomp=args.n64recomp,
                clean_output=args.clean_output,
                timeout=args.timeout,
                allow_missing_paths=args.allow_missing_paths,
            )
            write_json(args.report, report)
            if args.json:
                print_json(report)
            else:
                print(f"Status: {report['status']}")
                print(f"Report: {args.report}")
                if "output_summary" in report:
                    print(format_summary(summarize_output(report["output_summary"]["path"])))
            return 0 if report.get("status") == "ok" else 1
        if args.command == "summarize-output":
            summary = summarize_output(args.path, largest=args.largest)
            print_json(summary.to_dict()) if args.json else print(format_summary(summary))
            return 0 if summary.exists else 1

        if args.command == "toolchain-info":
            probes = discover_mips_toolchains([args.prefix] if args.prefix else None)
            data = [probe.to_dict() for probe in probes]
            print_json(data) if args.json else print(format_toolchains(probes))
            return 0 if any(probe.usable_for_elf_smoke for probe in probes) else 2
        if args.command == "mips-smoke":
            report = smoke_test_mips_toolchain(output_dir=args.output_dir, prefix=args.prefix, vram=parse_int(args.vram))
            if args.json:
                print_json(report)
            else:
                print(f"Status: {'ok' if report['ok'] else 'failed'}")
                print(f"Prefix: {report['prefix']}")
                print(f"Stage : {report['stage']}")
                print(f"ELF   : {report['paths']['elf']}")
            return 0 if report["ok"] else 1
        if args.command == "splat-init":
            report = create_splat_config(
                args.config,
                rom_path=args.rom,
                basename=args.basename,
                compiler=args.compiler,
                code_start=parse_int(args.code_start),
                vram=parse_int(args.vram),
                end=parse_int(args.end) if args.end else None,
                overwrite=args.overwrite,
            )
            print_json(report.to_dict()) if args.json else print(f"Wrote {report.config}")
            return 0
        if args.command == "splat-run":
            report = run_splat_config(args.config, splat=args.splat, cwd=args.cwd, timeout=args.timeout)
            write_json(args.report, report)
            if args.json:
                print_json(report)
            else:
                print(f"Status: {'ok' if report['ok'] else 'failed'}")
                print(f"Report: {args.report}")
            return 0 if report["ok"] else 1
        if args.command == "batch":
            report = run_batch(
                args.manifest,
                mode=args.mode,
                n64recomp=args.n64recomp,
                clean_output=args.clean_output,
                timeout=args.timeout,
                allow_missing_paths=args.allow_missing_paths,
            )
            write_json(args.report, report)
            if args.json:
                print_json(report)
            else:
                print(f"Projects: {report['project_count']}")
                print(f"Failures: {report['failed_count']}")
                print(f"Report: {args.report}")
            return 0 if report["ok"] else 1
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
