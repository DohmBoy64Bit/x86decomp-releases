from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RuntimeProjectReport:
    root: str
    name: str
    slug: str
    window_title: str
    files: list[str]

    def to_dict(self) -> dict[str, object]:
        return {
            "root": self.root,
            "name": self.name,
            "slug": self.slug,
            "window_title": self.window_title,
            "files": self.files,
            "file_count": len(self.files),
        }


def _slugify(value: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError("project name cannot be empty")
    slug = re.sub(r"[^A-Za-z0-9_+-]+", "-", value).strip("-")
    if not slug:
        raise ValueError("project name must contain at least one alphanumeric character")
    return slug.lower()


def _cmake_identifier(value: str) -> str:
    ident = re.sub(r"[^A-Za-z0-9_]", "_", value)
    ident = re.sub(r"_+", "_", ident).strip("_")
    if not ident:
        ident = "N64RuntimeStarter"
    if ident[0].isdigit():
        ident = f"N64_{ident}"
    return ident


def _cpp_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _render(text: str, mapping: dict[str, str]) -> str:
    for key, value in mapping.items():
        text = text.replace("{{" + key + "}}", value)
    return text


def _write(path: Path, text: str, overwrite: bool) -> None:
    if path.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite existing file: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.replace("\n", "\r\n") if path.suffix.lower() == ".ps1" else text, encoding="utf-8")


def generate_runtime_project(output: str | Path, *, name: str, window_title: str | None = None, overwrite: bool = False) -> RuntimeProjectReport:
    out = Path(output)
    slug = _slugify(name)
    ident = _cmake_identifier(name)
    exe = _cmake_identifier(slug)
    title = window_title or f"{name} Recompiled"
    mapping = {
        "PROJECT_NAME": name.strip(),
        "PROJECT_SLUG": slug,
        "PROJECT_IDENT": ident,
        "EXE_NAME": exe,
        "WINDOW_TITLE": title,
        "CPP_WINDOW_TITLE": _cpp_string(title),
    }
    files: list[str] = []
    for rel, text in _TEMPLATES.items():
        path = out / rel
        _write(path, _render(text, mapping), overwrite)
        files.append(rel)
    return RuntimeProjectReport(root=str(out), name=name.strip(), slug=slug, window_title=title, files=files)


_TEMPLATES: dict[str, str] = {
"CMakeLists.txt": r'''cmake_minimum_required(VERSION 3.24)
project({{PROJECT_IDENT}} VERSION 0.1.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

option(N64_STARTER_ENABLE_RT64 "Fetch and link RT64 renderer support" ON)
option(N64_STARTER_ENABLE_RMLUI "Link RmlUi for launcher and in-game menu assets" ON)
option(N64_STARTER_ENABLE_SVG "Enable LunaSVG dependency used by RmlUi SVG support" ON)
option(N64_STARTER_COPY_ASSETS "Copy runtime assets next to the executable" ON)

include(cmake/Dependencies.cmake)

add_executable({{EXE_NAME}}
    src/main.cpp
    src/app_settings.hpp
    src/asset_paths.cpp
    src/asset_paths.hpp
    src/rt64_support.cpp
    src/rt64_support.hpp
    src/rmlui_manifest.cpp
    src/rmlui_manifest.hpp
)

target_compile_definitions({{EXE_NAME}} PRIVATE
    N64_STARTER_PROJECT_NAME="{{PROJECT_NAME}}"
    N64_STARTER_WINDOW_TITLE="{{CPP_WINDOW_TITLE}}"
    N64_STARTER_ASSET_DIR="assets"
)

target_link_libraries({{EXE_NAME}} PRIVATE SDL2::SDL2 SDL2::SDL2main)

if(N64_STARTER_ENABLE_RMLUI)
    target_compile_definitions({{EXE_NAME}} PRIVATE N64_STARTER_HAS_RMLUI=1)
    target_link_libraries({{EXE_NAME}} PRIVATE RmlUi::RmlUi Freetype::Freetype)
else()
    target_compile_definitions({{EXE_NAME}} PRIVATE N64_STARTER_HAS_RMLUI=0)
endif()

if(N64_STARTER_ENABLE_SVG)
    target_compile_definitions({{EXE_NAME}} PRIVATE N64_STARTER_HAS_LUNASVG=1)
    target_link_libraries({{EXE_NAME}} PRIVATE lunasvg::lunasvg)
else()
    target_compile_definitions({{EXE_NAME}} PRIVATE N64_STARTER_HAS_LUNASVG=0)
endif()

if(N64_STARTER_ENABLE_RT64)
    target_compile_definitions({{EXE_NAME}} PRIVATE N64_STARTER_HAS_RT64=1)
    target_link_libraries({{EXE_NAME}} PRIVATE rt64)
else()
    target_compile_definitions({{EXE_NAME}} PRIVATE N64_STARTER_HAS_RT64=0)
endif()

if(MSVC)
    target_compile_options({{EXE_NAME}} PRIVATE /W4 /permissive-)
else()
    target_compile_options({{EXE_NAME}} PRIVATE -Wall -Wextra -Wpedantic)
endif()

if(N64_STARTER_COPY_ASSETS)
    add_custom_command(TARGET {{EXE_NAME}} POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_directory
                "${CMAKE_CURRENT_SOURCE_DIR}/assets"
                "$<TARGET_FILE_DIR:{{EXE_NAME}}>/assets"
        VERBATIM)
endif()

install(TARGETS {{EXE_NAME}} RUNTIME DESTINATION .)
install(DIRECTORY assets DESTINATION .)
''',
"cmake/Dependencies.cmake": r'''include(FetchContent)

set(FETCHCONTENT_QUIET OFF)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "Use static libraries for starter dependencies" FORCE)

find_package(SDL2 CONFIG REQUIRED)

if(N64_STARTER_ENABLE_RMLUI)
    set(RMLUI_SAMPLES OFF CACHE BOOL "Disable RmlUi samples" FORCE)
    set(RMLUI_LUA_BINDINGS OFF CACHE BOOL "Disable RmlUi Lua bindings" FORCE)
    set(RMLUI_SVG_PLUGIN ${N64_STARTER_ENABLE_SVG} CACHE BOOL "Enable RmlUi SVG plugin" FORCE)
    set(RMLUI_FONT_ENGINE freetype CACHE STRING "Use FreeType font engine" FORCE)
    find_package(Freetype REQUIRED)
    find_package(RmlUi CONFIG REQUIRED)
endif()

if(N64_STARTER_ENABLE_SVG)
    find_package(lunasvg CONFIG REQUIRED)
endif()

if(N64_STARTER_ENABLE_RT64)
    set(RT64_STATIC ON CACHE BOOL "Build RT64 as a static library" FORCE)
    FetchContent_Declare(
        rt64
        GIT_REPOSITORY https://github.com/rt64/rt64.git
        GIT_TAG main
        GIT_SHALLOW TRUE
        GIT_PROGRESS TRUE
    )
    FetchContent_MakeAvailable(rt64)
    if(NOT TARGET rt64)
        message(FATAL_ERROR "RT64 was fetched, but the expected CMake target 'rt64' was not created")
    endif()
endif()
''',
"CMakePresets.json": r'''{
  "version": 6,
  "cmakeMinimumRequired": {
    "major": 3,
    "minor": 24,
    "patch": 0
  },
  "configurePresets": [
    {
      "name": "windows-msvc-vcpkg",
      "displayName": "Windows MSVC with vcpkg manifest",
      "generator": "Ninja",
      "binaryDir": "${sourceDir}/build/windows-msvc-vcpkg",
      "cacheVariables": {
        "CMAKE_BUILD_TYPE": "RelWithDebInfo",
        "CMAKE_TOOLCHAIN_FILE": "$env{VCPKG_ROOT}/scripts/buildsystems/vcpkg.cmake",
        "VCPKG_MANIFEST_MODE": "ON"
      }
    },
    {
      "name": "windows-msvc-no-rt64",
      "displayName": "Windows MSVC with vcpkg manifest, RT64 fetch disabled",
      "inherits": "windows-msvc-vcpkg",
      "binaryDir": "${sourceDir}/build/windows-msvc-no-rt64",
      "cacheVariables": {
        "N64_STARTER_ENABLE_RT64": "OFF"
      }
    }
  ],
  "buildPresets": [
    {
      "name": "windows-msvc-vcpkg",
      "configurePreset": "windows-msvc-vcpkg"
    },
    {
      "name": "windows-msvc-no-rt64",
      "configurePreset": "windows-msvc-no-rt64"
    }
  ]
}
''',
"vcpkg.json": r'''{
  "name": "{{PROJECT_SLUG}}-runtime-starter",
  "version-string": "0.1.0",
  "dependencies": [
    "sdl2",
    "rmlui",
    "lunasvg",
    "freetype"
  ]
}
''',
"Makefile": r'''SHELL := pwsh.exe
.PHONY: configure build run clean

configure:
	./scripts/Configure-Windows.ps1

build:
	./scripts/Build-Windows.ps1

run:
	./scripts/Run-Windows.ps1

clean:
	Remove-Item -Recurse -Force build -ErrorAction SilentlyContinue
''',
"README.md": r'''# {{PROJECT_NAME}} runtime starter

This generated project is a Windows-first CMake starter for a native N64Recomp host application. It opens a basic SDL2 game window, links RT64 when enabled, and ships RmlUi launcher/menu assets with SVG and FreeType dependencies wired through CMake.

## What this project builds

- `{{EXE_NAME}}.exe`, a basic resizable game window.
- RT64 linked as a static CMake dependency when `N64_STARTER_ENABLE_RT64=ON`.
- RmlUi, LunaSVG, and FreeType dependencies available to the host application.
- Launcher and menu RML/CSS/SVG assets copied beside the executable.

The application does not contain any ROM data or proprietary game code. Recompiled game functions produced by N64Recomp should be added as normal CMake sources or as a library target after they exist.

## Windows build

Open an x64 Developer PowerShell for Visual Studio.

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\scripts\Configure-Windows.ps1
.\scripts\Build-Windows.ps1
.\scripts\Run-Windows.ps1
```

The configure script expects `VCPKG_ROOT` to point at a bootstrapped vcpkg checkout. If it is not set, the script installs vcpkg under `.deps\vcpkg` and uses that local copy.

## RT64 switch

RT64 is enabled by default. The configure step fetches `https://github.com/rt64/rt64.git` and links the `rt64` target. To build the starter window while isolating local dependency problems, use the no-RT64 preset:

```powershell
cmake --preset windows-msvc-no-rt64
cmake --build --preset windows-msvc-no-rt64
```

## Menu and launcher assets

RmlUi assets live in `assets/ui` and `assets/ui/styles`:

- `launcher.rml` for pre-game ROM/profile selection UI.
- `pause_menu.rml` for in-game pause settings.
- `settings.rml` for graphics, input, audio, and save-path settings.
- `styles/main.rcss` for the shared menu look.
- `svg/logo.svg` for LunaSVG-backed vector rendering.

`src/rmlui_manifest.cpp` lists these files so the host can validate them before creating actual RmlUi contexts and render interfaces.

## Adding N64Recomp output

After N64Recomp has emitted host C/C++ sources, add them in `CMakeLists.txt` with either `target_sources({{EXE_NAME}} PRIVATE ...)` or a separate static library linked to `{{EXE_NAME}}`. Runtime glue should connect generated functions to N64ModernRuntime, input, audio, saves, DMA, overlays, and the RT64 renderer.
''',
"scripts/Configure-Windows.ps1": r'''[CmdletBinding()]
param(
    [string]$Preset = "windows-msvc-vcpkg",
    [string]$VcpkgRoot = $env:VCPKG_ROOT
)

$ErrorActionPreference = "Stop"
$RepoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $RepoRoot

if ([string]::IsNullOrWhiteSpace($VcpkgRoot)) {
    $VcpkgRoot = Join-Path $RepoRoot ".deps\vcpkg"
}

if (!(Test-Path $VcpkgRoot)) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $VcpkgRoot) | Out-Null
    git clone https://github.com/microsoft/vcpkg.git $VcpkgRoot
}

$Bootstrap = Join-Path $VcpkgRoot "bootstrap-vcpkg.bat"
if (!(Test-Path (Join-Path $VcpkgRoot "vcpkg.exe"))) {
    & $Bootstrap -disableMetrics
}

$env:VCPKG_ROOT = (Resolve-Path $VcpkgRoot).Path
cmake --preset $Preset
''',
"scripts/Build-Windows.ps1": r'''[CmdletBinding()]
param(
    [string]$Preset = "windows-msvc-vcpkg"
)

$ErrorActionPreference = "Stop"
$RepoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $RepoRoot
cmake --build --preset $Preset
''',
"scripts/Run-Windows.ps1": r'''[CmdletBinding()]
param(
    [string]$Preset = "windows-msvc-vcpkg"
)

$ErrorActionPreference = "Stop"
$RepoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $RepoRoot
$BuildRoot = Join-Path $RepoRoot "build\$Preset"
$Exe = Get-ChildItem -Path $BuildRoot -Filter "{{EXE_NAME}}.exe" -Recurse | Select-Object -First 1
if ($null -eq $Exe) {
    throw "Executable not found under $BuildRoot. Run scripts\Build-Windows.ps1 first."
}
& $Exe.FullName
''',
"src/app_settings.hpp": r'''#pragma once

namespace starter {
inline constexpr const char *project_name = N64_STARTER_PROJECT_NAME;
inline constexpr const char *window_title = N64_STARTER_WINDOW_TITLE;
inline constexpr int default_width = 1280;
inline constexpr int default_height = 720;
}
''',
"src/asset_paths.hpp": r'''#pragma once

#include <filesystem>

namespace starter {
std::filesystem::path executable_directory();
std::filesystem::path asset_directory();
bool required_assets_present();
}
''',
"src/asset_paths.cpp": r'''#include "asset_paths.hpp"

#include <array>
#include <cstdlib>

#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

namespace starter {
std::filesystem::path executable_directory() {
#if defined(_WIN32)
    std::array<wchar_t, 32768> buffer{};
    const DWORD count = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
    if (count > 0 && count < buffer.size()) {
        return std::filesystem::path(buffer.data()).parent_path();
    }
#endif
    return std::filesystem::current_path();
}

std::filesystem::path asset_directory() {
    return executable_directory() / N64_STARTER_ASSET_DIR;
}

bool required_assets_present() {
    const auto root = asset_directory();
    return std::filesystem::exists(root / "ui" / "launcher.rml") &&
           std::filesystem::exists(root / "ui" / "pause_menu.rml") &&
           std::filesystem::exists(root / "ui" / "settings.rml") &&
           std::filesystem::exists(root / "ui" / "styles" / "main.rcss") &&
           std::filesystem::exists(root / "ui" / "svg" / "logo.svg");
}
}
''',
"src/rt64_support.hpp": r'''#pragma once

#include <string_view>

namespace starter::rt64_support {
bool linked();
std::string_view status();
}
''',
"src/rt64_support.cpp": r'''#include "rt64_support.hpp"

namespace starter::rt64_support {
bool linked() {
#if N64_STARTER_HAS_RT64
    return true;
#else
    return false;
#endif
}

std::string_view status() {
#if N64_STARTER_HAS_RT64
    return "RT64 CMake target linked";
#else
    return "RT64 disabled for this build";
#endif
}
}
''',
"src/rmlui_manifest.hpp": r'''#pragma once

#include <span>
#include <string_view>

namespace starter::rmlui_manifest {
std::span<const std::string_view> files();
bool rmlui_enabled();
bool svg_enabled();
}
''',
"src/rmlui_manifest.cpp": r'''#include "rmlui_manifest.hpp"

#include <array>

namespace starter::rmlui_manifest {
namespace {
constexpr std::array<std::string_view, 5> kFiles = {
    "ui/launcher.rml",
    "ui/pause_menu.rml",
    "ui/settings.rml",
    "ui/styles/main.rcss",
    "ui/svg/logo.svg",
};
}

std::span<const std::string_view> files() {
    return kFiles;
}

bool rmlui_enabled() {
#if N64_STARTER_HAS_RMLUI
    return true;
#else
    return false;
#endif
}

bool svg_enabled() {
#if N64_STARTER_HAS_LUNASVG
    return true;
#else
    return false;
#endif
}
}
''',
"src/main.cpp": r'''#include "app_settings.hpp"
#include "asset_paths.hpp"
#include "rt64_support.hpp"
#include "rmlui_manifest.hpp"

#include <SDL.h>

#include <iostream>
#include <string>

namespace {
void print_startup_summary() {
    std::cout << starter::project_name << '\n';
    std::cout << "RT64: " << starter::rt64_support::status() << '\n';
    std::cout << "RmlUi: " << (starter::rmlui_manifest::rmlui_enabled() ? "linked" : "disabled") << '\n';
    std::cout << "LunaSVG: " << (starter::rmlui_manifest::svg_enabled() ? "linked" : "disabled") << '\n';
    std::cout << "Assets: " << (starter::required_assets_present() ? "present" : "missing") << '\n';
}
}

int main(int argc, char **argv) {
    (void)argc;
    (void)argv;

    print_startup_summary();

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) != 0) {
        std::cerr << "SDL_Init failed: " << SDL_GetError() << '\n';
        return 1;
    }

    SDL_Window *window = SDL_CreateWindow(
        starter::window_title,
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        starter::default_width,
        starter::default_height,
        SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
    );

    if (window == nullptr) {
        std::cerr << "SDL_CreateWindow failed: " << SDL_GetError() << '\n';
        SDL_Quit();
        return 1;
    }

    std::string title = std::string(starter::window_title) + " - " + std::string(starter::rt64_support::status());
    SDL_SetWindowTitle(window, title.c_str());

    bool running = true;
    while (running) {
        SDL_Event event{};
        while (SDL_PollEvent(&event) != 0) {
            if (event.type == SDL_QUIT) {
                running = false;
            }
            if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) {
                running = false;
            }
        }
        SDL_Delay(16);
    }

    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
''',
"assets/ui/launcher.rml": r'''<rml>
<head>
    <title>{{PROJECT_NAME}} Launcher</title>
    <link type="text/rcss" href="styles/main.rcss" />
</head>
<body class="screen launcher">
    <div class="panel">
        <svg class="logo" src="svg/logo.svg" width="96" height="96" />
        <h1>{{PROJECT_NAME}}</h1>
        <p class="subtitle">Native recompilation launcher shell</p>
        <div class="button-row">
            <button id="start-game">Start Game</button>
            <button id="open-settings">Settings</button>
            <button id="quit-game">Quit</button>
        </div>
        <p class="hint">Menu documents are loaded from assets/ui and can be bound to host callbacks.</p>
    </div>
</body>
</rml>
''',
"assets/ui/pause_menu.rml": r'''<rml>
<head>
    <title>{{PROJECT_NAME}} Pause</title>
    <link type="text/rcss" href="styles/main.rcss" />
</head>
<body class="screen pause">
    <div class="panel compact">
        <h1>Paused</h1>
        <button id="resume-game">Resume</button>
        <button id="pause-settings">Settings</button>
        <button id="return-launcher">Return to Launcher</button>
    </div>
</body>
</rml>
''',
"assets/ui/settings.rml": r'''<rml>
<head>
    <title>{{PROJECT_NAME}} Settings</title>
    <link type="text/rcss" href="styles/main.rcss" />
</head>
<body class="screen settings">
    <div class="panel wide">
        <h1>Settings</h1>
        <section>
            <h2>Graphics</h2>
            <label><input type="checkbox" id="rt64-widescreen" /> RT64 widescreen enhancements</label>
            <label><input type="checkbox" id="rt64-interpolation" /> RT64 high-frame-rate interpolation</label>
        </section>
        <section>
            <h2>Input</h2>
            <button id="configure-controller">Configure Controller</button>
        </section>
        <section>
            <h2>Storage</h2>
            <button id="open-save-folder">Open Save Folder</button>
        </section>
        <button id="settings-back">Back</button>
    </div>
</body>
</rml>
''',
"assets/ui/styles/main.rcss": r'''body {
    font-family: sans-serif;
    color: #f5f5f5;
    background-color: #12141d;
}

.screen {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.panel {
    width: 720px;
    padding: 36px;
    border-radius: 18px;
    background-color: #202638;
    border: 2px #5e6ea8;
    text-align: center;
}

.panel.compact {
    width: 420px;
}

.panel.wide {
    width: 820px;
    text-align: left;
}

.logo {
    margin-bottom: 12px;
}

.subtitle,
.hint {
    color: #c6cbea;
}

.button-row {
    margin-top: 24px;
    display: block;
}

button {
    min-width: 180px;
    margin: 8px;
    padding: 12px 18px;
    color: #ffffff;
    background-color: #4454a3;
    border-color: #8291e4;
    border-width: 2px;
    border-radius: 8px;
}

button:hover {
    background-color: #596ad0;
}

section {
    margin: 18px 0;
    padding: 12px 0;
    border-top: 1px #3a415f;
}

label {
    display: block;
    margin: 8px 0;
}
''',
"assets/ui/svg/logo.svg": r'''<svg width="128" height="128" viewBox="0 0 128 128" xmlns="http://www.w3.org/2000/svg">
  <rect x="8" y="8" width="112" height="112" rx="24" fill="#202638" stroke="#8291e4" stroke-width="6" />
  <path d="M30 86 L30 42 L50 42 L78 78 L78 42 L98 42 L98 86 L78 86 L50 50 L50 86 Z" fill="#f5f5f5" />
  <circle cx="98" cy="30" r="10" fill="#59d0ff" />
</svg>
''',
"assets/fonts/README.md": r'''# Fonts

RmlUi uses FreeType for font rendering in this starter. Place redistributable `.ttf` or `.otf` files in this directory and load them from the host application before opening RML documents.

Do not commit commercial fonts unless the license allows redistribution.
''',
"docs/runtime-template.md": r'''# Runtime starter notes

This project is generated by `n64recomp-kit new-runtime-project`.

The starter deliberately separates three layers:

1. Host window and process lifetime in `src/main.cpp`.
2. Dependency wiring for RT64, RmlUi, LunaSVG, and FreeType in `CMakeLists.txt` and `cmake/Dependencies.cmake`.
3. Launcher/menu documents under `assets/ui`.

RT64 is linked through its CMake target. The first game-specific renderer integration step is to register the RT64 renderer with the runtime glue that also provides input, audio, PI DMA, saves, overlays, and VI timing.

RmlUi documents are copied beside the executable. The host application should create its RmlUi render interface after the graphics backend is chosen, then bind the button ids from the RML files to game actions.
''',
}
