from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path

from .rom import inspect_rom
from .util import run_command, which


@dataclass
class SplatConfigReport:
    config: str
    rom: str
    basename: str
    code_start: str
    vram: str
    end: str
    paths: dict[str, str]

    def to_dict(self) -> dict:
        return asdict(self)


def find_splat(explicit: str | None = None) -> str | None:
    if explicit:
        path = Path(explicit)
        if path.is_file():
            return str(path)
        resolved = which(explicit)
        if resolved:
            return resolved
        return None
    return which("splat")


def splat_status(splat: str | None = None) -> dict:
    path = find_splat(splat)
    data = {"path": path, "available": path is not None}
    if path:
        result = run_command([path, "--help"], timeout=15)
        text = (result.stdout or result.stderr).splitlines()
        data.update(
            {
                "help_returncode": result.returncode,
                "help_first_line": text[0] if text else "",
            }
        )
    return data


def _yaml_quote(text: str) -> str:
    return json.dumps(text)


def _write_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def create_splat_config(
    config_path: str | Path,
    *,
    rom_path: str | Path,
    basename: str,
    compiler: str = "IDO",
    code_start: int = 0x1000,
    vram: int = 0x80000400,
    end: int | None = None,
    overwrite: bool = False,
) -> SplatConfigReport:
    cfg = Path(config_path)
    if cfg.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite existing config: {cfg}")
    rom = Path(rom_path)
    if not rom.is_file():
        raise FileNotFoundError(f"ROM file not found: {rom}")
    info = inspect_rom(rom)
    if info.byte_order != "z64-big-endian":
        raise ValueError(f"Splat expects a normalized big-endian .z64 ROM; got {info.byte_order}")

    rom_size = rom.stat().st_size
    if end is None:
        end = rom_size
    if code_start < 0x1000:
        raise ValueError("code_start must be at or after 0x1000 for a normal N64 cartridge boot segment")
    if end <= code_start:
        raise ValueError("end offset must be larger than code_start")
    if end > rom_size:
        raise ValueError(f"end offset {hex(end)} is past ROM size {hex(rom_size)}")
    if vram % 4 != 0:
        raise ValueError("vram must be 4-byte aligned")

    base = cfg.parent if cfg.parent != Path("") else Path(".")
    dirs = {
        "asm": base / "asm",
        "src": base / "src",
        "assets": base / "assets",
        "build": base / "build",
        "symbols": base / "symbols",
    }
    for path in dirs.values():
        _write_dir(path)

    cfg.parent.mkdir(parents=True, exist_ok=True)
    relative_rom = Path(os.path.relpath(rom.resolve(), start=cfg.parent.resolve()))
    content = f"""options:
  base_path: {_yaml_quote(str(base))}
  platform: n64
  compiler: {_yaml_quote(compiler)}
  basename: {_yaml_quote(basename)}
  target_path: {_yaml_quote(str(relative_rom))}
  elf_path: {_yaml_quote(str(dirs['build'] / (basename + '.elf')))}
  asm_path: {_yaml_quote(str(dirs['asm']))}
  src_path: {_yaml_quote(str(dirs['src']))}
  build_path: {_yaml_quote(str(dirs['build']))}
  ld_script_path: {_yaml_quote(str(base / (basename + '.ld')))}
  cache_path: {_yaml_quote(str(base / '.splache'))}
  symbol_addrs_path: {_yaml_quote(str(dirs['symbols'] / (basename + '.symbols.txt')))}
  undefined_funcs_auto_path: {_yaml_quote(str(dirs['symbols'] / 'undefined_funcs_auto.txt'))}
  undefined_syms_auto_path: {_yaml_quote(str(dirs['symbols'] / 'undefined_syms_auto.txt'))}
  asset_path: {_yaml_quote(str(dirs['assets']))}
  o_as_suffix: True
  ld_dependencies: True
  create_asm_dependencies: True
  disassemble_all: True
  make_full_disasm_for_code: True
segments:
  - name: header
    type: header
    start: 0x0
  - name: ipl3
    type: bin
    start: 0x40
  - name: boot
    type: code
    start: {hex(code_start)}
    vram: {hex(vram)}
    subsegments:
      - [{hex(code_start)}, asm, boot]
      - [{hex(end)}]
"""
    cfg.write_text(content, encoding="utf-8")
    return SplatConfigReport(
        config=str(cfg),
        rom=str(rom),
        basename=basename,
        code_start=hex(code_start),
        vram=hex(vram),
        end=hex(end),
        paths={name: str(path) for name, path in dirs.items()},
    )


def run_splat_config(
    config_path: str | Path,
    *,
    splat: str | None = None,
    cwd: str | Path | None = None,
    timeout: int | None = None,
) -> dict:
    binary = find_splat(splat)
    if not binary:
        raise FileNotFoundError("splat command not found; install with: python3 -m pip install -U 'splat64[mips]>=0.41.0,<1.0.0'")
    cfg = Path(config_path)
    if not cfg.is_file():
        raise FileNotFoundError(f"Splat config not found: {cfg}")
    result = run_command([binary, str(cfg)], cwd=cwd, timeout=timeout)
    return {
        "ok": result.returncode == 0,
        "command": result.command,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "seconds": result.seconds,
        "config": str(cfg),
    }
