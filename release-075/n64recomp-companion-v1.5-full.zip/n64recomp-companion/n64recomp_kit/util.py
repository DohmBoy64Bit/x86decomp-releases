from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence


@dataclass
class CommandResult:
    command: list[str]
    returncode: int
    stdout: str
    stderr: str
    seconds: float

    def to_dict(self) -> dict:
        return asdict(self)


def which(name: str) -> str | None:
    return shutil.which(name)


def run_command(
    command: Sequence[str],
    *,
    cwd: str | Path | None = None,
    timeout: int | None = None,
    env: Mapping[str, str] | None = None,
) -> CommandResult:
    started = time.perf_counter()
    try:
        proc = subprocess.run(
            list(command),
            cwd=str(cwd) if cwd is not None else None,
            env=dict(env) if env is not None else None,
            text=True,
            errors="replace",
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        return CommandResult(
            command=list(command),
            returncode=proc.returncode,
            stdout=proc.stdout,
            stderr=proc.stderr,
            seconds=round(time.perf_counter() - started, 3),
        )
    except subprocess.TimeoutExpired as exc:
        return CommandResult(
            command=list(command),
            returncode=124,
            stdout=exc.stdout or "",
            stderr=(exc.stderr or "") + f"\nTimed out after {timeout} seconds.",
            seconds=round(time.perf_counter() - started, 3),
        )


def read_bytes(path: str | Path, max_bytes: int | None = None) -> bytes:
    p = Path(path)
    with p.open("rb") as f:
        return f.read() if max_bytes is None else f.read(max_bytes)


def write_json(path: str | Path, data: object) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def print_json(data: object) -> None:
    print(json.dumps(data, indent=2, sort_keys=True))


def parse_int(text: str) -> int:
    try:
        return int(text, 0)
    except ValueError as exc:
        raise ValueError(f"invalid integer {text!r}; use decimal or 0x-prefixed hex") from exc


def quote_command(command: Iterable[str]) -> str:
    return " ".join(shlex.quote(str(part)) for part in command)


def is_executable(path: str | Path) -> bool:
    p = Path(path)
    return p.is_file() and os.access(p, os.X_OK)


def python_version() -> str:
    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
