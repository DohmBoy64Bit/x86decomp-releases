# RT64/RmlUi runtime starter generator

`n64recomp-kit new-runtime-project` emits a Windows-first starter project for the host-runtime side of a native N64Recomp port.

## Generated project contents

- `CMakeLists.txt` and `CMakePresets.json` for a Visual Studio/Ninja/vcpkg workflow.
- `Makefile` that delegates to PowerShell scripts for users who prefer `make configure`, `make build`, and `make run`.
- `vcpkg.json` listing `sdl2`, `rmlui`, `lunasvg`, and `freetype`.
- `cmake/Dependencies.cmake` that finds SDL2/RmlUi/LunaSVG/FreeType from vcpkg and fetches RT64 with CMake FetchContent.
- `src/main.cpp`, which opens a basic resizable SDL2 window and prints dependency status.
- `src/rt64_support.*`, which records whether the RT64 target is linked.
- `src/rmlui_manifest.*`, which records launcher/menu asset paths for future RmlUi context loading.
- `assets/ui/launcher.rml`, `pause_menu.rml`, `settings.rml`, `styles/main.rcss`, and `svg/logo.svg`.

## Command

```powershell
python -m n64recomp_kit new-runtime-project --output .\runtime\MyGame --name "My Game" --overwrite
```

Then build the generated project from an x64 Developer PowerShell:

```powershell
cd .\runtime\MyGame
.\scripts\Configure-Windows.ps1
.\scripts\Build-Windows.ps1
.\scripts\Run-Windows.ps1
```

`Configure-Windows.ps1` uses `VCPKG_ROOT` when set. If it is absent, it clones and bootstraps vcpkg under `.deps\vcpkg` in the generated project.

## Dependency model

RT64 is enabled by default with `N64_STARTER_ENABLE_RT64=ON`. The generated CMake uses `FetchContent` to clone `https://github.com/rt64/rt64.git`, sets `RT64_STATIC=ON`, and links the expected `rt64` target.

RmlUi is enabled by default with `N64_STARTER_ENABLE_RMLUI=ON`. The generated CMake links `RmlUi::RmlUi` and `Freetype::Freetype`.

LunaSVG is enabled by default with `N64_STARTER_ENABLE_SVG=ON`; the generated CMake links `lunasvg::lunasvg`. The RmlUi SVG plugin path remains available to the project through vcpkg dependencies and the generated RML uses an SVG logo asset.

## Scope

The starter window proves that the Windows host project, dependency graph, assets, and project layout are in place. The actual game runtime still needs game-specific work: generated N64Recomp sources, N64ModernRuntime registration, controller callbacks, audio callbacks, PI DMA/ROM access, save backends, overlay metadata, and renderer registration.
