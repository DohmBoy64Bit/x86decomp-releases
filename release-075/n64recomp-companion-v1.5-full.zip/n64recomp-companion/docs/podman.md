# Podman workflow

This repository uses Podman as its container workflow. The image is built from `Containerfile` and contains upstream N64Recomp, Splat, `uv`, and open GNU MIPS tools.

## Windows setup

```powershell
.\scripts\Initialize-PodmanMachine.ps1
.\scripts\Build-PodmanImage.ps1
.\scripts\Enter-PodmanShell.ps1 -WorkDir .
```

Podman on Windows runs Linux containers through a Podman-managed Linux virtual machine. The helper script initializes and starts that machine, then `Enter-PodmanShell.ps1` mounts the current project at `/work`.

## Linux setup

```bash
./scripts/build_podman_image.sh
./scripts/podman_shell.sh "$PWD"
```

## Inside the image

```bash
N64Recomp --help
python3 -m n64recomp_kit doctor --root /work
python3 -m n64recomp_kit toolchain-info
python3 -m n64recomp_kit mips-smoke --prefix mips-linux-gnu-
splat --help
```

## Build arguments

Use a branch, tag, or commit for upstream N64Recomp:

```powershell
.\scripts\Build-PodmanImage.ps1 -N64RecompRef main
```

```bash
./scripts/build_podman_image.sh --ref main
```

Pinning a specific commit is recommended for reproducible project builds.
