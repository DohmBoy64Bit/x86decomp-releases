# Generating the N64 ELF for N64Recomp

N64Recomp consumes an ELF plus metadata, so a practical workflow needs an explicit step that turns Splat output into that ELF. This repository provides that bridge without claiming that a raw ROM can become a finished native PC port automatically.

## Inputs

The ELF builder reads a Splat YAML file and uses these `options` values when present:

- `basename`
- `base_path`
- `asm_path`
- `src_path`
- `build_path`
- `ld_script_path`
- `elf_path`

Paths are resolved from the project root supplied with `--root`. This matches the Windows-first habit of running commands from the project root.

## Build helpers

Create project-local wrappers:

```powershell
python -m n64recomp_kit emit-elf-build --root . --overwrite
```

That writes:

```text
scripts/Build-N64Elf.ps1
tools/n64_build_elf.py
```

## Dry run

Start with a dry run so path and toolchain issues are visible before building:

```powershell
.\scripts\Build-N64Elf.ps1 -Config decomp\splat.yaml -Root . -DryRun -Report build\elf-dry-run.json
```

The report includes every assembler, compiler, and linker command that would run.

## Assembly-only ELF

After Splat has generated assembly and a linker script, build the ELF:

```powershell
.\scripts\Build-N64Elf.ps1 -Config decomp\splat.yaml -Root . -Clean -Report build\elf-build-report.json
```

The same operation is available directly:

```powershell
python -m n64recomp_kit build-elf --config decomp\splat.yaml --root . --profile asm-only --clean --report build\elf-build-report.json
```

The default profile is `asm-only`. It assembles `.s` and `.S` files from Splat's `asm_path`, links them with `ld_script_path`, writes `elf_path`, and inspects the result as an ELF/MIPS file.

## C/C++ profile

Use the GNU C profile only for projects that already have compatible C/C++ sources and flags:

```powershell
python -m n64recomp_kit build-elf --config decomp\splat.yaml --root . --profile gnu-c --cflag -Iinclude --report build\elf-build-report.json
```

The default compiler flags target big-endian MIPS III freestanding code. Real matching decompilation projects often need game-specific include paths, compiler options, ABI constraints, and sometimes older compiler behavior. This toolkit does not ship proprietary IDO binaries.

## Toolchain prefix

The builder auto-discovers known MIPS prefixes and defaults to `mips-linux-gnu-` when producing a dry run. You can pin a prefix:

```powershell
python -m n64recomp_kit build-elf --config decomp\splat.yaml --root . --prefix mips-linux-gnu- --clean
```

Inside the Podman image, GNU MIPS binutils and compilers are already installed.

## N64Recomp handoff

After a successful ELF build:

```powershell
python -m n64recomp_kit elf-info decomp\build\game_us.elf
python -m n64recomp_kit init --config game.recomp.toml --entrypoint 0x80000400 --elf decomp\build\game_us.elf --output-func-path RecompiledFuncs --overwrite
python -m n64recomp_kit check-config game.recomp.toml
```

The ELF still needs correct symbols, section metadata, overlays, and runtime integration for a usable port.
