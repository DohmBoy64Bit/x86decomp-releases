[CmdletBinding()]
param(
  [string]$Image = 'n64recomp-companion:latest',
  [string]$N64RecompRef = 'main'
)

$ErrorActionPreference = 'Stop'
if (-not (Get-Command podman -ErrorAction SilentlyContinue)) {
  throw 'podman was not found on PATH.'
}
podman build --build-arg "N64RECOMP_REF=$N64RecompRef" -t $Image -f Containerfile .
