---
title: x86decomp coff-inspect
description: Exact parser-derived reference for x86decomp coff-inspect in 0.7.5.
---

# `x86decomp coff-inspect`

## `x86decomp coff-inspect`

usage: x86decomp coff-inspect [-h] object

### Usage

```text
x86decomp coff-inspect [-h] object
```

### Arguments

| Argument | Exact parser declaration |
| --- | --- |
| `object` | required · type: `_path`. No help text is declared; parser destination is `object`. |

### Source basis

| Parser owner | Source file and SHA-256 |
| --- | --- |
| `core` | `src/x86decomp/cli.py` · `21e0654ced2f5dd0588adcbedec328613fba524ff1e0a91ef07d63cbbf88288c` |
