# pcrecomp Notes for x86recomp

Source: https://github.com/sp00nznet/pcrecomp

pcrecomp is a strong reference for this project because it targets old PC software rather than console-only binaries. Its README frames the repository as a unified toolbox for taking apart old PC software and rebuilding it for modern systems.

## Useful structure ideas

- `tools/pe/`: PE analysis, imports, exports, sections, hashes, delay imports, protection/DRM detection, recursive binary catalog.
- `tools/ne/`: 16-bit New Executable parsing, disassembly, segment analysis, call graph work.
- `tools/disasm/`: recursive descent disassemblers, x87 FPU decoder, call graph scanners.
- `tools/lift/`: x86-32 and x86-16 to C lifters.
- `tools/classify/`: library/SDK/custom function classification.
- `tools/ghidra/` and `tools/ida/`: optional headless scripts for function bounds, decompilation, xrefs, and analysis exports.
- `runtime/`: runtime support for recompiled code.
- `templates/`: starter project files.
- `docs/`: philosophy and pipeline documentation.

## Useful workflow idea

pcrecomp’s short-form pipeline is directly applicable:

```text
Analyze -> Disassemble -> Classify -> Lift -> Shim -> Build -> Debug -> Ship
```

For x86recomp, this maps to:

1. Analyze PE and installation folder without committing target files.
2. Disassemble selected sections/functions.
3. Classify CRT, compiler helper, engine/library, imported API, and game functions.
4. Lift supported IA-32 instructions to explicit IR/C++.
5. Shim Win32/DirectX/DirectSound/input/filesystem behavior only as reached.
6. Build generated output.
7. Debug unsupported instructions/imports/control flow.
8. Ship only when a target-specific milestone is truly running.

## Warnings for this project

- Do not overfit to pcrecomp’s exact Python-heavy layout if the seed is currently C++20.
- Do not copy pcrecomp’s claims or project statuses into this project.
- Do not reinvent pcrecomp-aligned PE analysis, classification, x86 lifter, shim, or generated-project ideas without first recording why x86recomp needs a different design.
- Do not make a 1:1 copy unless no improvement is needed, licensing permits it, attribution is recorded, and tests cover the adapted behavior.
- Treat DRM/protection analysis as detection and documentation, not bypass assistance.
- Keep Battlefield Vietnam local-only target metadata separate from copyrighted game files.

## Concrete additions inspired by pcrecomp

- Add PE import and delay-import reporting.
- Add function classification files and tests.
- Add optional Ghidra/IDA import formats for function bounds.
- Add a target-safe recursive binary catalog for local install folders.
- Add unsupported opcode histograms.
- Add runtime shim registry keyed by imported DLL/function.
- Add regeneration-safe function patch/hook metadata inspired by N64Recomp and ReXGlue so target corrections do not require hand-editing emitted C/C++.

## 2026-06-26 upstream inspection

Inspected upstream clone:

- Repository: `https://github.com/sp00nznet/pcrecomp`
- Local path: `%TEMP%\x86recomp-pcrecomp-inspect`
- Commit: `b9ac5128852e52eee580115e655bbd7905c5d102`
- Latest visible subject: `readme: add Hellbender to project list; refresh dinopark status`

Files inspected for this comparison:

- `README.md`
- `docs/PHILOSOPHY.md`
- `docs/PIPELINE.md`
- `docs/PROJECTS.md`
- `tools/pe/pe_analyze.py`
- `tools/pe/extract_imports.py`
- `tools/pe/delay_imports.py`
- `tools/pe/catalog.py`
- `tools/pe/analyze_sections.py`
- `tools/disasm/disasm32.py`
- `tools/lift/lift32.py`
- `tools/lift/translator.py`
- `tools/lift/generate.py`
- `tools/classify/classify_functions.py`
- `tools/classify/combined_classify.py`
- `tools/classify/deep_classify.py`
- `tools/classify/resolve_stubs.py`
- `runtime/recomp32/recomp_types.h`
- `runtime/recomp32/main.c`
- `runtime/recomp32/image_loader.h`
- `runtime/recomp32/image_loader.c`
- `runtime/compat/win32_compat.h`
- `templates/CMakeLists.txt.template`
- `tools/__main__.py`

### What pcrecomp already does well

PE reconnaissance is substantially ahead of the current AetherX86 seed. `pe_analyze.py` has a structured `PEInfo` model, section records, import and export records, import DLL summaries, IAT mapping, code/data ranges, timestamps, linker version, subsystem, hashes, overlay size, UPX/packer indicators, JSON export, and a manual parser fallback when `pefile` is absent. `delay_imports.py`, `catalog.py`, and `analyze_sections.py` fill out the Phase 0 surface with delay-load imports, install-tree binary cataloging, entropy, and protection/packer indicators.

The 32-bit disassembler is also useful prior art. `disasm32.py` uses Capstone in 32-bit mode, builds instruction/basic-block/function records, follows direct branches with recursive descent, scans call targets and `55 8B EC` prologues, marks thunks, computes block successors, and reports honest byte coverage by unioning recovered intervals instead of summing overlapping functions.

The lifter contains many battle-tested details that AetherX86 should not rediscover blindly: partial-register helpers for 8/16/32-bit aliases, FS/GS memory handling, flag operand snapshots before destructive writes, condition generation from flag setter to `jcc`/`setcc`/`cmovcc`, string op handling, direct/import/indirect dispatch macros, x87 stack helpers, and visible `UNIMPLEMENTED` output.

The generated-project pattern is worth reusing conceptually: chunked `recomp_*.c`, a generated `recomp_funcs.h`, a generated sorted dispatch table, import stubs, `DO NOT EDIT` generated output conventions, fixed-base build settings, large native stack, and a debug loop centered on dispatch misses, import bridges, ICALL trace, and crash dumps.

The classifier scripts are game-specific, but the method is portable: name matching, string matching, call graph propagation, address clustering, confidence scores, function counts, and byte counts. For Battlefield Vietnam this should become a generic classifier framework plus BFV-specific evidence packs, not a BFV-only classifier baked into universal code.

### What is not drop-in

The current upstream clone has packaging drift around the full 32-bit pipeline:

- `python -m tools --help` fails because `tools/__main__.py` imports `tools.translator`, while the visible translator is `tools/lift/translator.py`.
- `tools/lift/translator.py` imports `.pe_analyze`, `.disasm`, and `.lifter`, but the inspected files live under `tools/pe/pe_analyze.py`, `tools/disasm/disasm32.py`, and `tools/lift/lift32.py`.
- `tools/lift/generate.py` imports `tools.pe_analyze` and `tools.lifter`, which also do not match the inspected tree.
- `runtime/recomp32/main.c` is useful as a debug/runtime reference but is target-shaped, not a universal runtime as-is.
- `runtime/compat/win32_compat.h` is a high-value import taxonomy and shim planning template, but its mappings are SoF-specific and cannot be copied as BFV truth.

This means AetherX86 should reuse pcrecomp concepts and, where licensing/attribution permit, small verified algorithms or schemas. It should not depend on the pcrecomp monorepo CLI as a turnkey pipeline without first fixing or wrapping the package layout.

### Battlefield Vietnam pcrecomp smoke evidence

Ran metadata-only pcrecomp Phase 0 tools on the user-owned local executable:

```text
C:\Program Files (x86)\EA GAMES\Battlefield Vietnam\BfVietnam.exe
```

Safe metadata reported by `tools/pe/pe_analyze.py`:

- Size: 9,688,576 bytes
- Machine: i386
- Format: PE32 EXE
- Image base: `0x00400000`
- Entrypoint: VA `0x007C1BCF`, RVA `0x003C1BCF`
- Linker: `7.10`
- Subsystem: Windows GUI
- Timestamp: `2004-09-23 15:24:37 UTC`
- Sections: 5 (`.text`, `.rdata`, `.data`, `.tls`, `.rsrc`)
- Code range: `0x00401000` to `0x00B41D2B`
- Data range: `0x00B42000` to `0x00E23009`
- Imports: 368 functions from 13 DLLs
- Exports: 15 decorated C++ symbols under `matchmaking@dice`

The imported DLL set matched the AetherX86 seed smoke result and added per-function/IAT detail. `tools/pe/analyze_sections.py` found ordinary-looking section entropy overall and one static signature hit, `AddD`, labelled by pcrecomp as a SecuROM marker. Treat this as a static protection indicator only; do not infer runtime behavior or bypass steps from it.

`tools/pe/delay_imports.py` found no delay imports via `pefile`.

Attempted metadata-only function recovery:

```text
python tools/disasm/disasm32.py BfVietnam.exe --output %TEMP%\bfv-pcrecomp-functions.json --min-size 1
```

This produced no output after roughly three minutes and was stopped. Treat this as evidence that BFV-scale pcrecomp recursive descent needs progress reporting, range limiting, sampling, cached analysis, or a timeout wrapper before it becomes part of the normal AetherX86 verification loop.

### AetherX86 decisions from this comparison

Use pcrecomp to avoid duplicated work in these areas:

- Expand the PE model now, before decoder work, toward `PeInfo`, `PeSection`, `PeImport`, `PeExport`, data-directory, code/data range, hash, timestamp, linker, subsystem, overlay, packer/protection-indicator, and JSON/golden-output support.
- Add delay-import, export-table, IAT map, and install-tree catalog support as explicit future Phase 0 tasks.
- Design decoder/CFG records to be compatible with Capstone truth verification and Ghidra function-bound imports.
- Use pcrecomp's disassembler algorithm as a reference, but keep AetherX86 range-bounded and test-driven from the beginning.
- Keep AetherX86's C++ decoder, IR, lifter, emitter, runtime, target manifest, and patch/hook layers separated. pcrecomp's direct-C lifter is valuable evidence, but a cleaner universal architecture needs stable intermediate contracts.
- Carry forward pcrecomp's flag snapshot, partial-register, segment, x87, import dispatch, ICALL trace, generated-chunk, and dispatch-table lessons when those milestones arrive.
- Build classifier support as generic infrastructure with target evidence packs, not hard-coded BFV rules in universal modules.
- Treat Win32 shim planning as a registry keyed by imported DLL/function/ordinal, with categories similar to KEEP/SHIM/SDL2/STUB/CRT but target-specific evidence and tests.

Current conclusion: pcrecomp can save AetherX86 significant work. The next PE milestone should be expanded with pcrecomp-inspired structure rather than merely printing a few more header fields. The full pcrecomp translator should be treated as prior art and a source of algorithms, not as an immediately reusable engine until its package entrypoints are repaired and BFV-scale runs are bounded.

## 2026-06-27 Phase 6 runtime reuse decision

Phase 6 reused pcrecomp concepts rather than copying implementation:

- Keep generated code behind explicit runtime/import/dispatch boundaries.
- Use visible missing-dispatch diagnostics instead of silent no-ops.
- Treat import shims as registry entries keyed by address/symbol.
- Keep generated code disposable and compile-tested with the runtime support code.

AetherX86 did not copy pcrecomp's `runtime/recomp32/main.c` or `runtime/compat/win32_compat.h` because those files are target-shaped and shim-taxonomy heavy. The seed instead adds a small C++ runtime skeleton that matches the current IR/CFG/emitter boundary and can later grow toward pcrecomp-style import categories, ICALL traces, crash diagnostics, and generated dispatch tables.

## 2026-06-27 Phase 11 import-pointer reuse decision

Phase 11 again reused pcrecomp concepts rather than copying implementation:

- Treat indirect imported calls as explicit ICALL/import-bridge boundaries.
- Keep generated code disposable and metadata-driven.
- Preserve missing shim diagnostics instead of silent no-ops.

AetherX86 adds `PatchKind::IndirectImportShim` and `runtime_import_pointer_shim` in the existing C++ seed instead of copying pcrecomp's C runtime/import bridge because the current milestone needs a small universal fixture before target-shaped Win32 shim categories are safe.

## 2026-06-27 Phase 12 manifest reuse decision

Phase 12 reused pcrecomp's generated-project and metadata-driven shim lessons without copying its Python/C project layout. The manifest format is intentionally small and line-oriented so the C++20 seed can validate synthetic patch/import records without a new dependency or a premature BFV target schema.

## 2026-06-27 Phase 13 ABI shim reuse decision

Phase 13 reused pcrecomp's import-bridge lesson that shim dispatch should be explicit, visible, and metadata-bound. AetherX86 kept the implementation in its C++ runtime registry and generated-code boundary rather than copying pcrecomp's target-shaped runtime. The important reuse is conceptual: ABI and import symbol are part of shim identity, mismatches must be logged, and generated output remains disposable.

## 2026-06-27 Phase 14 catalog reuse decision

Phase 14 reused pcrecomp's classifier ideas at the model level: entries carry source, confidence, kind, symbol, and evidence, and import/IAT facts are separated from normal direct call targets. AetherX86 did not copy pcrecomp's classifier scripts because they are game-specific and Python-heavy; the C++ seed now has a smaller universal catalog that can later ingest Ghidra or target evidence packs.

## 2026-06-27 Phase 15 lifter reuse decision

Phase 15 reused pcrecomp's flag and partial-register cautions conceptually. The implementation keeps AetherX86's C++ IR and generated-code style, but follows the pcrecomp lesson that flag producers and partial registers need explicit handling rather than broad text substitution. This is why `inc`/`dec` preserve CF and `movzx`/`movsx` register sources read masked portions of the owning 32-bit register.

## 2026-06-27 Phase 16 generated-pack reuse decision

Phase 16 reused pcrecomp's generated-project discipline conceptually:

- generated output carries a `DO NOT EDIT` marker and remains disposable;
- packs include debug map metadata for generated function names and original ranges;
- generated code is compile-checked through a scratch CMake project;
- target-derived generated files stay in ignored build artifacts.

AetherX86 did not copy pcrecomp's generated C layout, dispatch table, or runtime project templates. The seed adds a small C++20 `emit_cfg_c_pack` path that matches the existing runtime-bound emitter and can later grow toward chunked generated files and dispatch maps once function metadata is persistent.

## 2026-06-27 Phase 17 lifter reuse decision

Phase 17 reused pcrecomp's lifter lessons conceptually:

- partial-register writes must preserve unaffected bits of the owning 32-bit register;
- flag consumers such as `setcc` and `cmovcc` should reuse condition/flag-read logic;
- `adc`/`sbb` must snapshot incoming carry before producing new flags;
- unsupported forms should remain visible diagnostics.

AetherX86 did not copy pcrecomp's Python lifter. The implementation stays in the C++20 decoder/IR/emitter/runtime boundary and adds targeted tests plus Capstone parity for each supported form.

## 2026-06-27 Phase 18 function-pack manifest reuse decision

Phase 18 reused pcrecomp's generated-project discipline conceptually:

- bind generated inputs to a specific PE identity before emission;
- carry function-entry debug metadata alongside generated packs;
- validate generated candidates before writing disposable source;
- keep target-derived generated files in ignored build artifacts.

AetherX86 did not copy pcrecomp's Python project layout, generated C chunks, dispatch tables, or classifier scripts. The seed adds a small C++20 line-oriented manifest that reuses existing PE inspection and bounded slice analysis, with tests for malformed metadata and mismatch cases.

## 2026-06-27 Phase 19 Ghidra boundary reuse decision

Phase 19 reused pcrecomp's classifier and Ghidra/IDA-export lessons conceptually:

- import external function-boundary evidence as records with source, confidence, symbol/name, and evidence;
- separate classifier metadata from generated-code eligibility;
- require independent decode/slice verification before a boundary can feed codegen;
- keep target-derived evidence in manifests/summaries rather than universal hard-coded rules.

AetherX86 did not copy pcrecomp's classifier scripts or headless-tool wrappers. The seed adds a small C++20 `ghidra_function` boundary format and routes bounded, verifier-backed candidates through the existing function-pack manifest validator.

## 2026-06-27 Phase 20 call-boundary pack reuse decision

Phase 20 reused pcrecomp's generated dispatch/debug-map discipline conceptually:

- generated packs should show original function entries and call relationships;
- missing targets should remain visible diagnostics instead of silent fallthrough;
- generated code can directly dispatch only to functions already present in the verified pack;
- target-derived generated output stays under ignored build artifacts.

AetherX86 did not copy pcrecomp's chunked generated C files or sorted global dispatch table yet. The seed adds only pack-local direct-call dispatch and debug maps in the existing C++20 emitter.

## 2026-06-27 Phase 21 entry import-shim reuse decision

Phase 21 reused pcrecomp's import-bridge and shim-registry lessons conceptually:

- import shims are keyed by stable metadata instead of generated-code edits;
- DLL/function identity, IAT address, callsite address, ABI, and side-effect evidence belong in manifests;
- missing, mismatched, and unsupported shim behavior must remain visible diagnostics;
- generated code should keep calling runtime import-pointer boundaries.

AetherX86 did not copy pcrecomp's Win32 compatibility mappings or target-shaped runtime. The seed adds a small C++20 `entry_import_shim` manifest and a synthetic `GetVersionExA` harness before any real target import behavior is attempted.

## 2026-06-27 Phase 22 import-pointer binding reuse decision

Phase 22 reused pcrecomp's import bridge setup lesson conceptually:

- bind import-pointer callsites by writing target pointers into runtime-owned guest memory;
- register import callbacks through an explicit symbol/ABI boundary;
- surface unsafe memory as diagnostics instead of silently faking import resolution.

AetherX86 keeps this as a small C++ runtime helper, `runtime_bind_import_pointer_shim_abi`, rather than copying pcrecomp's compatibility runtime or Win32 shim tables. Real PE image loading and host import resolution remain future milestones.

## 2026-06-27 Phase 23 runtime-init manifest reuse decision

Phase 23 reused pcrecomp's import bridge and generated-project metadata lessons conceptually:

- bind runtime setup to a specific image identity before execution-like setup;
- keep IAT pointer writes, shim target addresses, ABI, and side-effect evidence in metadata;
- validate mismatches and unsafe memory ranges before calling runtime helpers;
- keep generated target output disposable and under ignored artifacts.

AetherX86 did not copy pcrecomp's compatibility runtime, shim table, or generated project layout. The seed adds a small C++20 `runtime_init_import_pointer` manifest plus a `runtime_apply_import_pointer_init` helper that delegates to the existing import-pointer binding boundary.

## 2026-06-27 Phase 24 PE image-map reuse decision

Phase 24 reused pcrecomp's aligned PE-analysis/runtime-loader lesson conceptually:

- derive image layout from the PE section table rather than generated code;
- keep RVA/VA/raw-size/virtual-size fields explicit;
- validate overlaps, truncation, overflows, and invalid base before memory mutation;
- keep target image bytes out of committed artifacts.

AetherX86 did not copy pcrecomp's PE loader or runtime image loader. The seed adds a small C++ runtime image-map skeleton for synthetic tests plus a PE metadata formatter for BFV-safe layout summaries.

## 2026-06-27 Phase 25 import resolver reuse decision

Phase 25 reused pcrecomp's import bridge and resolver lesson conceptually:

- PE import-table facts should drive IAT identity;
- shim metadata should match PE facts before generated/runtime setup uses it;
- ordinal-only imports and mismatches should stay visible;
- generated fixtures should prove resolver success before runtime dispatch.

AetherX86 did not copy pcrecomp's import resolver or Win32 compatibility shim tables. The seed adds a small C++20 binding summary that links existing PE, entry-import, and runtime-init records.

## 2026-06-27 Phase 26 runtime-start harness reuse decision

Phase 26 reused pcrecomp's generated-project/runtime bring-up discipline conceptually:

- keep startup state in explicit metadata instead of hidden harness constants;
- prepare guest stack/CPU state through runtime-owned helpers;
- preserve visible diagnostics for unsupported ABI or unsafe stack writes;
- keep generated entry fixtures disposable and synthetic before touching BFV execution.

AetherX86 did not copy pcrecomp's runtime startup code or target-shaped process loader. The seed adds a small C++20 `runtime_start` manifest plus `runtime_prepare_start`, limited to controlled `cdecl`/`stdcall` synthetic fixtures and BFV metadata-only notes.

## 2026-06-28 Phase 27 integrated bring-up reuse decision

Phase 27 reused pcrecomp's bring-up/debug-loop discipline conceptually:

- validate PE/import/runtime/start metadata before running generated code;
- keep generated debug maps and unresolved boundaries visible;
- compose image mapping, IAT setup, import dispatch, stack setup, and generated direct calls in a repeatable build artifact;
- keep target readiness reports as metadata until real execution prerequisites are verified.

AetherX86 did not copy pcrecomp's generated C project, dispatch table, image loader, or compatibility runtime. The seed adds one integrated Python CTest fixture around the existing C++20 boundaries so the next phase can decide whether to grow core machinery or target manifests based on evidence.
