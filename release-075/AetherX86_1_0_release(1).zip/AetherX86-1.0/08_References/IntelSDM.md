# Intel SDM

## Classification
- Kind: reference note
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

## Phase 17 ISA notes
- `NOT` performs one's complement and does not affect flags.
- `NEG` subtracts the operand from zero and defines CF/PF/AF/ZF/SF/OF; CF is clear only when the operand is zero.
- `ADC` and `SBB` consume incoming CF and then define CF/PF/AF/ZF/SF/OF from the full add-with-carry or subtract-with-borrow result.
- For one-bit `SHL`/`SHR`/`SAR`, generated code updates CF and result flags for the tested 32-bit forms; OF is handled only for count one.
- For one-bit `ROL`/`ROR`, generated code updates CF/OF for tested 32-bit forms and leaves other tracked flags unchanged.
- `SETcc` and `CMOVcc` consume condition flags and do not modify flags.
