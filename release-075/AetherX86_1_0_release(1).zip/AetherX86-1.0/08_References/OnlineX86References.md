# Online X86 References

## Purpose

Use this file when checking opcode encodings, instruction names, operand forms, flags, and ISA coverage before modifying decoder, lifter, flag, x87, SSE, or opcode-truth files.

## Authority Order

1. Intel SDM and AMD APM remain primary authorities for architectural semantics.
2. `https://ref.x86asm.net/` is a navigation aid for opcode tables and compact x86/x86-64 encoding lookup. Prefer `coder32` pages for IA-32 work and `coder64` pages only when comparing 64-bit behavior.
3. `https://www.felixcloutier.com/x86/` is a convenient per-instruction reference derived from Intel SDM content. Treat it as secondary; its own page warns it is mechanically separated and not perfect.
4. Tool behavior from Ghidra MCP, Capstone, QEMU, Bochs, LLVM, XED, or pcrecomp-style tests can support implementation details only when recorded as evidence. See `ToolTruthVerifiers.md`.

## Fact Rule

Do not implement instruction semantics from a single secondary website. Triple-check with:

- primary manual text or table,
- a second reference such as ref.x86asm.net or Felix Cloutier,
- and a test, emulator comparison, trace, or explicitly documented blocker.

If references disagree, mark the instruction as blocked or hypothesis and record the disagreement in `05_Recompiler/OpcodeTruthDatabase.md` or `01_Memory/UnresolvedFacts.md`.

## Useful Starting Points

- X86 Opcode and Instruction Reference: `https://ref.x86asm.net/`
- IA-32 opcode tables: `https://ref.x86asm.net/coder32.html`
- x86-64 comparison tables: `https://ref.x86asm.net/coder64.html`
- Felix Cloutier x86 index: `https://www.felixcloutier.com/x86/`
- Ghidra MCP: `https://github.com/bethington/ghidra-mcp`
- Capstone: `https://www.capstone-engine.org/`
