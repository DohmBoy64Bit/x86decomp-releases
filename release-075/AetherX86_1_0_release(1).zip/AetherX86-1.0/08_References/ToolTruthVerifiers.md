# Tool Truth Verifiers

## Purpose

Use this file when a decoder, function-boundary, CFG, import, type, or target-behavior claim needs independent tool evidence. These tools are verifiers, not final authorities.

## Ghidra MCP

Use `bethington/ghidra-mcp` as the preferred AI-driven Ghidra bridge when available. It exposes Ghidra analysis through MCP tools for binary analysis, decompilation, cross-references, symbols, types, batch operations, P-code emulation, live debugger integration, and static/dynamic address translation.

Acceptable uses:

- confirm function starts, tails, thunks, xrefs, imports, exports, strings, and data references;
- inspect decompiler output as a hypothesis generator;
- compare P-code/data-flow evidence against the planned IR;
- record static-to-dynamic address translation for runtime trace comparison;
- export evidence into target manifests or verification notes.

Rules:

- Never treat a decompiler guess as source truth.
- Record Ghidra version, loader, image base, analysis options, tool output, and exact address/range.
- Cross-check Ghidra results with Capstone, manual byte decoding, runtime trace, or Intel/AMD docs before modifying decoder/lifter semantics.

Reference: `https://github.com/bethington/ghidra-mcp`

## Capstone

Use Capstone as an independent disassembly oracle for byte-to-instruction decoding. Capstone is a lightweight multi-platform, multi-architecture disassembly framework with X86 16/32/64 support.

Acceptable uses:

- compare instruction length, mnemonic, operands, groups, and implicit registers;
- generate differential decoder fixtures for raw byte sequences;
- detect discrepancies between x86recomp decode output and a mature decoder;
- smoke-test instruction coverage across random or target-derived byte slices.

Rules:

- Capstone verifies decoding, not full architectural semantics.
- Record Capstone version, mode (`16`, `32`, or `64`), syntax, detail flags, input bytes, base VA, and output.
- If Capstone disagrees with Intel/AMD manuals, treat the issue as blocked until explained.

Reference: `https://www.capstone-engine.org/`

## Evidence Status

Tool evidence can support a claim only when paired with:

- primary ISA documentation for semantics,
- local x86recomp test or fixture,
- and a recorded reproduction command or trace.

## Current x86recomp verifier hook

The seed project now includes a Capstone-backed decode verifier:

```text
09_ProjectSeed/x86recomp/tools/capstone_decode_verify.py
```

CTest runs it as `capstone_decode_verify` when a Python interpreter is available. The script imports Python Capstone, uses `CS_ARCH_X86` with `CS_MODE_32`, and compares x86recomp `lift-raw` output against Capstone for the current supported fixture set. It verifies instruction address, mnemonic, and normalized operands for the tested decoder slice only.

Reproduction command from the seed directory:

```bash
python tools/capstone_decode_verify.py build/Debug/x86recomp.exe
```

Current verified environment:

- Capstone Python package: `5.0.7`
- Mode: x86 32-bit
- Fixture count: 59 after Phase 17
- Covered fixture families: starter `mov`/`ret`/`nop`, stack register and immediate `push`/`pop` forms, moffs accumulator moves, ModRM/SIB memory operands, direct `call`/`jmp`/`jcc`, selected group-5 forms, operand-size prefix `0x66` for tested `mov imm16`, 8-bit register moves, arithmetic/logical ModRM forms, `test`, group-1 immediate forms, `C7 /0` move immediate to r/m, `inc`, `dec`, `xchg`, `movzx`, `movsx`, `not`, `neg`, `adc`, `sbb`, selected shifts/rotates, `setcc`, and `cmovcc`.

If Capstone is not installed for the interpreter CTest uses, the verifier exits with skip code `77`. A skipped Capstone test means the C++ seed can still build, but decoder parity claims must not be extended from that run.

## PE slice verifier

The seed project also includes a Capstone-backed PE slice verifier:

```text
09_ProjectSeed/x86recomp/tools/capstone_slice_verify.py
```

CTest runs it as `capstone_slice_verify` when Python is available. In strict test mode, the script creates a synthetic PE32 file, runs `x86recomp analyze-pe-slice`, and verifies the reported instruction count against Capstone 32-bit disassembly for that supported slice.

Reproduction command from the seed directory:

```bash
python tools/capstone_slice_verify.py build/Debug/x86recomp.exe
```

For target-owned local binaries, the same script can compare a bounded PE slice without failing on unsupported coverage:

```bash
python tools/capstone_slice_verify.py build/Debug/x86recomp.exe <pe> <rva> <size>
```

Target-slice mode reports whether x86recomp and Capstone instruction counts match. A mismatch is evidence for a decoder/support blocker, not permission to claim target function recovery.

## Phase 9 Ghidra MCP use

Ghidra MCP was used as function-boundary evidence for Battlefield Vietnam only after Capstone/local decoder checks were already available. The active program was `BfVietnam.exe`; `get_function_count` reported 24,551 functions. `disassemble_function` at VA `0x0048E510` reported a two-instruction function shape, which x86recomp and Capstone then verified as a bounded generated candidate. Ghidra output remains a verifier/hypothesis source, not source truth.

## Phase 10 Ghidra MCP use

Ghidra MCP was used to verify the BFV entrypoint indirect-call blocker after the universal IR/CFG/runtime change was already covered by local tests. `disassemble_bytes` for VA `0x007C1BCF`, length 64, reported 17 instructions and the indirect callsite at VA `0x007C1BEF` as `CALL dword ptr [0x00b42238]`. `audit_globals_in_function` for `entry` named `00B42238` as `PTR_GetVersionExA_00b42238`, type `pointer`, with 7 xrefs. `get_bulk_xrefs` for `00B42238` included a READ from `007C1BEF`. The PE import table independently maps IAT RVA `0x00742238` to `KERNEL32.dll!GetVersionExA`.

Use this only as metadata evidence for a future shim/manifest record. It is not source truth for ABI, side effects, or Battlefield Vietnam runtime behavior.

## Phase 16 Ghidra MCP and Capstone use

Ghidra MCP was retried after earlier parallel calls timed out. `list_instances` reported one connected `BFV` project with open program `BfVietnam.exe` over TCP `127.0.0.1:8089`. Single Ghidra calls then succeeded.

BFV candidate evidence:
- `disassemble_bytes` at VA `0x00401070`, `0x0048E510`, and `0x00874080` reported `MOV dword ptr [ECX], imm32; RET` followed by `INT3` padding.
- `search_instructions` associated the selected starts with `FUN_00401070`, `~IHostService`, and `FUN_00874080`.
- x86recomp `analyze-pe-slice` and `capstone_slice_verify.py` independently verified each seven-byte slice as two instructions, count match true, zero unsupported IR, complete CFG, and generated candidate true.

This is function-boundary and decode-parity evidence for isolated compile-only generated snippets. It is not proof of BFV object state, constructor/destructor correctness, imported API behavior, or executable gameplay.

## Phase 17 Capstone use

Capstone 5.0.7 verified 59 x86 32-bit decode fixtures after adding `not`, `neg`, `adc`, `sbb`, selected shifts/rotates, `setcc`, and `cmovcc`. This verifies byte-to-instruction parity only. Intel/AMD semantics plus local unit/generated tests are the evidence for flag and codegen claims.

## Phase 19 Ghidra MCP and Capstone use

Ghidra MCP remained connected to the `BFV` project with open program `BfVietnam.exe`. Phase 19 used it to verify boundary metadata only:

- `disassemble_bytes` at VA `0x00401070`, `0x0048E510`, and `0x00874080` reported `MOV dword ptr [ECX], imm32; RET` followed by `INT3` padding.
- `disassemble_bytes` at VA `0x007C1BCF` reported the entrypoint instruction stream and kept the entrypoint as unbounded metadata.
- `capstone_slice_verify.py` on the three seven-byte candidate slices reported two x86recomp instructions, two Capstone instructions, count match true, and generated candidate true.
- `capstone_slice_verify.py` on the BFV entrypoint slice at RVA `0x003C1BCF`, size 64, reported 17 x86recomp instructions, 17 Capstone instructions, count match true, and generated candidate false.
- The temporary build-tree `bfv_phase19_ghidra.boundaries` manifest formatted with `ghidra_boundary_issues: 0` and cataloged four `ghidra_function_boundary` entries.

This evidence supports metadata import and bounded candidate validation only. It is not source truth, not a decompiler-truth claim, and not BFV execution behavior.

## Phase 21 Ghidra MCP and PE import use

Ghidra MCP remained connected to the `BFV` project with open program `BfVietnam.exe`. Phase 21 used it only to cross-check entry import-shim metadata:

- `disassemble_bytes` at VA `0x007C1BCF`, length 64, reported 17 instructions and `CALL dword ptr [0x00b42238]` at VA `0x007C1BEF`.
- `x86recomp inspect` independently mapped `KERNEL32.dll!GetVersionExA` to IAT RVA `0x00742238`, which corresponds to VA `0x00B42238` at image base `0x00400000`.
- `x86recomp analyze-pe-slice` for the same entrypoint range reported one indirect call and kept the slice non-generated.

This supports the Phase 21 metadata record only. It is not source truth for Win32 side effects and not BFV runtime behavior evidence.
