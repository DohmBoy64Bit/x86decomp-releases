# Ownership Rules

## Classification
- Kind: architecture contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.
- Maintain strict ownership boundaries:
  - PE loader owns file validation, sections, RVA/file-offset mapping, imports, relocations, image base, and entrypoint facts.
  - Decoder owns bytes, prefixes, ModRM/SIB, immediates, instruction length, operands, and support state.
  - Lifter owns semantics and IR effects for registers, memory, flags, stack, and control flow.
  - CFG/function discovery owns blocks, edges, entrypoints, jump tables, and unresolved indirects.
  - Emitter owns generated C/C++ shape and debug maps.
  - Runtime owns CPU state, memory map, imports, Win32 shims, traps, and host interactions.
  - Target manifests own Battlefield Vietnam-specific facts.
  - Frontend integration owns only agent rule files and must not alter recompiler semantics.
- If a task crosses boundaries, document the handoff or explicitly update the affected contract before editing.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
