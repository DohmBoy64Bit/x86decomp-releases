# Module Contracts

## Filled contract
Contracts: pe -> decode -> analysis/CFG -> IR/lift/flags -> emit -> runtime/imports -> targets. Decoder is target-agnostic. Battlefield-specific work belongs under target manifests/shims.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.

<!-- AETHERX86-1.0:Phase 28 PE image loader completion -->
## Phase 28 PE image loader completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: promote Phase 27 metadata-only PE image planning into a loader-owned image map that can copy headers/sections and apply PE32 base relocations for synthetic and supported PE32 inputs.

Implemented surface:
- `map-pe-image <pe> [mapped_base]` CLI.
- `xr::map_pe_image` and `xr::format_pe_loaded_image` API.
- PE32 section copy into a loader-owned image buffer.
- Relocation directory walking with `IMAGE_REL_BASED_ABSOLUTE` skip and `IMAGE_REL_BASED_HIGHLOW` adjustment.
- Hard diagnostics for unsupported relocation types, malformed relocation blocks, out-of-image relocation targets, and rebased images that lack relocation data.

Verification:
- Synthetic relocation unit test maps a PE at a non-preferred base and verifies a HIGHLOW target is adjusted by the base delta.
- Supplied mock `BfVietnam.exe` maps cleanly at its preferred base and reports a diagnostic when deliberately rebased because its relocation directory is absent.

<!-- AETHERX86-1.0:Phase 29 import IAT application completion -->
## Phase 29 import IAT application completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move import handling from binding summaries into controlled loaded-image IAT writes, while keeping ordinal imports explicit and non-silent.

Implemented surface:
- `apply-pe-imports <pe> <runtime_init_manifest> [mapped_base]` CLI.
- `xr::apply_imports_to_loaded_image` and `xr::format_pe_import_apply_result` API.
- Name-import and delay-import IAT writes sourced from validated runtime-init manifests.
- Duplicate, missing, and malformed manifest validation before image mutation.
- Ordinal-only imports produce explicit diagnostics and do not receive guessed addresses.

Verification:
- Synthetic ordinary import and delay-import IAT writes are checked byte-for-byte in the loaded image.
- Synthetic ordinal import fixture fails with the diagnostic `ordinal import requires explicit non-name policy`.

