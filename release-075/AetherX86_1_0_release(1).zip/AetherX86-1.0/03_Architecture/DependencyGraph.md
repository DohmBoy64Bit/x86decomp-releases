# Dependency Graph

## Classification
- Kind: architecture contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

<!-- AETHERX86-1.0:Phase 30 generated dispatch completion -->
## Phase 30 generated dispatch completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: replace pack-local direct-call emission with a deterministic generated dispatch boundary that can grow into chunked generated functions.

Implemented surface:
- Generated packs now emit `generated_function_record`, `k_generated_functions`, and `generated_dispatch(ctx, rt, target)`.
- Pack-local direct calls route through `generated_dispatch` instead of hardwired direct subroutine calls.
- Runtime direct-call fallback is retained when the target is outside the generated pack.
- `format-generated-dispatch-raw` CLI exposes dispatch metadata for raw fixtures.

Verification:
- Existing direct-call generated-pack tests now assert dispatch-table output and generated dispatch invocation.
- New CLI smoke evidence writes a generated dispatch summary for a tiny raw pack.

