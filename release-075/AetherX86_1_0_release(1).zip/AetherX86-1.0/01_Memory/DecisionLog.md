# Decision Log

## Classification
- Kind: living register
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

## 2026-06-27 Phase 8 stack expansion
- Decision: reduce the BFV entrypoint-slice blocker by adding universal IA-32 stack decode/codegen support for `push r32`, `pop r32`, `push imm32`, and sign-extended `push imm8`, rather than adding BFV-specific target exceptions.
- Evidence basis: BFV safe slice listed `0x56`, `0x68`, and `0x6A` among unsupported opcodes; Intel/AMD ISA rules define push immediate sign-extension behavior; Capstone 5.0.7 verifies the new byte-to-instruction fixtures; local C++ tests and generated-code compile/run checks cover the implementation.
- pcrecomp reuse: follow pcrecomp's visible runtime-bound stack/diagnostic style conceptually, but keep the implementation in the current C++20 decoder, IR, emitter, and runtime boundaries.
- Limit: 16-bit stack forms, memory push/pop, call/return ABI, and BFV runtime behavior are not claimed.

## 2026-06-27 Phase 9 BFV first trace
- Decision: complete Phase 9 by first making the BFV entrypoint slice decode-length-equivalent with Capstone, then selecting a Ghidra-confirmed tiny BFV export slice as the generated-code candidate. Do not attempt to generate the entrypoint slice while it still contains an unsupported indirect call.
- Evidence basis: Ghidra MCP reported active program `BfVietnam.exe`, 24,551 functions, and a two-instruction function at VA `0x0048E510`; Capstone 5.0.7 verified the BFV entrypoint slice and export slice counts; local CTest passed 8/8; local generated-code compile/run for the BFV export slice passed under the ignored build tree.
- pcrecomp reuse: keep pcrecomp's bounded-disassembly, visible unsupported, and runtime-dispatch lessons; do not copy its lifter or runtime. The indirect call should become an explicit metadata/runtime dispatch problem, not a guessed direct call.
- Limit: the BFV entrypoint slice is still not a generated candidate; the export-slice compile is tiny generated-code shape evidence only, not BFV runtime behavior.

## 2026-06-27 Phase 10 indirect-call dispatch preparation
- Decision: preserve indirect `call r/m32` and indirect `jmp r/m32` as explicit IR/CFG/runtime metadata rather than lowering them to unsupported IR or guessing a direct target.
- Evidence basis: Capstone 5.0.7 continues to verify 39 decode fixtures; CTest passes 9/9 including `generated_indirect_call_compile`; BFV entrypoint slice reports zero unsupported IR and one indirect CFG call site; PE import summary maps IAT RVA `0x00742238` to `KERNEL32.dll!GetVersionExA`; Ghidra MCP disassembly/xrefs confirm the entrypoint callsite reads VA `0x00B42238`.
- pcrecomp reuse: reuse pcrecomp's ICALL trace/import-dispatch lesson conceptually by making indirect dispatch visible and metadata-driven, while keeping the implementation in the existing C++ IR/CFG/runtime boundary.
- Limit: no import shim, calling convention, side-effect model, generated dispatch table, or BFV runtime behavior is claimed.

## 2026-06-27 Phase 11 import-shim manifest binding preparation
- Decision: add callsite-keyed `IndirectImportShim` metadata for indirect import-pointer calls instead of baking BFV IAT addresses into decode/lift logic.
- Evidence basis: Phase 10 identified BFV `GetVersionExA` as an indirect import-pointer callsite; CTest passes 10/10 with a synthetic `FF /2` import-pointer fixture; generated output remains disposable and metadata-driven.
- pcrecomp reuse: reuse pcrecomp's import bridge/ICALL trace concept at the boundary level, not its runtime implementation.
- Limit: this is not a persistent manifest parser and not a Win32 shim behavior claim.

## 2026-06-27 Phase 12 persistent manifest schema
- Decision: use a minimal line-oriented `patch key=value...` manifest instead of adding YAML/JSON dependencies or a broad target-manifest language.
- Evidence basis: existing `PatchManifest` already models the needed synthetic patch/import records; CTest passes 11/11 with a tracked `IndirectImportShim` fixture; generated code remains disposable and metadata-driven.
- pcrecomp reuse: preserve pcrecomp's generated-project/import-bridge discipline conceptually, but keep the schema small until target records need richer PE identity and ABI fields.
- Limit: no BFV manifest record, binary hash binding, image-base handling, or Win32 shim behavior is claimed.

## 2026-06-27 Phase 13 ABI-aware import shim boundary
- Decision: make ABI a required import-shim manifest field and pass it through generated runtime calls instead of relying on an implicit import-shim convention.
- Evidence basis: Phase 12 persistent manifests already carry an `abi` field; pcrecomp's import-bridge/shim-registry prior art treats ABI and import dispatch as explicit metadata; local runtime tests prove success and mismatch events; CTest and generated-manifest compile checks pass.
- pcrecomp reuse: reuse pcrecomp's explicit import bridge and visible diagnostic pattern conceptually, not its target-shaped C runtime.
- Limit: the synthetic `GetVersionExA` test proves controlled memory/ABI dispatch only. It is not BFV execution and not a complete Win32 shim.

## 2026-06-27 Phase 14 function catalog and import classification
- Decision: add a bounded, evidence-tagged catalog layer instead of attempting whole-program BFV function recovery or copying pcrecomp classifier scripts.
- Evidence basis: pcrecomp's classifier prior art uses sources, confidence, symbols, and call graph facts; the existing C++ seed already has PE entrypoint/export/import facts and bounded CFG direct/indirect sites; local tests and BFV smoke prove the catalog output shape.
- pcrecomp reuse: reuse the concept of confidence-scored classification and separated import/callsite categories, not pcrecomp's game-specific classifier implementation.
- Limit: no prologue scan, Ghidra import file, whole-program recursive descent, or BFV function-boundary claim is included.

## 2026-06-27 Phase 15 bounded lifter expansion
- Decision: implement a bounded high-value subset (`inc`/`dec`, `xchg`, register-source `movzx`/`movsx`) instead of a broad opcode table.
- Evidence basis: pcrecomp notes emphasize partial-register and flag-snapshot care; Intel/AMD semantics require `inc`/`dec` to preserve CF; Capstone verifies the new byte decode fixtures; CTest and generated compile/run prove the implemented forms.
- pcrecomp reuse: reuse the partial-register and flag-preservation design lessons, not pcrecomp's lifter implementation.
- Limit: `adc`/`sbb`, shifts/rotates, `neg`/`not`, `setcc`, `cmovcc`, and memory-source extension codegen remain for later phases.

## 2026-06-27 Phase 16 generated function pack
- Decision: add a universal multi-function generated C++ pack emitter with debug map comments instead of stitching together single-function generated translation units.
- Evidence basis: the existing single-function emitter already owned literal runtime-bound generated code; pcrecomp generated-project notes recommend generated function maps and buildable bundles; CTest `generated_function_pack_compile` now compiles and runs a three-function synthetic pack.
- BFV evidence: Ghidra MCP lists the active BFV instance and associates the selected tiny candidates with functions (`FUN_00401070`, `~IHostService` at VA `0x0048E510`, and `FUN_00874080`). x86recomp and Capstone 5.0.7 verify each seven-byte slice as two instructions, zero unsupported IR, complete CFG, and generated candidate.
- Limit: the BFV pack is generated, compiled, and run only under ignored build artifacts. No BFV source, raw bytes, executable, assets, menu reach, frame loop, or playability is claimed or committed.

## 2026-06-27 Phase 17 high-value lifter remainder
- Decision: correct the continuation plan by implementing the Phase 17 lifter-remainder milestone before persistent function-pack manifests. Add targeted 32-bit support for `not`, `neg`, `adc`, `sbb`, one-bit `shl`/`shr`/`sar`/`rol`/`ror`, register `setcc`, simple 32-bit `cmovcc`, and partial-register writes, rather than building a broad opcode table.
- Evidence basis: Phase 15 left these families as known gaps; pcrecomp notes warn that partial registers, flag snapshots, condition generation, and visible unsupported output are high-risk lifter areas; Intel/AMD rules define the tested flag behavior; Capstone 5.0.7 verifies 59 decode fixtures; CTest passes 14/14 including a generated Phase 17 compile/run fixture.
- pcrecomp reuse: reuse pcrecomp's lifter lessons conceptually, especially carry snapshots and partial-register helpers. Do not copy pcrecomp's Python lifter.
- Limit: multi-bit or CL-count shifts/rotates, `rcl`/`rcr`/`sal`, memory-destination `setcc`, broad byte/word codegen, x87/SSE, segment overrides, and BFV runtime behavior are not claimed.

## 2026-06-27 Phase 18 persistent function-pack manifest schema
- Decision: add a small line-oriented function-pack manifest instead of broad generated-project machinery. The manifest records PE path, image base, FNV-1a64 file hash, function VA/RVA/size/source/confidence/section/evidence/rollback/enabled, then reuses PE inspection and bounded slice analysis for validation.
- Evidence basis: pcrecomp generated-project notes recommend binding generated output to source-image identity and debug maps; Phase 16 already had disposable generated packs; Phase 18 CTest passes 15/15 including synthetic manifest-generated pack compile/run; BFV metadata-only manifest smoke reports `function_pack_issues: 0` for the three Phase 16 tiny candidates.
- pcrecomp reuse: reuse generated-project discipline conceptually. Do not copy pcrecomp's Python project layout, generated chunks, dispatch table, or classifier scripts.
- Limit: this is not Ghidra boundary import, not a BFV committed target manifest, not a multi-function call-boundary pack, and not BFV execution.

## 2026-06-27 Phase 19 Ghidra function-boundary import
- Decision: add a small `ghidra_function` boundary import format and keep it as verifier/classifier metadata unless a record has bounded size and `verifier=capstone_x86recomp`.
- Evidence basis: pcrecomp notes recommend Ghidra/IDA-derived function-boundary exports as classifier evidence; ToolTruthVerifiers requires Ghidra to be cross-checked; CTest passes 16/16 including synthetic Ghidra-boundary generated-pack compile/run; BFV Ghidra MCP plus Capstone/x86recomp slice checks validate three tiny bounded candidates as metadata.
- pcrecomp reuse: reuse classifier records with source/confidence/evidence and external-tool boundary import concepts. Do not copy pcrecomp classifier scripts or headless wrappers.
- Limit: imported Ghidra boundaries are not source truth, and unbounded records cannot feed codegen.

## 2026-06-27 Phase 20 multi-function call boundary pack
- Decision: add pack-local direct-call dispatch in generated C++ only when the direct-call target is present in the verified generated pack entry set; otherwise keep `runtime_direct_call` diagnostics.
- Evidence basis: pcrecomp generated-project notes recommend dispatch maps and visible misses; CFG already records direct-call targets; CTest passes 17/17 including a synthetic direct-call pack compile/run; BFV bounded tiny pack compiles/runs with no internal direct-call maps.
- pcrecomp reuse: reuse dispatch/debug-map discipline conceptually, not pcrecomp's chunked C output or global dispatch table.
- Limit: no automatic call-graph expansion, broad dispatch table, calling-convention recovery, BFV runtime behavior, or playability claim.

## 2026-06-27 Phase 21 entry import-shim metadata bring-up
- Decision: add a dedicated entry import-shim metadata format and convert valid records into existing `IndirectImportShim` patches instead of hard-coding BFV IAT addresses or Win32 behavior in generated output.
- Evidence basis: pcrecomp import-bridge notes recommend metadata-keyed shims with visible diagnostics; PE inspection maps BFV `KERNEL32.dll!GetVersionExA` to IAT VA `0x00B42238`; Ghidra MCP reports the entrypoint callsite at VA `0x007C1BEF`; CTest passes 18/18 including a synthetic generated-pack `GetVersionExA` pointer-shim harness.
- pcrecomp reuse: reuse import registry and missing/mismatch diagnostic concepts, not pcrecomp's target-shaped Win32 compatibility layer.
- Limit: `version_info_write` is the only accepted side-effect model and is proven only by synthetic controlled-memory tests. No BFV execution, Win32 API completeness, PE image loading, menu/frame reach, or playability is claimed.

## 2026-06-27 Phase 22 import-pointer binding initialization
- Decision: add a runtime-owned helper, `runtime_bind_import_pointer_shim_abi`, for the paired setup operation of writing a shim target into a mapped IAT slot and registering the ABI-aware import callback.
- Evidence basis: Phase 21 already persisted DLL/symbol/IAT/callsite/ABI metadata; pcrecomp import-bridge notes favor explicit import dispatch setup; focused CTest proves the helper writes the IAT slot, dispatches through `runtime_import_pointer_shim_abi`, and fails visibly through `memory_fault` on an unmapped IAT slot.
- pcrecomp reuse: reuse the import bridge initialization concept, not pcrecomp's target-shaped Win32 compatibility runtime.
- Limit: this is not PE image loading, host DLL resolution, caller stack cleanup, real Win32 side effects, BFV execution, menu/frame reach, or playability.

## 2026-06-27 Phase 23 persistent runtime-init manifest
- Decision: add a separate PE-bound runtime-init manifest for import-pointer setup instead of overloading patch manifests or hard-coding BFV IAT setup in generated output.
- Evidence basis: pcrecomp import bridge notes favor explicit image-bound setup records; Phase 22 already provided the runtime-owned IAT write and ABI-aware shim registration helper; unit tests cover malformed/duplicate/missing-evidence/unmapped-IAT/unsupported-side-effect/ABI-missing/image-mismatch cases; CTest passes 19/19 including `generated_runtime_init_manifest_compile`; BFV metadata-only manifest validates local image hash/base and the existing `GetVersionExA` IAT.
- pcrecomp reuse: reuse image-bound import bridge setup concepts, not pcrecomp's Win32 compatibility runtime or shim tables.
- Limit: this is not PE section mapping, host import resolution, real Win32 side effects, stack/ABI execution, BFV execution, menu/frame reach, or playability.

## 2026-06-27 Phase 24 PE image memory-map skeleton
- Decision: add a runtime-owned image map skeleton fed by PE section metadata instead of teaching generated code or manifests to copy image bytes.
- Evidence basis: pcrecomp PE/runtime prior art keeps image layout and RVA/VA mapping explicit; the existing PE loader already owns section metadata; unit tests cover synthetic raw copy, zero-fill, permissions metadata, overlapping sections, truncated raw data, section overflow, invalid base, and unmapped writes; CTest passes 19/19; BFV `format-pe-image-map` reports five sections and zero image-map issues without mapping bytes.
- pcrecomp reuse: reuse PE section-table and visible-loader-diagnostic concepts, not pcrecomp's PE loader implementation.
- Limit: no permission enforcement, relocations, import binding, stack setup, BFV byte mapping, BFV execution, menu/frame reach, or playability is claimed.

## 2026-06-27 Phase 25 PE import binding resolver
- Decision: add a deterministic resolver summary that matches PE import table facts to entry import-shim metadata and runtime-init records instead of duplicating shim targets in entry metadata or executing imports.
- Evidence basis: pcrecomp import bridge prior art keeps IAT identity and shim metadata explicit; unit tests cover success, duplicate import names, ordinal-only imports, missing imports, ABI mismatch, and unsupported side effects; generated `GetVersionExA` fixture requires resolver success; BFV metadata resolves the entrypoint `GetVersionExA` binding and leaves ordinal-only imports visible.
- pcrecomp reuse: reuse import resolver and visible diagnostic concepts, not pcrecomp's compatibility shim tables.
- Limit: no host DLL resolution, ordinal shim policy, real Win32 behavior, BFV import execution, BFV image loading, menu/frame reach, or playability is claimed.

## 2026-06-27 Phase 26 controlled runtime-start harness
- Decision: add a synthetic-only runtime-start manifest and runtime preparation helper instead of treating generated harness constants as target startup state.
- Evidence basis: pcrecomp runtime bring-up notes favor explicit generated-project/runtime boundaries; Phase 24 image-memory work requires stack preparation to preserve pre-mapped image/IAT memory; unit tests cover metadata validation and stack diagnostics; CTest `generated_runtime_start_manifest_compile` proves a generated function can read a prepared stack argument.
- pcrecomp reuse: reuse explicit runtime startup/debug discipline conceptually, not pcrecomp's target-shaped process loader or runtime startup code.
- Limit: only controlled `cdecl`/`stdcall` synthetic entry-call fixtures are supported. No process-entry ABI, PEB/TEB/SEH/TLS state, BFV entrypoint execution, menu/frame reach, or playability is claimed.

## 2026-06-28 Phase 27 integrated synthetic bring-up pack
- Decision: prove the existing PE image-map, runtime-init, import-binding, runtime-start, generated direct-call, and import-pointer shim boundaries together in one synthetic CTest fixture before adding broader target machinery.
- Evidence basis: pcrecomp's bring-up flow emphasizes repeatable generated projects, visible dispatch/import misses, and debug maps; the AetherX86 seed already had each boundary tested separately; CTest `integrated_synthetic_bringup_pack_compile` now validates and runs them together.
- pcrecomp reuse: reuse bring-up/debug-map discipline conceptually, not pcrecomp's generated C chunks, image loader, dispatch table, or compatibility runtime.
- Limit: the integrated pack is synthetic only. BFV readiness is metadata-only and still blocks on image bytes, process-entry state, ordinal imports, real side effects, and generated entrypoint selection.

<!-- AETHERX86-1.0:1.0 release candidate status -->
## 1.0 release candidate status

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

1.0 usable-state means the seed is no longer only a planning skeleton: it has a buildable C++20 CLI/library/test surface, PE inspection, PE image mapping, relocation diagnostics, controlled import IAT application, generated-pack dispatch metadata, expanded IA-32 semantics, and a minimal tested Win32 import shim boundary.

Verified local commands:
- CMake configure/build passed in Release mode.
- `x86tests` passed.
- All 21 CTest tests passed when run in timeout-safe chunks.
- Capstone-backed decode and PE-slice verification tests passed with Capstone 5.0.7 available.
- Mock BFV PE inspection and preferred-base image mapping completed as safe metadata evidence.

Deferred local/user-environment gates:
- Windows/MSVC rebuild and test run.
- Any full target/game execution or playability test.
- Any import application against the mock BFV executable without a complete, explicit runtime-init manifest covering its imports.


<!-- AETHERX86-1.0:mandatory-hash-policy-decision -->
## 2026-07-05 Mandatory post-edit rule refresh and integrity hash scope

- Decision: codify the user's rule that every major code edit requires a fresh `AGENTS.md` re-read before continuing, and widen release hash verification to cover mandatory numbered-folder docs plus release-relevant source/config/test/tool files.
- Evidence basis: user instruction in the 1.0 release session, existing `AGENTS.md` documentation/register rules, existing `doc_hash_check.py` manifest behavior, and the final regenerated hash manifests.
- Scope: this is a workflow/tooling/documentation hardening pass for the already-built 1.0 release candidate. No new recompiler runtime or opcode capability is claimed by this follow-up.
- Limit: hash manifests prove file identity at packaging time; they do not prove semantic correctness without the build/test/evidence gates already recorded for the release.

<!-- AETHERX86-1.0:source-package-tool-build-decision -->
## 2026-07-05 Source package generated-tool-build exclusion

- Decision: remove generated `tools/bfvtool` build outputs from the 1.0 source package and keep `tools-source/bfvtool` as the reproducible source of truth.
- Evidence basis: `AGENTS.md` states generated tool builds belong under ignored `tools/<tool-name>/`; package inspection showed generated Visual Studio/CMake/PDB/library artifacts under `tools/bfvtool`; source files already exist under `tools-source/bfvtool`.
- Scope: packaging hygiene only. No `bfvtool` source behavior, x86recomp runtime behavior, BFV target behavior, or executable support claim changes.
