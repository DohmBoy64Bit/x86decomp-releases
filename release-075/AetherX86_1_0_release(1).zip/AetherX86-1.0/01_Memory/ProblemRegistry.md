# Problem Registry

## Classification
- Kind: living register
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

## 2026-06-27 BFV entrypoint-slice indirect-call blocker
- Status: narrowed blocker.
- Evidence: after Phase 10, `analyze-pe-slice` on local `BfVietnam.exe` RVA `0x003C1BCF`, size 64 reports 17 x86recomp decoded slots, 17 supported, 0 unsupported decode slots, 0 unsupported IR records, 1 indirect CFG call site, `slice_cfg_complete=false`, and `slice_generated_candidate=false`. Capstone 5.0.7 reports 17 instructions for the same bounded slice.
- Resolved part: the `FF /2` call is now explicit `IndirectCall` IR/CFG/runtime metadata instead of unsupported IR.
- Remaining blocker: the BFV callsite is an indirect import pointer to `KERNEL32.dll!GetVersionExA`, but no ABI-checked import-shim/manifest binding or runtime side-effect model exists yet.
- Phase 11 progress: a synthetic import-pointer metadata/shim fixture now exists through `PatchKind::IndirectImportShim`, generated `runtime_import_pointer_shim` emission, runtime dispatch tests, and generated-code compile coverage.
- Phase 12 progress: a minimal persistent manifest parser and tracked synthetic `IndirectImportShim` fixture now exist.
- Phase 13 progress: ABI is now required for direct and indirect import-shim records; generated code preserves that ABI; runtime dispatch logs `import_abi_mismatch`; and a synthetic `GetVersionExA`-shaped callback is verified against controlled runtime stack/memory.
- Phase 14 progress: BFV entrypoint catalog smoke now separates the PE entrypoint, the indirect callsite at VA `0x007C1BEF`, and the `KERNEL32.dll!GetVersionExA` IAT entry at VA `0x00B42238` as safe metadata.
- Phase 15 progress: the universal lifter now supports tested `inc`/`dec`, `xchg`, register-source `movzx`, and register-source `movsx`; BFV entrypoint still remains non-generated because of the indirect CFG call, not because of unsupported IR in that slice.
- Phase 16 progress: a generated function pack now exists for multiple bounded functions, with CTest coverage for a synthetic pack and a BFV compile-only pack under ignored build artifacts using Ghidra-associated tiny function starts.
- Phase 17 progress: the universal lifter/codegen now supports the tested high-value remainder forms (`not`, `neg`, `adc`, `sbb`, one-bit shifts/rotates, register `setcc`, simple `cmovcc`, and partial-register writes). BFV entrypoint still remains non-generated because of import-shim/manifest/runtime boundaries, not because of unsupported IR in that slice.
- Phase 18 progress: a persistent function-pack manifest schema now binds generated-pack candidates to PE path, image base, FNV-1a64 file hash, VA/RVA/size, source/confidence/section/evidence/rollback/enabled metadata, with strict validation for malformed records, duplicates, missing evidence, image/hash mismatch, out-of-section slices, unsupported IR, and non-generated candidates. BFV Phase 16 tiny candidates validate as metadata-only records with `function_pack_issues: 0`.
- Phase 19 progress: Ghidra-derived boundary records now seed the universal catalog and can feed generated packs only when bounded and verifier-backed. BFV temporary Ghidra-boundary metadata validates three tiny candidates plus the entrypoint blocker with `ghidra_boundary_issues: 0`.
- Phase 20 progress: generated packs now call pack-local verified generated callees directly and keep missing direct-call targets as visible `runtime_direct_call` diagnostics. BFV bounded tiny pack compiles/runs under ignored artifacts, but has no internal direct-call relationship claim.
- Phase 21 progress: a dedicated `entry_import_shim` manifest now records DLL/symbol, IAT VA/RVA, callsite VA/RVA, ABI, side-effect evidence, rollback, and enabled metadata. The BFV entrypoint `GetVersionExA` record validates as safe metadata under ignored build artifacts, and a synthetic generated-pack harness proves controlled `version_info_write` dispatch without BFV execution.
- Phase 22 progress: runtime setup for an import-pointer shim now has `runtime_bind_import_pointer_shim_abi`, which writes a mapped IAT slot and registers the ABI-aware shim callback as one tested boundary. The synthetic generated-pack harness uses this helper; unmapped IAT setup fails with `memory_fault`.
- Phase 23 progress: a PE-bound runtime-init manifest now records image path/base/hash, IAT VA/RVA, shim target VA, DLL/symbol, ABI, side-effect model, evidence, rollback, and enabled metadata. A synthetic generated-pack harness validates the manifest and applies `runtime_apply_import_pointer_init`; BFV `GetVersionExA` runtime-init metadata validates with `runtime_init_issues: 0`.
- Phase 24 progress: runtime image mapping now has a synthetic-first section skeleton with raw copy, zero-fill, range metadata, and diagnostics for overlaps/truncation/overflow/invalid base. BFV image layout formats as metadata only with five sections and `pe_image_map_issues: 0`.
- Phase 25 progress: PE import facts, entry import-shim metadata, and runtime-init metadata now resolve into deterministic import binding summaries. BFV `GetVersionExA` resolves as metadata, while unrelated ordinal-only imports remain visible diagnostics.
- Phase 26 progress: a controlled synthetic runtime-start manifest and stack/ABI harness now prepares CPU state, initial ESP, and 32-bit argument writes for generated entry-call fixtures. BFV has only a disabled metadata note for the entry VA and remains unexecuted.
- Phase 27 progress: the synthetic bring-up path now composes PE image mapping, runtime-init IAT setup, import binding, runtime-start stack setup, generated pack-local direct calls, and a controlled `GetVersionExA` import-pointer callback in one CTest fixture. BFV readiness is recorded as metadata only.
- Remaining blocker: no BFV committed target manifest, no target-safe BFV image loader that maps BFV bytes, no ordinal import policy, no automatic call-graph expansion, no broad generated dispatch table, no real Win32 side-effect model beyond synthetic `version_info_write`, no process-entry ABI/process-state model, no entrypoint generated BFV pack, or executable runtime behavior.
- Next verification step: plan the next five phases from the Phase 27 baseline, likely target-safe image-loading policy, ordinal import/shim taxonomy, process-entry state modeling, broader generated-pack dispatch, and BFV metadata manifests.
