# Audit Checklist

## Classification
- Kind: verification contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

<!-- AETHERX86-1.0:mandatory-integrity-scope -->
## Mandatory numbered-folder and integrity-hash audit

For every major code edit or release-relevant tool edit, the audit must confirm:

- `AGENTS.md` was re-read after the edit before continuing verification or further implementation.
- Affected living records in `00_Governance/` through `09_ProjectSeed/` were updated during the same session.
- The integrity manifest includes relevant root docs/rules, mandatory numbered-folder docs, seed source, tests, CMake/config files, release tools, target manifests, and evidence text.
- Build trees, VCS metadata, generated binaries, and self-referential hash manifests are excluded from integrity hashes.
- The final report names any deferred local gates instead of converting them into unsupported claims.
