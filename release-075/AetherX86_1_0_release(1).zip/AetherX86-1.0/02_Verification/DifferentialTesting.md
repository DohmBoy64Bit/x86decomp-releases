# Differential Testing

## Filled contract
Compare original x86 behavior against lifted/emitted behavior at instruction, block, function, import-boundary, and target-trace levels. Compare registers, flags, touched memory, control flow, and exceptions.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.
