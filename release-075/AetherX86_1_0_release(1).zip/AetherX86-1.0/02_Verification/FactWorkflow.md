# Fact Workflow

## Classification
- Kind: verification contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.
- Triple-check each implementation fact before code or docs rely on it:
  1. project source, target manifest, or local documentation;
  2. authoritative manual, official docs, or verified web reference;
  3. test, emulator comparison, runtime trace, binary evidence, or direct user confirmation.
- If an edit cannot pass the triple check, do not silently proceed. Mark the work as hypothesis/blocker or ask for evidence.
- Prefer Intel SDM/AMD APM for instruction semantics, with ref.x86asm.net and Felix Cloutier as secondary navigation aids.
- Use Ghidra MCP and Capstone as independent truth verifiers: Ghidra MCP for function boundaries, xrefs, imports, types, P-code, and static/dynamic address evidence; Capstone for byte-to-instruction decode comparison. Neither replaces primary ISA documentation or local tests.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the real-game pressure test and ultimate acceptance case, while x86recomp remains the general-purpose project being built.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
