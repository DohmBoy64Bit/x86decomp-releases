---
name: x86recomp
description: x86/IA-32 static recompilation workflow for old Win32 PC games and PE binaries. Use when working on x86recomp, PE inspection, IA-32 decoding, ModRM/SIB decoding, flags, x87/SSE planning, IR/lifting, CFG/function discovery, generated C/C++ emitters, function patching/hooks, runtime/import shims, target manifests, game-format reverse engineering that supports static recompilation, BFV bfvtool archive/asset/script evidence, pcrecomp-style pipelines or x86 lifter reuse, Battlefield Vietnam as the ultimate static-recomp test case, Ghidra MCP/Capstone truth verification, or frontend-specific agent rule files. Do not use for OpenBFVietnam asset-engine work unless the task is specifically about static recompilation of the Win32 executable.
---

# x86recomp Static Recompiler Skill

## Purpose

Turn this preserved planning tree plus the compiling C++ seed into an actively maintained x86 static recompilation project. The work is dual-purpose: build x86recomp as a general IA-32/Win32 static recompilation toolkit, and continuously exercise its features on Battlefield Vietnam. The ultimate acceptance test is statically recompiling enough of Battlefield Vietnam to prove the recompiler, runtime, and target metadata pipeline under real-game pressure.

Preserve engineering honesty: produce real files, real build commands, real tests, visible unsupported cases, and no claims that a game has been recompiled until generated output actually builds and runs through a verified milestone.

Reference families to apply:

- N64Recomp: metadata-assisted function splitting, literal translation, runtime helpers, and function patch/hook concepts after a compiling baseline.
- xboxrecomp: x86 lifting risks such as variable-length decoding, partial registers, flags, x87, stack discipline, imports, and runtime shims.
- XenonRecomp: explicit converter/runtime boundary, missing-instruction traps, CPU-state objects, and metadata for indirect branches.
- ReXGlue: SDK-style patch registries, runtime hook boundaries, generated-code stability, and target metadata that avoids hand-editing generated output.
- pcrecomp: PE/NE analysis, disassembly, classification, x86 lifting, shims, templates, assets, Ghidra/IDA helpers, and the pipeline `Analyze -> Disassemble -> Classify -> Lift -> Shim -> Build -> Debug -> Ship`. Reuse or adapt pcrecomp ideas when they align; do not reinvent an equivalent x86 lifter path unless x86recomp can make a verified improvement.

## Non-Negotiable Rules

- Leave each modifying session with one of these outcomes: builds and passes tests; intentionally fails with a documented blocker and exact reproduction command; or research-only docs under `08_References/`, `01_Memory/`, or `07_ProjectManagement/` with citations and no code claims.
- Every numbered phase or milestone must be goal-driven. Before starting the phase, create or confirm an explicit Codex goal that names the outcome, verification commands, evidence requirements, scope limits, and blocker stop condition; close the goal only after the implementation, verification, and living docs are complete.
- Keep `09_ProjectSeed/x86recomp` compiling unless the task is explicitly research-only.
- Never leave filler-only files.
- Never write `future-task marker` without owner, reason, and next verification step.
- Do not claim instruction, calling convention, PE feature, runtime API, or Battlefield Vietnam behavior is supported unless a test or target trace proves it.
- Mark unsupported instructions, imports, APIs, and target facts as visible blockers.
- Keep universal recompiler logic separate from `targets/bfvietnam` facts.
- Do not hand-edit generated decomp/recomp output as a normal workflow. Express corrections as function patch metadata, runtime hooks, import shims, lifter fixes, or target manifests so regeneration is repeatable.
- Prefer proven prior art over reinvention. If pcrecomp's x86 lifter, PE analysis, classification, or shim design aligns with x86recomp, pull the concept or implementation pattern with attribution and improve it where useful; only mirror it closely when no better local design is justified and licensing permits.
- Triple-check every implementation claim before editing: source documentation, local code/tests, and either official/web reference, runtime trace, binary evidence, or direct user confirmation. If any leg is missing, label the claim as hypothesis or ask.
- Read local docs first, search current web/docs for unstable third-party or ISA facts, and ask the user rather than assuming when evidence is missing.
- Give every code or doc edit a purpose, evidence basis, and verification plan in the work log or final report.
- Document every change, update, modification, tool use, discovery, decision, assumption, blocker, and verification result in the appropriate living register during the same work session. Do this as soon as the fact is stable, before final response, commit, handoff, or context switch.
- After each major code edit, re-read `AGENTS.md`/active frontend rules before continuing, and update the affected mandatory numbered project records under `00_Governance/` through `09_ProjectSeed/`.
- Use a zero-hallucination loop breaker: after three failed attempts at the same blocker, stop, document exact evidence and reproduction, and request new input or a different strategy.
- Reject fillers, scope creep, and drift: if a proposed edit does not advance the current milestone or documented blocker, stop and record it as out of scope or ask for approval.
- Keep strict separation of concerns between PE/decode/lift/emit/runtime/target/frontend-rule work; do not silently expand ownership.
- Do not commit Battlefield Vietnam binaries, assets, CD contents, cracks, serials, DRM bypass payloads, copied proprietary code, or extracted copyrighted files.

## Repository Layout

```text
SKILL.md                         Authoritative skill entrypoint.
skill/SKILL.md                   Compatibility copy; keep identical to root SKILL.md.
README.md                        Human package overview.
CLASSIFICATION.md                Preserved-tree classification.
BUILD_TEST_RESULT.txt            Last known seed build/test transcript.
FILLER_SCAN.txt             Filler scan result.
00_Governance/                   Scope, anti-hallucination, coding, review, DoD.
01_Memory/                       Decisions, assumptions, problems, session history.
02_Verification/                 Evidence, confidence, regression, differential rules.
03_Architecture/                 Module contracts, interfaces, ownership, performance.
04_Workflows/                    Session, task, refactor, review, release workflows.
05_Recompiler/                   PE loader, decoder, IR, lifter, CFG, runtime, target plan.
06_Testing/                      Unit, golden, fuzz, differential, performance, CI.
07_ProjectManagement/            Requirements, milestones, backlog, traceability.
08_References/                   Intel/AMD/QEMU/LLVM/McSema/RetDec/revng/pcrecomp notes.
09_ProjectSeed/x86recomp/        Buildable C++20 seed project.
```

When asked where the skill is, answer `SKILL.md` at the archive root. Mention the compatibility copy at `skill/SKILL.md`.

In the broader x86recomp workspace, optional tool sources live under `tools-source/<tool-name>/` and build outputs under `tools/<tool-name>/`. `bfvtool` is the Battlefield Vietnam archive/asset/script inspection tool when those files exist.

## Startup Protocol

For code-changing work:

1. Read this `SKILL.md`.
2. Read the active frontend/repo rules such as `AGENTS.md` when present.
3. Read `README.md`.
4. Read `BUILD_TEST_RESULT.txt` and decide whether it is stale.
5. Inspect `09_ProjectSeed/x86recomp/CMakeLists.txt`.
6. For every numbered phase or milestone, create or confirm a Codex goal before implementation.
7. Build the seed before code edits unless the task is documentation-only.
8. Read only the relevant contract or workflow file from the routing table below.
9. Make the smallest coherent milestone advance.
10. Rebuild and run tests.
11. After each major code edit, re-read `AGENTS.md`/active frontend rules and confirm the edit still follows repository requirements.
12. Update all relevant living records under `00_Governance/` through `09_ProjectSeed/`, including documentation and release-integrity hash manifests when behavior, evidence, tests, workflow, architecture, or target facts changed.

Seed commands:

```bash
cd 09_ProjectSeed/x86recomp
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

For clean artifact verification:

```bash
cmake -S 09_ProjectSeed/x86recomp -B /tmp/x86recomp-build
cmake --build /tmp/x86recomp-build
ctest --test-dir /tmp/x86recomp-build --output-on-failure
```

## Context Routing

Load only the files needed for the current task.

| Task | Read |
| --- | --- |
| Scope, claims, completion | `00_Governance/ScopeControl.md`, `00_Governance/DefinitionOfDone.md`, `00_Governance/AntiHallucination.md` |
| Coding style or naming | `00_Governance/CodingStandard.md`, `00_Governance/NamingConvention.md` |
| Session, refactor, review, release | `04_Workflows/SessionStart.md`, `04_Workflows/TaskLifecycle.md`, `04_Workflows/DocumentationWorkflow.md`, `04_Workflows/RefactorWorkflow.md`, `04_Workflows/CodeReviewChecklist.md`, `04_Workflows/ReleaseWorkflow.md`, `04_Workflows/SessionEnd.md` |
| Frontend agent rules | `04_Workflows/AgentFrontendIntegration.md` |
| Evidence or confidence | `02_Verification/TruthLevels.md`, `02_Verification/FactWorkflow.md`, `02_Verification/ConfidencePolicy.md`, `02_Verification/DifferentialTesting.md` |
| PE work | `05_Recompiler/PELoader.md`, `05_Recompiler/Imports.md` |
| Decode/lift/semantics | `05_Recompiler/Decoder.md`, `05_Recompiler/Lifter.md`, `05_Recompiler/Flags.md`, `05_Recompiler/OpcodeTruthDatabase.md` |
| CFG/function discovery | `05_Recompiler/CFGDesign.md`, `05_Recompiler/FunctionDiscovery.md`, `05_Recompiler/SwitchRecovery.md`, `05_Recompiler/StackRecovery.md` |
| IR/codegen/runtime | `05_Recompiler/IRDesign.md`, `05_Recompiler/Codegen.md`, `05_Recompiler/Runtime.md`, `05_Recompiler/CallingConventions.md` |
| Function patching/hooks | `05_Recompiler/FunctionPatching.md`, `05_Recompiler/Codegen.md`, `05_Recompiler/Runtime.md`, `08_References/PCRecompNotes.md` |
| x87/SSE/SSA/types | `05_Recompiler/x87Plan.md`, `05_Recompiler/SSEPlan.md`, `05_Recompiler/SSAPlan.md`, `05_Recompiler/MemorySSA.md`, `05_Recompiler/TypePropagation.md` |
| Ghidra/Capstone verification | `08_References/ToolTruthVerifiers.md`, `08_References/OnlineX86References.md` |
| Game-format RE for static recomp | `05_Recompiler/GameFormatReverseEngineering.md` |
| BFV archive/asset/script evidence | `05_Recompiler/BFVToolWorkflow.md`, `05_Recompiler/GameFormatReverseEngineering.md`, `05_Recompiler/BattlefieldVietnamPlan.md` |
| Battlefield Vietnam target | `05_Recompiler/BattlefieldVietnamPlan.md`, `09_ProjectSeed/x86recomp/targets/bfvietnam/manifest.template.yml` |
| Testing strategy | `06_Testing/UnitTests.md`, `06_Testing/GoldenOutputs.md`, `06_Testing/RegressionSuite.md`, `06_Testing/DifferentialFuzzing.md`, `06_Testing/CoverageRequirements.md` |
| Planning/status | `01_Memory/DecisionLog.md`, `01_Memory/AssumptionRegistry.md`, `01_Memory/ProblemRegistry.md`, `07_ProjectManagement/Milestones.md`, `07_ProjectManagement/TraceabilityMatrix.md` |
| External references | Relevant file under `08_References/`, especially `IntelSDM.md`, `AMDAPM.md`, `OnlineX86References.md`, `ToolTruthVerifiers.md`, `QEMUNotes.md`, `PCRecompNotes.md`, `LLVMNotes.md`, `McSemaNotes.md`, `RetDecNotes.md`, `RevngNotes.md` |

## Development Philosophy

Build from a narrow vertical slice:

```text
raw bytes or PE section
  -> decode instructions
  -> construct structured instruction records
  -> lift to explicit IR or C-like operations
  -> emit C/C++
  -> compile generated output
  -> run unit/golden/differential tests
```

Metadata is allowed and expected. Store target metadata in manifests, not hidden lifter constants. Valid metadata may include image base, sections, entrypoint RVA, known function starts, imports, compiler/library signatures, jump tables, function pointers, globals, patches/hooks, function replacements, and runtime shim mappings.

Generated C/C++ should be boring and literal. Prefer explicit helpers such as `add32`, `write32`, `unsupported_instruction`, and labels that preserve original addresses. Pretty decompilation is a later concern.

Generated output must be disposable. If a target function needs correction, replacement, logging, or host integration, add a patch/hook record keyed by VA/RVA/symbol/import and regenerate rather than editing emitted C/C++ by hand.

## Milestones

1. Package sanity: root `SKILL.md`, `skill/SKILL.md`, compiling seed, passing CTest, no filler-only files.
2. PE inspection: DOS/PE validation, COFF machine, section count, optional header, image base, entrypoint RVA, section table, import directory detection, malformed/truncated tests.
3. Decoder foundation: instruction byte ranges, prefixes, ModRM/SIB, displacements/immediates, direct branch targets, explicit unsupported records.
4. IA-32 semantics subset: `mov`, `lea`, `push`, `pop`, `xchg`, `movzx`, `movsx`, arithmetic/logical ops, `call`, `ret`, `jmp`, `jcc`, stack-frame idioms, and CF/PF/AF/ZF/SF/OF behavior.
5. CFG/function discovery: recursive descent, block splitting, direct calls/jumps, returns, import thunks, unknown indirect branches, manifest-supplied starts.
6. C/C++ emitter: generated translation units, labels, CPU state, memory helpers, unsupported traps, golden output tests.
7. Patch/hook metadata: function replacement records, before/after hooks, import shim bindings, regeneration-safe emitted code tests.
8. Runtime skeleton: CPU state, memory map, stack helpers, import dispatcher, Win32 shim boundary, logging and traps.
9. Battlefield Vietnam first trace: local/user-owned PE metadata, import list, decoded function sample, unsupported opcode histogram, generated code for a small verified function, no playability claim.

## Module Contracts

- PE loader input: user-owned executable path. Output validated PE metadata, section table, RVA/file-offset mapping, imports, relocations if present, entrypoint RVA, and image base. Fail visibly on non-MZ, invalid PE, unsupported machine, truncation, malformed directories, or packing/protection suspicion.
- Decoder input: bytes, virtual address, and `x86_32` mode. Output structured instruction with address, length, raw bytes, prefixes, opcode, operands, flags read/written, branch target if direct, and support state. Fail visibly on invalid encodings, unsupported prefixes/opcodes, or section overrun.
- Lifter input: structured instruction and function context. Output literal IR for registers, memory, flags, and control flow. Fail visibly when operand kind, flag behavior, addressing form, x87/SSE, or segment behavior is unsupported.
- CFG builder input: decoded stream plus entrypoints. Output blocks, edges, calls, returns, unresolved indirects, and possible jump tables. Flag branches outside code, overlapping instructions, and inconsistent boundaries.
- Emitter input: lifted IR. Output buildable C/C++ with runtime headers/macros, unsupported traps, and debug maps. Fail visibly on missing emission rules, type/width ambiguity, or unsupported control flow.
- Patch manager input: target manifest records keyed by VA/RVA/symbol/import plus hook kind and evidence. Output generated dispatcher bindings, replacement calls, before/after hooks, or shim mappings without modifying generated function bodies by hand. Fail visibly on ambiguous addresses, missing evidence, ABI mismatch, or unsafe state access.
- Runtime input: generated code calls and initial process/game state. Output CPU state behavior, memory access, import shims, patch/hook dispatch, filesystem/time/thread/input/graphics/audio boundaries. Fail visibly on unimplemented imports or unsafe memory access.

## Testing Requirements

- Use unit tests for byte parsing, PE parsing, ModRM/SIB, register widths, flags, immediates/displacements, and emitter fragments.
- Use golden tests for byte sequence to decoded instruction list, generated C/C++ text, and manifest/import summaries.
- Use differential tests for instruction semantics against native assembly, QEMU/Bochs, Intel/AMD manual examples, or hand-checked flag cases.
- Add a regression test before closing any fixed bug.
- Keep Battlefield Vietnam tests local-data safe: no committed executable, archives, assets, or extracted proprietary samples.

## Code Style

- Use C++20 and CMake 3.20+.
- Avoid heavyweight dependencies until a clear need exists.
- Keep functions small and testable.
- Bounds-check all binary reads.
- Use explicit address names or types: `rva`, `va`, `file_offset`.
- Never mix RVA, VA, and file offsets without conversion helpers.
- Preserve flags, width, partial-register behavior, and original addresses in generated code.
- Separate implemented-and-tested, implemented-but-not-fully-tested, designed-only, hypothesis, and blocked claims.

## Request Handling

- If asked to improve the project: make a narrow change, preserve the tree, preserve the compiling seed, run tests, and report exact changes.
- If asked to use a new reference repo: inspect the reference, extract engineering lessons, add notes under `08_References/`, and update `SKILL.md` only if operating procedure changes.
- If asked about pcrecomp: compare its x86 lifter, PE analyzer, classifier, shim registry, and generated project structure against x86recomp goals. Reuse concepts or patterns that fit, improve them where x86recomp has a clearer design, and avoid a 1:1 copy unless evidence shows no improvement is needed and licensing/attribution are handled.
- If asked about patches or hooks: model them like N64Recomp/ReXGlue-style metadata and runtime dispatch so generated code remains disposable and reproducible.
- If asked for Battlefield Vietnam progress: do not ask for copyrighted files unless needed for local analysis; explain what can be done without the binary; track target blockers in `05_Recompiler/BattlefieldVietnamPlan.md`.
- If asked about game formats: reverse engineer only the formats needed to explain executable behavior, target metadata, imports, assets referenced by code, or runtime shims. Keep this subordinate to static recompilation, and do not drift into a separate clean-room engine unless explicitly requested.
- If BFV archive, asset, `.con`, `.tweak`, mesh, material, terrain, vegetation, lightmap, sound, shader, or dependency evidence is relevant to static recompilation, build and use `bfvtool` from the workspace root: `cmake -S tools-source/bfvtool -B tools/bfvtool`, then `cmake --build tools/bfvtool --config Debug`. Use `tools/bfvtool/Debug/bfvtool.exe` on Visual Studio builds, or the configured single-config output elsewhere. Commit only summaries/manifests, never game data.
- If asked for universal support: translate it into staged PE support, decoder coverage, instruction semantics, ABI/calling convention support, runtime shim coverage, and repeated target bring-up.
- If asked to generate agent/frontend rules: detect Codex, Claude Code, Cursor, OpenCode, and related frontends from existing files/config; verify current docs for exact filenames; ask the user when multiple targets are plausible; generate only the rule files for the selected frontend.

## Current Seed Capabilities

The seed under `09_ProjectSeed/x86recomp` currently supports:

- parse hex bytes,
- decode a tiny IA-32 subset: `nop`, `ret`, `push ebp`, `pop ebp`, `mov ebp, esp`, `mov r32, imm32`,
- mark unsupported bytes explicitly,
- emit text lift output,
- emit simple C-like output,
- inspect minimal PE headers,
- run a CTest unit test.

The next expansion should be structured operand types and ModRM/SIB decoding, not a large fake instruction table.

## Immediate Next Tasks

1. Replace string operands with structured operand types.
2. Add ModRM decoding tests.
3. Add SIB decoding tests.
4. Add direct `call rel32`, `jmp rel32`, and short/near `jcc` decoding.
5. Add flag helpers for `add`, `sub`, `cmp`, and `test`.
6. Expand PE inspection to list sections and imports.
7. Add a target-safe Battlefield Vietnam analysis report template.
8. Add generated-code compile tests.
9. Add unsupported opcode histogram generation.
10. Add a minimal runtime header for generated C/C++.
11. Add a regeneration-safe function patch/hook manifest and tests.

## Status Report Format

Finish work sessions with:

```text
Changed:
- ...

Documented:
- file: ...
- purpose/evidence/why: ...

Verified:
- command: ...
- result: ...

Skill location:
- SKILL.md
- skill/SKILL.md

Seed project:
- 09_ProjectSeed/x86recomp

Known limits:
- ...
```

## Definition of Done

The package is acceptable only when:

- root `SKILL.md` exists and validates,
- `skill/SKILL.md` exists and matches root `SKILL.md`,
- preserved tree still exists,
- C++ seed configures, builds, and passes CTest,
- no filler-only files remain,
- README points users to the skill and seed,
- pcrecomp reference notes are included,
- final answer reports verification and any limits.
