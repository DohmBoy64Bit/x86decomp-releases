# Documentation Workflow

## Classification
- Kind: workflow
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.
- Treat documentation as part of the change, not cleanup after the change. Update the appropriate living register as soon as a fact becomes stable enough to rely on.
- Document every code edit, doc edit, tool use, discovery, reverse-engineering observation, target fact, assumption, blocker, decision, and verification result before the final response or handoff.
- Record purpose, evidence, why the change was made, exact files touched, commands run, result, confidence level, and remaining uncertainty.
- Use the closest owner file:
  - `01_Memory/DecisionLog.md` for decisions and tradeoffs.
  - `01_Memory/AssumptionRegistry.md` for assumptions and hypotheses.
  - `01_Memory/ProblemRegistry.md` for blockers, repeated failures, and circuit-breaker stops.
  - `01_Memory/SessionHistory.md` for session summaries.
  - `02_Verification/EvidenceTemplate.md` or task-specific verification docs for evidence.
  - `05_Recompiler/OpcodeTruthDatabase.md` for instruction/opcode facts.
  - `05_Recompiler/BattlefieldVietnamPlan.md` for target progress.
  - `07_ProjectManagement/TraceabilityMatrix.md` for milestone-to-evidence links.
- If no owner file exists, create the smallest appropriate entry in `01_Memory/UnresolvedFacts.md` rather than inventing unsupported conclusions.
- Never defer documentation because the change is "small"; small unrecorded facts become stale assumptions.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
- A session is not complete until docs reflect the current state or explicitly say why no persistent update was needed.

<!-- AETHERX86-1.0:numbered-doc-sync -->
## Numbered-folder synchronization and hash workflow

After any major code edit, re-read `AGENTS.md` before continuing. Then update the closest affected living records in the mandatory numbered folders:

- `00_Governance/` for scope, review, definition-of-done, anti-hallucination, and coding-rule changes.
- `01_Memory/` for decisions, assumptions, discoveries, blockers, and session history.
- `02_Verification/` for evidence, confidence, audit, regression, and hash-scope changes.
- `03_Architecture/` for ownership, module, interface, and data-flow changes.
- `04_Workflows/` for process and release-workflow changes.
- `05_Recompiler/` for PE/decode/lift/emit/runtime/target facts.
- `06_Testing/` for test strategy, fixtures, regression scope, CI, and golden evidence.
- `07_ProjectManagement/` for milestone, requirements, release criteria, and traceability updates.
- `08_References/` for source-of-truth notes and external verifier guidance.
- `09_ProjectSeed/` for buildable seed docs, release evidence, source, tests, and tools.

Regenerate the release integrity hash manifest after documentation synchronization so the final package can be checked for drift.
