# Session End

## Classification
- Kind: workflow
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.
- Before ending, audit the session for undocumented changes, discoveries, tool outputs, assumptions, blockers, and verification results.
- Update the relevant living register before final response. If no persistent update is warranted, state why in the final report.
- Confirm no filler-only files, silent unverified future-task markers, or stale "works" claims were introduced.
- Confirm scope stayed within the current milestone. If scope expanded, document user approval or mark the expansion as blocked/out of scope.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
- Final status must include Changed, Documented, Verified, Known limits, and any circuit-breaker or out-of-scope notes.

<!-- AETHERX86-1.0:rule-refresh-end -->
## End-of-session integrity closeout

Before final handoff, confirm the session record includes whether a major code edit occurred, whether `AGENTS.md` was re-read afterward, which mandatory numbered-folder records changed, the final hash-manifest command, and any deferred gates. Release handoff is incomplete until this closeout is reflected in `01_Memory/SessionHistory.md`, `02_Verification/` evidence, and `07_ProjectManagement/TraceabilityMatrix.md` when relevant.
