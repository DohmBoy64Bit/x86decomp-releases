# Agent Frontend Integration

## Purpose

Use this workflow when generating or updating project instruction files for coding-agent frontends such as Codex, OpenCode, Claude Code, Cursor, Continue, Roo/Kilo Code, Antigravity, VS Code extensions, or similar tools.

## Detection

1. Inspect the repository for existing frontend files before creating anything:
   - Codex/OpenCode/shared agents: `AGENTS.md`.
   - Claude Code: `CLAUDE.md`, `.claude/`, `.claude/rules/`.
   - Cursor: `.cursor/rules/`, `.cursorrules`, `.mdc` files.
   - OpenCode: `AGENTS.md`, `opencode.json`, `.opencode/`, command/agent config.
2. Check installed tool markers only when local filesystem evidence is insufficient.
3. Search current official docs before writing frontend-specific filenames or config because these conventions can change.
4. If exactly one frontend is proven, generate only that frontend's rule file.
5. If multiple frontends are present or none are proven, ask the user which frontend(s) to target.

## Generation Rules

- Keep one canonical project policy where possible, then reference or mirror it into frontend-specific files.
- Do not invent frontend capabilities. If docs are unclear, write a generic `AGENTS.md` and ask before adding specialized config.
- Keep rules strict, concise, and testable: build/test commands, evidence policy, code ownership, legal constraints, and status-report format.
- Never include secrets, proprietary Battlefield Vietnam data, local install paths, or user-specific machine details in committed rule files.
- Preserve existing user-written frontend rules unless the user asks for replacement.

## Required Policy Content

Every generated frontend rule file must include:

- triple fact-checking before implementation claims,
- zero-hallucination and loop/circuit-breaker rules,
- strict separation of PE/decode/lift/emit/runtime/target/frontend-rule concerns,
- requirement to read local docs, search current docs/web for unstable facts, and ask rather than assume,
- requirement that every code/doc edit state purpose, evidence, and verification.
