# Task Lifecycle

## Classification
- Kind: workflow
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.
- Before editing, state the edit purpose, the evidence being used, and how the change will be verified.
- Read the relevant local docs and module contracts before drawing conclusions. Search current official docs/web for unstable external facts. Ask the user when evidence is missing or conflicting.
- During debugging, stop after three repeats of the same failure without new evidence. Preserve the failing command/output and switch to evidence gathering.
- In final status, list what changed, why it changed, what evidence supported it, what verification ran, and what remains uncertain.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
