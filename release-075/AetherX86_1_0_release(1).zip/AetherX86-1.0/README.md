# x86recomp v5 preserved-tree skill package

## Start here

The authoritative AI skill entrypoint is:

```text
SKILL.md
```

A duplicate compatibility copy is also provided at:

```text
skill/SKILL.md
```

The compiling seed project is preserved at:

```text
09_ProjectSeed/x86recomp
```

Build/test command:

```bash
cmake -S 09_ProjectSeed/x86recomp -B /tmp/x86recomp-build
cmake --build /tmp/x86recomp-build
ctest --test-dir /tmp/x86recomp-build --output-on-failure
```

This package preserves the original 101-file planning tree, adds a real detailed skill entrypoint, adds pcrecomp reference notes, and keeps the seed project buildable.

---

# Autonomous Static Recompiler Skill v4 — preserved tree

This rebuild keeps every original v3 file path and replaces the empty filler text with usable contracts. It also adds a buildable C++20 seed project under `09_ProjectSeed/x86recomp`.

Goal: create a universal IA-32/Windows static recompiler, with Battlefield Vietnam as the first acceptance target. The core must remain universal; target-specific facts live in manifests/shims.

Build seed:
```bash
cd 09_ProjectSeed/x86recomp
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

Current verified seed status: Phase 27 adds an integrated synthetic bring-up pack that combines PE image-memory mapping, runtime-init import-pointer setup, PE import binding resolution, controlled stack preparation, generated direct-call dispatch, and a `GetVersionExA`-shaped import-pointer callback in one compile/run fixture. The current local suite is 21 CTest tests. BFV remains safe metadata evidence only, with no committed BFV bytes/generated source, no BFV image mapping/execution, and no runtime or playability claim.

<!-- AETHERX86-1.0:1.0 release candidate status -->
## 1.0 release candidate status

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

1.0 usable-state means the seed is no longer only a planning skeleton: it has a buildable C++20 CLI/library/test surface, PE inspection, PE image mapping, relocation diagnostics, controlled import IAT application, generated-pack dispatch metadata, expanded IA-32 semantics, and a minimal tested Win32 import shim boundary.

Verified local commands:
- CMake configure/build passed in Release mode.
- `x86tests` passed.
- All 21 CTest tests passed when run in timeout-safe chunks.
- Capstone-backed decode and PE-slice verification tests passed with Capstone 5.0.7 available.
- Mock BFV PE inspection and preferred-base image mapping completed as safe metadata evidence.

Deferred local/user-environment gates:
- Windows/MSVC rebuild and test run.
- Any full target/game execution or playability test.
- Any import application against the mock BFV executable without a complete, explicit runtime-init manifest covering its imports.

