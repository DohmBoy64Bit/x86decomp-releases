# Regression Suite

## Classification
- Kind: testing contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Current regression coverage
Phase 4 adds `generated_cfg_compile` to CTest. This protects the first generated C++ path against syntax regressions, missing helper definitions, invalid labels, and broken CMake scratch-build assumptions.

Phase 5 adds `generated_cfg_patched_compile` to CTest. This protects the patch-aware generated C++ path against syntax regressions in replacement, hook, skip-original, and import-shim call boundaries. The `x86tests` binary also now rejects invalid patch manifests before emission.

Phase 6 links generated-code scratch builds against `runtime.cpp`. The regular generated CFG fixture is also executed after compilation and must exit without runtime events. `x86tests` now covers runtime memory, stack, direct-call, import-shim, patch/hook, trap, and event-format behavior.

Phase 7 adds `capstone_slice_verify` to CTest. This creates a synthetic PE, runs `analyze-pe-slice`, and checks the instruction count against Capstone for a supported bounded slice. `x86tests` also covers successful PE slice mapping and rejection when a requested slice exceeds raw section data.

Phase 8 adds `generated_stack_compile` to CTest. This protects generated `push imm32; pop eax; ret` output against syntax regressions and runtime stack-helper regressions by compiling and executing the generated program. The Capstone decode verifier now covers 33 fixtures, including stack register and immediate push/pop encodings.

Phase 9 adds `generated_moffs_compile` and `generated_mov_imm_rm_compile` to CTest. These protect moffs memory moves, `C7 /0`, and generated memory address expressions. The Capstone decode verifier now covers 39 fixtures, including moffs, group-11 move immediate, and selected group-5 forms.

Phase 10 adds `generated_indirect_call_compile` to CTest. This protects the generated C++ shape for `FF /2` indirect calls through the runtime dispatch boundary. The `x86tests` binary also covers explicit indirect-call/indirect-jump IR, CFG site lists, runtime unresolved-event logging, and PE slice summary fields that keep indirect sites from being mistaken for complete CFG recovery.

Phase 11 adds `generated_indirect_import_shim_compile` to CTest. This protects the patch-aware generated C++ path for a synthetic indirect import-pointer fixture. `x86tests` also covers `PatchKind::IndirectImportShim` validation, generated output, `runtime_import_pointer_shim` callback dispatch, and missing-shim event metadata.

Phase 12 adds `generated_manifest_indirect_import_compile` to CTest. This protects the persistent manifest path by loading a tracked synthetic fixture, generating C++ through `emit-cfg-c-manifest-raw`, and compiling it with `runtime.cpp`.

Phase 13 keeps the same CTest surface but strengthens `x86tests` and generated-output checks: import-shim records without ABI now fail validation; runtime ABI mismatches log `import_abi_mismatch`; and a synthetic `GetVersionExA`-shaped shim writes deterministic data through controlled runtime memory. `generated_manifest_indirect_import_compile` now compile-checks `_abi` import-pointer emission from the parsed fixture.

Phase 14 keeps the CTest count unchanged and extends `x86tests` with catalog regression checks over the synthetic PE fixture and a bounded CFG+manifest fixture. These protect import classification from collapsing IAT entries, indirect callsites, and direct call targets into one category.

Phase 15 adds CTest `generated_phase15_lifter_compile`, bringing the suite to 12 tests. The Capstone decode verifier now covers 46 fixtures, including `inc`, `dec`, `xchg`, `movzx`, and `movsx` forms. `x86tests` covers CF-preserving `inc`/`dec` helper behavior and generated-output strings.

Phase 16 adds CTest `generated_function_pack_compile`, bringing the suite to 13 tests. It invokes `emit-cfg-c-pack-raw` for three synthetic bounded functions, checks required debug map strings in the generated translation unit, compiles it with `runtime.cpp`, and runs the generated executable. `x86tests` also covers pack debug map strings, generated call sequencing, patch-boundary preservation, and duplicate entry rejection.

Phase 17 adds CTest `generated_phase17_lifter_compile`, bringing the suite to 14 tests. It compiles and runs a generated fixture covering the tested 32-bit high-value remainder forms. The Capstone decode verifier now covers 59 fixtures, including `not`, `neg`, `adc`, `sbb`, selected shifts/rotates, `setcc`, and `cmovcc`.

Phase 18 adds CTest `generated_function_pack_manifest_compile`, bringing the suite to 15 tests. The Python helper creates a synthetic PE and `.functionpack` manifest in the build tree, validates the manifest through `format-function-pack-manifest`, emits generated C++ through `emit-cfg-c-pack-manifest`, checks required debug map strings, compiles the generated pack with `runtime.cpp`, and runs it. `x86tests` also covers malformed and mismatch validation cases for the manifest parser.

Phase 19 adds CTest `generated_function_pack_ghidra_compile`, bringing the suite to 16 tests. The Python helper creates a synthetic PE and Ghidra-boundary manifest in the build tree, validates the boundary import, checks catalog seeding, emits generated C++ through `emit-cfg-c-pack-ghidra`, checks required debug map strings, compiles the generated pack with `runtime.cpp`, and runs it.

Phase 20 adds CTest `generated_function_pack_direct_call_compile`, bringing the suite to 17 tests. It emits a three-function synthetic pack where the first function directly calls a verified generated callee, checks the resolved direct-call debug map, compiles with `runtime.cpp`, and runs without unresolved runtime events.

Phase 21 adds CTest `generated_entry_import_shim_pack_compile`, bringing the suite to 18 tests. The CMake helper writes a synthetic `entry_import_shim` manifest, emits a generated pack for `call dword ptr [iat]`, checks DLL/IAT/side-effect/debug metadata, compiles a harness that registers `KERNEL32.dll!GetVersionExA` as controlled metadata, and runs it against mapped guest memory.

Phase 22 keeps the suite at 18 tests and strengthens `x86tests` plus `generated_entry_import_shim_pack_compile`: import-pointer setup now flows through `runtime_bind_import_pointer_shim_abi`, and the unit suite covers both successful IAT binding and an unmapped-IAT `memory_fault`.

Phase 23 adds CTest `generated_runtime_init_manifest_compile`, bringing the suite to 19 tests. The Python helper creates a synthetic PE and `.runtimeinit` manifest in the build tree, validates the manifest through `format-runtime-init`, emits a disposable `GetVersionExA` indirect-import generated pack, compiles a harness with `runtime.cpp`, applies `runtime_apply_import_pointer_init`, and runs the generated function against controlled memory.

Phase 24 keeps the suite at 19 tests and strengthens `x86tests`: synthetic PE section metadata now drives `runtime_map_image`, with regression checks for raw copy, zero-fill, mapped range summaries, overlapping sections, truncated raw data, section overflow, invalid image base, and unmapped writes.

Phase 25 keeps the suite at 19 tests and strengthens `x86tests` plus `generated_runtime_init_manifest_compile`: the generated `GetVersionExA` fixture now uses a synthetic PE import table and must pass `format-import-bindings` before generated compile/run.

Phase 26 adds CTest `generated_runtime_start_manifest_compile`, bringing the suite to 20 tests. The Python helper writes a synthetic `.runtime_start` manifest, validates it through `format-runtime-start`, emits a generated pack for `mov eax, [esp + 4]; ret`, compiles a harness with `runtime.cpp`, prepares stack/CPU state through `runtime_prepare_start`, runs the generated function, and verifies the prepared argument reaches `EAX`. `x86tests` also protects pre-mapped image memory from being erased by stack preparation.

Phase 27 adds CTest `integrated_synthetic_bringup_pack_compile`, bringing the suite to 21 tests. The Python helper creates a synthetic PE, validates image-map/runtime-init/import-binding/runtime-start metadata, emits a two-function generated pack with one direct generated call and one indirect `GetVersionExA` import-pointer call, writes a stable debug map, compiles a scratch harness, maps synthetic image memory, applies runtime init, prepares stack state, runs generated code, and verifies the controlled callback writes version data.

Keep this test small and deterministic. Broader generated-output tests should add new fixtures only when the decoder, IR, CFG, or emitter support expands with evidence.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

<!-- AETHERX86-1.0:1.0 release candidate status -->
## 1.0 release candidate status

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

1.0 usable-state means the seed is no longer only a planning skeleton: it has a buildable C++20 CLI/library/test surface, PE inspection, PE image mapping, relocation diagnostics, controlled import IAT application, generated-pack dispatch metadata, expanded IA-32 semantics, and a minimal tested Win32 import shim boundary.

Verified local commands:
- CMake configure/build passed in Release mode.
- `x86tests` passed.
- All 21 CTest tests passed when run in timeout-safe chunks.
- Capstone-backed decode and PE-slice verification tests passed with Capstone 5.0.7 available.
- Mock BFV PE inspection and preferred-base image mapping completed as safe metadata evidence.

Deferred local/user-environment gates:
- Windows/MSVC rebuild and test run.
- Any full target/game execution or playability test.
- Any import application against the mock BFV executable without a complete, explicit runtime-init manifest covering its imports.

