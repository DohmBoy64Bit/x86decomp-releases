# Unit Tests

## Classification
- Kind: testing contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

## Phase 17 unit coverage
- Decode/IR tests cover `not`, `neg`, `adc`, `sbb`, one-bit `shl`/`shr`/`sar`/`rol`/`ror`, `sete`, `cmovne`, multi-bit immediate shift decode, CL-count shift decode, truncated `setcc`, and unsupported group-2 diagnostics.
- Flag-helper tests cover `flags_adc` carry/overflow cases and `flags_sbb` borrow/overflow cases.
- Generated-output tests cover carry/borrow runtime helpers, partial-register `setcc`, simple `cmovcc`, one-bit arithmetic shift emission, and visible unsupported output for an unverified count.

## Phase 21 unit coverage
- Entry import-shim tests cover valid metadata with DLL/symbol/IAT/callsite/ABI/side-effect/evidence/rollback fields, malformed record kinds, missing side-effect evidence, unsupported side-effect models, duplicate records, conversion to `IndirectImportShim`, and generated-output preservation of `KERNEL32.dll!GetVersionExA`.
- Runtime tests cover the visible `unsupported_side_effect` diagnostic in addition to existing missing-shim, ABI-mismatch, and memory-fault diagnostics.

## Phase 22 unit coverage
- Runtime tests cover `runtime_bind_import_pointer_shim_abi` writing a mapped IAT slot, registering the ABI-aware shim callback, dispatching through `runtime_import_pointer_shim_abi`, and failing visibly with `memory_fault` when the IAT slot is unmapped.

## Phase 23 unit coverage
- Runtime-init manifest tests cover valid PE-bound image/hash metadata, IAT VA/RVA plus shim-target fields, malformed record kinds and unknown fields, duplicate records, missing evidence, unsupported side-effect models, missing ABI, unmapped-IAT validation, image-base mismatch, and file-hash mismatch.
- Runtime tests cover `runtime_apply_import_pointer_init` applying a valid setup record shape through the existing import-pointer binding helper and failing visibly with `memory_fault` on unmapped IAT memory.

## Phase 24 unit coverage
- PE/runtime image-map tests cover `format_pe_image_map_summary`, runtime image mapping from parsed synthetic PE sections, raw section copying, zero-fill after raw bytes, readable/writable/executable metadata, mapped read/write checks, unmapped write `memory_fault`, overlapping section rejection, truncated raw data rejection, section overflow rejection, and invalid image-base rejection.

## Phase 25 unit coverage
- Import binding tests cover successful PE import plus entry-import plus runtime-init matching, deterministic formatter output, duplicate PE import name diagnostics, ordinal-only import diagnostics, missing import diagnostics, ABI mismatch diagnostics, and unsupported side-effect diagnostics.

## Phase 26 unit coverage
- Runtime-start manifest tests cover valid entry/stack/ESP/ABI/evidence/rollback metadata, deterministic formatter output, unsupported ABI diagnostics, stack argument overflow diagnostics, and unaligned argument diagnostics.
- Runtime tests cover `runtime_prepare_start` stack mapping, initial `ESP` setup, 32-bit argument writes, and preservation of pre-mapped image/IAT memory when the requested stack range fits inside the existing runtime memory map.

## Phase 27 integration coverage
- Phase 27 adds no new core unit-test assertions; it adds a CTest integration fixture that composes existing PE image-map, runtime-init, import-binding, runtime-start, generated direct-call, and import-pointer shim boundaries in one generated compile/run path.
