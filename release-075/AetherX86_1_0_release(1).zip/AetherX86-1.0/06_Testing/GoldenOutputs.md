# Golden Outputs

## Classification
- Kind: testing contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Current generated-output checks
Phase 4 adds a generated-code compile check. CTest runs `generated_cfg_compile`, which invokes `x86recomp emit-cfg-c-raw` on a fixed bounded byte fixture, writes the generated translation unit to the build tree, configures a scratch CMake project, and compiles it.

Unit tests also assert stable generated-output strings for the current fixture: generated-file marker, function name, original-VA labels, conditional branch `goto`, flag-helper use, and return emission.

Phase 5 adds patch-aware generated-output checks. Unit tests assert stable replacement, before-hook, after-hook, skip-original, and import-shim call boundaries. CTest runs `generated_cfg_patched_compile`, which invokes `x86recomp emit-cfg-c-patched-raw` on a fixed direct-call fixture and compiles the generated translation unit.

Phase 6 changes the generated-output shape to include `runtime.hpp` and runtime-context parameters. Golden assertions now protect runtime-owned calls such as `xr::runtime_set_sub_flags`, `xr::runtime_patch_replace`, `xr::runtime_import_shim`, and `xr::runtime_direct_call`.

Phase 7 adds safe PE slice summary output. Unit tests assert stable fields such as `slice_rva`, `slice_va`, `slice_file_offset`, `slice_section`, instruction support counts, CFG completeness, and `slice_generated_candidate`.

Phase 8 adds golden assertions for runtime-bound stack emission: generated C++ initializes `ctx.esp`, calls `xr::runtime_push32`, calls `xr::runtime_pop32`, and writes popped values back to a CPU register.

Phase 9 adds golden assertions for generated memory address expressions and 32-bit memory moves: `A1/A3` moffs loads/stores and `C7 /0` move-immediate-to-memory emit `runtime_read_mem32`/`runtime_write_mem32` with base/index/displacement-aware address expressions.

Phase 10 adds golden assertions for indirect control-flow output. Unit tests assert `ir.indirect_call`, `indirect_call` CFG edges, `slice_cfg_indirect_calls`, and generated `xr::runtime_indirect_call` / `xr::runtime_indirect_jump` calls. CTest `generated_indirect_call_compile` compile-checks a generated indirect-call fixture without running it, because the unresolved runtime event is expected until a target binding exists.

Phase 11 adds golden assertions for patch-aware indirect import-shim output. Unit tests assert that an `IndirectImportShim` record emits a local `target`, calls `xr::runtime_import_pointer_shim`, and falls back to `xr::runtime_indirect_call`. CTest `generated_indirect_import_shim_compile` compile-checks this synthetic generated output.

Phase 12 adds golden assertions for parsed patch manifests. Unit tests assert parsed `IndirectImportShim` records, manifest summary text, malformed manifest failures, and generated output from parsed metadata. CTest `generated_manifest_indirect_import_compile` compile-checks generated C++ from the tracked manifest fixture.

Phase 13 updates the import-shim golden strings to ABI-aware runtime calls. Unit tests now assert `runtime_import_shim_abi`, `runtime_import_pointer_shim_abi`, and the `stdcall` ABI string in generated output from synthetic patch records and the tracked manifest fixture.

Phase 14 adds golden assertions for function catalog formatting. Unit tests assert entrypoint, export, ordinary import IAT, delay-import IAT, bounded CFG entry, direct call target, indirect callsite, and manifest import-pointer classifications.

Phase 15 adds golden assertions for generated `inc`/`dec` CF preservation, `xchg eax, ebx`, `movzx eax, bl`, and `movsx eax, bx`. CTest `generated_phase15_lifter_compile` compiles and runs the generated fixture.

Phase 16 adds golden assertions for generated function-pack output. Unit tests assert `debug_function_pack_count`, per-function `debug_function_map` lines, generated function call sequencing from `main`, patch-boundary preservation inside a pack, and duplicate-entry rejection. CTest `generated_function_pack_compile` also checks the scratch-generated pack for three required debug map entries before compiling and running it.

Phase 17 adds golden assertions for generated `adc`/`sbb` carry helpers, one-bit arithmetic shift output, partial-register `setcc` writes, simple `cmovcc`, and visible unsupported output for an unverified multi-bit shift count. CTest `generated_phase17_lifter_compile` compiles and runs the generated fixture.

Phase 18 adds golden assertions for function-pack manifest summaries and validation diagnostics. Unit tests assert `function_pack_issues: 0` for a valid synthetic PE manifest, stable function summary fields, unsupported record-kind rejection, duplicate-function diagnostics, missing-evidence diagnostics, image-base/hash mismatch diagnostics, out-of-section diagnostics, unsupported/non-generated candidate diagnostics, and generated pack output through `emit_cfg_c_pack_manifest`. CTest `generated_function_pack_manifest_compile` validates a generated synthetic manifest and compiles/runs the resulting three-function pack.

Phase 19 adds golden assertions for Ghidra boundary import summaries, catalog entries, generated-pack conversion, and validation diagnostics. Unit tests assert `ghidra_boundary_issues: 0`, `kind=ghidra_function_boundary`, Ghidra symbol propagation, duplicate/conflicting/missing-evidence/unsupported-tool/missing-verifier diagnostics, unbounded generated-pack rejection, and non-generated candidate rejection. CTest `generated_function_pack_ghidra_compile` validates, catalogs, emits, compiles, and runs a synthetic Ghidra-boundary pack.

Phase 20 adds golden assertions for generated direct-call pack maps and local generated-callee dispatch. Unit tests assert `debug_direct_call_map` entries for resolved and missing direct-call targets, generated forward declarations, direct `sub_...` calls for verified pack-local callees, `runtime_direct_call` fallback for missing targets, and `debug_patch_boundary` lines for enabled patch metadata.

Phase 21 adds golden assertions for entry import-shim manifest summaries, validation diagnostics, converted patch metadata, generated import-pointer shim calls, and generated-pack debug comments carrying DLL, IAT, ABI, and side-effect metadata. CTest `generated_entry_import_shim_pack_compile` emits a synthetic `GetVersionExA` pack from the manifest, checks required debug/output strings, compiles a controlled-memory harness, and runs it.

Phase 22 keeps the same generated pack fixture but updates the harness golden path to use `runtime_bind_import_pointer_shim_abi` for IAT setup plus ABI-aware shim registration. Unit tests protect the helper's mapped-IAT success path and unmapped-IAT failure path.

Phase 23 adds golden assertions for runtime-init manifest summaries and validation diagnostics. Unit tests assert `runtime_init_issues: 0` for a valid PE-bound manifest, stable IAT/shim-target summary fields, malformed and unsupported record-kind failures, duplicate diagnostics, missing-evidence diagnostics, unsupported side-effect diagnostics, missing-ABI diagnostics, unmapped-IAT diagnostics, and image-base/hash mismatch diagnostics. CTest `generated_runtime_init_manifest_compile` checks generated import-pointer metadata strings before compiling and running the synthetic manifest-driven harness.

Phase 24 adds golden assertions for PE image-map summaries and runtime mapped-range summaries. Unit tests assert stable `pe_image_map_section` fields, permission booleans, `pe_image_map_issues: 0`, `runtime_image_ranges`, section names, and visible diagnostics for unsafe mapping inputs.

Phase 25 adds golden assertions for import-binding summaries and diagnostics. Unit tests assert stable `import_binding` fields for DLL/symbol/IAT/callsite/shim target/ABI/side-effect metadata plus visible diagnostic strings for duplicate imports, ordinal-only imports, missing imports, ABI mismatch, and unsupported side effects.

Phase 26 adds golden assertions for runtime-start manifest summaries and generated entry-call harness output. Unit tests assert stable `runtime_start` and `runtime_start_argument` formatter fields plus visible diagnostics for unsupported ABI, argument overflow, and unaligned arguments. CTest `generated_runtime_start_manifest_compile` validates a synthetic runtime-start manifest, checks generated pack debug strings, compiles a harness, prepares stack state, runs generated code, and verifies the prepared stack argument reaches `EAX`.

Phase 27 adds integrated golden assertions across PE image-map summaries, runtime-init summaries, import-binding summaries, runtime-start summaries, and generated pack debug comments. CTest `integrated_synthetic_bringup_pack_compile` checks the combined build-tree debug map plus generated `debug_function_map`, `debug_direct_call_map`, `debug_indirect_call_map`, and `debug_patch_boundary` strings before compiling and running the synthetic bring-up harness.

This is a compile/runtime-boundary test only; target runtime behavior still needs separate execution and differential tests.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
