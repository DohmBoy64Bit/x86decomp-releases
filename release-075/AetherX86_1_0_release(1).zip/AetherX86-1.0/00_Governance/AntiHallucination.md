# Anti Hallucination

## Filled contract
Never claim universal recompilation or Battlefield Vietnam recompilation without build/test/trace evidence. Label facts as verified by build, source, binary observation, hypothesis, or blocked.

## Zero-hallucination policy
- Do not implement or document a fact as true until it is backed by at least three evidence legs: project source/docs, authoritative external reference or runtime/binary evidence, and a test or reproducible command. If three legs are impossible, label the claim as hypothesis, blocked, or needs verification.
- Search current official docs or web references for volatile facts such as tool frontends, compiler behavior, library APIs, and external instruction tables. Use local docs first for repository facts.
- Ask the user when ownership, target data, frontend selection, legal status, or source evidence is ambiguous. Never fill gaps with plausible-sounding assumptions.
- Stop after three failed attempts at the same error or blocker. Record the exact command, output, attempted fixes, and next evidence needed before continuing.
- Every code or doc edit must have a stated purpose, evidence basis, and verification path.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.
