# Change Control

## Classification
- Kind: governance policy
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.
- Every modification must have a stated purpose, owner area, evidence source, expected effect, and verification command or reason verification is not possible.
- Update documentation in the same session as the change. Do not batch undocumented changes across sessions.
- Reject changes that are cosmetic, speculative, or unrelated to the current milestone unless the user explicitly approves them.
- Do not add empty APIs, empty files, vague unverified future-task markers, future-proof abstractions, or "we will later" scaffolding without owner/reason/next verification.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
- The change log in final status must say why each changed area moved and what evidence justified it.
