# Classification

| File | Role | Disposition |
|---|---|---|
| `00_Governance/AntiHallucination.md` | governance policy | kept and filled |
| `00_Governance/ChangeControl.md` | governance policy | kept and filled |
| `00_Governance/CodingStandard.md` | governance policy | kept and filled |
| `00_Governance/Constitution.md` | governance policy | kept and filled |
| `00_Governance/DefinitionOfDone.md` | governance policy | kept and filled |
| `00_Governance/EngineeringPrinciples.md` | governance policy | kept and filled |
| `00_Governance/NamingConvention.md` | governance policy | kept and filled |
| `00_Governance/ReviewPolicy.md` | governance policy | kept and filled |
| `00_Governance/RiskManagement.md` | governance policy | kept and filled |
| `00_Governance/ScopeControl.md` | governance policy | kept and filled |
| `01_Memory/ArchitectureMemory.md` | living register | kept and filled |
| `01_Memory/AssumptionRegistry.md` | living register | kept and filled |
| `01_Memory/DecisionLog.md` | living register | kept and filled |
| `01_Memory/Glossary.md` | living register | kept and filled |
| `01_Memory/KnowledgeBase.md` | living register | kept and filled |
| `01_Memory/LessonsLearned.md` | living register | kept and filled |
| `01_Memory/ProblemRegistry.md` | living register | kept and filled |
| `01_Memory/Roadmap.md` | living register | kept and filled |
| `01_Memory/SessionHistory.md` | living register | kept and filled |
| `01_Memory/UnresolvedFacts.md` | living register | kept and filled |
| `02_Verification/AuditChecklist.md` | verification contract | kept and filled |
| `02_Verification/ConfidencePolicy.md` | verification contract | kept and filled |
| `02_Verification/CrossReferenceRules.md` | verification contract | kept and filled |
| `02_Verification/DifferentialTesting.md` | verification contract | kept and filled |
| `02_Verification/DisputeResolution.md` | verification contract | kept and filled |
| `02_Verification/EvidenceTemplate.md` | verification contract | kept and filled |
| `02_Verification/FactWorkflow.md` | verification contract | kept and filled |
| `02_Verification/RegressionRules.md` | verification contract | kept and filled |
| `02_Verification/Sources.md` | verification contract | kept and filled |
| `02_Verification/TruthLevels.md` | verification contract | kept and filled |
| `03_Architecture/ADR_TEMPLATE.md` | architecture contract | kept and filled |
| `03_Architecture/DataFlow.md` | architecture contract | kept and filled |
| `03_Architecture/DependencyGraph.md` | architecture contract | kept and filled |
| `03_Architecture/ErrorHandling.md` | architecture contract | kept and filled |
| `03_Architecture/InterfaceRules.md` | architecture contract | kept and filled |
| `03_Architecture/LoggingPolicy.md` | architecture contract | kept and filled |
| `03_Architecture/ModuleContracts.md` | architecture contract | kept and filled |
| `03_Architecture/OwnershipRules.md` | architecture contract | kept and filled |
| `03_Architecture/PerformancePolicy.md` | architecture contract | kept and filled |
| `03_Architecture/SecurityPolicy.md` | architecture contract | kept and filled |
| `04_Workflows/CodeReviewChecklist.md` | workflow | kept and filled |
| `04_Workflows/CommitWorkflow.md` | workflow | kept and filled |
| `04_Workflows/DocumentationWorkflow.md` | workflow | kept and filled |
| `04_Workflows/IncidentWorkflow.md` | workflow | kept and filled |
| `04_Workflows/MilestoneGates.md` | workflow | kept and filled |
| `04_Workflows/RefactorWorkflow.md` | workflow | kept and filled |
| `04_Workflows/ReleaseWorkflow.md` | workflow | kept and filled |
| `04_Workflows/SessionEnd.md` | workflow | kept and filled |
| `04_Workflows/SessionStart.md` | workflow | kept and filled |
| `04_Workflows/TaskLifecycle.md` | workflow | kept and filled |
| `05_Recompiler/BattlefieldVietnamPlan.md` | recompiler design contract | kept and filled |
| `05_Recompiler/CFGDesign.md` | recompiler design contract | kept and filled |
| `05_Recompiler/CallingConventions.md` | recompiler design contract | kept and filled |
| `05_Recompiler/Codegen.md` | recompiler design contract | kept and filled |
| `05_Recompiler/Decoder.md` | recompiler design contract | kept and filled |
| `05_Recompiler/Flags.md` | recompiler design contract | kept and filled |
| `05_Recompiler/FunctionDiscovery.md` | recompiler design contract | kept and filled |
| `05_Recompiler/IRDesign.md` | recompiler design contract | kept and filled |
| `05_Recompiler/Imports.md` | recompiler design contract | kept and filled |
| `05_Recompiler/Lifter.md` | recompiler design contract | kept and filled |
| `05_Recompiler/MemorySSA.md` | recompiler design contract | kept and filled |
| `05_Recompiler/OpcodeTruthDatabase.md` | recompiler design contract | kept and filled |
| `05_Recompiler/PELoader.md` | recompiler design contract | kept and filled |
| `05_Recompiler/Runtime.md` | recompiler design contract | kept and filled |
| `05_Recompiler/SSAPlan.md` | recompiler design contract | kept and filled |
| `05_Recompiler/SSEPlan.md` | recompiler design contract | kept and filled |
| `05_Recompiler/StackRecovery.md` | recompiler design contract | kept and filled |
| `05_Recompiler/SwitchRecovery.md` | recompiler design contract | kept and filled |
| `05_Recompiler/TypePropagation.md` | recompiler design contract | kept and filled |
| `05_Recompiler/x87Plan.md` | recompiler design contract | kept and filled |
| `06_Testing/CIRequirements.md` | testing contract | kept and filled |
| `06_Testing/CoverageRequirements.md` | testing contract | kept and filled |
| `06_Testing/DifferentialFuzzing.md` | testing contract | kept and filled |
| `06_Testing/FailureAnalysis.md` | testing contract | kept and filled |
| `06_Testing/GoldenOutputs.md` | testing contract | kept and filled |
| `06_Testing/PerformanceBenchmarks.md` | testing contract | kept and filled |
| `06_Testing/PropertyTests.md` | testing contract | kept and filled |
| `06_Testing/RegressionSuite.md` | testing contract | kept and filled |
| `06_Testing/TestTemplates.md` | testing contract | kept and filled |
| `06_Testing/UnitTests.md` | testing contract | kept and filled |
| `07_ProjectManagement/BacklogRules.md` | project-management contract | kept and filled |
| `07_ProjectManagement/DecisionTemplate.md` | project-management contract | kept and filled |
| `07_ProjectManagement/IssueTemplate.md` | project-management contract | kept and filled |
| `07_ProjectManagement/Metrics.md` | project-management contract | kept and filled |
| `07_ProjectManagement/Milestones.md` | project-management contract | kept and filled |
| `07_ProjectManagement/ReleaseCriteria.md` | project-management contract | kept and filled |
| `07_ProjectManagement/Requirements.md` | project-management contract | kept and filled |
| `07_ProjectManagement/ScopeFreeze.md` | project-management contract | kept and filled |
| `07_ProjectManagement/StatusReports.md` | project-management contract | kept and filled |
| `07_ProjectManagement/TraceabilityMatrix.md` | project-management contract | kept and filled |
| `08_References/AMDAPM.md` | reference note | kept and filled |
| `08_References/Bibliography.md` | reference note | kept and filled |
| `08_References/BochsNotes.md` | reference note | kept and filled |
| `08_References/IntelSDM.md` | reference note | kept and filled |
| `08_References/LLVMNotes.md` | reference note | kept and filled |
| `08_References/McSemaNotes.md` | reference note | kept and filled |
| `08_References/QEMUNotes.md` | reference note | kept and filled |
| `08_References/ResearchQueue.md` | reference note | kept and filled |
| `08_References/RetDecNotes.md` | reference note | kept and filled |
| `08_References/RevngNotes.md` | reference note | kept and filled |


## v5 skill additions

- `SKILL.md`: authoritative detailed AI skill entrypoint.
- `skill/SKILL.md`: compatibility copy for tools/importers that expect a `skill/` directory.
- `08_References/PCRecompNotes.md`: pcrecomp-derived lessons for PC-focused static recompilation.

These additions do not replace the preserved 101-file tree; they make the tree operational.
