# Release Criteria

## Classification
- Kind: project-management contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

<!-- AETHERX86-1.0:1.0 release candidate status -->
## 1.0 release candidate status

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

1.0 usable-state means the seed is no longer only a planning skeleton: it has a buildable C++20 CLI/library/test surface, PE inspection, PE image mapping, relocation diagnostics, controlled import IAT application, generated-pack dispatch metadata, expanded IA-32 semantics, and a minimal tested Win32 import shim boundary.

Verified local commands:
- CMake configure/build passed in Release mode.
- `x86tests` passed.
- All 21 CTest tests passed when run in timeout-safe chunks.
- Capstone-backed decode and PE-slice verification tests passed with Capstone 5.0.7 available.
- Mock BFV PE inspection and preferred-base image mapping completed as safe metadata evidence.

Deferred local/user-environment gates:
- Windows/MSVC rebuild and test run.
- Any full target/game execution or playability test.
- Any import application against the mock BFV executable without a complete, explicit runtime-init manifest covering its imports.

