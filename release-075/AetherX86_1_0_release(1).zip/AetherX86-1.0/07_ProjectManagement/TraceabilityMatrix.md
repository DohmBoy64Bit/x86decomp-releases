# Traceability Matrix

## Classification
- Kind: project-management contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

## Phase 8 stack milestone
- Requirement: reduce the first BFV slice blocker through universal IA-32 stack instruction support, not BFV-specific logic.
- Code: `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tools/capstone_decode_verify.py`, CTest `generated_stack_compile`.
- Evidence: Capstone 5.0.7 verifies 33 decode fixtures; CTest passes 6/6; BFV entrypoint-slice safe metadata improves from 30 decoded slots/17 unsupported/14 unsupported opcode kinds to 26 decoded slots/11 unsupported/10 unsupported opcode kinds.
- Remaining blocker: BFV entrypoint slice still has x86recomp/Capstone count mismatch, unsupported IR, and `slice_generated_candidate=false`.

## Phase 9 BFV first trace
- Requirement: turn the BFV first-trace milestone into bounded decode parity plus one tiny generated-code candidate without committing BFV bytes or generated BFV source.
- Code: `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tools/capstone_decode_verify.py`, CTest `generated_moffs_compile`, CTest `generated_mov_imm_rm_compile`, Ghidra MCP `get_function_count`/`disassemble_function`, Capstone slice verifier.
- Evidence: BFV entrypoint slice now reports 17 x86recomp instructions, 17 Capstone instructions, zero unsupported decode slots, one unsupported IR record, and `slice_generated_candidate=false`; BFV export slice at RVA `0x0008E510`, size 7, reports 2 x86recomp instructions, 2 Capstone instructions, zero unsupported IR, and `slice_generated_candidate=true`; local generated-code compile/run for the export slice passed under the ignored build tree.
- Remaining blocker: the BFV entrypoint slice requires indirect-call dispatch metadata/runtime support before it can become a generated candidate.

## Phase 10 indirect-call dispatch preparation
- Requirement: model `FF /2` and indirect jump control flow as explicit unresolved IR/CFG/runtime metadata rather than unsupported IR or guessed direct calls.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CTest `generated_indirect_call_compile`, Capstone decode verifier, Capstone PE slice verifier, Ghidra MCP `disassemble_bytes`, `audit_globals_in_function`, and `get_bulk_xrefs`.
- Evidence: BFV entrypoint slice now reports 17 x86recomp instructions, 17 Capstone instructions, zero unsupported decode slots, zero unsupported IR records, one indirect CFG call site, `slice_cfg_complete=false`, and `slice_generated_candidate=false`; PE import table maps RVA `0x00742238` to `KERNEL32.dll!GetVersionExA`; Ghidra reports the entrypoint callsite reading `00B42238`.
- Remaining blocker: no ABI-checked import shim or target-manifest binding exists for the indirect `GetVersionExA` callsite, and no BFV runtime behavior is claimed.

## Phase 11 import-shim manifest binding preparation
- Requirement: add a universal, regeneration-safe metadata path for indirect import-pointer calls before adding BFV-specific target records.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/tools/compile_generated_cfg.cmake`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CTest `generated_indirect_import_shim_compile`, Capstone decode verifier, Capstone slice verifier, BFV safe slice smoke.
- Evidence: synthetic `FF /2` fixture can compile through generated `runtime_import_pointer_shim` fallback code; runtime tests prove pointer-shim dispatch and missing-shim events; BFV entrypoint remains metadata-only with zero unsupported IR and one indirect CFG callsite.
- Remaining blocker: no persistent manifest parser and no ABI/side-effect-checked Win32 shim implementation.

## Phase 12 persistent manifest schema
- Requirement: move synthetic patch/import metadata from in-memory fixtures to a small parsed manifest file before adding BFV records.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/tools/compile_generated_cfg.cmake`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tests/fixtures/indirect_import.patchmanifest`, CTest `generated_manifest_indirect_import_compile`, Capstone decode verifier, Capstone slice verifier, BFV safe slice smoke.
- Evidence: the tracked fixture formats with `patch_issues: 0`, generated code emits `runtime_import_pointer_shim`, CTest passes 11/11, and BFV entrypoint metadata remains unchanged and non-generated.
- Remaining blocker: no ABI-aware import shim behavior or target manifest record for BFV.

## Phase 13 ABI-aware import shim boundary
- Requirement: require ABI metadata for direct and indirect import-shim records, pass that ABI through generated code, and make ABI mismatches visible in the runtime.
- Code: `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tests/fixtures/indirect_import.patchmanifest`, CTest `generated_manifest_indirect_import_compile`, Capstone decode verifier, Capstone slice verifier, BFV safe slice smoke.
- Evidence: CTest passes 11/11; the tracked fixture formats with `abi=stdcall` and `patch_issues: 0`; generated manifest output emits `runtime_import_pointer_shim_abi`; runtime tests cover successful `stdcall` `GetVersionExA`-shaped dispatch plus `cdecl` mismatch events.
- Remaining blocker: no BFV target manifest record, no full Win32 side-effect model, and no BFV runtime behavior claim.

## Phase 14 function catalog and import classification
- Requirement: add a universal function catalog model and separate import/IAT/callsite classifications without whole-BFV scanning.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CLI `function-catalog`, CLI `function-catalog-slice`, Capstone decode verifier, Capstone slice verifier, BFV safe catalog smoke.
- Evidence: CTest passes 11/11; unit tests cover PE entrypoint/export/import/delay-import catalog entries plus bounded CFG direct/indirect callsite and manifest import-pointer entries; BFV entrypoint catalog smoke reports 388 safe metadata entries and identifies `KERNEL32.dll!GetVersionExA` IAT separately from the indirect callsite.
- Remaining blocker: no whole-program function recovery, Ghidra-imported function-boundary catalog, prologue scanning, or BFV execution behavior claim.

## Phase 15 high-value lifter expansion
- Requirement: expand a small high-value IA-32 semantic subset with Capstone/manual evidence, flag tests, generated-output assertions, and visible limits.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/tools/capstone_decode_verify.py`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CTest `generated_phase15_lifter_compile`, Capstone decode verifier, Capstone slice verifier, BFV slice smoke, BFV unsupported-histogram smoke.
- Evidence: CTest passes 12/12; Capstone verifies 46 decode fixtures; generated fixture compile/runs `inc`, `dec`, `xchg`, `movzx`, and `movsx`; BFV entrypoint slice remains decode/IR clean but non-generated due to indirect CFG call.
- Remaining blocker: `adc`/`sbb`, shifts/rotates, `neg`/`not`, `setcc`, `cmovcc`, memory-source `movzx`/`movsx` codegen, full partial-register writes, and BFV runtime behavior remain unimplemented.

## Phase 16 verified generated function pack
- Requirement: emit and compile-check a generated C++ pack from multiple verified bounded functions, with BFV acceptance limited to ignored local artifacts.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/tools/compile_generated_pack.cmake`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CTest `generated_function_pack_compile`, CLI `emit-cfg-c-pack-raw`, CLI `emit-cfg-c-pack-slices`, Ghidra MCP `list_instances`/`disassemble_bytes`/`search_instructions`, Capstone slice verifier, local BFV scratch-pack compile.
- Evidence: full CTest passes 13/13; synthetic generated pack compiles and runs; Ghidra associates BFV VA `0x00401070`, `0x0048E510`, and `0x00874080` with tiny functions; x86recomp and Capstone verify each BFV slice as generated-candidate true; the BFV pack compiles and runs under `09_ProjectSeed/x86recomp/build/bfv_phase16_pack`.
- Remaining blocker: no committed BFV generated source or bytes, no BFV entrypoint pack, no import/runtime behavior, no target manifest identity record, and no playability claim.

## Phase 17 complete high-value lifter remainder
- Requirement: close the remaining Phase 15 high-value opcode-family gap with evidence-led, tested IA-32 forms rather than a giant opcode table.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tools/capstone_decode_verify.py`, CTest `generated_phase17_lifter_compile`, BFV unsupported-histogram smoke, BFV bounded slice smoke.
- Evidence: configure/build pass; full CTest passes 14/14; Capstone 5.0.7 verifies 59 decode fixtures; generated Phase 17 fixture compiles and runs; BFV metadata-only histogram reports 3,004,248 decoded slots, 2,189,413 supported, 814,835 unsupported, and 165 unsupported opcode kinds.
- Remaining blocker: unverified forms still route to visible unsupported diagnostics, including byte/word codegen beyond the tested partial-write surface, multi-bit/CL shift and rotate codegen, `rcl`/`rcr`/`sal`, memory-destination `setcc`, memory-source extension codegen, x87/SSE, segment overrides, and BFV runtime behavior.

## Phase 18 persistent function-pack manifest schema
- Requirement: persist generated-pack inputs as PE-bound metadata before scaling beyond tiny verified slices.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/tools/compile_generated_pack_manifest.py`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CTest `generated_function_pack_manifest_compile`, CLI `format-function-pack-manifest`, CLI `emit-cfg-c-pack-manifest`, BFV metadata-only manifest smoke.
- Evidence: configure/build pass; full CTest passes 15/15; unit tests cover malformed records, duplicates, missing evidence, image-base/hash mismatch, out-of-section slices, unsupported/non-generated candidates, and generated output through the parsed manifest; synthetic generated-pack manifest compile/run passes; BFV temporary manifest for the three Phase 16 tiny candidates reports `function_pack_issues: 0`.
- Remaining blocker: no Ghidra boundary import format, no multi-function call-boundary pack, no BFV committed target manifest, no entrypoint import-shim metadata bring-up, no full Win32 side-effect model, and no BFV runtime behavior.

## Phase 19 Ghidra function-boundary import
- Requirement: import Ghidra-derived function-boundary evidence into the universal catalog and function-pack manifest workflow without treating Ghidra as source truth.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/tools/compile_generated_pack_ghidra.py`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CTest `generated_function_pack_ghidra_compile`, CLI `format-ghidra-boundaries`, CLI `function-catalog-ghidra`, CLI `emit-cfg-c-pack-ghidra`, Ghidra MCP `disassemble_bytes`, Capstone slice verifier.
- Evidence: configure/build pass; full CTest passes 16/16; unit tests cover invalid, duplicate, conflicting, missing-evidence, unsupported-tool, missing-verifier, unbounded, and non-generated candidate cases; BFV temporary Ghidra-boundary manifest reports `ghidra_boundary_issues: 0`; Capstone/x86recomp slice parity is true for the three bounded BFV candidates and the entrypoint remains non-generated.
- Remaining blocker: no multi-function call-boundary pack, no generated dispatch map for direct-call relationships, no BFV committed target manifest, no entrypoint import-shim metadata bring-up, no Win32 side-effect model, and no BFV runtime behavior.

## Phase 20 multi-function call boundary pack
- Requirement: dispatch direct calls inside a generated pack only when the callee is present and verified, while preserving visible runtime diagnostics for missing targets.
- Code: `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tools/compile_generated_pack.cmake`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: CTest `generated_function_pack_direct_call_compile`, CTest `generated_function_pack_compile`, `x86tests`, BFV bounded-pack compile smoke under ignored build artifacts.
- Evidence: configure/build pass; full CTest passes 17/17; unit tests cover generated-callee dispatch, missing-target fallback, direct-call debug maps, and patch-boundary debug maps; BFV bounded Ghidra pack compiles/runs under `09_ProjectSeed/x86recomp/build/bfv_phase20_pack`.
- Remaining blocker: no automatic call graph expansion, no generated dispatch table for broad packs, no BFV committed target manifest, no entrypoint import-shim metadata bring-up, no Win32 side-effect model, and no BFV runtime behavior.

## Phase 21 entry import-shim metadata bring-up
- Requirement: represent the BFV entrypoint `GetVersionExA` indirect import call as metadata, add target-safe shim fields, preserve generated-code boundaries, and strengthen visible runtime diagnostics without claiming BFV execution.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/tools/compile_entry_import_shim_pack.cmake`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CTest `generated_entry_import_shim_pack_compile`, CLI `format-entry-import-shims`, CLI `emit-cfg-c-pack-entry-import-raw`, PE `inspect`, Ghidra MCP `disassemble_bytes`, BFV metadata-only manifest under ignored build artifacts.
- Evidence: configure/build pass; full CTest passes 18/18; unit tests cover valid/malformed/duplicate/missing/unsupported side-effect manifest records and `unsupported_side_effect` diagnostics; generated synthetic `GetVersionExA` pack compiles/runs with controlled memory; BFV manifest reports `entry_import_shim_issues: 0`.
- Remaining blocker: no committed BFV target manifest, no PE image loader, no real Win32 shim side-effect model beyond the synthetic `version_info_write` fixture, no generated BFV entrypoint pack, no BFV execution, and no menu/frame/playability claim.

## Phase 22 import-pointer binding initialization
- Requirement: add a runtime initialization boundary that writes a manifest/shim-selected target into a mapped IAT slot and registers the ABI-aware shim callback, with visible failure on unsafe memory.
- Code: `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tools/compile_entry_import_shim_pack.cmake`.
- Tests/tools: `x86tests`, CTest `generated_entry_import_shim_pack_compile`, generated synthetic `GetVersionExA` harness.
- Evidence: unit tests cover successful IAT write, import-pointer dispatch through the registered shim, and unmapped-IAT `memory_fault`; generated harness compile/run uses `runtime_bind_import_pointer_shim_abi`; final CTest remains 18/18.
- Remaining blocker: no PE image loader, no host import resolver, no real Win32 side-effect model beyond synthetic `version_info_write`, no BFV entrypoint execution, and no menu/frame/playability claim.

## Phase 23 persistent runtime-init manifest
- Requirement: persist import-pointer runtime setup records separately from patch and entry-import manifests, validate image identity and unsafe IAT setup, and convert valid record shape into runtime setup calls.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/tools/compile_runtime_init_manifest.py`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `09_ProjectSeed/x86recomp/tests/test_core.cpp`, CTest `generated_runtime_init_manifest_compile`, CLI `format-runtime-init`, Ghidra MCP `list_instances` and `disassemble_bytes`, BFV metadata-only runtime-init smoke.
- Evidence: configure/build pass; full CTest passes 19/19; unit tests cover valid records, malformed/unsupported kinds, duplicate records, missing evidence, missing ABI, unsupported side effects, unmapped IAT validation, and image base/hash mismatch; the synthetic generated `GetVersionExA` harness validates a runtime-init manifest and applies `runtime_apply_import_pointer_init`; BFV temporary manifest reports `runtime_init_issues: 0`; Ghidra confirms the entrypoint callsite reads `0x00B42238`.
- Remaining blocker: no PE image memory map, no import binding resolver, no controlled entrypoint stack/ABI harness, no real Win32 side-effect model beyond synthetic `version_info_write`, no BFV entrypoint execution, and no menu/frame/playability claim.

## Phase 24 PE image memory-map skeleton
- Requirement: add a universal runtime image-memory setup boundary from PE section metadata, synthetic first, with safe metadata-only BFV layout reporting.
- Code: `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/tests/test_core.cpp`.
- Tests/tools: `x86tests`, CLI `format-pe-image-map`, CTest full suite, BFV metadata-only section-layout smoke, Ghidra MCP `get_address_spaces`.
- Evidence: configure/build pass; full CTest passes 19/19; unit tests cover valid image mapping, raw copy, zero-fill, runtime range summaries, mapped read/write, unmapped writes, overlapping sections, truncated raw data, section overflow, and invalid image base; BFV image-map summary reports five sections and `pe_image_map_issues: 0`; Ghidra reports a 32-bit byte-addressed `ram` space.
- Remaining blocker: no BFV byte mapping, no section permission enforcement, no relocations, no import binding resolver, no controlled entrypoint stack/ABI harness, no BFV execution, and no menu/frame/playability claim.

## Phase 25 PE import binding resolver
- Requirement: bridge PE import-table facts, entry import-shim metadata, and runtime-init records into deterministic binding summaries with visible diagnostics.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tools/compile_runtime_init_manifest.py`.
- Tests/tools: `x86tests`, CTest `generated_runtime_init_manifest_compile`, CLI `format-import-bindings`, BFV metadata-only binding smoke, Ghidra MCP `disassemble_bytes`.
- Evidence: configure/build pass; full CTest passes 19/19; unit tests cover valid binding, duplicate imports, ordinal-only imports, missing imports, ABI mismatch, and unsupported side-effect diagnostics; generated synthetic `GetVersionExA` harness requires resolver success before compile/run; BFV `GetVersionExA` binding resolves with 28 visible ordinal-only diagnostics for unrelated imports; Ghidra confirms the callsite.
- Remaining blocker: no host import resolver, no ordinal import policy, no controlled entrypoint stack/ABI harness, no real Win32 side-effect model beyond synthetic `version_info_write`, no BFV execution, and no menu/frame/playability claim.

## Phase 26 controlled entrypoint stack/ABI harness
- Requirement: add a synthetic runtime-start manifest and controlled stack/ABI harness for generated-function entry calls, with BFV limited to metadata-only blocker notes.
- Code: `09_ProjectSeed/x86recomp/src/core.hpp`, `09_ProjectSeed/x86recomp/src/core.cpp`, `09_ProjectSeed/x86recomp/src/main.cpp`, `09_ProjectSeed/x86recomp/src/runtime.hpp`, `09_ProjectSeed/x86recomp/src/runtime.cpp`, `09_ProjectSeed/x86recomp/tests/test_core.cpp`, `09_ProjectSeed/x86recomp/tools/compile_runtime_start_manifest.py`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: `x86tests`, CTest `generated_runtime_start_manifest_compile`, CLI `format-runtime-start`, BFV disabled metadata-only runtime-start smoke.
- Evidence: configure/build pass; full CTest passes 20/20; unit tests cover valid start metadata, unsupported ABI, stack argument overflow, unaligned argument diagnostics, runtime stack preparation, initial ESP, argument writes, and pre-mapped image memory preservation; generated synthetic harness compiles/runs and verifies a prepared stack argument reaches `EAX`; BFV record remains disabled metadata only.
- Remaining blocker: no BFV target-safe image loader, no process-entry ABI/process-state model, no import/runtime side-effect integration for a full bring-up pack, no ordinal import policy, no BFV execution, and no menu/frame/playability claim.

## Phase 27 integrated synthetic bring-up pack
- Requirement: combine runtime-init manifest, PE image-memory skeleton, import binding resolver, and controlled stack harness into one synthetic generated bring-up pack, with BFV readiness reporting only.
- Code: `09_ProjectSeed/x86recomp/tools/compile_integrated_bringup_pack.py`, `09_ProjectSeed/x86recomp/CMakeLists.txt`.
- Tests/tools: CTest `integrated_synthetic_bringup_pack_compile`, CLI `format-pe-image-map`, CLI `format-runtime-init`, CLI `format-import-bindings`, CLI `format-runtime-start`, Ghidra MCP `disassemble_bytes`, BFV metadata-only readiness report under ignored build artifacts.
- Evidence: baseline configure/build/CTest passed 20/20; post-edit configure/build passed; full CTest passed 21/21; the integrated synthetic fixture validates metadata, emits a two-function pack, maps synthetic image memory, applies runtime init, prepares stack state, runs generated code, and verifies controlled `GetVersionExA` output; BFV readiness report records PE layout, resolved entry import binding, disabled start metadata, and Ghidra callsite confirmation.
- Remaining blocker: no BFV bytes mapped, no BFV generated entrypoint pack, no process-entry ABI/process-state model, no ordinal import policy, no real Win32/DirectX/DirectSound/input/filesystem/timing/thread side-effect model, no BFV execution, and no menu/frame/playability claim.

<!-- AETHERX86-1.0:Phase 28 PE image loader completion -->
## Phase 28 PE image loader completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: promote Phase 27 metadata-only PE image planning into a loader-owned image map that can copy headers/sections and apply PE32 base relocations for synthetic and supported PE32 inputs.

Implemented surface:
- `map-pe-image <pe> [mapped_base]` CLI.
- `xr::map_pe_image` and `xr::format_pe_loaded_image` API.
- PE32 section copy into a loader-owned image buffer.
- Relocation directory walking with `IMAGE_REL_BASED_ABSOLUTE` skip and `IMAGE_REL_BASED_HIGHLOW` adjustment.
- Hard diagnostics for unsupported relocation types, malformed relocation blocks, out-of-image relocation targets, and rebased images that lack relocation data.

Verification:
- Synthetic relocation unit test maps a PE at a non-preferred base and verifies a HIGHLOW target is adjusted by the base delta.
- Supplied mock `BfVietnam.exe` maps cleanly at its preferred base and reports a diagnostic when deliberately rebased because its relocation directory is absent.

<!-- AETHERX86-1.0:Phase 29 import IAT application completion -->
## Phase 29 import IAT application completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move import handling from binding summaries into controlled loaded-image IAT writes, while keeping ordinal imports explicit and non-silent.

Implemented surface:
- `apply-pe-imports <pe> <runtime_init_manifest> [mapped_base]` CLI.
- `xr::apply_imports_to_loaded_image` and `xr::format_pe_import_apply_result` API.
- Name-import and delay-import IAT writes sourced from validated runtime-init manifests.
- Duplicate, missing, and malformed manifest validation before image mutation.
- Ordinal-only imports produce explicit diagnostics and do not receive guessed addresses.

Verification:
- Synthetic ordinary import and delay-import IAT writes are checked byte-for-byte in the loaded image.
- Synthetic ordinal import fixture fails with the diagnostic `ordinal import requires explicit non-name policy`.

<!-- AETHERX86-1.0:Phase 30 generated dispatch completion -->
## Phase 30 generated dispatch completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: replace pack-local direct-call emission with a deterministic generated dispatch boundary that can grow into chunked generated functions.

Implemented surface:
- Generated packs now emit `generated_function_record`, `k_generated_functions`, and `generated_dispatch(ctx, rt, target)`.
- Pack-local direct calls route through `generated_dispatch` instead of hardwired direct subroutine calls.
- Runtime direct-call fallback is retained when the target is outside the generated pack.
- `format-generated-dispatch-raw` CLI exposes dispatch metadata for raw fixtures.

Verification:
- Existing direct-call generated-pack tests now assert dispatch-table output and generated dispatch invocation.
- New CLI smoke evidence writes a generated dispatch summary for a tiny raw pack.

<!-- AETHERX86-1.0:Phase 31 IA-32 semantic expansion completion -->
## Phase 31 IA-32 semantic expansion completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: reduce the next high-value BFV blockers with universal IA-32 semantics only, not BFV-specific decoding branches.

Implemented surface:
- `ret imm16` (`C2 iw`).
- `leave` (`C9`) lifted to explicit frame teardown code.
- `mov r8, imm8` (`B0..B7`) with partial-register-safe write emission for generated C.
- Accumulator immediate arithmetic/logic forms (`04/05/0C/0D/14/15/1C/1D/24/25/2C/2D/34/35/3C/3D`).
- 8-bit ModRM arithmetic/logic forms and `test r/m8, r8` (`84 /r`).
- `mov r/m8, imm8` (`C6 /0 ib`) in addition to existing 32-bit immediate moves.

Verification:
- Unit tests cover decode, lift, and generated C output for the newly supported forms.
- Capstone decode and PE-slice verifier tests pass with Capstone 5.0.7 available in the environment.
- Mock BFV unsupported histogram improved from the earlier baseline of 3,004,248 decoded slots / 2,189,413 supported / 814,835 unsupported to 2,750,940 decoded slots / 2,310,829 supported / 440,111 unsupported in this build.

<!-- AETHERX86-1.0:Phase 32 Win32 shim boundary completion -->
## Phase 32 Win32 shim boundary completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move the synthetic `GetVersionExA` import-pointer callback into a small tested Win32 shim boundary without claiming full Windows emulation.

Implemented surface:
- `runtime_win32_builtin_callback` resolves builtin callbacks by case-insensitive Win32 symbol name.
- `runtime_apply_builtin_import_pointer_init` applies runtime-init records and fills builtin callbacks when available.
- `runtime_win32_get_version_ex_a` implements a minimal stdcall-shaped `OSVERSIONINFOA` write: success return, Windows XP-era version fields, and unchanged behavior when memory validation fails.
- Byte-level runtime memory helpers support shim structure writes.

Verification:
- Runtime unit test initializes a `KERNEL32.dll!GetVersionExA` import pointer through the builtin resolver, calls it, and checks that the version structure is written.
- Scope remains intentionally narrow: no BFV execution/playability claim and no broad Win32 API emulation claim.


<!-- AETHERX86-1.0:mandatory-doc-hash-trace -->
## 1.0 mandatory documentation/hash-control follow-up

User requirement: after each major code edit, re-read `AGENTS.md`; keep all relevant docs under mandatory folders `00` through `09` synchronized; include those docs and all release-relevant files in mandatory hash checks.

Traceability:
- Rules: `AGENTS.md`, `SKILL.md`, and `skill/SKILL.md` now explicitly require post-edit rule refresh and numbered-folder documentation synchronization.
- Workflow: `04_Workflows/DocumentationWorkflow.md`, `04_Workflows/SessionStart.md`, and `04_Workflows/SessionEnd.md` now define the numbered-folder sync and closeout checks.
- Verification: `02_Verification/AuditChecklist.md` and `02_Verification/EvidenceTemplate.md` now require release-integrity hash scope and evidence command capture.
- Tooling: `09_ProjectSeed/x86recomp/tools/doc_hash_check.py` now covers docs plus release-relevant source/config/test/tool files instead of only `.md`, `.txt`, and `CMakeLists.txt`.
- Evidence: `02_Verification/doc_hash_final_1_0.sha256` and `09_ProjectSeed/x86recomp/docs/DOC_HASHES.sha256` are regenerated from the widened scope.
- Packaging: generated tool builds are excluded from the source package; source is retained under `tools-source/bfvtool`.
