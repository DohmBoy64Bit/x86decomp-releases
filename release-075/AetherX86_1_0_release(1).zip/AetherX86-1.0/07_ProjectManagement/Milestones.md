# Milestones

## Classification
- Kind: project-management contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

## Phase operating rules
- Every phase refreshes `SKILL.md`, `AGENTS.md`, `README.md`, `BUILD_TEST_RESULT.txt`, and `09_ProjectSeed/x86recomp/CMakeLists.txt` before implementation.
- Every phase creates or confirms an explicit Codex goal before implementation, and the goal stays open until code, docs, tests, evidence, and known limits are verified.
- pcrecomp is consulted before adding schema, classifier, lifter, shim, or generated-project machinery.

## Current phase status
- Phase 1 verified front end: complete for the documented PE/decode subset.
- Phase 2 minimal IR/lifter: complete for the documented instruction subset.
- Phase 3 bounded CFG: complete for direct branch/call/return fixtures.
- Phase 4 compile-checked codegen: complete for bounded CFG generated C++ compile checks.
- Phase 5 regeneration-safe patch/hook metadata: complete for in-memory metadata validation and patch-aware generated C++ compile checks.
- Phase 6 runtime skeleton: complete for runtime-owned CPU state, memory/stack helpers, direct-call/import-shim registries, patch/hook registries, event logging, generated-code runtime binding, and no-trap generated executable smoke.
- Phase 7 BFV first-trace preparation: complete for safe bounded PE slice analysis, synthetic Capstone slice verification, and BFV entrypoint-slice blocker evidence.
- Phase 8 stack decode/codegen expansion: complete for `push r32`, `pop r32`, `push imm32`, sign-extended `push imm8`, runtime-bound 32-bit stack emission, Capstone decode verification, and generated stack compile/run coverage.
- Phase 9 BFV first trace: complete for BFV entrypoint-slice decode parity with Capstone, Ghidra-confirmed tiny BFV export-slice generated candidate, local generated-code compile/run for that slice in the ignored build tree, moffs/group-5/group-11 decoder expansion, and memory-address-aware generated C++ checks.
- Phase 10 indirect-call dispatch preparation: complete for explicit indirect-call/indirect-jump IR, CFG site metadata, runtime indirect dispatch/event helpers, generated indirect-call compile coverage, and BFV entrypoint IAT/Ghidra evidence for the `GetVersionExA` indirect callsite.
- Phase 11 import-shim manifest binding preparation: complete for synthetic callsite-keyed `IndirectImportShim` metadata, runtime import-pointer shim dispatch, generated-code compile coverage, and BFV metadata-only blocker tracking for the `GetVersionExA` callsite.
- Phase 12 persistent manifest schema: complete for a minimal parsed patch manifest format, malformed/duplicate/missing-evidence validation, tracked synthetic `IndirectImportShim` fixture, and generated-code compile coverage from parsed metadata.
- Phase 13 ABI-aware import shim boundary: complete for ABI-required import-shim metadata, ABI-aware runtime dispatch/mismatch events, generated `_abi` import-shim calls, and a synthetic `GetVersionExA`-shaped controlled-memory runtime test.
- Phase 14 function catalog and import classification: complete for universal catalog records, PE entrypoint/export/import/delay-import seeding, bounded CFG direct/indirect callsite seeding, manifest start seeding, CLI catalog reports, and BFV metadata-only catalog smoke.
- Phase 15 high-value lifter expansion: complete for tested `inc`/`dec`, `xchg`, register-source `movzx`, register-source `movsx`, CF-preserving flag helpers, Capstone fixture expansion, generated compile/run coverage, and BFV metadata-only histogram/slice smoke.
- Phase 16 verified generated function pack: complete for universal multi-function generated packs with debug maps, synthetic CTest compile/run coverage, PE-slice pack emission, and a BFV three-function compile/run smoke under ignored build artifacts.
- Phase 17 complete high-value lifter remainder: complete for tested 32-bit `not`, `neg`, `adc`, `sbb`, one-bit `shl`/`shr`/`sar`/`rol`/`ror`, register `setcc`, simple 32-bit `cmovcc`, partial-register writes for byte/word register destinations, Capstone fixture expansion, generated compile/run coverage, and BFV metadata-only histogram/slice smoke.
- Phase 18 persistent function-pack manifest schema: complete for parsed PE-bound function-pack manifests, image-base/hash validation, function VA/RVA/size/evidence records, malformed/duplicate/missing-evidence/mismatch/out-of-section/non-generated validation, CLI manifest formatting/emission, synthetic generated-pack compile/run coverage, and BFV metadata-only manifest smoke.
- Phase 19 Ghidra function-boundary import: complete for parsed Ghidra boundary records, PE-section validation, catalog seeding, bounded verifier-backed conversion into function-pack manifests, synthetic generated-pack compile/run coverage, and BFV metadata-only Ghidra/Capstone cross-check notes.
- Phase 20 multi-function call boundary pack: complete for pack-local direct-call dispatch to verified generated callees, runtime diagnostics for missing direct-call targets, stable debug maps for entries/direct calls/indirect calls/patch boundaries, synthetic direct-call pack compile/run coverage, and BFV bounded-pack compile smoke with no internal call-relationship claim.
- Phase 21 entry import-shim metadata bring-up: complete for parsed entry import-shim metadata, DLL/symbol/IAT/callsite/ABI/side-effect/rollback/enabled fields, malformed/duplicate/missing/unsupported side-effect validation, conversion into existing indirect import-shim patch boundaries, synthetic generated-pack `GetVersionExA` compile/run coverage, and BFV metadata-only entrypoint smoke.
- Phase 22 import-pointer binding initialization: complete for a runtime-owned helper that writes a mapped IAT slot, registers the ABI-aware import-shim callback, dispatches through the existing import-pointer shim path, fails visibly on unmapped IAT memory, and keeps generated harness setup metadata-driven.
- Phase 23 persistent runtime-init manifest: complete for parsed PE-bound runtime-init import-pointer records, image-base/hash validation, IAT VA/RVA/shim-target/DLL/symbol/ABI/side-effect/evidence/rollback/enabled metadata, malformed/duplicate/missing/unmapped-IAT/unsupported-side-effect/image-mismatch validation, CLI formatting, synthetic generated-pack compile/run coverage, and BFV metadata-only runtime-init smoke.
- Phase 24 PE image memory-map skeleton: complete for synthetic PE image mapping, section VA/RVA/raw-size/virtual-size/permission metadata, zero-fill, overlapping-section/truncated-raw/invalid-base/section-overflow diagnostics, runtime read/write bounds checks, CLI image-layout formatting, and BFV metadata-only section-layout smoke.
- Phase 25 PE import binding resolver: complete for deterministic PE import plus entry-import plus runtime-init binding summaries, missing/duplicate/ordinal-only/ABI-mismatch/unsupported-side-effect diagnostics, resolver-gated synthetic `GetVersionExA` generated fixture, and BFV metadata-only binding smoke.
- Phase 26 controlled entrypoint stack/ABI harness: complete for parsed synthetic runtime-start manifests, stack range/initial ESP/argument/ABI/evidence/rollback/enabled metadata, stack bounds and argument diagnostics, runtime CPU/stack preparation, pre-mapped memory preservation, generated entry-call compile/run coverage, and BFV disabled metadata-only note.
- Phase 27 integrated synthetic bring-up pack: complete for composing PE image-map metadata, runtime-init import-pointer setup, PE import binding, runtime-start stack setup, generated pack-local direct call, indirect `GetVersionExA` import-pointer dispatch, stable build-tree debug maps, and BFV readiness reporting without execution.

Next smallest verified milestone: plan the next five goal-driven phases from the Phase 27 baseline, likely around target-safe image loading policy, ordinal import/shim taxonomy, process-entry state modeling, broader generated-pack dispatch, and BFV metadata manifests.

<!-- AETHERX86-1.0:1.0 release candidate status -->
## 1.0 release candidate status

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

1.0 usable-state means the seed is no longer only a planning skeleton: it has a buildable C++20 CLI/library/test surface, PE inspection, PE image mapping, relocation diagnostics, controlled import IAT application, generated-pack dispatch metadata, expanded IA-32 semantics, and a minimal tested Win32 import shim boundary.

Verified local commands:
- CMake configure/build passed in Release mode.
- `x86tests` passed.
- All 21 CTest tests passed when run in timeout-safe chunks.
- Capstone-backed decode and PE-slice verification tests passed with Capstone 5.0.7 available.
- Mock BFV PE inspection and preferred-base image mapping completed as safe metadata evidence.

Deferred local/user-environment gates:
- Windows/MSVC rebuild and test run.
- Any full target/game execution or playability test.
- Any import application against the mock BFV executable without a complete, explicit runtime-init manifest covering its imports.

