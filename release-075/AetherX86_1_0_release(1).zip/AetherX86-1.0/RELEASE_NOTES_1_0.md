# AetherX86 / x86recomp 1.0 release notes

## Completed scope

- Phase 28: loader-owned PE32 image mapping with section/header copy and HIGHLOW relocation support for rebased images.
- Phase 29: validated ordinary/delay import IAT application from runtime-init manifests; ordinal imports are explicit diagnostics, not guessed.
- Phase 30: deterministic generated dispatch table and pack-local generated dispatch boundary.
- Phase 31: universal IA-32 decode/lift/codegen expansion for high-value blockers, including `ret imm16`, `leave`, 8-bit immediate moves, accumulator immediate ops, selected 8-bit ModRM forms, `test r/m8,r8`, and `mov r/m8,imm8`.
- Phase 32: split Win32 builtin shim boundary with tested minimal `GetVersionExA` behavior.
- Mandatory documentation/hash follow-up: post-major-code-edit `AGENTS.md` re-read is codified; `00` through `09` docs are mandatory synchronized records; release-integrity hashes now include relevant docs, source, tests, CMake/config files, tools, target manifests, and evidence text.
- Source package hygiene: generated `tools/bfvtool` build outputs are excluded; reproducible source remains under `tools-source/bfvtool`.

## Verification

- Release CMake configure/build: passed.
- `x86tests`: passed.
- CTest: 21/21 passed through timeout-safe chunks/individual runs.
- Capstone decode and PE-slice verifier tests: active and passed with Capstone 5.0.7.
- Widened release-integrity hash check: passed with `02_Verification/doc_hash_final_1_0.sha256` and mirrored `09_ProjectSeed/x86recomp/docs/DOC_HASHES.sha256`.
- `SKILL.md` and `skill/SKILL.md`: byte-identical.

## Mock BFV evidence

The supplied mock executable was used only as local evidence and is not included in the release package.

- `inspect`: succeeded.
- preferred-base `map-pe-image`: succeeded.
- rebased `map-pe-image`: correctly reports missing relocation directory and does not claim a valid rebased image.
- unsupported histogram after Phase 31: 2,750,940 decoded slots, 2,310,829 supported, 440,111 unsupported, 109 unsupported opcode kinds.

## Deferred local gates

- Windows/MSVC rebuild and CTest.
- Full target/game execution or playability.
- Complete import application for the mock BFV executable without an explicit runtime-init manifest covering its imports.
