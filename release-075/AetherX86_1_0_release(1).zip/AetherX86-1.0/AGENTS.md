# Repository Guidelines

## Project Structure & Module Organization

This repo preserves and develops the `x86recomp` skill package. The authoritative skill is `SKILL.md`; keep `skill/SKILL.md` identical whenever the skill text changes. Governance, verification, architecture, workflows, recompiler design, testing, project-management, references, and the buildable seed live in mandatory project records `00_Governance/` through `09_ProjectSeed/`.

The buildable C++ seed is `09_ProjectSeed/x86recomp`, with `src/`, `tests/`, and `targets/`. Keep universal IA-32/Win32 recompiler logic separate from Battlefield Vietnam-specific target metadata. Tool sources live under `tools-source/<tool-name>/`; generated tool builds go under ignored `tools/<tool-name>/`.

## Build, Test, and Development Commands

```powershell
cmake -S 09_ProjectSeed/x86recomp -B 09_ProjectSeed/x86recomp/build
cmake --build 09_ProjectSeed/x86recomp/build
ctest --test-dir 09_ProjectSeed/x86recomp/build -C Debug --output-on-failure
cmake -S tools-source/bfvtool -B tools/bfvtool
cmake --build tools/bfvtool --config Debug
```

Use `ctest -R x86tests --test-dir 09_ProjectSeed/x86recomp/build -C Debug --output-on-failure` for the current single seed test.

## Mandatory Rule Refresh & Integrity Hashing

After each major code edit, re-read this `AGENTS.md` before continuing implementation or verification. Treat the re-read as a guardrail check: confirm the edit still respects project structure, scope, evidence, documentation, Battlefield Vietnam safety, separation-of-concerns, and status-report rules.

The numbered folders `00_Governance/` through `09_ProjectSeed/` are mandatory synchronized project records. When a code or release-relevant tool change affects behavior, evidence, workflow, architecture, testing, scope, or target facts, update the closest relevant files in those folders during the same session.

Documentation and release integrity manifests must include all relevant root rules/docs, the mandatory `00` through `09` folders, seed source, tests, CMake/configuration files, release tools, target manifests, and evidence text. Exclude only generated build trees, VCS metadata, binary artifacts, and self-referential hash manifests.

## Evidence, Documentation & Scope Rules

Follow the x86recomp skill exactly. For code-changing work, read `SKILL.md`, this `AGENTS.md`, `README.md`, stale/current `BUILD_TEST_RESULT.txt`, `09_ProjectSeed/x86recomp/CMakeLists.txt`, then the relevant contract file from `00_Governance/` through `08_References/`. Build the seed before edits unless the task is documentation-only, then rebuild and run CTest after edits.

Every numbered phase or milestone must be goal-driven like Phase 10. Before starting phase implementation, create or confirm an explicit Codex goal that names the intended outcome, verification commands, evidence requirements, scope limits, and blocker stop condition. Do not mark the goal complete until code/docs/tests/evidence for that phase are actually complete.

Triple-check implementation claims with three evidence legs: local source/docs, an authoritative reference or verifier, and a test/trace/user-owned binary fact. Use Intel SDM/AMD APM as primary ISA authorities; use ref.x86asm.net and Felix Cloutier only as secondary navigation aids. Use Capstone for byte-to-instruction decode checks and Ghidra MCP for function starts, xrefs, imports, P-code, and static/dynamic address evidence, but never treat decompiler output as source truth.

Document every code edit, doc edit, tool use, discovery, decision, assumption, blocker, and verification result in the relevant living register during the same session. Preferred owners: `01_Memory/DecisionLog.md`, `AssumptionRegistry.md`, `ProblemRegistry.md`, `UnresolvedFacts.md`, `SessionHistory.md`, `02_Verification/EvidenceTemplate.md`, `05_Recompiler/OpcodeTruthDatabase.md`, `05_Recompiler/BattlefieldVietnamPlan.md`, and `07_ProjectManagement/TraceabilityMatrix.md`. A session is not done until docs reflect the current state or the final report states why no persistent update was needed.

Keep each task tied to one milestone, blocker, or explicit user request. Stop after three failed attempts at the same blocker, record the exact command/output and attempted fixes, then switch to evidence gathering or ask. Reject filler-only files, vague unverified future-task markers, silent unsupported behavior, speculative scaffolding, and unrelated refactors.

Do not commit Battlefield Vietnam executables, archives, extracted assets, CD contents, cracks, serials, or DRM bypass material. Commit only summaries, manifests, tests, and source.

## Recompiler Boundaries

Maintain strict ownership boundaries. The PE loader owns file validation, sections, RVA/file-offset mapping, imports, relocations, image base, and entrypoint facts. The decoder owns bytes, prefixes, ModRM/SIB, immediates, instruction length, operands, and support state; it must not infer semantics. The lifter owns register, memory, flag, stack, and control-flow effects. CFG/function discovery owns blocks, edges, entrypoints, jump tables, and unresolved indirects. The emitter owns generated C/C++ shape and debug maps. The runtime owns CPU state, guest memory, imports, Win32/DirectX/audio/input/filesystem/timing shims, callbacks, traps, and host interactions. Target manifests own Battlefield Vietnam facts.

Generated code is disposable. Do not hand-edit emitted C/C++ for target fixes; represent corrections as patch/hook metadata, import shims, runtime calls, target manifests, or decode/lift/emit fixes. Patch records must be keyed by stable evidence such as VA/RVA, symbol/import name, binary hash, function-boundary source, ABI/calling convention, and reason.

Compare pcrecomp before reinventing aligned PE analysis, classification, x86 lifting, shim registries, or generated-project machinery. Reuse concepts when they fit the C++20 seed and evidence rules; record attribution and tests for close reuse.

## Battlefield Vietnam Evidence

Battlefield Vietnam is the pressure-test target, not the architecture. Use only legally owned local installs. Record hashes, PE facts, sections, imports, entrypoints, unsupported opcode histograms, and blockers as metadata or summaries. Use `bfvtool` only when archive/script/asset/dependency evidence supports static recompilation: target manifests, import/runtime shim design, asset paths referenced by code, generated-code tests, or milestone reports. If `bfvtool` work only advances an asset viewer or clean-room engine, mark it out of scope unless explicitly requested.

## Coding Style & Naming Conventions

Use C++20 and CMake 3.20+. Bounds-check binary reads. Name address concepts explicitly as `rva`, `va`, or `file_offset`, and convert through helpers rather than mixing address spaces. Generated code must remain disposable; express corrections as metadata, hooks, shims, manifests, or lifter fixes.

## Testing Guidelines

CTest is the seed test runner. Add focused tests for PE parsing, decoder, lifter, emitter, flags, runtime, and malformed/truncated inputs as features land. Add regression tests before closing fixed bugs. For instruction behavior, compare registers, flags, touched memory, control flow, and exceptions against native assembly, emulator/tool output, manual examples, or hand-checked fixtures. Battlefield Vietnam tests must remain local-data safe.

## Status Reports

End x86recomp sessions with `Changed`, `Documented`, `Verified`, `Skill location`, `Seed project`, and `Known limits`. Mark claims as implemented-and-tested, implemented-but-not-fully-tested, hypothesis, or blocked. Do not claim Battlefield Vietnam recompilation, menu reach, frame loop, instruction support, import shim support, or runtime behavior without build/test/trace evidence.

## Commit & Pull Request Guidelines

There is no commit history convention yet. Use short imperative commit subjects. PRs should list changed files, purpose, evidence, verification commands/results, documentation updates, and known limits.
