# Repository Guidelines

## Project Structure & Module Organization

This repo preserves the `x86recomp` skill package. The authoritative skill is `x86recomp_v5_skill/SKILL.md`; keep `x86recomp_v5_skill/skill/SKILL.md` identical. Governance, verification, architecture, workflow, recompiler design, testing, project-management, and reference notes live in `00_Governance/` through `08_References/`.

The buildable seed is `x86recomp_v5_skill/09_ProjectSeed/x86recomp` with `src/`, `tests/`, and `targets/`. The mission is dual-purpose: build general IA-32/Win32 static recompilation capability while using Battlefield Vietnam as the real-game pressure test and ultimate acceptance case. Tool sources live under `tools-source/<tool-name>/`; tool build trees go under `tools/<tool-name>/`.

## Build, Test, and Development Commands

```bash
cmake -S x86recomp_v5_skill/09_ProjectSeed/x86recomp -B build/x86recomp
cmake --build build/x86recomp
ctest --test-dir build/x86recomp --output-on-failure
ctest --test-dir build/x86recomp -R x86tests --output-on-failure
cmake -S tools-source/bfvtool -B tools/bfvtool
cmake --build tools/bfvtool --config Debug
```

Use the first four commands for the seed project. Use the last two for `bfvtool`.

## Evidence, Documentation & Scope Rules

Triple-check implementation claims with local source/docs, an authoritative reference or tool verifier, and a test/trace/user confirmation. Use Intel/AMD manuals first; `ref.x86asm.net`, Felix Cloutier, Ghidra MCP, and Capstone are secondary verifiers.

Document every code edit, doc edit, tool use, discovery, decision, assumption, blocker, and verification result in the relevant living register during the same session, before final response or handoff. Include purpose, evidence, why, files touched, commands, results, confidence, and uncertainty.

No filler-only files, vague unverified future-task markers, silent unsupported behavior, speculative scaffolding, scope creep, or drift. If work does not advance the current milestone or documented blocker, record it as out of scope or ask.

## Coding Style & Naming Conventions

Use C++20 and CMake 3.20+. Keep binary reads bounds-checked. Name address concepts explicitly: `rva`, `va`, `file_offset`. Do not mix RVA, VA, and file offsets without conversion helpers. Keep universal recompiler logic separate from Battlefield Vietnam-specific target metadata.

## Testing Guidelines

CTest is the seed test runner. Add focused tests for decoder, PE parsing, lifter, emitter, flags, and runtime behavior. For instruction decoding, compare against Capstone where useful; for function boundaries, xrefs, imports, and P-code evidence, use Ghidra MCP when available. Battlefield Vietnam tests must use local-owned data only and commit summaries/manifests, not proprietary files.

## Commit & Pull Request Guidelines

There is no commit history convention yet. Use short imperative subjects. PRs must list changed files, purpose, evidence, verification commands/results, documentation updates, and known limits. Mark claims as implemented-and-tested, implemented-but-not-fully-tested, hypothesis, or blocked.
