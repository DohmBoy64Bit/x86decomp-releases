# Opcode Truth Database

## Classification
- Kind: recompiler design contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Phase 2 verified semantic slice
Implemented-and-tested in the seed:

- `mov`: lifted as `IrOp::Move`; flags unchanged.
- `lea`: lifted as `IrOp::Lea`; flags unchanged.
- `add`: lifted as `IrOp::Add`; CF/PF/AF/ZF/SF/OF defined; helper tests cover carry and signed overflow cases.
- `sub` and `cmp`: lifted as subtract-style flag producers; CF/PF/AF/ZF/SF/OF defined; helper tests cover borrow and signed overflow cases.
- `and`, `or`, `xor`, `test`: lifted as logical/test-style flag producers; CF/OF cleared, PF/ZF/SF defined, AF undefined.
- direct `call`, `jmp`, and `jcc`: lifted as direct control-flow IR; conditional branches record flag reads.
- `push r32`, `pop r32`, `push imm32`, and `push imm8`: decoded and lifted as stack IR. `push imm8` is sign-extended to operand size for the tested 32-bit fixture. Generated 32-bit stack code is runtime-bound through `runtime_push32`/`runtime_pop32`.
- `A1/A3` moffs moves and `C7 /0` move-immediate-to-r/m: decoded and lifted as `IrOp::Move`; generated 32-bit memory moves use runtime memory helpers and generated address expressions.
- `FF /2` indirect call and `FF /4` indirect jump: decoded for instruction-length parity, then marked unsupported in IR pending indirect dispatch metadata/runtime support.
- `FF /6` push r/m: decoded and lifted as `IrOp::Push`.
- `inc`/`dec`: register opcodes `40-4F` and `FF /0`/`FF /1` decode and lift as `IrOp::Inc`/`IrOp::Dec`; CF is unchanged and PF/AF/ZF/SF/OF are defined for tested 32-bit forms.
- `xchg r/m32,r32`: decoded and lifted as `IrOp::Xchg`; flags unchanged; generated 32-bit register/memory-capable swap code is compile/run checked for a register fixture.
- `movzx r32,r/m8` and `movsx r32,r/m16`: decoded and lifted as `IrOp::Movzx`/`IrOp::Movsx`; generated code is compile/run checked for register-source fixtures with explicit partial-register reads.
- `not r/m32` and `neg r/m32`: decoded and lifted as explicit IR ops for tested 32-bit forms. `not` leaves flags unchanged. `neg` uses subtract-from-zero flag semantics for generated output and flag metadata.
- `adc r/m32,r32`, `adc r/m32,imm8`, `sbb r/m32,r32`, and `sbb r/m32,imm8`: decoded and lifted as explicit IR ops for tested 32-bit forms; IR records CF as a read and generated code uses dedicated carry/borrow flag helpers.
- `shl`/`shr`/`sar`/`rol`/`ror` one-bit 32-bit forms: decoded, lifted, and generated for count-one fixtures. Multi-bit immediate and CL-count forms decode for parity but intentionally emit visible unsupported diagnostics until flag semantics are verified for those counts.
- `setcc r8` and simple `cmovcc r32,r/m32`: decoded and lifted with condition flag reads. Generated `setcc` supports register byte destinations through partial-register writes; generated `cmovcc` supports tested 32-bit destination registers.
- unsupported bytes: lifted as explicit unsupported IR records with diagnostics.

Evidence basis: current decoder unit tests, Phase 2 IR/flag unit tests, Phase 8 stack unit/generated tests, Phase 9 memory/group opcode tests, Capstone decode verifier for byte decoding, Ghidra MCP function-boundary evidence for the BFV export slice, pcrecomp lifter/runtime-boundary comparison notes, and Intel/AMD manual rules as the authority for future semantic expansion.

Not claimed: memory-source `movzx`/`movsx` generated behavior, broad byte/word arithmetic codegen, multi-bit or CL-count shift/rotate semantics, `rcl`/`rcr`/`sal`, memory-destination `setcc`, x87/SSE, segment overrides, or BFV runtime behavior.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

<!-- AETHERX86-1.0:Phase 31 IA-32 semantic expansion completion -->
## Phase 31 IA-32 semantic expansion completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: reduce the next high-value BFV blockers with universal IA-32 semantics only, not BFV-specific decoding branches.

Implemented surface:
- `ret imm16` (`C2 iw`).
- `leave` (`C9`) lifted to explicit frame teardown code.
- `mov r8, imm8` (`B0..B7`) with partial-register-safe write emission for generated C.
- Accumulator immediate arithmetic/logic forms (`04/05/0C/0D/14/15/1C/1D/24/25/2C/2D/34/35/3C/3D`).
- 8-bit ModRM arithmetic/logic forms and `test r/m8, r8` (`84 /r`).
- `mov r/m8, imm8` (`C6 /0 ib`) in addition to existing 32-bit immediate moves.

Verification:
- Unit tests cover decode, lift, and generated C output for the newly supported forms.
- Capstone decode and PE-slice verifier tests pass with Capstone 5.0.7 available in the environment.
- Mock BFV unsupported histogram improved from the earlier baseline of 3,004,248 decoded slots / 2,189,413 supported / 814,835 unsupported to 2,750,940 decoded slots / 2,310,829 supported / 440,111 unsupported in this build.

