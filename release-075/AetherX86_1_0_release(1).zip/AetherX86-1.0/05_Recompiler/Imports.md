# Imports

## Classification
- Kind: recompiler design contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

## Phase 11 import-pointer shim preparation
The seed now has a universal path for indirect import-pointer calls:

```text
call dword ptr [iat_slot]
  -> IrOp::IndirectCall
  -> PatchKind::IndirectImportShim keyed by callsite VA
  -> generated runtime_import_pointer_shim(callsite, resolved_pointer, symbol)
  -> runtime import-shim registry lookup by resolved pointer and symbol
```

Implemented-and-tested for synthetic fixtures only. For Battlefield Vietnam, the entrypoint callsite at VA `0x007C1BEF` is metadata-linked to IAT RVA `0x00742238` / `KERNEL32.dll!GetVersionExA`, but the repo does not yet contain an ABI-checked target manifest record or a Win32 shim implementation.

## Phase 12 manifest-backed import fixture
The synthetic import-pointer path can now be driven by a tracked manifest fixture:

```text
patch kind=indirect_import_shim va=0x00401000 symbol=demo_indirect_import_shim abi= reason=synthetic_phase12 evidence=synthetic_hex_fixture rollback=remove_record enabled=true
```

This is still universal test metadata. BFV import records remain blocked until Phase 13 records ABI and side-effect expectations for the shim boundary.

## Phase 13 ABI-aware import boundary
The synthetic import-shim path now requires ABI metadata before generated code can route through an import shim:

```text
patch kind=indirect_import_shim va=0x00401000 symbol=demo_indirect_import_shim abi=stdcall reason=synthetic_phase12 evidence=synthetic_hex_fixture rollback=remove_record enabled=true
```

Generated code now calls `runtime_import_pointer_shim_abi(..., "symbol", "stdcall")` for manifest-backed indirect import-pointer calls. Runtime dispatch logs `import_abi_mismatch` when an import binding exists for the target and symbol but not for the requested ABI.

BFV status: the entrypoint callsite remains metadata-only evidence for `KERNEL32.dll!GetVersionExA`. No BFV manifest record or Win32 behavior claim is committed yet.

## Phase 14 import classification
The function catalog now classifies PE import facts separately from callsite facts:

- `import_iat` for ordinary PE import address table entries.
- `delay_import_iat` for delay-import address table entries.
- `indirect_callsite` for bounded CFG indirect calls.
- `manifest_import_pointer_callsite` for manifest-backed indirect import-pointer callsites.

This prevents the catalog from treating an IAT slot, an indirect call instruction, and a normal direct call target as the same kind of function evidence.

## Phase 25 import binding resolver
Implemented-and-tested in the C++ seed:

- `resolve_import_bindings` bridges inspected PE imports, `entry_import_shim` records, and `runtime_init_import_pointer` records.
- Matching requires DLL/symbol plus IAT VA/RVA agreement. PE import facts provide the source IAT; entry metadata provides callsite/ABI/side-effect intent; runtime-init metadata provides the shim target VA.
- `format-import-bindings <pe> <entry_import_manifest> <runtime_init_manifest>` emits deterministic binding summaries and diagnostics.
- Visible diagnostics cover missing PE imports, missing runtime-init records, duplicate import names, ordinal-only imports, ABI mismatch, side-effect mismatch, and unsupported side-effect metadata.
- The synthetic generated `GetVersionExA` harness now requires a resolver success before compiling and running generated code.

BFV status: the entrypoint `KERNEL32.dll!GetVersionExA` binding resolves as safe metadata, while unrelated WSOCK32/OLEAUT32 ordinal-only imports remain visible diagnostics. No BFV import execution or Win32 behavior is claimed.

## Phase 27 integrated import-pointer bring-up
The integrated synthetic bring-up fixture now requires PE import-table facts, an `entry_import_shim` record, and a `runtime_init_import_pointer` record to agree before generated code is compiled and run. The synthetic generated pack then reads the IAT slot, dispatches through `runtime_import_pointer_shim_abi`, and reaches a controlled `GetVersionExA` callback only after `runtime_apply_import_pointer_init` has initialized the slot.

BFV status: the same metadata path still resolves the entrypoint `GetVersionExA` binding and preserves 28 unrelated ordinal-only import diagnostics. This is readiness evidence only; no BFV import is executed.

<!-- AETHERX86-1.0:Phase 29 import IAT application completion -->
## Phase 29 import IAT application completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move import handling from binding summaries into controlled loaded-image IAT writes, while keeping ordinal imports explicit and non-silent.

Implemented surface:
- `apply-pe-imports <pe> <runtime_init_manifest> [mapped_base]` CLI.
- `xr::apply_imports_to_loaded_image` and `xr::format_pe_import_apply_result` API.
- Name-import and delay-import IAT writes sourced from validated runtime-init manifests.
- Duplicate, missing, and malformed manifest validation before image mutation.
- Ordinal-only imports produce explicit diagnostics and do not receive guessed addresses.

Verification:
- Synthetic ordinary import and delay-import IAT writes are checked byte-for-byte in the loaded image.
- Synthetic ordinal import fixture fails with the diagnostic `ordinal import requires explicit non-name policy`.

<!-- AETHERX86-1.0:Phase 32 Win32 shim boundary completion -->
## Phase 32 Win32 shim boundary completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move the synthetic `GetVersionExA` import-pointer callback into a small tested Win32 shim boundary without claiming full Windows emulation.

Implemented surface:
- `runtime_win32_builtin_callback` resolves builtin callbacks by case-insensitive Win32 symbol name.
- `runtime_apply_builtin_import_pointer_init` applies runtime-init records and fills builtin callbacks when available.
- `runtime_win32_get_version_ex_a` implements a minimal stdcall-shaped `OSVERSIONINFOA` write: success return, Windows XP-era version fields, and unchanged behavior when memory validation fails.
- Byte-level runtime memory helpers support shim structure writes.

Verification:
- Runtime unit test initializes a `KERNEL32.dll!GetVersionExA` import pointer through the builtin resolver, calls it, and checks that the version structure is written.
- Scope remains intentionally narrow: no BFV execution/playability claim and no broad Win32 API emulation claim.

