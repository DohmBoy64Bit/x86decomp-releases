# Function Discovery

## Classification
- Kind: recompiler design contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Phase 3 seed support
Function discovery is currently limited to a caller-supplied entrypoint inside a caller-supplied byte range. This intentionally avoids claiming whole-program function recovery before range bounds, imported thunk handling, and target verifier workflows are ready.

The seed records direct call targets separately from same-function block successors. That follows pcrecomp's recursive-descent lesson while avoiding accidental callee merging in the first C++ implementation.

Next requirements before claiming broader function discovery:
- recover candidate function starts from direct calls and prologue patterns only inside bounded executable ranges;
- keep progress reporting and time/range limits for BFV-scale scans;
- compare selected function boundaries against Ghidra MCP evidence when target-specific claims are needed;
- record unresolved indirect calls/jumps and import thunks as blockers or manifest facts, never silent fallthroughs.

## Phase 14 function catalog seed
Implemented-and-tested in the C++ seed:

- `FunctionCatalogEntry` records entry VA/RVA, source, confidence, section, kind, symbol, and evidence.
- PE-only catalog seeding records PE entrypoint, exports, import IAT entries, and delay-import IAT entries.
- Bounded CFG catalog seeding records the caller-provided entry, direct call targets, and indirect callsites.
- Manifest seeding records patch/import-shim starts, including `manifest_import_pointer_callsite` for indirect import metadata.
- CLI commands `function-catalog <pe>` and `function-catalog-slice <pe> <rva> <size> [manifest]` provide reproducible metadata-only reports.

Known limits: this is not whole-program recursive function discovery, not prologue scanning, not Ghidra import/export ingestion, and not BFV function-boundary proof beyond the bounded slice facts being reported.

## Phase 18 function-pack manifest boundary
The function-pack manifest is now the persistent selection boundary for generated packs. It records PE identity plus selected function VA/RVA/size/source/confidence/section/evidence/rollback/enabled fields, then revalidates each enabled function through PE inspection and bounded slice analysis before codegen.

This does not replace function discovery. It only persists verified candidates from another source, such as synthetic fixtures, prior bounded slice work, or future Ghidra-imported evidence. Duplicate functions, missing evidence, image-base/hash mismatches, section mismatches, out-of-section slices, unsupported IR, and non-generated candidates are visible validation issues.

Known limits: no Ghidra boundary import path, prologue scanner, recursive call graph expansion, or whole-BFV function recovery is claimed.

## Phase 19 Ghidra boundary import
The seed now parses a small Ghidra-derived boundary format with `ghidra_function` records. Each enabled record carries VA/RVA, function name, source tool, confidence, evidence, optional bounded size, optional verifier marker, and enabled state.

Implemented-and-tested:
- `format-ghidra-boundaries <pe> <manifest>` validates and summarizes imported records against PE section facts;
- `function-catalog-ghidra <pe> <manifest>` seeds `kind=ghidra_function_boundary` catalog entries without claiming source truth;
- `emit-cfg-c-pack-ghidra <pe> <manifest>` converts only bounded `verifier=capstone_x86recomp` records into the existing function-pack manifest path, which then revalidates generated-candidate status before codegen.

Known limits: Ghidra evidence is verifier metadata only. This is not a broad Ghidra XML/JSON exporter, not whole-program discovery, and not proof that an imported BFV boundary is safe to execute.

## Phase 20 call-boundary pack use
Function discovery still does not recover whole-program call graphs. Phase 20 only consumes direct-call targets already recorded by bounded CFGs. If a target is also a verified generated pack entry, generated code dispatches to that generated callee; otherwise the call remains an unresolved runtime boundary.

Known limits: no recursive expansion, no automatic callee selection, no import-thunk resolution, and no BFV call graph claim.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.

<!-- AETHERX86-1.0:Phase 30 generated dispatch completion -->
## Phase 30 generated dispatch completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: replace pack-local direct-call emission with a deterministic generated dispatch boundary that can grow into chunked generated functions.

Implemented surface:
- Generated packs now emit `generated_function_record`, `k_generated_functions`, and `generated_dispatch(ctx, rt, target)`.
- Pack-local direct calls route through `generated_dispatch` instead of hardwired direct subroutine calls.
- Runtime direct-call fallback is retained when the target is outside the generated pack.
- `format-generated-dispatch-raw` CLI exposes dispatch metadata for raw fixtures.

Verification:
- Existing direct-call generated-pack tests now assert dispatch-table output and generated dispatch invocation.
- New CLI smoke evidence writes a generated dispatch summary for a tiny raw pack.

