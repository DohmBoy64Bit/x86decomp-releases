# IRDesign

## Classification
- Kind: recompiler design contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Phase 2 seed IR
The current seed IR is deliberately small and literal. `IrOp` names the operation family; operands reuse the decoder's structured register/immediate/memory/relative records; `IrFlagEffects` records flag writes and reads without hiding unsupported semantics.

This shape follows pcrecomp's useful lessons without copying its direct-C lifter: preserve original addresses, snapshot/record flag-producing operations before consumers, keep partial-width operands visible, and emit visible unsupported records. AetherX86 keeps a stable IR boundary so future CFG and emitter work can consume records without being tied to one generated-C style.

Implemented-and-tested: a CLI formatter, `lift-ir-raw`, and unit coverage for `mov`, arithmetic/logical ops, `cmp`, `test`, direct branch flag reads, `nop`, `ret`, and unsupported bytes.

Phase 10 implemented-and-tested: indirect `call r/m32` and indirect `jmp r/m32` no longer collapse into unsupported IR when the decoder already has a valid operand. The lifter preserves them as explicit `IndirectCall` and `IndirectJump` IR operations with visible diagnostics describing the unresolved runtime-dispatch requirement. This follows pcrecomp's ICALL-trace lesson conceptually while keeping AetherX86's C++20 IR boundary intact.

Blocked/future: SSA, full memory effects, full stack/calling-convention effects, target-manifest classification for indirect calls, and generated dispatch tables.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
