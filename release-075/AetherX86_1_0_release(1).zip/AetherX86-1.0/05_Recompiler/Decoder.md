# Decoder

## Filled contract
Decode IA-32 bytes with exact length, prefixes, ModRM/SIB, immediates, displacements, raw bytes, and diagnostics. The seed supports only a tiny starter subset; full support must be incremental and tested. Never infer semantics in the decoder.

## Current seed support
The Phase 1 decoder records structured operands for registers, immediates, memory references, and direct relative branches. It has verified coverage for the starter subset, ModRM/SIB memory forms, direct `call`/`jmp`/`jcc`, tested operand-size prefix handling, 8-bit register moves, arithmetic/logical ModRM forms, `test`, group-1 immediate forms, `push r32`, `pop r32`, `push imm32`, sign-extended `push imm8`, `A0-A3` accumulator moffs moves, `C7 /0` move immediate to r/m, and selected `FF` group-5 decode forms in 32-bit mode. Every expanded form must be added to both C++ tests and the Capstone verifier before it is treated as supported.

Phase 8 evidence: C++ tests cover stack register ranges, immediate push decoding, sign-extension for `6A FC`, and truncated `68` input. Capstone 5.0.7 verifies 33 decode fixtures in x86 32-bit mode, including the new stack fixtures.

Phase 9 evidence: C++ tests cover moffs moves, `C7 /0`, `FF /2` indirect call, `FF /4` indirect jump, `FF /6` push, and malformed/truncated inputs. Capstone 5.0.7 verifies 39 decode fixtures in x86 32-bit mode. BFV entrypoint-slice decode now matches Capstone instruction count for the bounded 64-byte slice.

Phase 15 evidence: C++ tests and Capstone 5.0.7 cover register `inc`/`dec` opcodes `40-4F`, `FF /0` and `FF /1`, `xchg r/m32,r32`, `movzx r32,r/m8`, and `movsx r32,r/m16`. Capstone now verifies 46 decode fixtures.

Phase 17 evidence: C++ tests and Capstone 5.0.7 cover `F6/F7` group-3 `not`/`neg`, `adc`/`sbb` ModRM and group-1 immediate forms, selected group-2 shifts/rotates (`shl`, `shr`, `sar`, `rol`, `ror`), `setcc`, and `cmovcc`. Capstone now verifies 59 decode fixtures in x86 32-bit mode. Unsupported group-2 subops and unsupported group-3 subops consume their full instruction where known so later decode remains aligned.

Known limits: this is decoding only, not lifted semantics. Segment overrides, address-size override, x87/SSE, flags, indirect control flow semantics, function discovery, and CFG construction remain future work.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.

<!-- AETHERX86-1.0:Phase 31 IA-32 semantic expansion completion -->
## Phase 31 IA-32 semantic expansion completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: reduce the next high-value BFV blockers with universal IA-32 semantics only, not BFV-specific decoding branches.

Implemented surface:
- `ret imm16` (`C2 iw`).
- `leave` (`C9`) lifted to explicit frame teardown code.
- `mov r8, imm8` (`B0..B7`) with partial-register-safe write emission for generated C.
- Accumulator immediate arithmetic/logic forms (`04/05/0C/0D/14/15/1C/1D/24/25/2C/2D/34/35/3C/3D`).
- 8-bit ModRM arithmetic/logic forms and `test r/m8, r8` (`84 /r`).
- `mov r/m8, imm8` (`C6 /0 ib`) in addition to existing 32-bit immediate moves.

Verification:
- Unit tests cover decode, lift, and generated C output for the newly supported forms.
- Capstone decode and PE-slice verifier tests pass with Capstone 5.0.7 available in the environment.
- Mock BFV unsupported histogram improved from the earlier baseline of 3,004,248 decoded slots / 2,189,413 supported / 814,835 unsupported to 2,750,940 decoded slots / 2,310,829 supported / 440,111 unsupported in this build.

