# BFV Tool Workflow

## Classification
- Kind: target-support workflow
- Disposition: conditional guidance for using `bfvtool` when Battlefield Vietnam file-format evidence supports static recompilation.

## Purpose
Use `bfvtool` to inspect Battlefield Vietnam archives, scripts, assets, and dependency chains only when that evidence helps x86recomp work: target manifests, import/runtime shim design, asset paths referenced by code, generated-code tests, or Battlefield Vietnam milestone reports.

## Build
From the x86recomp workspace root, build the tool from source and place outputs under the matching tool directory:

```bash
cmake -S tools-source/bfvtool -B tools/bfvtool
cmake --build tools/bfvtool --config Debug
```

Use `tools/bfvtool/Debug/bfvtool.exe` for Visual Studio multi-config builds. On single-config generators, use the executable produced directly under `tools/bfvtool` or its generator-specific subdirectory.

## Use When Relevant
- `bfvtool rfa list <archive.rfa>` or `bfvtool rfa info <archive.rfa>` to summarize local archive contents.
- `bfvtool template build <archive.rfa> <con_path>` to inspect object template/script relationships.
- `bfvtool asset resolve <archive.rfa> <con_path>` to resolve mesh/material/texture dependencies referenced by game logic.
- `bfvtool sm info`, `rs info`, `terrain info`, `wst info`, `lsb info`, `ssc info`, `fx info`, and related commands to produce shareable metadata summaries.

## Guardrails
- Do not commit Battlefield Vietnam archives, extracted files, executable bytes, assets, cracks, serials, or local install paths.
- Prefer command output summaries, hashes, counts, dimensions, dependency names, and manifests over extracted content.
- Tie every `bfvtool` use back to a static recompilation purpose. If it only advances a clean-room engine or asset viewer, record it as out of scope unless the user explicitly expands the task.
- Document command, input category, output summary, and how the finding affects PE metadata, function discovery, runtime shims, asset dependency, generated-code tests, or a Battlefield Vietnam milestone.
