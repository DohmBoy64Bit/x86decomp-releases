# Battlefield Vietnam Plan

## Filled contract
Use a legally owned local Battlefield Vietnam install. Record hash, PE facts, sections, imports, entrypoint, and blockers in a local manifest. Milestones: inspect PE, decode entrypoint, emit tiny function, build runtime skeleton, compare traces, reach menu, reach offline frame loop.

## Dual-purpose mission
Battlefield Vietnam is not a side project and not the whole architecture. Use it as the concrete target that forces x86recomp to become real: every PE, decoder, lifter, CFG, emitter, runtime, import-shim, and game-format feature should either improve the general recompiler or be recorded as Battlefield Vietnam-specific target metadata.

Ultimate test case: statically recompile enough of Battlefield Vietnam from a legally owned local install to prove x86recomp's generated code, runtime shims, and target metadata under an actual Win32 game workload. Do not claim this milestone until build, runtime, and trace evidence prove it.

Game-format reverse engineering is allowed only when it supports this goal: archive/script/asset facts may guide imports, runtime shims, dependency manifests, test fixtures, or trace interpretation, but proprietary files must never be committed.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.

## First-trace preparation
The seed now supports metadata-only bounded PE slice analysis with:

```text
x86recomp analyze-pe-slice <pe> <rva> <size>
```

Use this for Battlefield Vietnam only on a legally owned local executable. The command reports RVA, VA, file offset, section name, decoded instruction count, supported/unsupported count, unsupported IR count, unsupported opcode histogram, CFG block/call counts, CFG completeness, and whether the slice is currently a generated-code candidate. It does not print raw bytes and must not write BFV bytes into the repository.

Current BFV smoke evidence from local `BfVietnam.exe` entrypoint slice after Phase 10 indirect-call modeling:

- RVA: `0x003C1BCF`
- VA: `0x007C1BCF`
- size: 64 bytes
- section: `.text`
- x86recomp decoded slots: 17
- supported slots: 17
- unsupported slots: 0
- unsupported IR: 0
- unsupported opcode kinds: 0
- indirect CFG call sites: 1
- Capstone 5.0.7 decoded instructions for the same slice: 17
- count match: true
- generated candidate: false

This is now a target-classification/runtime blocker rather than a decoder or unsupported-IR blocker. The remaining indirect callsite is explicit CFG/runtime metadata. PE import evidence maps IAT RVA `0x00742238` to `KERNEL32.dll!GetVersionExA`; Ghidra MCP disassembly of the entrypoint range reports `CALL dword ptr [0x00b42238]` at VA `0x007C1BEF`; Ghidra bulk xrefs report a READ from `0x007C1BEF` to `0x00B42238`; and `audit_globals_in_function` names that global `PTR_GetVersionExA_00b42238`. A future shim/manifest record still needs ABI and side-effect evidence before execution is claimed.

Phase 11 adds universal synthetic support for callsite-keyed indirect import-shim metadata. This is enough to represent the BFV entrypoint `GetVersionExA` callsite as a future manifest candidate, but no BFV target manifest entry is committed yet because ABI and side-effect evidence are still required before executing a Win32 shim.

Phase 13 adds universal ABI-aware import-shim dispatch and a synthetic `GetVersionExA`-shaped runtime-memory test. The BFV entrypoint `GetVersionExA` callsite remains metadata-only: the safe smoke command still reports one indirect CFG call and `slice_generated_candidate=false`. No BFV generated source, raw bytes, executable, assets, runtime behavior, menu reach, frame loop, or playability is claimed.

Phase 14 adds safe BFV catalog smoke output. `function-catalog-slice` on the entrypoint slice reports 388 metadata entries for the local PE32 executable, including the PE entrypoint, the bounded indirect callsite at VA `0x007C1BEF`, and the IAT entry `KERNEL32.dll!GetVersionExA` at VA `0x00B42238`. This is classification evidence only; no BFV target manifest record or execution behavior is claimed.

Ghidra MCP first generated-code candidate evidence:

- Ghidra program: `BfVietnam.exe`
- Ghidra function count: 24,551
- Function: export/destructor-equivalent at VA `0x0048E510`, RVA `0x0008E510`
- Ghidra listing summary: two instructions, `mov dword ptr [ECX], imm32; ret`
- x86recomp slice size: 7 bytes
- x86recomp decoded slots: 2
- Capstone 5.0.7 decoded slots: 2
- count match: true
- unsupported slots: 0
- unsupported IR: 0
- generated candidate: true
- local generated-code compile/run: passed under `09_ProjectSeed/x86recomp/build/bfv_export_0048e510_compile`

No BFV raw bytes or generated BFV source are committed. This is generated-code shape evidence for a tiny function slice, not Battlefield Vietnam runtime behavior, menu reach, frame loop, or playability.

## Phase 16 generated pack smoke
Phase 16 expands the local-only BFV generated-code smoke from one tiny function to a three-function pack, still without committing BFV bytes or generated BFV source.

Selected candidates:
- VA `0x00401070`, RVA `0x00001070`, Ghidra function `FUN_00401070`;
- VA `0x0048E510`, RVA `0x0008E510`, Ghidra function `~IHostService`;
- VA `0x00874080`, RVA `0x00474080`, Ghidra function `FUN_00874080`.

Evidence:
- Ghidra MCP `disassemble_bytes` reports each selected start as `mov dword ptr [ECX], imm32; ret` followed by `INT3` padding.
- Ghidra MCP `search_instructions` associates each selected start with a function name.
- `x86recomp analyze-pe-slice` reports each seven-byte slice as 2 decoded instructions, 2 supported instructions, 0 unsupported decode slots, 0 unsupported IR records, complete CFG, and `slice_generated_candidate=true`.
- Capstone 5.0.7 reports a matching two-instruction count for each bounded slice.
- `emit-cfg-c-pack-slices` generated one disposable pack with debug maps preserving VAs `0x00401070`, `0x0048E510`, and `0x00874080`.
- The generated BFV pack compiled and ran under `09_ProjectSeed/x86recomp/build/bfv_phase16_pack`.

Known limit: this is compile/run evidence for isolated generated snippets under synthetic runtime memory only. It is not BFV process initialization, import execution, object construction correctness, menu reach, frame loop, or playability.

## Phase 17 lifter remainder smoke
Phase 17 reran BFV-safe metadata only after adding universal high-value opcode-family support. The full unsupported histogram over executable sections reported:

- decoded slots: 3,004,248
- supported slots: 2,189,413
- unsupported slots: 814,835
- unsupported opcode kinds: 165

This is a prioritization signal, not exact function coverage. `F6`, `F7`, `C1`, `D1`, and `D3` can still appear in the unsupported histogram when the target bytes use unimplemented subops, byte/word forms, multi-bit/CL counts, or other unverified forms. A bounded metadata-only slice at RVA `0x00001070`, size 16, reports `INT3` padding after the tiny candidate and remains non-generated for that larger padded range. No BFV generated source, raw bytes, executable behavior, menu reach, frame loop, or playability is claimed.

## Phase 18 function-pack manifest smoke
Phase 18 persists the Phase 16 BFV tiny candidate inputs as a temporary metadata-only function-pack manifest under the ignored build tree:

- image: local `BfVietnam.exe`
- image base: `0x00400000`
- FNV-1a64 file hash: `0xC83D9C86E790C6E0`
- selected records: VA/RVA/size triples `0x00401070`/`0x00001070`/7, `0x0048E510`/`0x0008E510`/7, and `0x00874080`/`0x00474080`/7
- command: `x86recomp format-function-pack-manifest 09_ProjectSeed/x86recomp/build/bfv_phase18.functionpack`
- result: `function_pack_functions: 3` and `function_pack_issues: 0`

This is safe target metadata only. No BFV generated source, raw bytes, committed target manifest, executable behavior, menu reach, frame loop, or playability is claimed.

## Phase 19 Ghidra boundary import smoke
Phase 19 imports BFV Ghidra-derived boundary evidence as safe metadata only. A temporary build-tree manifest `bfv_phase19_ghidra.boundaries` records:

- bounded candidates: `FUN_00401070`, `IHostService_dtor` at VA `0x0048E510`, and `FUN_00874080`, each with size 7 and `verifier=capstone_x86recomp`;
- unbounded entrypoint blocker: `entry` at VA `0x007C1BCF`, RVA `0x003C1BCF`, without size so it cannot become a generated-pack candidate.

Evidence:
- Ghidra MCP `disassemble_bytes` reports each bounded candidate as `MOV dword ptr [ECX], imm32; RET` followed by `INT3` padding.
- `capstone_slice_verify.py` reports count match true and `generated_candidate=true` for each bounded seven-byte candidate.
- The BFV entrypoint slice remains count match true but `generated_candidate=false`.
- `format-ghidra-boundaries` reports `ghidra_boundary_functions: 4` and `ghidra_boundary_issues: 0`.
- `function-catalog-ghidra` adds `ghidra_function_boundary` catalog entries for the three bounded candidates plus the entrypoint blocker.

This is not a committed BFV target manifest, not generated BFV source, not execution, and not a playability claim.

## Phase 20 multi-function call-boundary smoke
Phase 20 compile-checks the existing three bounded BFV tiny candidates through the Ghidra-boundary pack path under ignored build artifacts:

- temporary manifest: `09_ProjectSeed/x86recomp/build/bfv_phase20_bounded_ghidra.boundaries`
- generated scratch project: `09_ProjectSeed/x86recomp/build/bfv_phase20_pack`
- result: generated pack configured, built, and ran successfully
- debug maps: three `debug_function_map` entries and no `debug_direct_call_map` entries

Interpretation: the Phase 20 BFV smoke proves the pack still compiles after adding direct-call dispatch machinery. It does not claim any verified BFV internal direct-call relationship, runtime behavior, menu reach, frame loop, or playability.

## Phase 21 entry import-shim metadata smoke
Phase 21 persists the BFV entrypoint `GetVersionExA` indirect import call as metadata only under ignored build artifacts:

- temporary manifest: `09_ProjectSeed/x86recomp/build/bfv_phase21_entry_import_shims.manifest`
- DLL/symbol: `KERNEL32.dll!GetVersionExA`
- IAT: VA `0x00B42238`, RVA `0x00742238`
- callsite: VA `0x007C1BEF`, RVA `0x003C1BEF`
- ABI: `stdcall`
- side-effect model: `version_info_write`

Evidence:
- `x86recomp inspect` maps `KERNEL32.dll!GetVersionExA` to IAT RVA `0x00742238`.
- Ghidra MCP `disassemble_bytes` for VA `0x007C1BCF`, length 64, reports `CALL dword ptr [0x00b42238]` at VA `0x007C1BEF`.
- `x86recomp analyze-pe-slice` for RVA `0x003C1BCF`, size 64, still reports 17 decoded instructions, one indirect call, incomplete CFG, and `slice_generated_candidate=false`.
- `x86recomp format-entry-import-shims` reports `entry_import_shim_issues: 0`.

Interpretation: this models the entrypoint import-shim boundary safely. It does not execute BFV, load the BFV image, commit BFV bytes/generated source, prove Win32 behavior, reach a menu, render a frame, or claim playability.

## Phase 22 import-pointer binding smoke
Phase 22 keeps BFV as metadata-only evidence while adding a universal runtime setup helper for the same class of import-pointer call:

- helper: `runtime_bind_import_pointer_shim_abi`
- setup operation: write a selected shim target to a mapped IAT VA and register the ABI-aware shim callback
- synthetic proof: the generated `GetVersionExA` pack harness now uses the helper instead of open-coding IAT writes plus registration
- failure proof: unit tests show an unmapped IAT slot fails with `memory_fault`

BFV interpretation: the existing `KERNEL32.dll!GetVersionExA` IAT/callsite metadata is closer to a runtime initialization plan, but it is still not executed. BFV still needs PE image memory setup, stack/ABI validation, real side-effect modeling, and target manifest policy before any entrypoint execution claim.

## Phase 23 runtime-init manifest smoke
Phase 23 persists the BFV entrypoint `GetVersionExA` import-pointer setup as metadata only under ignored build artifacts:

- temporary manifest: `09_ProjectSeed/x86recomp/build/bfv_phase23.runtimeinit`
- image: local `BfVietnam.exe`
- image base: `0x00400000`
- FNV-1a64 file hash: `0xC83D9C86E790C6E0`
- DLL/symbol: `KERNEL32.dll!GetVersionExA`
- IAT: VA `0x00B42238`, RVA `0x00742238`
- shim target filler: VA `0x00510000`
- ABI: `stdcall`
- side-effect model: `version_info_write`

Evidence:
- `x86recomp format-runtime-init 09_ProjectSeed/x86recomp/build/bfv_phase23.runtimeinit 0x00400000 0x00A25000` reports `runtime_init_issues: 0`.
- Ghidra MCP is connected to the `BFV` project with `BfVietnam.exe` open.
- Ghidra `disassemble_bytes` for VA `0x007C1BCF`, length 64 confirms `CALL dword ptr [0x00b42238]` at VA `0x007C1BEF`.

Interpretation: the BFV import-pointer setup can now be represented as PE-bound runtime-init metadata. It still is not executed. BFV still needs PE image memory mapping, resolver policy, stack/ABI harnessing, real side-effect safety, and target manifest policy before entrypoint execution can be attempted.

## Phase 24 image-layout metadata smoke
Phase 24 records the BFV PE section layout as metadata only:

- command: `x86recomp format-pe-image-map "C:\Program Files (x86)\EA GAMES\Battlefield Vietnam\BfVietnam.exe"`
- image base: `0x00400000`
- size of image: `10637312`
- sections: `.text`, `.rdata`, `.data`, `.tls`, `.rsrc`
- result: `pe_image_map_issues: 0`

Evidence:
- `.text` reports VA `0x00401000`, RVA `0x00001000`, raw size `7605760`, virtual size `7605547`, readable/executable.
- `.rdata` reports VA `0x00B42000`, RVA `0x00742000`, raw size `1439232`, virtual size `1438774`, readable.
- `.data` reports VA `0x00CA2000`, RVA `0x008A2000`, raw size `638464`, virtual size `1576260`, readable/writable.
- Ghidra MCP reports the open BFV program uses a 32-bit byte-addressed `ram` address space.

Interpretation: the BFV image layout is ready as safe metadata for a future target-safe loader, but Phase 24 does not map BFV bytes, apply relocations, bind imports, execute code, or claim runtime behavior.

## Phase 25 import-binding metadata smoke
Phase 25 bridges the BFV PE import table, entry import-shim metadata, and runtime-init metadata:

- temporary entry manifest: `09_ProjectSeed/x86recomp/build/bfv_phase25_entry_import.manifest`
- temporary runtime-init manifest: `09_ProjectSeed/x86recomp/build/bfv_phase25.runtimeinit`
- resolved binding: `KERNEL32.dll!GetVersionExA`
- IAT: VA `0x00B42238`, RVA `0x00742238`
- callsite: VA `0x007C1BEF`, RVA `0x003C1BEF`
- shim target filler: VA `0x00510000`
- ABI: `stdcall`
- side-effect model: `version_info_write`

Evidence:
- `x86recomp format-import-bindings ...` reports `import_bindings: 1` for `GetVersionExA`.
- The same report intentionally keeps 28 unrelated ordinal-only import diagnostics visible for BFV `WSOCK32.dll` and `OLEAUT32.dll` imports.
- Ghidra MCP `disassemble_bytes` at VA `0x007C1BEF`, length 6 confirms `CALL dword ptr [0x00b42238]`.

Interpretation: the entrypoint import-pointer binding is now deterministically summarized from PE plus metadata. This still does not execute the import, load the BFV image, implement Win32 behavior, or claim BFV runtime progress.

## Phase 26 runtime-start metadata note
Phase 26 keeps BFV entrypoint startup as metadata only while adding the universal synthetic stack/ABI harness:

- temporary manifest: `09_ProjectSeed/x86recomp/build/bfv_phase26.runtime_start`
- entry VA: `0x007C1BCF`
- enabled: `false`
- purpose: record that BFV entrypoint execution is still blocked while synthetic generated entry calls are now testable

Evidence:
- `x86recomp format-runtime-start 09_ProjectSeed/x86recomp/build/bfv_phase26.runtime_start` reports `runtime_start_issues: 0` because the BFV record is disabled metadata.
- CTest `generated_runtime_start_manifest_compile` proves only a synthetic generated function can run with controlled stack preparation and a 32-bit argument write.

Interpretation: the universal runtime can now prepare a controlled synthetic stack and CPU state for generated entry-call fixtures. BFV remains blocked on a target-safe image loader, process-entry ABI model, import/runtime side-effect policy, ordinal import policy, and verified generated entrypoint pack. No BFV execution, generated BFV source, menu reach, frame loop, or playability is claimed.

## Phase 27 readiness report
Phase 27 combines the image-map, runtime-init, import-binding, stack-start, and generated-pack boundaries in one synthetic fixture. BFV use remains a readiness report only:

Satisfied metadata prerequisites:
- PE section layout reports `pe_image_map_issues: 0` for image base `0x00400000` and size of image `0x00A25000`.
- The entrypoint import binding resolves as `KERNEL32.dll!GetVersionExA`, with IAT VA/RVA `0x00B42238`/`0x00742238`, callsite VA/RVA `0x007C1BEF`/`0x003C1BEF`, ABI `stdcall`, and side-effect model `version_info_write`.
- The runtime-start metadata records BFV entry VA `0x007C1BCF` as disabled metadata and reports `runtime_start_issues: 0`.
- Ghidra MCP confirms the entrypoint callsite instruction: `CALL dword ptr [0x00b42238]` at VA `0x007C1BEF`.

Visible blockers:
- 28 unrelated ordinal-only imports remain visible for BFV `WSOCK32.dll` and `OLEAUT32.dll`.
- No BFV bytes are mapped into runtime memory.
- No BFV entrypoint generated pack is emitted or committed.
- No process-entry ABI/process-state model exists.
- No real Win32, DirectX, DirectSound, input, filesystem, timing, thread, SEH, TLS, PEB, or TEB model exists.

Interpretation: the universal synthetic bring-up path is now integrated, but BFV is still metadata-only. No BFV execution, menu reach, frame loop, or playability is claimed.

<!-- AETHERX86-1.0:Phase 32 Win32 shim boundary completion -->
## Phase 32 Win32 shim boundary completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move the synthetic `GetVersionExA` import-pointer callback into a small tested Win32 shim boundary without claiming full Windows emulation.

Implemented surface:
- `runtime_win32_builtin_callback` resolves builtin callbacks by case-insensitive Win32 symbol name.
- `runtime_apply_builtin_import_pointer_init` applies runtime-init records and fills builtin callbacks when available.
- `runtime_win32_get_version_ex_a` implements a minimal stdcall-shaped `OSVERSIONINFOA` write: success return, Windows XP-era version fields, and unchanged behavior when memory validation fails.
- Byte-level runtime memory helpers support shim structure writes.

Verification:
- Runtime unit test initializes a `KERNEL32.dll!GetVersionExA` import pointer through the builtin resolver, calls it, and checks that the version structure is written.
- Scope remains intentionally narrow: no BFV execution/playability claim and no broad Win32 API emulation claim.

