# Game Format Reverse Engineering

## Purpose

Use game-format reverse engineering only when it supports static recompilation of a Win32 executable. The main project is x86recomp; Battlefield Vietnam is the real-game test case used to drive decoder, lifter, CFG, runtime, import, and target-manifest work.

## Scope

Allowed format work:

- identify files referenced by PE imports, strings, config paths, resource loaders, or runtime shims;
- document enough archive/script/asset structure to explain executable behavior and create target metadata;
- build local-only summaries, manifests, dependency graphs, and histograms from user-owned data;
- use format facts to prioritize runtime shims and generated-code tests.
- build and use `bfvtool` per `BFVToolWorkflow.md` when Battlefield Vietnam archive, script, asset, terrain, vegetation, lightmap, sound, shader, or dependency evidence is relevant to static recompilation.

Out of scope unless explicitly requested:

- building a separate clean-room game engine;
- reproducing gameplay systems unrelated to static recompilation;
- committing original Battlefield Vietnam archives, assets, executable bytes, extracted samples, cracks, serials, or DRM bypass material.

## Evidence Rule

Every game-format claim must state:

- source file class or path pattern without proprietary sample data,
- evidence level: public docs, local observation, tool output, runtime trace, or binary analysis,
- how it affects x86recomp work: PE metadata, function discovery, import/runtime shim, asset dependency, generated-code test, or Battlefield Vietnam milestone.

If the format fact does not influence static recompilation, record it as out of scope or hand it to an OpenBFVietnam-style engine task rather than adding it to x86recomp.
