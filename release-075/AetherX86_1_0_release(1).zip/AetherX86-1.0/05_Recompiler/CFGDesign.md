# CFGDesign

## Classification
- Kind: recompiler design contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Phase 3 seed CFG
The current seed supports bounded single-entry CFG construction from raw bytes. `build_cfg(bytes, base, entry)` decodes the bounded range, lifts to IR, recursively discovers reachable block leaders from direct `jmp`/`jcc` targets and fallthroughs, splits blocks at leaders and terminators, and records edges as fallthrough, branch-taken, call-target, return, or unresolved.

Implemented-and-tested:
- conditional branch split into branch-taken and fallthrough blocks;
- direct `jmp` self-loop edge;
- direct `call` target recording without chasing the callee as an intra-function block;
- `ret` exit edges;
- unsupported bytes as unresolved terminating edges;
- entry outside the bounded range as a diagnostic.

Phase 10 implemented-and-tested: bounded CFG construction now records indirect call and indirect jump sites explicitly. Indirect calls add `indirect_call` edges and continue through fallthrough instructions; indirect jumps add `indirect_jump` edges and terminate the block. PE slice summaries report `slice_cfg_indirect_calls` and `slice_cfg_indirect_jumps`, and any unresolved indirect edge keeps `slice_cfg_complete=false`.

Known limits: no whole-PE scan, no global function catalog, no switch recovery, no import-thunk classification beyond PE/Ghidra evidence, no overlap validation beyond the bounded decoded range, and no recovered target set for indirect branches.

Phase 14 adds a separate catalog layer above bounded CFG. CFG still owns blocks and edges; the catalog consumes `direct_call_targets`, `indirect_call_sites`, and manifest records to classify starts/callsites without changing CFG ownership or pretending indirect targets are recovered.

Phase 20 keeps that ownership split. CFG records direct-call targets; generated packs may dispatch a direct call to another generated function only when the target is already present in the verified pack entry set. Otherwise generated code preserves the `runtime_direct_call` diagnostic boundary.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
