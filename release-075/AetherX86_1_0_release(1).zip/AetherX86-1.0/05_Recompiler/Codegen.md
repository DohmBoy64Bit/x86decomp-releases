# Codegen

## Classification
- Kind: recompiler design contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

Generated code is disposable output. Do not manually edit emitted C/C++ for target fixes; represent those changes as patch/hook metadata, import shims, runtime calls, or lifter/codegen fixes so the output can be regenerated.

When adding patch-aware emission, keep the generated function body literal and add stable call boundaries for replacement, before-hook, after-hook, skip-original, and import-shim dispatch.

## Phase 4 seed support
The seed can emit a self-contained C++ translation unit from a bounded `CfgFunction` with `emit_cfg_c`. The output is marked as generated/disposable, preserves original VA labels, emits direct conditional branches as `goto`, emits direct calls through a visible `direct_call` boundary, emits `return` for returns, and emits explicit traps for unsupported instructions or unresolved jumps.

Implemented-and-tested:
- `emit-cfg-c-raw <hex>` CLI command;
- generated labels named from original VAs;
- generated CPU-state shell with general-purpose registers and EFLAGS booleans;
- generated helper functions for the currently tested arithmetic/logical flag slice;
- CTest `generated_cfg_compile`, which generates a scratch translation unit and compiles it with CMake.

Known limits: generated code is compile-checked only. It is not a full runtime, does not implement real guest memory, does not execute imported APIs, does not model call/return stack ABI, and is not BFV runtime evidence.

## Phase 5 patch-aware emission
The emitter now has a patch-aware overload, `emit_cfg_c(const CfgFunction&, const PatchManifest&)`. It validates metadata before generation and emits stable runtime call boundaries for replacement, before-hook, after-hook, skip-original, trap, and import-shim records.

Implemented-and-tested:
- `emit-cfg-c-patched-raw <hex>` CLI command with synthetic fixture metadata only;
- generated helper stubs named `patch_replace`, `patch_before`, `patch_after`, `patch_skip_original`, `patch_import_shim`, and `patch_trap`;
- unit assertions for generated patch boundary text;
- CTest `generated_cfg_patched_compile`, which compiles patch-aware generated C++ from a direct-call fixture.

The generated instruction body remains literal and disposable. Target corrections must still arrive through metadata, lifter/codegen fixes, or future runtime dispatch, never hand-edited generated files.

Known limits: helper stubs are compile boundaries only. They do not execute host replacements/hooks/shims, enforce ABI, inspect CPU-state effects, or prove target behavior.

## Phase 6 runtime-bound emission
Generated C++ now includes `runtime.hpp` and accepts both `cpu_state& ctx` and `xr::runtime_context& rt`. The emitter no longer emits private CPU-state, memory, direct-call, patch, or trap stubs. Instead, generated code calls the runtime skeleton for:

- flag updates;
- guest memory reads/writes;
- unsupported instruction and unresolved-jump diagnostics;
- direct-call dispatch;
- import-shim lookup;
- replacement, before-hook, after-hook, skip-original, and trap dispatch.

CTest compiles generated code with `runtime.cpp`; the non-patched fixture is also executed as a no-trap smoke test. This is runtime-bound generated-code evidence, not target behavior evidence.

## Phase 8 stack emission
The emitter now generates runtime-bound code for 32-bit `push` and `pop`. Supported forms call `xr::runtime_push32` and `xr::runtime_pop32`; generated smoke programs initialize `ctx.esp` before calling the generated function. Non-32-bit stack forms still produce visible unsupported diagnostics.

Implemented-and-tested:
- `push imm32; pop eax; ret` generated output assertions;
- CTest `generated_stack_compile`, which compiles and executes a generated stack fixture with `runtime.cpp`.

Known limits: this is generated stack-helper evidence only. It is not a complete call/return ABI, stack-frame recovery, exception model, or Battlefield Vietnam runtime claim.

## Phase 9 memory move emission
The emitter now uses a shared generated address expression for memory operands instead of treating every memory operand as displacement-only. This lets generated code preserve base/index/displacement forms such as `[ecx]`, `[esi + 4]`, and absolute moffs addresses for the currently supported 32-bit memory move slice.

Implemented-and-tested:
- `A1/A3` moffs generated output assertions and `generated_moffs_compile`;
- `C7 /0` move-immediate-to-memory generated output assertions and `generated_mov_imm_rm_compile`;
- local generated-code compile/run for a Ghidra-confirmed BFV export slice under the ignored build tree.

Known limits: indirect calls and jumps still emit unsupported traps through IR unsupported records. This is not an import thunk, indirect-call dispatcher, ABI recovery, or Battlefield Vietnam runtime behavior claim.

## Phase 10 indirect-control-flow emission
The emitter now generates runtime-bound calls for explicit indirect control flow:

- `IrOp::IndirectCall` emits `xr::runtime_indirect_call(rt, ctx, callsite_va, target_expr)` and preserves normal fallthrough.
- `IrOp::IndirectJump` emits `xr::runtime_indirect_jump(rt, ctx, site_va, target_expr); return;`.

The generated target expression comes from the existing structured operand reader, so `call dword ptr [disp32]` reads the pointer through `runtime_read_mem32` instead of treating the operand address as a direct target. `generated_indirect_call_compile` protects this output shape. This is not an import shim or ABI recovery claim; it is the regeneration-safe boundary needed before target metadata can bind an indirect site.

## Phase 11 indirect import-shim emission
Patch-aware generated C++ now recognizes `PatchKind::IndirectImportShim` records keyed by an indirect callsite VA. For a matching `IrOp::IndirectCall`, the emitter stores the resolved pointer in a local `target`, calls `xr::runtime_import_pointer_shim(rt, ctx, callsite_va, target, symbol)`, and falls back to `xr::runtime_indirect_call` if no shim binding exists.

CTest `generated_indirect_import_shim_compile` compile-checks this generated shape from a synthetic `FF /2` fixture. This is still a metadata boundary, not a BFV import implementation or ABI proof.

## Phase 12 manifest-backed emission
Generated C++ can now be produced from a parsed manifest using `emit-cfg-c-manifest-raw <hex> <manifest>`. CTest `generated_manifest_indirect_import_compile` proves the tracked synthetic manifest fixture emits the same indirect import-shim boundary as the in-memory fixture.

## Phase 13 ABI-aware import emission
Patch-aware generated C++ now preserves manifest ABI metadata at import-shim boundaries:

- Direct import-shim patches emit `xr::runtime_import_shim_abi`.
- Indirect import-pointer patches emit `xr::runtime_import_pointer_shim_abi`.
- Both paths still fall back to the visible direct/indirect call runtime boundaries if no matching shim executes.

The generated code remains disposable and metadata-driven. ABI changes belong in the manifest record, not in hand-edited emitted C++.

## Phase 15 lifter expansion emission
Generated C++ now compile/runs a deterministic fixture for tested 32-bit `inc`, `dec`, `xchg`, register-source `movzx`, and register-source `movsx`. `inc`/`dec` save and restore `ctx.cf` around add/sub flag helper calls so CF remains unchanged. Partial-register reads for the tested `bl` and `bx` sources are emitted as masks/shifts from the owning 32-bit register.

Known limits: memory-source `movzx`/`movsx`, partial-register writes, `adc`/`sbb`, shifts/rotates, `neg`/`not`, `setcc`, and `cmovcc` still emit unsupported or are not decoded.

## Phase 16 generated function pack
Generated C++ can now be emitted as a small multi-function pack with `emit_cfg_c_pack`. The pack keeps the same runtime-bound generated-function shape as `emit_cfg_c`, emits one disposable translation unit, and adds debug map comments with function count, generated function names, entry VA, range start/end, and block count.

Implemented-and-tested:
- `emit-cfg-c-pack-raw <hex> [hex...]` CLI command for synthetic bounded functions;
- `emit-cfg-c-pack-slices <pe> <rva> <size> [rva size...]` CLI command for safe local PE slice packs that preserve original VAs;
- unit assertions for debug map text, generated call sequencing, patch-boundary preservation, and duplicate-entry rejection;
- CTest `generated_function_pack_compile`, which compiles and runs a three-function synthetic pack.

Battlefield Vietnam use remains local-only: three Ghidra-associated tiny slices were generated, compiled, and run from ignored build artifacts. No BFV generated source or raw bytes are committed.

## Phase 17 high-value lifter remainder emission
Generated C++ now compile/runs a deterministic fixture for tested 32-bit `not`, `neg`, `adc`, `sbb`, one-bit `shl`/`shr`/`sar`/`rol`/`ror`, register `setcc`, and simple `cmovcc`. `adc`/`sbb` use dedicated runtime flag helpers that include the incoming CF. `setcc r8` uses partial-register writes so `al`/`ah` destinations preserve the rest of the owning 32-bit register.

Known limits: generated output intentionally emits `runtime_unsupported` for unverified forms such as multi-bit/CL-count shifts and rotates, `rcl`/`rcr`/`sal`, memory-destination `setcc`, and unsupported widths. These are visible diagnostics, not silent no-ops.

## Phase 18 function-pack manifest emission
Generated function packs can now be emitted from a parsed function-pack manifest using `emit-cfg-c-pack-manifest <manifest>`. The manifest binds a PE path, image base, FNV-1a64 file hash, and selected function VA/RVA/size/evidence records before generated code is emitted.

Implemented-and-tested:
- CLI `format-function-pack-manifest <manifest>` validates and summarizes the manifest without emitting source;
- CLI `emit-cfg-c-pack-manifest <manifest>` emits a disposable generated pack after validation;
- CTest `generated_function_pack_manifest_compile` creates a synthetic PE/manifest in the build tree, validates it, emits a three-function pack, compiles it with `runtime.cpp`, and runs it.

Known limits: this is not a broad generated-project system, not a Ghidra boundary import format, and not a BFV generated-source commitment. BFV Phase 18 use is metadata-only manifest validation under ignored build artifacts.

## Phase 19 Ghidra boundary pack emission
Generated function packs can now be emitted from bounded Ghidra boundary records using `emit-cfg-c-pack-ghidra <pe> <manifest>`. The command accepts only records that pass Ghidra-boundary validation, require `verifier=capstone_x86recomp` when a size is present, and then flow through the Phase 18 function-pack manifest validator before codegen.

CTest `generated_function_pack_ghidra_compile` creates a synthetic PE and Ghidra-boundary manifest in the build tree, validates it, catalogs the imported boundaries, emits a generated pack, compiles it with `runtime.cpp`, and runs it.

Known limits: this is still a compile-checked generated-code boundary. Ghidra names and boundaries are evidence records, not source truth or target behavior claims.

## Phase 20 multi-function call-boundary pack
Generated packs now dispatch direct calls to generated functions when the target VA is present in the verified pack entry set. Missing direct-call targets still emit `xr::runtime_direct_call`, preserving visible runtime diagnostics.

Pack output now includes stable debug comments for:
- function entries and ranges;
- direct-call targets and whether they resolve to generated code or `runtime_direct_call`;
- indirect-call sites and their runtime boundary;
- enabled patch/shim boundaries.

CTest `generated_function_pack_direct_call_compile` compiles and runs a synthetic pack where `sub_00401000` directly calls verified generated callee `sub_00402000`. Unit tests also cover missing-target fallback diagnostics.

Known limits: this is not whole-program call graph recovery, not calling-convention validation, and not generated dispatch-table/chunk machinery. It only dispatches direct calls between functions already selected into the same verified pack.

## Phase 21 entry import-shim metadata emission
Generated code can now be driven from an entry import-shim manifest through `emit-cfg-c-entry-import-raw` and `emit-cfg-c-pack-entry-import-raw`. The manifest converts to an `IndirectImportShim` patch boundary and preserves DLL, symbol, IAT VA/RVA, callsite VA/RVA, ABI, side-effect evidence, rollback, and enabled metadata in generated debug comments.

CTest `generated_entry_import_shim_pack_compile` emits a disposable pack from a synthetic `call dword ptr [iat]` fixture, compiles a harness that registers `KERNEL32.dll!GetVersionExA` as controlled test metadata, and runs it against mapped guest memory.

Known limits: this is a generated-code boundary and synthetic harness test only. It is not a standalone generated executable with Win32 shims, not a PE loader, and not Battlefield Vietnam execution evidence.

## Phase 22 import-pointer setup harness
The synthetic generated entry-import harness now initializes the IAT slot and shim callback through `runtime_bind_import_pointer_shim_abi`. Generated function bodies remain unchanged: they still read the import pointer and call the runtime import-pointer boundary. This keeps setup in runtime-owned code and preserves generated output as disposable.

## Phase 27 integrated bring-up pack
CTest `integrated_synthetic_bringup_pack_compile` emits a disposable two-function generated pack with:

- `debug_function_map` entries for both generated functions;
- a `debug_direct_call_map` showing a direct call resolved to a pack-local generated callee;
- a `debug_indirect_call_map` preserving the runtime indirect-call boundary;
- a `debug_patch_boundary` for the import-pointer shim metadata.

The generated function body remains ordinary regenerated output. Image mapping, import-pointer binding, stack setup, and the synthetic `GetVersionExA` side effect live in the harness/runtime metadata path, not in hand-edited generated C++.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
- Generated-code tests prove patches/hooks survive regeneration without hand edits.

<!-- AETHERX86-1.0:Phase 30 generated dispatch completion -->
## Phase 30 generated dispatch completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: replace pack-local direct-call emission with a deterministic generated dispatch boundary that can grow into chunked generated functions.

Implemented surface:
- Generated packs now emit `generated_function_record`, `k_generated_functions`, and `generated_dispatch(ctx, rt, target)`.
- Pack-local direct calls route through `generated_dispatch` instead of hardwired direct subroutine calls.
- Runtime direct-call fallback is retained when the target is outside the generated pack.
- `format-generated-dispatch-raw` CLI exposes dispatch metadata for raw fixtures.

Verification:
- Existing direct-call generated-pack tests now assert dispatch-table output and generated dispatch invocation.
- New CLI smoke evidence writes a generated dispatch summary for a tiny raw pack.

<!-- AETHERX86-1.0:Phase 31 IA-32 semantic expansion completion -->
## Phase 31 IA-32 semantic expansion completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: reduce the next high-value BFV blockers with universal IA-32 semantics only, not BFV-specific decoding branches.

Implemented surface:
- `ret imm16` (`C2 iw`).
- `leave` (`C9`) lifted to explicit frame teardown code.
- `mov r8, imm8` (`B0..B7`) with partial-register-safe write emission for generated C.
- Accumulator immediate arithmetic/logic forms (`04/05/0C/0D/14/15/1C/1D/24/25/2C/2D/34/35/3C/3D`).
- 8-bit ModRM arithmetic/logic forms and `test r/m8, r8` (`84 /r`).
- `mov r/m8, imm8` (`C6 /0 ib`) in addition to existing 32-bit immediate moves.

Verification:
- Unit tests cover decode, lift, and generated C output for the newly supported forms.
- Capstone decode and PE-slice verifier tests pass with Capstone 5.0.7 available in the environment.
- Mock BFV unsupported histogram improved from the earlier baseline of 3,004,248 decoded slots / 2,189,413 supported / 814,835 unsupported to 2,750,940 decoded slots / 2,310,829 supported / 440,111 unsupported in this build.

