# Runtime

## Filled contract
Runtime owns guest memory, CPU state, imports, callbacks, Win32/DirectX/audio/input/filesystem/timing shims, and exceptions. Converter emits code; runtime makes it behave.

## Current seed boundary
Phase 4 generated code contains only a minimal compile-check CPU-state shell and stub helpers. Phase 5 adds compile-check patch helper stubs for replacement, before-hook, after-hook, skip-original, import-shim, and trap boundaries. Those helpers exist to prove the emitter produces valid C++ and stable labels/traps/patch call sites; they are not the runtime contract for Battlefield Vietnam or any other target.

Future runtime work must replace stubs with real guest memory, stack, import dispatch, patch/hook registry dispatch, call/return behavior, logging, traps, and host API boundaries. Until then, generated-code compilation is evidence of emitter shape only, not behavioral execution.

## Phase 6 seed support
Implemented-and-tested in the C++ seed:

- `src/runtime.hpp` and `src/runtime.cpp` define the first runtime-owned `cpu_state`, `runtime_context`, event log, guest memory map, stack helpers, direct-call registry, import-shim registry, patch/hook registries, trap logging, and flag helpers.
- Generated C++ now includes `runtime.hpp` and calls runtime APIs for memory reads/writes, flag updates, unsupported instructions, unresolved jumps, direct calls, import shims, replacement hooks, before/after hooks, skip-original records, and patch traps.
- Runtime missing behavior is visible: unmapped memory, missing direct calls, missing import shims, unresolved jumps, unsupported instructions, and patch traps become `runtime_event` records.
- `x86tests` directly covers memory bounds, little-endian `read32`/`write32`, stack push/pop, direct-call callbacks, import-shim callbacks, replacement/before/after/skip patch callbacks, patch-trap events, and formatted runtime events.
- `generated_cfg_compile` now builds generated C++ with `runtime.cpp` and runs a no-trap generated executable smoke test.
- Phase 8 generated stack code now uses the existing runtime stack helpers through `runtime_push32` and `runtime_pop32`; `generated_stack_compile` executes a generated stack fixture with mapped guest memory and initialized `ESP`.
- Phase 9 generated memory move fixtures use `runtime_read_mem32` and `runtime_write_mem32` with generated base/index/displacement address expressions. `generated_moffs_compile`, `generated_mov_imm_rm_compile`, and the local BFV export-slice compile/run smoke pass through the existing runtime memory map.

## Phase 10 indirect dispatch boundary
Implemented-and-tested in the C++ seed:

- `runtime_indirect_call` accepts the callsite VA and resolved pointer value, tries existing direct-call and import-shim bindings by target address, and logs `unresolved_indirect_call` when no binding exists.
- `runtime_indirect_jump` logs `unresolved_indirect_jump` with source and target metadata.
- Unit tests cover successful indirect dispatch through a direct-call binding and unresolved indirect call/jump event logging.

This is dispatch preparation, not a BFV shim claim. A target manifest or import shim still needs evidence for ABI, side effects, and safe host behavior before executing real target imports.

## Phase 11 import-pointer shim boundary
Implemented-and-tested in the C++ seed:

- `runtime_import_pointer_shim` accepts a callsite VA, resolved pointer target, and import symbol.
- It dispatches through the existing import-shim registry when a binding matches the resolved pointer and symbol.
- Missing bindings log `missing_import_shim` at the callsite and preserve the resolved pointer in the event `aux` field.

This gives generated code a metadata-bound import-pointer path without guessing direct targets or hand-editing generated C++. It is not a Win32 implementation; no Battlefield Vietnam import behavior is claimed.

## Phase 13 ABI-aware import shim boundary
Implemented-and-tested in the C++ seed:

- Import-shim runtime bindings now store an ABI string.
- `runtime_register_import_shim_abi`, `runtime_import_shim_abi`, and `runtime_import_pointer_shim_abi` provide ABI-aware registration and dispatch while preserving the older non-ABI helpers as compatibility wrappers.
- ABI mismatches are visible runtime events named `import_abi_mismatch`; pointer-shim mismatch events preserve both the callsite VA and resolved target pointer.
- A synthetic `GetVersionExA`-shaped callback uses controlled runtime stack/memory only: it reads the output pointer from `[ESP + 4]`, validates a minimal structure size, writes deterministic version fields, and returns success through `EAX`.

This is ABI-boundary evidence, not a Win32 implementation. The runtime still does not implement real Windows API behavior, caller stack cleanup, SEH, process state, BFV execution, or DirectX/DirectSound/input/filesystem shims.

## Phase 17 carry/borrow flag helpers
Implemented-and-tested in the C++ seed:

- `runtime_set_adc_flags` updates CF/PF/AF/ZF/SF/OF from `a + b + carry_in`.
- `runtime_set_sbb_flags` updates CF/PF/AF/ZF/SF/OF from `a - b - carry_in`.
- Generated `adc`/`sbb` captures incoming `ctx.cf` before writing flags so the carry input is not overwritten by the result calculation.

This is IA-32 flag-helper evidence only. It is not a full EFLAGS materialization model or target runtime behavior.

## Phase 20 direct-call pack boundary
Generated packs now call verified pack-local generated functions directly when a direct-call target is present in the same generated pack. Missing direct-call targets still call `runtime_direct_call`, so unresolved or out-of-pack calls remain visible runtime events.

This keeps runtime ownership intact: the runtime still owns unresolved direct-call diagnostics and host callback dispatch, while the emitter owns only verified pack-local C++ calls.

## Phase 21 entry import-shim diagnostics
Implemented-and-tested in the C++ seed:

- Entry import-shim metadata can drive existing ABI-aware import-pointer dispatch through generated code.
- Runtime diagnostics remain visible for missing shims and ABI mismatches.
- `runtime_unsupported_side_effect` records `unsupported_side_effect` when a shim metadata side-effect model is not safe for the synthetic handler.
- The generated synthetic `GetVersionExA` pack fixture registers a controlled callback, writes only deterministic version fields into mapped guest memory, and fails on unsafe memory through existing `memory_fault` diagnostics.

This is not a real Win32 implementation. The runtime still does not execute Battlefield Vietnam, load the PE image, clean caller stacks, model process state, or provide DirectX/DirectSound/input/filesystem shims.

## Phase 22 import-pointer binding initialization
Implemented-and-tested in the C++ seed:

- `runtime_bind_import_pointer_shim_abi` writes a selected shim target into a mapped guest IAT slot and registers the ABI-aware import-shim callback.
- The helper fails visibly through existing `memory_fault` diagnostics when the IAT slot is not mapped.
- The synthetic generated `GetVersionExA` pack harness now uses this runtime-owned setup boundary instead of open-coding IAT writes plus shim registration.

This is runtime initialization scaffolding only. It does not load a PE image, resolve imports from host DLLs, implement Win32 side effects, or prove Battlefield Vietnam execution.

## Phase 23 persistent runtime-init manifest
Implemented-and-tested in the C++ seed:

- `RuntimeInitManifest` parses PE-bound runtime initialization records for import-pointer setup.
- Required metadata includes image path, image base, FNV-1a64 file hash, IAT VA/RVA, shim target VA, DLL/symbol, ABI, side-effect model, evidence, rollback, and enabled state.
- Validation rejects malformed record kinds/fields, duplicate import-pointer records, missing evidence, missing ABI, unsupported side-effect models, IAT VA/RVA mismatches, unmapped IAT writes when a mapped range is supplied, and image base/hash mismatches.
- `format-runtime-init` exposes the manifest summary and diagnostics through the CLI.
- `runtime_apply_import_pointer_init` converts a validated setup record shape into the existing `runtime_bind_import_pointer_shim_abi` boundary.
- `generated_runtime_init_manifest_compile` validates a synthetic PE-bound manifest, emits a disposable generated pack with a `GetVersionExA` indirect import-pointer call, applies runtime init metadata, and runs the generated function against controlled memory.

This is a manifest-to-runtime setup boundary only. It does not map PE sections, resolve host DLL imports, implement full Win32 side effects, or prove Battlefield Vietnam execution.

## Phase 24 PE image-memory skeleton
Implemented-and-tested in the C++ seed:

- `runtime_image_section` records image section VA/RVA, raw size, virtual size, readable/writable/executable flags, name, and synthetic raw bytes.
- `runtime_map_image` validates image base/size, VA/RVA consistency, section overflow, overlapping section ranges, and truncated raw data before mutating runtime memory.
- Valid maps allocate one zero-filled image range with `runtime_map_memory`, copy raw section data at RVA offsets, preserve zero-fill after raw bytes, and record `runtime_image_range` metadata for diagnostics.
- Existing `runtime_read32` and `runtime_write32` bounds checks provide visible `memory_fault` diagnostics for unmapped image writes.
- `format_runtime_image_map` emits a deterministic runtime range summary for tests and later debug logs.

This is a synthetic image-memory boundary only. It does not parse PE files in the runtime, enforce page permissions, apply relocations, bind imports, create stacks, or execute Battlefield Vietnam.

## Phase 26 controlled runtime-start harness
Implemented-and-tested in the C++ seed:

- `RuntimeStartManifest` parses synthetic entry-call setup metadata: entry VA, stack base/size, initial ESP, expected ABI, evidence, rollback, enabled state, and 32-bit argument writes.
- `format-runtime-start` exposes deterministic summaries and diagnostics.
- `runtime_prepare_start` validates stack bounds, stack overflow, initial ESP, argument size/alignment/range, missing entry, and supported ABI (`cdecl`/`stdcall`) before mutating runtime state.
- When runtime memory is empty, `runtime_prepare_start` maps a stack-only range; when image memory is already mapped, it requires the stack range to fit inside the existing map and preserves image/IAT bytes.
- `generated_runtime_start_manifest_compile` validates a synthetic manifest, compiles a generated `mov eax, [esp + 4]; ret` pack, prepares the stack, runs generated code, and verifies the stack argument reaches `EAX`.

This is a controlled synthetic entry-call harness only. It does not recover real process-entry ABI, build `argv`/PEB/TEB/SEH/TLS state, clean caller stacks, bind imports by itself, execute Battlefield Vietnam, or prove target runtime behavior.

## Phase 27 integrated synthetic bring-up
Implemented-and-tested in the C++ seed through CTest `integrated_synthetic_bringup_pack_compile`:

- A synthetic PE image map, runtime-init import-pointer record, import-binding summary, and runtime-start record are validated together before generated code runs.
- Runtime image memory is mapped first, then the IAT slot is initialized through `runtime_apply_import_pointer_init`, then stack/CPU state is prepared through `runtime_prepare_start`.
- A generated two-function pack exercises one verified direct generated call and one indirect import-pointer call to a controlled `GetVersionExA`-shaped callback.
- The build-tree debug map records image ranges, runtime-init binding metadata, import-binding metadata, runtime-start metadata, generated function maps, direct-call map, indirect-call map, and import-shim boundary comments.

This proves boundary composition for a synthetic fixture only. It still does not load or execute Battlefield Vietnam, enforce section permissions, apply relocations, initialize process state, resolve ordinal imports, or implement real Win32/DirectX/DirectSound/input/filesystem behavior.

Known limits: this is a skeleton runtime, not an OS or game runtime. It has no PE image loader, no real Win32/DirectX/DirectSound/input/filesystem/time shims, no host ABI enforcement, no call/return stack semantics beyond standalone `push32`/`pop32`, no generated dispatch table, no exception model, and no Battlefield Vietnam runtime behavior claim.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.

<!-- AETHERX86-1.0:Phase 32 Win32 shim boundary completion -->
## Phase 32 Win32 shim boundary completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move the synthetic `GetVersionExA` import-pointer callback into a small tested Win32 shim boundary without claiming full Windows emulation.

Implemented surface:
- `runtime_win32_builtin_callback` resolves builtin callbacks by case-insensitive Win32 symbol name.
- `runtime_apply_builtin_import_pointer_init` applies runtime-init records and fills builtin callbacks when available.
- `runtime_win32_get_version_ex_a` implements a minimal stdcall-shaped `OSVERSIONINFOA` write: success return, Windows XP-era version fields, and unchanged behavior when memory validation fails.
- Byte-level runtime memory helpers support shim structure writes.

Verification:
- Runtime unit test initializes a `KERNEL32.dll!GetVersionExA` import pointer through the builtin resolver, calls it, and checks that the version structure is written.
- Scope remains intentionally narrow: no BFV execution/playability claim and no broad Win32 API emulation claim.

