# Function Patching

## Classification
- Kind: recompiler design contract
- Disposition: active guidance for patch and hook support.

## Purpose
Keep generated decomp/recomp output disposable. x86recomp should support function patches, hooks, import shims, and replacements through metadata and runtime dispatch so agents do not manually edit emitted C/C++ after each generation pass.

## Required use
- Read this file when adding patch manifests, hook dispatch, function replacements, import shims, generated code boundaries, or target-specific corrections.
- Keep patch records in manifests or target metadata, not hidden in the lifter or emitted function body.
- Key each patch by stable evidence: VA/RVA, symbol/import name when available, binary hash, function boundary source, ABI/calling convention, and reason.
- Support N64Recomp/ReXGlue-style patterns: replace function, call hook before original, call hook after original, skip original, map import to host shim, and trap unsupported function.
- Preserve generated code as rebuildable output. If generated code is wrong, fix decode/lift/emit. If target behavior needs host integration or temporary override, add a patch/hook record.
- Reject patches that hide unsupported IA-32 semantics, ambiguous function boundaries, unsafe state access, or unverified Battlefield Vietnam claims.

## pcrecomp reuse policy
- Check pcrecomp before designing equivalent PE analysis, classification, x86 lifting, shim, or generated-project machinery.
- Reuse concepts or implementation patterns when they align with x86recomp's C++20 seed and evidence rules.
- Improve the design when x86recomp can make the boundary clearer, more testable, or more regeneration-safe.
- Use close 1:1 reuse only when no improvement is needed, licensing permits it, attribution is recorded, and tests prove behavior.

## Acceptance checks
- Patch metadata survives regeneration without hand edits to emitted files.
- Generated code has a clear call boundary for replacements/hooks.
- ABI, register/flag/memory effects, and ownership of CPU state are documented.
- Each patch has a purpose, evidence source, verification step, and rollback path.
- Unit or golden tests cover at least one replacement, one before/after hook, and one import shim before claiming the system works.

## Phase 5 seed support
Implemented-and-tested in the C++ seed:

- `PatchKind`, `PatchRecord`, and `PatchManifest` model replacement, before-hook, after-hook, skip-original, import-shim, and trap records.
- `validate_patch_manifest` rejects enabled records that are missing reason, evidence, rollback, required ABI, import-shim symbol, or duplicate kind/address/symbol keys.
- `format_patch_manifest` provides a text summary plus validation issues for logs and future target manifests.
- `emit_cfg_c(cfg, manifest)` fails visibly on invalid patch metadata and emits regeneration-safe call boundaries instead of changing generated instruction bodies.
- Entry-level replacement, before-hook, skip-original, and after-hook boundaries are emitted around the generated function body.
- Direct call emission can route through an import-shim boundary before falling back to the current direct-call stub.
- CTest covers metadata validation, bad-manifest rejection, replacement, before-hook, after-hook, skip-original, import-shim emission, and compile-checks patch-aware generated C++.

Known limits: patch records are in-memory seed structures and a synthetic CLI fixture only. There is no YAML/JSON target manifest parser yet, no runtime patch registry, no ABI enforcement beyond required metadata fields, no host hook implementation, and no Battlefield Vietnam patch claim.

## Phase 6 runtime dispatch
Patch and hook records now have runtime-facing registries in `runtime_context`: replacements, before hooks, after hooks, skip-original hooks, traps, import shims, and direct calls. Generated code calls these registries through `xr::runtime_patch_replace`, `runtime_patch_before`, `runtime_patch_after`, `runtime_patch_skip_original`, `runtime_patch_trap`, and `runtime_import_shim`.

Unit tests prove callbacks can be registered and reached for synthetic records. Missing import shims and patch traps are logged as runtime events. This is still not a target manifest system: persistent patch files, ABI/state-effect validation, and Battlefield Vietnam patch evidence remain future work.

## Phase 11 indirect import-shim metadata
Implemented-and-tested in the C++ seed:

- `PatchKind::IndirectImportShim` models a callsite-keyed metadata binding for indirect import-pointer calls such as `call dword ptr [iat_slot]`.
- Validation requires a symbol, reason, evidence, and rollback path, but does not require a guest ABI string for import-shim metadata.
- Patch-aware emission for `IrOp::IndirectCall` can route through `xr::runtime_import_pointer_shim` before falling back to `xr::runtime_indirect_call`.
- Unit tests cover valid and invalid indirect import-shim records, generated output strings, and runtime callback/missing-shim events.

This remains synthetic/universal infrastructure. A Battlefield Vietnam record for `GetVersionExA` still needs ABI and side-effect evidence before any target shim execution claim.

## Phase 12 persistent manifest schema
Implemented-and-tested in the C++ seed:

- A small line-oriented manifest format supports one `patch` record per line with `key=value` fields.
- Supported fields are `kind`, `va` or `rva`, `symbol`/`import`, `abi`, `reason`, `evidence`, `rollback`, and `enabled`.
- `parse_patch_manifest_text` and `load_patch_manifest` round-trip parsed records into the existing `PatchManifest` / `PatchRecord` model.
- Malformed records, unsupported kinds, both-VA-and-RVA ambiguity, missing addresses, and unknown fields fail visibly; existing manifest validation still rejects missing evidence/reason/rollback, duplicates, and missing symbols.
- `emit-cfg-c-manifest-raw` and CTest `generated_manifest_indirect_import_compile` prove a tracked synthetic `IndirectImportShim` manifest can drive generated code without hand-editing output.

Known limits: this is a minimal text manifest, not a full target manifest language. It does not yet store image base, binary hash, target identity, ABI side-effect models, or Battlefield Vietnam records.

## Phase 13 ABI metadata enforcement
Implemented-and-tested in the C++ seed:

- Enabled `ImportShim` and `IndirectImportShim` records now require a non-empty ABI string, matching the existing requirement for other patch kinds.
- Patch-aware generated code passes the manifest ABI into `runtime_import_shim_abi` or `runtime_import_pointer_shim_abi`.
- The tracked synthetic manifest fixture uses `abi=stdcall`.
- Unit tests reject missing-ABI import-shim records and preserve malformed/missing-evidence manifest coverage.

This keeps ABI metadata attached to regeneration-safe patch records rather than hiding it in generated output or runtime defaults.

## Phase 21 entry import-shim metadata
Implemented-and-tested in the C++ seed:

- A dedicated `entry_import_shim` manifest record stores DLL, symbol, IAT VA/RVA, callsite VA/RVA, ABI, side-effect evidence, rollback, and enabled fields.
- Validation rejects missing DLL/symbol/ABI/evidence/rollback/address fields, duplicate callsites/IAT records, and unsupported side-effect models.
- Valid records convert into existing `PatchKind::IndirectImportShim` metadata so generated code still uses the regeneration-safe import-pointer boundary.
- The initial supported side-effect model is `version_info_write`, proven only by a synthetic `GetVersionExA` fixture with controlled runtime memory.

Battlefield Vietnam use is metadata-only: the entrypoint `GetVersionExA` callsite can be represented, but no BFV shim execution is claimed.

## Phase 22 import-pointer initialization boundary
Implemented-and-tested in the C++ seed:

- Runtime setup for an indirect import-pointer shim now has a single helper, `runtime_bind_import_pointer_shim_abi`.
- The helper keeps target metadata out of generated code by taking the IAT VA, selected shim target, symbol, ABI, and callback as explicit setup inputs.
- Unit tests prove that the helper writes the IAT slot, dispatches through the existing import-pointer shim path, and logs `memory_fault` when the IAT slot is not mapped.

This keeps the patch/shim model regeneration-safe while postponing PE image loading and real Win32 import resolution.

## Phase 23 runtime-init manifest boundary
Implemented-and-tested in the C++ seed:

- A dedicated `runtime_init_import_pointer` manifest stores PE image path/base/hash plus IAT VA/RVA, shim target VA, DLL, symbol, ABI, side-effect model, evidence, rollback, and enabled fields.
- Validation rejects duplicate records, missing evidence, missing ABI, unsupported side-effect models, IAT VA/RVA mismatches, unmapped IAT setup when a mapped range is supplied, and image identity/hash mismatch.
- Valid runtime-init setup can be represented as `runtime_import_pointer_init` and applied through `runtime_apply_import_pointer_init`, which delegates to `runtime_bind_import_pointer_shim_abi`.
- CTest `generated_runtime_init_manifest_compile` proves the path through a synthetic PE-bound manifest and a controlled generated `GetVersionExA` fixture.

This remains setup metadata, not a BFV shim execution claim. Real PE image mapping and host import resolution remain future work.
