# Lifter

## Filled contract
Translate decoded instructions into IR with explicit register, memory, control-flow, and flag effects. Unsupported or partial semantics must emit diagnostics with address and bytes.

## Current seed support
Phase 2 adds a minimal universal lifter contract over the Phase 1 verified decoder subset. `lift_ir` converts decoded instructions into `IrInst` records with original address, raw bytes, mnemonic, operands, width, target, condition, support state, diagnostic text, and flag effects.

Implemented-and-tested IR ops: `nop`, `mov`, `lea`, `add`, `or`, `and`, `sub`, `xor`, `cmp`, `test`, `push`, `pop`, direct `call`, direct `jmp`, direct conditional branch, `ret`, and explicit `unsupported`.

Phase 8 evidence: stack decode expansion preserves `push`/`pop` as `IrOp::Push` and `IrOp::Pop`; tests cover register push/pop and immediate pushes. Full stack semantics still belong to runtime/codegen, not the lifter.

Phase 9 evidence: `A1/A3` and `C7 /0` are lifted as `IrOp::Move`; `FF /6` is lifted as `IrOp::Push`; indirect `FF /2` calls and `FF /4` jumps decode successfully but become explicit unsupported IR records until indirect dispatch metadata/runtime support exists.

Phase 15 evidence: `inc`, `dec`, `xchg`, `movzx`, and `movsx` have explicit IR ops for tested 32-bit forms. `inc`/`dec` flag metadata preserves CF as unchanged and defines PF/AF/ZF/SF/OF. Generated-code coverage exists for register `inc`/`dec`, `xchg eax, ebx`, `movzx eax, bl`, and `movsx eax, bx`.

Phase 17 evidence: `not`, `neg`, `adc`, `sbb`, one-bit `shl`/`shr`/`sar`/`rol`/`ror`, register `setcc`, and simple 32-bit `cmovcc` have explicit IR ops for tested forms. `adc`/`sbb`, `setcc`, and `cmovcc` record their flag reads; shifts/rotates record defined/undefined/unchanged flag effects conservatively for the supported one-bit forms.

Known limits: memory-source `movzx`/`movsx` codegen, broad byte/word arithmetic codegen, multi-bit or CL-count shift/rotate codegen, `rcl`/`rcr`/`sal`, memory-destination `setcc`, segment behavior, exceptions, and BFV runtime behavior remain unsupported or unclaimed.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.

<!-- AETHERX86-1.0:Phase 31 IA-32 semantic expansion completion -->
## Phase 31 IA-32 semantic expansion completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: reduce the next high-value BFV blockers with universal IA-32 semantics only, not BFV-specific decoding branches.

Implemented surface:
- `ret imm16` (`C2 iw`).
- `leave` (`C9`) lifted to explicit frame teardown code.
- `mov r8, imm8` (`B0..B7`) with partial-register-safe write emission for generated C.
- Accumulator immediate arithmetic/logic forms (`04/05/0C/0D/14/15/1C/1D/24/25/2C/2D/34/35/3C/3D`).
- 8-bit ModRM arithmetic/logic forms and `test r/m8, r8` (`84 /r`).
- `mov r/m8, imm8` (`C6 /0 ib`) in addition to existing 32-bit immediate moves.

Verification:
- Unit tests cover decode, lift, and generated C output for the newly supported forms.
- Capstone decode and PE-slice verifier tests pass with Capstone 5.0.7 available in the environment.
- Mock BFV unsupported histogram improved from the earlier baseline of 3,004,248 decoded slots / 2,189,413 supported / 814,835 unsupported to 2,750,940 decoded slots / 2,310,829 supported / 440,111 unsupported in this build.

