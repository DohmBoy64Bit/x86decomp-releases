# PELoader

## Filled contract
Parse PE safely: MZ/PE headers, machine, image base, entrypoint RVA, sections, imports, relocations, TLS, and RVA/file mappings. Treat binaries as untrusted.

## Current seed support
The Phase 1 seed parser reports structured PE32 metadata for headers, data directories, sections, import DLLs/functions, exports, relocation blocks, TLS directory fields, delay-import DLLs/functions, overlay size, FNV-1a64 file hash, and static protection indicators. The parser is universal: target-specific facts belong in manifests or smoke logs, not hardcoded parser branches.

Known limits: PE32+ is unsupported, protection indicators are evidence tags only, resource/certificate/debug directories are not summarized yet, and parsed directory metadata does not imply runtime behavior.

## Phase 7 slice analysis support
The seed exposes `analyze_pe_slice(path, rva, size)` and CLI `analyze-pe-slice <pe> <rva> <size>`. This reuses the PE section table and RVA/file-offset mapping to read a bounded slice from a PE file, then reports decode/IR/CFG support metadata without printing raw bytes.

Acceptance evidence:
- Synthetic PE unit tests cover successful `.text` slice mapping and overlarge slice rejection.
- `capstone_slice_verify` creates a synthetic PE, analyzes a supported slice, and compares instruction count with Capstone.
- Battlefield Vietnam smoke analysis writes safe metadata only under `%TEMP%`.

Known limits: this is not whole-function discovery, not a PE image loader, not a trace runner, and not proof that a target slice can execute.

## Phase 14 catalog facts
The seed now exposes `build_function_catalog` and CLI `function-catalog <pe>` / `function-catalog-slice <pe> <rva> <size> [manifest]`. The catalog reuses PE entrypoint, export, import IAT, delay-import IAT, section, and image-base facts instead of reparsing addresses in a separate classifier.

Known limit: the PE parser remains PE32-only. The local host-built `x86recomp.exe` is PE32+ and is rejected by design; BFV `BfVietnam.exe` is PE32 and can be summarized as safe metadata.

## Phase 18 manifest validation facts
Function-pack manifests now reuse PE loader facts for file identity and address validation. A manifest image record must match the inspected PE image base and FNV-1a64 file hash before enabled function records can become generated-pack candidates.

Function records are checked against section mapping and raw section bounds through the same `analyze_pe_slice(path, rva, size)` path used by PE slice reports. This keeps RVA/file-offset ownership in the PE loader/slice layer and prevents manifest parsing from becoming a second PE analyzer.

Known limit: file hash identity is FNV-1a64 metadata for local verification, not a cryptographic trust boundary.

## Phase 24 image-map metadata facts
The seed now exposes `format_pe_image_map_summary(info)` and CLI `format-pe-image-map <pe>`. The summary reuses inspected PE section metadata and reports image base, size of image, section VA/RVA, raw size, virtual size, and readable/writable/executable flags.

Validation is metadata-only at the PE layer: it flags invalid image base/size, empty mapped sections, section overflow, and overlapping section ranges. It does not copy bytes or create runtime memory by itself.

Battlefield Vietnam use remains safe metadata only: the local PE reports five sections and `pe_image_map_issues: 0`. The runtime mapper is tested only on synthetic PE data and must not be used to map or commit BFV bytes until a target-safe image-loading policy exists.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.

<!-- AETHERX86-1.0:Phase 28 PE image loader completion -->
## Phase 28 PE image loader completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: promote Phase 27 metadata-only PE image planning into a loader-owned image map that can copy headers/sections and apply PE32 base relocations for synthetic and supported PE32 inputs.

Implemented surface:
- `map-pe-image <pe> [mapped_base]` CLI.
- `xr::map_pe_image` and `xr::format_pe_loaded_image` API.
- PE32 section copy into a loader-owned image buffer.
- Relocation directory walking with `IMAGE_REL_BASED_ABSOLUTE` skip and `IMAGE_REL_BASED_HIGHLOW` adjustment.
- Hard diagnostics for unsupported relocation types, malformed relocation blocks, out-of-image relocation targets, and rebased images that lack relocation data.

Verification:
- Synthetic relocation unit test maps a PE at a non-preferred base and verifies a HIGHLOW target is adjusted by the base delta.
- Supplied mock `BfVietnam.exe` maps cleanly at its preferred base and reports a diagnostic when deliberately rebased because its relocation directory is absent.

<!-- AETHERX86-1.0:Phase 29 import IAT application completion -->
## Phase 29 import IAT application completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move import handling from binding summaries into controlled loaded-image IAT writes, while keeping ordinal imports explicit and non-silent.

Implemented surface:
- `apply-pe-imports <pe> <runtime_init_manifest> [mapped_base]` CLI.
- `xr::apply_imports_to_loaded_image` and `xr::format_pe_import_apply_result` API.
- Name-import and delay-import IAT writes sourced from validated runtime-init manifests.
- Duplicate, missing, and malformed manifest validation before image mutation.
- Ordinal-only imports produce explicit diagnostics and do not receive guessed addresses.

Verification:
- Synthetic ordinary import and delay-import IAT writes are checked byte-for-byte in the loaded image.
- Synthetic ordinal import fixture fails with the diagnostic `ordinal import requires explicit non-name policy`.

