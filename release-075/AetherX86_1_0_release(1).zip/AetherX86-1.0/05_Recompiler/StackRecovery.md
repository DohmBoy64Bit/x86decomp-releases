# Stack Recovery

## Classification
- Kind: recompiler design contract
- Disposition: active filled contract.

## Purpose
This file now has an active role in the x86recomp skill/project. It exists to keep the universal x86 static recompiler honest, testable, and separated from Battlefield Vietnam target-specific assumptions.

## Required use
- Record concrete facts, contracts, or checklist items here; do not use filler.
- Mark claims as verified, hypothesis, or blocked.
- Keep universal decode/lift/emit/runtime work separate from `targets/bfvietnam` work.
- Add build, test, trace, or source evidence before claiming completion.

## x86recomp guidance
The project should follow a converter/runtime split inspired by N64Recomp, xboxrecomp, and XenonRecomp: parse target metadata, discover functions, decode IA-32, lift to IR, emit deterministic C/C++, and rely on a runtime for OS/API behavior. Battlefield Vietnam is the first acceptance target, not the whole architecture.

## Phase 26 controlled stack setup
Implemented-and-tested support is a manifest-driven synthetic stack setup for generated entry-call fixtures. Records carry stack base, stack size, initial ESP, and explicit 32-bit argument writes. Validation rejects stack overflow, initial ESP outside the stack, non-4-byte argument writes, unaligned arguments, argument writes outside the stack, and stack ranges outside an existing mapped image memory region.

This is not automatic stack recovery from a target binary. It does not infer local variables, calling convention cleanup, exception frames, thread stacks, guard pages, or Battlefield Vietnam process-entry state.

## Acceptance checks
- This file names the responsibility it controls.
- Related code/tests/docs point back here when the contract changes.
- Unsupported opcodes, imports, runtime APIs, and target facts remain visible blockers, never silent unverified future-task markers.
