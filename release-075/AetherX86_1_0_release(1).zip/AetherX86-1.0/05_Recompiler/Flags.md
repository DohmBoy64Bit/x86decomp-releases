# Flags

## Filled contract
Model EFLAGS accurately. Track CF/PF/AF/ZF/SF/OF and undefined flags explicitly. Conditional branches, setcc, lahf/sahf, pushf/popf, and calls that observe flags require materialization.

## Current seed support
Phase 2 adds tested helper calculations for `add`, `sub`/`cmp`, and logical/test-style results. The helpers cover CF, PF, AF, ZF, SF, and OF for 8/16/32-bit widths. Logical/test-style IR marks CF and OF as cleared, PF/ZF/SF as defined, and AF as undefined.

Conditional branch IR records which flags are read for the decoded `jcc` family. This follows the pcrecomp lesson that flag producers and consumers must be connected through captured state, not re-evaluated from mutated operands.

Evidence: unit tests cover carry, zero, auxiliary carry, sign, overflow, parity, logical zero, and branch flag-read records. Intel SDM/AMD APM remain the required authorities for future instructions before semantics are claimed.

Phase 15 adds tested `flags_inc` and `flags_dec` helpers. They reuse add/sub flag math for PF/AF/ZF/SF/OF while preserving the incoming CF, matching Intel/AMD semantics for the tested 32-bit cases. Generated `inc`/`dec` code also saves and restores `ctx.cf` around runtime flag helper calls.

Phase 17 adds tested `flags_adc` and `flags_sbb` helpers plus generated-runtime carry/borrow helpers. `adc`/`sbb` record CF as a read. `setcc` and `cmovcc` reuse the existing condition-to-flag-read mapping. One-bit shifts and rotates now have generated flag updates for tested 32-bit forms: shifts update arithmetic/logical result flags and CF/OF, while rotates update CF/OF and leave the other tracked flags unchanged.

Known limits: the seed does not yet materialize full EFLAGS storage, handle multi-bit/CL shift and rotate flags, `rcl`/`rcr`, mul/div, x87/SSE status, or validate branch outcomes against native execution.

## Acceptance
This file is actionable: code changes must add tests, diagnostics, and evidence.
