#include "rfa_reader.h"
#include "sm_reader.h"
#include "rs_reader.h"
#include "template_database.h"
#include "con_parser.h"
#include "static_asset_loader.h"
#include "heightmap_reader.h"
#include "wst_reader.h"
#include "lsb_reader.h"
#include "pal_reader.h"
#include "tga_reader.h"
#include "ssc_reader.h"
#include "rcm_reader.h"
#include "ske_reader.h"
#include "baf_reader.h"
#include "skn_reader.h"
#include "geometry_template_reader.h"
#include "dif_reader.h"
#include "fx_reader.h"
#include <algorithm>
#include <climits>
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

using namespace openbfv::vfs::rfa;
using namespace openbfv::assets::mesh;
using namespace openbfv::assets::material;
using namespace openbfv::assets::loader;
using namespace openbfv::assets::terrain;
using namespace openbfv::game::object_template;
using namespace openbfv::script::con;
using namespace openbfv::assets::audio;
using namespace openbfv::assets::animation;
using namespace openbfv::assets::texture;
using namespace openbfv::assets::font;

static void print_usage() {
    std::cout << "bfvtool - OpenBFVietnam toolkit\n\n";
    std::cout << "Usage:\n";
    std::cout << "  bfvtool rfa list <archive.rfa>               List files\n";
    std::cout << "  bfvtool rfa info <archive.rfa>               Show header info\n";
    std::cout << "  bfvtool rfa extract <archive.rfa> <path>     Extract a file to stdout\n";
    std::cout << "  bfvtool rfa extract-to <archive.rfa> <path> <out>  Extract a file to disk\n";
    std::cout << "  bfvtool sm info <file.sm>                    Show .sm mesh info\n";
    std::cout << "  bfvtool rs info <file.rs>                    Show .rs render state info\n";
    std::cout << "  bfvtool template build <arch.rfa> <con>      Build template DB from CON in RFA\n";
    std::cout << "  bfvtool asset resolve <arch.rfa> <con>      Resolve and load all meshes from CON in archive\n";
    std::cout << "  bfvtool terrain info <heightmap.raw>         Show terrain heightmap info\n";
    std::cout << "  bfvtool wst info <file.wst>                  Show WST vegetation info\n";
    std::cout << "  bfvtool lsb info <file.lsb>                  Show LightmapShadowBits info\n";
    std::cout << "  bfvtool tga info <file.tga>                  Show TGA image info\n";
    std::cout << "  bfvtool pal info <file.pal>                  Show color palette info\n";
    std::cout << "  bfvtool ssc info <file.ssc>                  Show sound script info\n";
    std::cout << "  bfvtool rcm info <file.rcm>                  Show environment map info\n";
    std::cout << "  bfvtool ske info <file.ske>                  Show skeleton info\n";
    std::cout << "  bfvtool baf info <file.baf>                  Show animation info\n";
    std::cout << "  bfvtool skn info <file.skn>                  Show skin info\n";
    std::cout << "  bfvtool dif info <file.dif>                  Show DICE font info\n";
    std::cout << "  bfvtool fx info <file.fx>                    Show shader effect info\n";
}

static int cmd_rfa_list(const std::string& archive_path) {
    RfaReader reader(archive_path);
    if (!reader.open()) {
        std::cerr << "Error: could not open archive: " << archive_path << "\n";
        return 1;
    }

    const auto& info = reader.info();
    const auto& files = reader.files();

    std::cout << "Archive: " << archive_path << "\n";
    std::cout << "  Format: " << (info.header.is_v1_1 ? "v1.1" : "v1.0") << "\n";
    std::cout << "  Compressed: " << (info.header.compressed ? "yes" : "no") << "\n";
    std::cout << "  XPack: " << info.header.xpack_name;
    if (info.header.xpack_header_id != 0) {
        std::cout << " (0x" << std::hex << info.header.xpack_header_id << std::dec << ")";
    }
    std::cout << "\n";
    std::cout << "  Files: " << files.size() << "\n\n";

    for (size_t i = 0; i < files.size(); ++i) {
        const auto& f = files[i];
        std::cout << std::setw(6) << i << "  ";
        std::cout << std::setw(10) << f.uncompressed_size << "  ";
        if (info.header.compressed) {
            std::cout << std::setw(10) << f.compressed_size << "  ";
        }
        std::cout << f.path << "\n";
    }

    return 0;
}

static int cmd_rfa_info(const std::string& archive_path) {
    RfaReader reader(archive_path);
    if (!reader.open()) {
        std::cerr << "Error: could not open archive: " << archive_path << "\n";
        return 1;
    }

    const auto& info = reader.info();

    std::cout << "Archive: " << archive_path << "\n";
    std::cout << "  Format version: " << (info.header.is_v1_1 ? "1.1" : "1.0") << "\n";
    std::cout << "  Compressed: " << (info.header.compressed ? "yes" : "no") << "\n";
    std::cout << "  Directory offset: 0x" << std::hex << info.header.directory_offset << std::dec << "\n";
    std::cout << "  XPack header ID: 0x" << std::hex << info.header.xpack_header_id << std::dec;
    std::cout << " (" << info.header.xpack_name << ")\n";
    std::cout << "  File count: " << info.files.size() << "\n";

    if (!info.files.empty()) {
        uint64_t total_uncompressed = 0;
        uint64_t total_compressed = 0;
        for (const auto& f : info.files) {
            total_uncompressed += f.uncompressed_size;
            if (info.header.compressed)
                total_compressed += f.compressed_size;
        }
        std::cout << "  Total uncompressed: " << total_uncompressed << " bytes";
        if (total_uncompressed > 1024*1024)
            std::cout << " (" << (total_uncompressed / (1024*1024)) << " MB)";
        std::cout << "\n";
        if (info.header.compressed) {
            std::cout << "  Total compressed: " << total_compressed << " bytes\n";
        }

        std::cout << "\nUnknown fields per entry:\n";
        bool has_unknowns = false;
        for (const auto& f : info.files) {
            if (f.unknown[0] != 0 || f.unknown[1] != 0 || f.unknown[2] != 0) {
                has_unknowns = true;
                break;
            }
        }
        if (!has_unknowns) {
            std::cout << "  (all zero — may be reserved)\n";
        } else {
            for (const auto& f : info.files) {
                if (f.unknown[0] != 0 || f.unknown[1] != 0 || f.unknown[2] != 0) {
                    std::cout << "  " << f.path << ": "
                              << "unk=[" << f.unknown[0] << ","
                              << f.unknown[1] << ","
                              << f.unknown[2] << "]\n";
                }
            }
        }
    }

    return 0;
}

static int cmd_rfa_extract(const std::string& archive_path, const std::string& file_path, const std::string& output_path = "") {
    RfaReader reader(archive_path);
    if (!reader.open()) {
        std::cerr << "Error: could not open archive: " << archive_path << "\n";
        return 1;
    }

    auto data = reader.extract(file_path);
    if (!data) {
        std::cerr << "Error: file not found or extraction failed: " << file_path << "\n";
        return 1;
    }

    if (output_path.empty()) {
        std::cout.write(reinterpret_cast<const char*>(data->data()), data->size());
    } else {
        std::ofstream out(output_path, std::ios::binary);
        if (!out) {
            std::cerr << "Error: could not write to: " << output_path << "\n";
            return 1;
        }
        out.write(reinterpret_cast<const char*>(data->data()), data->size());
    }
    return 0;
}

static int cmd_sm_info(const std::string& sm_path) {
    std::ifstream file(sm_path, std::ios::binary);
    if (!file) {
        std::cerr << "Error: could not open file: " << sm_path << "\n";
        return 1;
    }

    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());

    SmReader reader(data);
    if (!reader.parse()) {
        std::cerr << "Error: failed to parse .sm file\n";
        return 1;
    }

    const auto& info = reader.info();

    std::cout << "File: " << sm_path << "\n";
    std::cout << "  Version: " << info.header.version;
    std::cout << " (" << SmReader::version_name(info.header.version) << ")\n";
    std::cout << "  Unknown1: " << info.header.unknown1 << "\n";
    std::cout << "  Bounding box:\n";
    std::cout << "    min: (" << info.header.bounds.min.x << ", "
              << info.header.bounds.min.y << ", " << info.header.bounds.min.z << ")\n";
    std::cout << "    max: (" << info.header.bounds.max.x << ", "
              << info.header.bounds.max.y << ", " << info.header.bounds.max.z << ")\n";
    if (info.header.has_qflag) {
        std::cout << "  QFlag: " << (int)info.header.qflag << "\n";
    }
    std::cout << "\n";

    std::cout << "  Collision meshes: " << info.collision_meshes.size() << "\n";
    for (size_t i = 0; i < info.collision_meshes.size(); ++i) {
        const auto& col = info.collision_meshes[i];
        std::cout << "    [" << i << "]: " << col.vertices.size() << " verts, "
                  << col.faces.size() << " faces\n";
    }
    std::cout << "\n";

    std::cout << "  LODs: " << info.lods.size() << "\n";
    for (size_t i = 0; i < info.lods.size(); ++i) {
        const auto& lod = info.lods[i];
        std::cout << "    [" << i << "]: " << lod.materials.size() << " materials\n";
        for (size_t j = 0; j < lod.materials.size(); ++j) {
            const auto& mat = lod.materials[j];
            std::cout << "      [" << j << "]: \"" << mat.name << "\"\n";
            std::cout << "        renderType: " << mat.render_type
                      << " (" << SmReader::render_type_name(mat.render_type) << ")\n";
            std::cout << "        vertexFormat: " << mat.vertex_format << "\n";
            std::cout << "        vertexByteSize: " << mat.vertex_byte_size << "\n";
            std::cout << "        vertices: " << mat.num_vertices << "\n";
            std::cout << "        indices: " << mat.num_face_values << "\n";
            std::cout << "        settings: " << mat.material_settings
                      << " (" << SmReader::material_settings_desc(mat.material_settings) << ")\n";
        }
    }
    std::cout << "\n";

    if (info.has_shadow_lods) {
        std::cout << "  Shadow LODs: " << info.shadow_lods.size() << "\n";
    } else {
        std::cout << "  Shadow LODs: none\n";
    }

    std::cout << "  Portal mesh block: " << info.portal_block_size << " bytes\n";
    std::cout << "\n";

    std::cout << "  Totals: " << info.vertex_count() << " vertices, "
              << info.face_count() << " faces, "
              << info.collision_vertex_count() << " collision verts, "
              << info.collision_face_count() << " collision faces\n";

    return 0;
}

static int cmd_rs_info(const std::string& rs_path) {
    std::ifstream file(rs_path);
    if (!file) {
        std::cerr << "Error: could not open file: " << rs_path << "\n";
        return 1;
    }

    std::stringstream ss;
    ss << file.rdbuf();
    std::string content = ss.str();

    RsReader reader(content);
    if (!reader.parse()) {
        std::cerr << "Error: failed to parse .rs file\n";
        return 1;
    }

    const auto& info = reader.info();

    std::cout << "File: " << rs_path << "\n";
    std::cout << "  Subshaders: " << info.subshaders.size() << "\n";

    for (size_t i = 0; i < info.subshaders.size(); ++i) {
        const auto& s = info.subshaders[i];
        std::cout << "  [" << i << "]: \"" << s.name << "\" (" << s.shader_type << ")\n";
        if (!s.texture.empty()) {
            std::cout << "        texture: \"" << s.texture << "\"\n";
        }
        std::cout << "        transparent: " << RsReader::bool_str(s.transparent) << "\n";
        std::cout << "        lighting: " << RsReader::bool_str(s.lighting) << "\n";
        std::cout << "        lightingSpecular: " << RsReader::bool_str(s.lighting_specular) << "\n";
        std::cout << "        twosided: " << RsReader::bool_str(s.twosided) << "\n";
        std::cout << "        envmap: " << RsReader::bool_str(s.envmap) << "\n";
        std::cout << "        textureFade: " << RsReader::bool_str(s.texture_fade) << "\n";
        std::cout << "        depthWrite: " << RsReader::bool_str(s.depth_write) << "\n";
        if (!s.blend_src.empty()) {
            std::cout << "        blendSrc: \"" << s.blend_src << "\"\n";
        }
        if (!s.blend_dest.empty()) {
            std::cout << "        blendDest: \"" << s.blend_dest << "\"\n";
        }
        std::cout << "        alphaTestRef: " << s.alpha_test_ref << "\n";
        std::cout << "        materialDiffuse: " << s.material_diffuse[0] << " "
                  << s.material_diffuse[1] << " " << s.material_diffuse[2] << "\n";
        std::cout << "        materialSpecular: " << s.material_specular[0] << " "
                  << s.material_specular[1] << " " << s.material_specular[2] << "\n";
        std::cout << "        materialSpecularPower: " << s.material_specular_power << "\n";

        if (!s.unknown_properties.empty()) {
            for (const auto& [key, val] : s.unknown_properties) {
                std::cout << "        UNKNOWN: " << key << " = " << val << "\n";
            }
        }
    }

    if (info.unknown_lines > 0) {
        std::cout << "  Unknown top-level lines: " << info.unknown_lines << "\n";
    }

    return 0;
}

static int cmd_template_build(const std::string& archive_path, const std::string& con_path) {
    RfaReader reader(archive_path);
    if (!reader.open()) {
        std::cerr << "Error: could not open archive: " << archive_path << "\n";
        return 1;
    }

    auto con_str = reader.extract_string(con_path);
    if (!con_str) {
        std::cerr << "Error: could not extract '" << con_path << "' from archive\n";
        return 1;
    }

    ConParser parser(*con_str);
    ConScript script = parser.parse();

    for (const auto& err : parser.errors()) {
        std::cerr << "CON warning: " << err << "\n";
    }

    TemplateBuilder builder;
    TemplateDatabase db;
    size_t created = builder.build_from_script(script, db);

    std::cout << "Archive: " << archive_path << "\n";
    std::cout << "Source: " << con_path << "\n";
    std::cout << "Templates created: " << created << "\n";
    std::cout << "Total in DB: " << db.size() << "\n\n";

    for (const auto& [name, tmpl] : db.all()) {
        std::cout << "  Template: \"" << name << "\" (" << tmpl.type << ")\n";
        if (!tmpl.skeleton_name.empty())
            std::cout << "    skeleton: " << tmpl.skeleton_name << "\n";
        if (!tmpl.mesh_name.empty())
            std::cout << "    mesh: " << tmpl.mesh_name << "\n";
        if (!tmpl.geometry_name.empty())
            std::cout << "    geometry: " << tmpl.geometry_name << "\n";
        if (!tmpl.ai_template.empty())
            std::cout << "    aiTemplate: " << tmpl.ai_template << "\n";
        if (!tmpl.parent_template_name.empty())
            std::cout << "    extends: " << tmpl.parent_template_type << " " << tmpl.parent_template_name << "\n";

        if (tmpl.save_in_separate_file || tmpl.create_not_in_grid || tmpl.create_invisible ||
            tmpl.create_visible_in_editor || tmpl.is_not_saveable || tmpl.template_has_been_used ||
            tmpl.remove_at_restart || tmpl.always_use_complex_collision_lod || tmpl.has_map ||
            tmpl.is_below_ground || tmpl.is_entry_point || tmpl.has_dynamic_shadows ||
            tmpl.has_mobile_physics) {
            std::cout << "    flags:";
            if (tmpl.save_in_separate_file) std::cout << " saveInSeparateFile";
            if (tmpl.has_mobile_physics) std::cout << " hasMobilePhysics";
            if (tmpl.create_not_in_grid) std::cout << " createNotInGrid";
            if (tmpl.create_invisible) std::cout << " createInvisible";
            if (tmpl.create_visible_in_editor) std::cout << " createVisibleInEditor";
            if (tmpl.is_not_saveable) std::cout << " isNotSaveable";
            if (tmpl.template_has_been_used) std::cout << " templateHasBeenUsed";
            if (tmpl.remove_at_restart) std::cout << " removeAtRestart";
            if (tmpl.always_use_complex_collision_lod) std::cout << " alwaysUseComplexCollisionLod";
            if (tmpl.has_map) std::cout << " hasMap";
            if (tmpl.is_below_ground) std::cout << " isBelowGround";
            if (tmpl.is_entry_point) std::cout << " isEntryPoint";
            if (tmpl.has_dynamic_shadows) std::cout << " hasDynamicShadows";
            std::cout << "\n";
        }

        std::cout << "    cullRadiusScale: " << tmpl.cull_radius_scale
                  << "  strength: " << tmpl.strength
                  << "  team: " << tmpl.team << "\n";

        if (!tmpl.children.empty()) {
            std::cout << "    children: " << tmpl.children.size() << "\n";
            for (const auto& child : tmpl.children) {
                std::cout << "      " << child.name;
                if (child.input_id >= 0) std::cout << " inputId=" << child.input_id;
                if (child.is_first_person_part) std::cout << " 1p";
                if (child.lod_value != 0.0f) std::cout << " lod=" << child.lod_value;
                if (child.position_x != 0 || child.position_y != 0 || child.position_z != 0)
                    std::cout << " pos=" << child.position_x << "/" << child.position_y << "/" << child.position_z;
                if (child.rotation_pitch != 0 || child.rotation_yaw != 0 || child.rotation_roll != 0)
                    std::cout << " rot=" << child.rotation_pitch << "/" << child.rotation_yaw << "/" << child.rotation_roll;
                std::cout << "\n";
            }
        }

        if (tmpl.fire_delay > 0) std::cout << "    fireDelay: " << tmpl.fire_delay << "\n";
        if (tmpl.delay_to_use > 0) std::cout << "    delayToUse: " << tmpl.delay_to_use << "\n";
        if (tmpl.fire_once) std::cout << "    fireOnce: yes\n";
        if (tmpl.alt_fire_once) std::cout << "    altFireOnce: yes\n";
        if (tmpl.self_destroy) std::cout << "    selfDestroy: yes\n";
        if (tmpl.heat_add_when_fire > 0) std::cout << "    heatAddWhenFire: " << tmpl.heat_add_when_fire << "\n";
        if (tmpl.cool_down_per_sec > 0) std::cout << "    coolDownPerSec: " << tmpl.cool_down_per_sec << "\n";
        if (tmpl.change_weapon_when_no_ammo) std::cout << "    changeWeaponWhenNoAmmo: yes\n";
        if (tmpl.time_to_not_allow_change > 0) std::cout << "    timeToNotAllowChange: " << tmpl.time_to_not_allow_change << "\n";
        if (tmpl.min_deviation > 0) std::cout << "    minDev: " << tmpl.min_deviation << "\n";
        if (tmpl.fire_deviation[0] > 0 || tmpl.fire_deviation[1] > 0 || tmpl.fire_deviation[2] > 0)
            std::cout << "    fireDev: " << tmpl.fire_deviation[0] << "/" << tmpl.fire_deviation[1] << "/" << tmpl.fire_deviation[2] << "\n";
        if (tmpl.has_recoil_force) std::cout << "    hasRecoilForce: yes\n";
        if (tmpl.go_back_on_recoil) std::cout << "    goBackOnRecoil: yes\n";
        if (tmpl.recoil_force_up > 0) std::cout << "    recoilForceUp: " << tmpl.recoil_force_up << "\n";
        if (tmpl.recoil_force_left_right > 0) std::cout << "    recoilForceLeftRight: " << tmpl.recoil_force_left_right << "\n";
        if (tmpl.add_root_speed) std::cout << "    addRootSpeed: yes\n";
        if (tmpl.velocity_dependent_on_heat) std::cout << "    velocityDependentOnHeat: yes\n";
        if (tmpl.rotational_speed[0] > 0 || tmpl.rotational_speed[1] > 0 || tmpl.rotational_speed[2] > 0)
            std::cout << "    rotationalSpeed: " << tmpl.rotational_speed[0] << "/" << tmpl.rotational_speed[1] << "/" << tmpl.rotational_speed[2] << "\n";
        if (tmpl.velocity > 0) std::cout << "    velocity: " << tmpl.velocity << "\n";
        if (tmpl.explosion_radius != 15.0f || tmpl.explosion_damage != 10.0f) {
            std::cout << "    explosion: radius=" << tmpl.explosion_radius << " damage=" << tmpl.explosion_damage
                      << " force=" << tmpl.explosion_force << " max=" << tmpl.explosion_force_max << "\n";
        }
        if (tmpl.soldier_zoom_fov > 0) std::cout << "    soldierZoomFov: " << tmpl.soldier_zoom_fov << "\n";
        if (tmpl.soldier_zoom_position_x != 0 || tmpl.soldier_zoom_position_y != 0 || tmpl.soldier_zoom_position_z != 0)
            std::cout << "    soldierZoomPosition: " << tmpl.soldier_zoom_position_x << "/" << tmpl.soldier_zoom_position_y << "/" << tmpl.soldier_zoom_position_z << "\n";
        if (tmpl.soldier_camera_position_x != 0 || tmpl.soldier_camera_position_y != 0 || tmpl.soldier_camera_position_z != 0)
            std::cout << "    soldierCameraPosition: " << tmpl.soldier_camera_position_x << "/" << tmpl.soldier_camera_position_y << "/" << tmpl.soldier_camera_position_z << "\n";
        if (tmpl.use_scope) std::cout << "    useScope: yes\n";
        if (tmpl.un_zoom_between_fire_time > 0) std::cout << "    unZoomBetweenFireTime: " << tmpl.un_zoom_between_fire_time << "\n";
        if (tmpl.fire_in_camera_dof) std::cout << "    fireInCameraDof: yes\n";

        if (!tmpl.unknown_properties.empty()) {
            std::cout << "    unknown properties: " << tmpl.unknown_properties.size() << "\n";
            for (const auto& [cmd, args] : tmpl.unknown_properties) {
                std::cout << "      " << cmd;
                for (const auto& a : args) std::cout << " " << a;
                std::cout << "\n";
            }
        }
        std::cout << "\n";
    }

    return 0;
}

static int cmd_asset_resolve(const std::string& archive_path, const std::string& con_path) {
    RfaReader reader(archive_path);
    if (!reader.open()) {
        std::cerr << "Error: could not open archive: " << archive_path << "\n";
        return 1;
    }

    auto con_str = reader.extract_string(con_path);
    if (!con_str) {
        std::cerr << "Error: could not extract '" << con_path << "' from archive\n";
        return 1;
    }

    ConParser parser(*con_str);
    ConScript script = parser.parse();

    TemplateBuilder builder;
    TemplateDatabase db;
    size_t created = builder.build_from_script(script, db);

    std::cout << "Archive: " << archive_path << "\n";
    std::cout << "Source: " << con_path << "\n";
    std::cout << "Templates: " << created << "\n\n";

    StaticAssetLoader loader(reader);
    auto result = loader.load_all_from_template_db(db);

    std::cout << "Assets resolved: " << result.meshes.size() << "\n\n";

    for (const auto& mesh : result.meshes) {
        std::cout << "  Mesh: \"" << mesh.name << "\"\n";
        if (mesh.mesh) {
            std::cout << "    .sm: v" << mesh.mesh->header.version
                      << " (" << SmReader::version_name(mesh.mesh->header.version) << ")\n";
            std::cout << "    LODs: " << mesh.mesh->lods.size() << "\n";
            std::cout << "    Collision: " << mesh.mesh->collision_meshes.size() << "\n";
            std::cout << "    Vertices: " << mesh.mesh->vertex_count() << "\n";
            std::cout << "    Faces: " << mesh.mesh->face_count() << "\n";
        }
        if (mesh.material) {
            std::cout << "    .rs: " << mesh.material->subshaders.size() << " subshaders\n";
            for (const auto& shader : mesh.material->subshaders) {
                std::cout << "      \"" << shader.name << "\"";
                if (!shader.texture.empty())
                    std::cout << " -> " << shader.texture;
                std::cout << "\n";
            }
        }
        if (!mesh.referenced_textures.empty()) {
            std::cout << "    Textures:\n";
            for (const auto& tex : mesh.referenced_textures) {
                std::cout << "      " << tex << "\n";
            }
        }
        std::cout << "\n";
    }

    if (!result.errors.empty()) {
        std::cout << "Errors (" << result.errors.size() << "):\n";
        for (const auto& err : result.errors) {
            std::cout << "  " << err << "\n";
        }
        std::cout << "\n";
    }

    std::cout << "Total loaded: " << result.total_loaded << " assets\n";
    return 0;
}

static int cmd_wst_info(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        std::cerr << "Error: could not open file: " << path << "\n";
        return 1;
    }
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)),
                                std::istreambuf_iterator<char>());

    WstReader wst;
    if (!wst.parse(data)) {
        std::cerr << "Error: could not parse WST file\n";
        return 1;
    }

    const auto& d = wst.data();
    std::cout << "WST: " << path << "\n";
    std::cout << "  Type: " << d.type << "\n";
    std::cout << "  Version: " << d.version << "\n";
    if (!d.material_map_filename.empty())
        std::cout << "  Material map: " << d.material_map_filename << "\n";
    if (d.material_map_side_size > 0)
        std::cout << "  Map size: " << d.material_map_side_size << "x" << d.material_map_side_size << "\n";
    std::cout << "  View distance: " << d.view_distance << "\n";
    if (d.close_dist_fade > 0)
        std::cout << "  Close fade: " << d.close_dist_fade << "  LOD factor: " << d.close_dist_lod_factor
                  << "  Percentage: " << d.close_dist_percentage << "\n";

    int total_entries = 0;
    for (const auto& mg : d.material_groups) {
        std::cout << "  Material '" << mg.material_name << "': " << mg.entries.size() << " type(s)\n";
        for (const auto& e : mg.entries) {
            std::cout << "    " << e.geometry_name
                      << " prob=" << e.probability << " scale=" << e.scale_min << "-" << e.scale_max
                      << " radius_eq=" << e.min_radius_dist_to_equals
                      << " radius_other=" << e.min_radius_dist_to_others << "\n";
        }
        total_entries += static_cast<int>(mg.entries.size());
    }
    std::cout << "  Total entries: " << total_entries << "\n";
    return 0;
}

static int cmd_terrain_info(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        std::cerr << "Error: could not open file: " << path << "\n";
        return 1;
    }

    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)),
                                std::istreambuf_iterator<char>());

    TerrainReader reader;
    if (!reader.read_heightmap(data)) {
        std::cerr << "Error: file is not a valid uint16 heightmap (must be square dimensions)\n";
        return 1;
    }

    const auto& td = reader.data();
    std::cout << "Heightmap: " << path << "\n";
    std::cout << "  Grid size: " << td.grid_size() << "x" << td.grid_size() << "\n";
    std::cout << "  Data size: " << data.size() << " bytes\n";

    uint16_t min_h = UINT16_MAX, max_h = 0;
    double sum = 0;
    for (auto h : td.heightmap) {
        min_h = std::min(min_h, h);
        max_h = std::max(max_h, h);
        sum += h;
    }
    std::cout << "  Raw height range: " << min_h << " - " << max_h << "\n";
    std::cout << "  Raw height avg: " << (sum / td.heightmap.size()) << "\n";

    {
        float min_scaled = (static_cast<float>(min_h) / 256.0f) * td.config.y_scale;
        float max_scaled = (static_cast<float>(max_h) / 256.0f) * td.config.y_scale;
        std::cout << "  Scaled height range: " << min_scaled << " - " << max_scaled << "\n";
    }

    return 0;
}

static int cmd_lsb_info(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        std::cerr << "Error: could not open file: " << path << "\n";
        return 1;
    }
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)),
                                std::istreambuf_iterator<char>());

    LsbReader lsb;
    if (!lsb.load(data)) {
        std::cerr << "Error: could not parse LSB file\n";
        return 1;
    }

    const auto& info = lsb.info();
    std::cout << "LightmapShadowBits: " << path << "\n";
    std::cout << "  Grid: " << info.width << "x" << info.height << "\n";
    size_t shadow_count = 0;
    for (uint8_t b : info.shadow_bits) {
        if (b != 0) ++shadow_count;
    }
    std::cout << "  Shadow cells: " << shadow_count << "/" << info.shadow_bits.size()
              << " (" << (shadow_count * 100 / std::max(size_t(1), info.shadow_bits.size())) << "%)\n";
    return 0;
}

static int cmd_tga_info(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        std::cerr << "Error: could not open file: " << path << "\n";
        return 1;
    }
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)),
                                std::istreambuf_iterator<char>());

    TgaReader tga(data);
    if (!tga.parse()) {
        std::cerr << "Error: could not parse TGA file\n";
        return 1;
    }

    const auto& info = tga.info();
    std::cout << "TGA: " << path << "\n";
    std::cout << "  Dimensions: " << info.width << "x" << info.height << "\n";
    std::cout << "  Depth: " << info.bpp << " bpp\n";
    std::cout << "  Alpha: " << (info.has_alpha ? "yes" : "no") << "\n";
    std::cout << "  Grayscale: " << (info.is_grayscale ? "yes" : "no") << "\n";
    return 0;
}

static int cmd_pal_info(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        std::cerr << "Error: could not open file: " << path << "\n";
        return 1;
    }
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)),
                                std::istreambuf_iterator<char>());

    PalReader pal;
    if (!pal.load(data)) {
        std::cerr << "Error: could not parse PAL file\n";
        return 1;
    }

    const auto& info = pal.info();
    std::cout << "Palette: " << path << "\n";
    std::cout << "  Entries: " << info.entry_count << "\n";
    std::cout << "  Alpha: " << (info.has_alpha ? "yes" : "no") << "\n";
    return 0;
}

static int cmd_ssc_info(const std::string& path) {
    std::ifstream file(path);
    if (!file) {
        std::cerr << "Error: could not open file: " << path << "\n";
        return 1;
    }
    std::stringstream ss;
    ss << file.rdbuf();
    std::string content = ss.str();

    SscReader ssc(content);
    if (!ssc.parse()) {
        std::cerr << "Error: could not parse SSC file\n";
        return 1;
    }

    const auto& info = ssc.info();
    std::cout << "SoundScript: " << path << "\n";
    std::cout << "  Sounds: " << info.sounds.size() << "\n";
    for (size_t i = 0; i < info.sounds.size() && i < 10; ++i) {
        const auto& s = info.sounds[i];
        std::cout << "  [" << i << "]: \"" << s.name << "\""
                  << " file=" << (s.filename.empty() ? "(none)" : s.filename)
                  << " vol=" << s.volume;
        if (s.loop) std::cout << " loop";
        std::cout << "\n";
    }
    if (info.sounds.size() > 10) {
        std::cout << "  ... and " << (info.sounds.size() - 10) << " more\n";
    }
    return 0;
}

static int cmd_rcm_info(const std::string& path) {
    std::ifstream file(path);
    if (!file) {
        std::cerr << "Error: could not open file: " << path << "\n";
        return 1;
    }
    std::stringstream ss;
    ss << file.rdbuf();
    std::string content = ss.str();

    RcmReader rcm(content);
    if (!rcm.parse()) {
        std::cerr << "Error: could not parse RCM file\n";
        return 1;
    }

    const auto& info = rcm.info();
    std::cout << "EnvironmentMap: " << path << "\n";
    std::cout << "  Faces: " << info.faces.size() << "\n";
    for (size_t i = 0; i < info.faces.size(); ++i) {
        std::cout << "    [" << i << "]: " << info.faces[i].texture_name << ".dds\n";
    }
    if (!info.name.empty()) {
        std::cout << "  Derived name: " << info.name << "\n";
    }
    return 0;
}

static int cmd_ske_info(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) { std::cerr << "Error: could not open file: " << path << "\n"; return 1; }
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    SkeReader ske(data);
    if (!ske.parse()) { std::cerr << "Error: could not parse SKE file\n"; return 1; }
    const auto& info = ske.info();
    std::cout << "Skeleton: " << path << "\n  Bones: " << info.bones.size() << "\n";
    for (size_t i = 0; i < info.bones.size() && i < 10; ++i) {
        const auto& b = info.bones[i];
        std::cout << "  [" << i << "]: \"" << b.name << "\" parent=";
        if (b.parent_index == 0xFFFFFFFF) std::cout << "root"; else std::cout << b.parent_index;
        std::cout << "\n";
    }
    if (info.bones.size() > 10) std::cout << "  ... and " << (info.bones.size() - 10) << " more\n";
    return 0;
}

static int cmd_baf_info(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) { std::cerr << "Error: could not open file: " << path << "\n"; return 1; }
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    BafReader baf(data);
    if (!baf.parse()) { std::cerr << "Error: could not parse BAF file\n"; return 1; }
    const auto& info = baf.info();
    std::cout << "Animation: " << path << "\n";
    if (!info.bones.empty()) {
        std::cout << "  Bones: " << info.bones.size() << "\n";
        for (size_t i = 0; i < info.bones.size() && i < 5; ++i)
            std::cout << "    [" << i << "]: \"" << info.bones[i].name << "\"\n";
        if (info.bones.size() > 5) std::cout << "    ... and " << (info.bones.size() - 5) << " more\n";
    }
    std::cout << "  Frame data: " << info.frame_data_size << " bytes (~" << info.record_count << " frames)\n";
    return 0;
}

static int cmd_skn_info(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) { std::cerr << "Error: could not open file: " << path << "\n"; return 1; }
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    SknReader skn(data);
    if (!skn.parse()) { std::cerr << "Error: could not parse SKN file\n"; return 1; }
    const auto& info = skn.info();
    std::cout << "Skin: " << path << "\n  Vertices: " << info.vertices.size() << "\n";
    size_t total_weights = 0;
    for (const auto& v : info.vertices) total_weights += v.weights.size();
    std::cout << "  Total bone influences: " << total_weights << "\n";
    return 0;
}

static int cmd_dif_info(const std::string& path) {
    std::ifstream file(path);
    if (!file) { std::cerr << "Error: could not open file: " << path << "\n"; return 1; }
    std::stringstream ss; ss << file.rdbuf();
    DifReader dif(ss.str());
    if (!dif.parse()) { std::cerr << "Error: could not parse DIF file\n"; return 1; }
    const auto& info = dif.info();
    std::cout << "Font: " << path << "\n";
    std::cout << "  Name: \"" << info.font_name << "\"\n";
    std::cout << "  Texture: " << info.texture_width << "x" << info.texture_height
              << " (" << info.bit_depth << "bpp)\n";
    std::cout << "  Glyphs: " << info.glyphs.size() << "\n";
    std::cout << "  Texture file: " << info.texture_path << "\n";
    return 0;
}

static int cmd_fx_info(const std::string& path) {
    std::ifstream file(path);
    if (!file) { std::cerr << "Error: could not open file: " << path << "\n"; return 1; }
    std::stringstream ss; ss << file.rdbuf();
    FxReader fx(ss.str());
    if (!fx.parse()) { std::cerr << "Error: could not parse FX file\n"; return 1; }
    const auto& info = fx.info();
    std::cout << "Shader: " << path << "\n";
    std::cout << "  Lines: " << info.total_lines << "\n";
    std::cout << "  Includes: " << info.includes.size() << "\n";
    for (const auto& inc : info.includes) std::cout << "    #include \"" << inc.path << "\"\n";
    if (!info.shader_model.empty()) std::cout << "  Shader model: " << info.shader_model << "\n";
    std::cout << "  Techniques: " << info.techniques.size() << "\n";
    for (const auto& tech : info.techniques) std::cout << "    " << tech.name << "\n";
    return 0;
}

int main(int argc, char* argv[]) {
    std::vector<std::string> args(argv + 1, argv + argc);

    if (args.size() < 2) {
        print_usage();
        return 1;
    }

    const std::string& cmd = args[0];
    const std::string& subcmd = args[1];

    if (cmd == "rfa") {
        if (subcmd == "list" && args.size() >= 3) {
            return cmd_rfa_list(args[2]);
        } else if (subcmd == "info" && args.size() >= 3) {
            return cmd_rfa_info(args[2]);
        } else if (subcmd == "extract" && args.size() >= 4) {
            return cmd_rfa_extract(args[2], args[3]);
        } else if (subcmd == "extract-to" && args.size() >= 5) {
            return cmd_rfa_extract(args[2], args[3], args[4]);
        }
    } else if (cmd == "sm") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_sm_info(args[2]);
        }
    } else if (cmd == "rs") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_rs_info(args[2]);
        }
    } else if (cmd == "template") {
        if (subcmd == "build" && args.size() >= 4) {
            return cmd_template_build(args[2], args[3]);
        }
    } else if (cmd == "asset") {
        if (subcmd == "resolve" && args.size() >= 4) {
            return cmd_asset_resolve(args[2], args[3]);
        }
    } else if (cmd == "terrain") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_terrain_info(args[2]);
        }
    } else if (cmd == "wst") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_wst_info(args[2]);
        }
    } else if (cmd == "lsb") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_lsb_info(args[2]);
        }
    } else if (cmd == "tga") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_tga_info(args[2]);
        }
    } else if (cmd == "pal") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_pal_info(args[2]);
        }
    } else if (cmd == "ssc") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_ssc_info(args[2]);
        }
    } else if (cmd == "rcm") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_rcm_info(args[2]);
        }
    } else if (cmd == "ske") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_ske_info(args[2]);
        }
    } else if (cmd == "baf") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_baf_info(args[2]);
        }
    } else if (cmd == "skn") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_skn_info(args[2]);
        }
    } else if (cmd == "dif") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_dif_info(args[2]);
        }
    } else if (cmd == "fx") {
        if (subcmd == "info" && args.size() >= 3) {
            return cmd_fx_info(args[2]);
        }
    }

    print_usage();
    return 1;
}
