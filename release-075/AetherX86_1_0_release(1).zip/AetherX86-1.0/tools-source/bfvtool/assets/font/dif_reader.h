#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace openbfv::assets::font {

struct DifGlyph {
    uint32_t index;
    int32_t x, y;
    uint32_t width, height;
    int32_t x_offset, y_offset;
    int32_t x_advance;
    uint32_t page;
};

struct DifInfo {
    uint32_t version;
    std::string font_name;
    uint32_t texture_width;
    uint32_t texture_height;
    uint32_t bit_depth;
    std::vector<DifGlyph> glyphs;
    std::string texture_path; // derived from font_name + ".tga"
    bool valid = false;
};

// .dif DICE Font Bitmap reader
// Text-based format: header, version, font name, texture dims, glyph definitions
// Each glyph: index, x, y, width, height, x_offset, y_offset, x_advance, page
class DifReader {
public:
    explicit DifReader(const std::string& content);
    bool parse();
    const DifInfo& info() const { return info_; }

private:
    std::string content_;
    DifInfo info_;
    bool parsed_ = false;
};

}
