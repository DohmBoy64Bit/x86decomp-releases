#include "dif_reader.h"
#include <sstream>
#include <algorithm>
#include <cctype>

namespace openbfv::assets::font {

DifReader::DifReader(const std::string& content) : content_(content) {}

static std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) ++start;
    size_t end = s.size();
    while (end > start && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\r')) --end;
    return s.substr(start, end - start);
}

bool DifReader::parse() {
    std::istringstream stream(content_);
    std::string line;

    // Line 1: magic "header"
    if (!std::getline(stream, line)) return false;
    line = trim(line);
    if (line != "header") return false;

    // Line 2: version
    if (!std::getline(stream, line)) return false;
    info_.version = static_cast<uint32_t>(std::stoi(trim(line)));

    // Line 3: font name
    if (!std::getline(stream, line)) return false;
    info_.font_name = trim(line);

    // Line 4: texture width
    if (!std::getline(stream, line)) return false;
    info_.texture_width = static_cast<uint32_t>(std::stoul(trim(line)));

    // Line 5: texture height
    if (!std::getline(stream, line)) return false;
    info_.texture_height = static_cast<uint32_t>(std::stoul(trim(line)));

    // Line 6: bit depth
    if (!std::getline(stream, line)) return false;
    info_.bit_depth = static_cast<uint32_t>(std::stoul(trim(line)));

    // Line 7: "glyphs"
    if (!std::getline(stream, line)) return false;
    line = trim(line);
    if (line != "glyphs") return false;

    // Line 8: glyph count
    if (!std::getline(stream, line)) return false;
    uint32_t glyph_count = static_cast<uint32_t>(std::stoul(trim(line)));

    // Lines 9+: glyph definitions
    info_.glyphs.reserve(glyph_count);
    while (std::getline(stream, line) && info_.glyphs.size() < glyph_count) {
        line = trim(line);
        if (line.empty()) continue;

        std::istringstream ls(line);
        DifGlyph g = {};
        ls >> g.index >> g.x >> g.y >> g.width >> g.height
           >> g.x_offset >> g.y_offset >> g.x_advance >> g.page;
        info_.glyphs.push_back(g);
    }

    // Derive texture path from font name
    info_.texture_path = info_.font_name + ".tga";

    info_.valid = !info_.glyphs.empty();
    return info_.valid;
}

}
