#include "skn_reader.h"
#include <cstring>

namespace openbfv::assets::animation {

SknReader::SknReader(const std::vector<uint8_t>& data) : data_(data) {}

bool SknReader::parse() {
    if (data_.size() < 8) return false;
    offset_ = 0;

    std::memcpy(&info_.version, data_.data() + offset_, 4); offset_ += 4;
    if (info_.version != 1) return false;

    std::memcpy(&info_.vertex_count, data_.data() + offset_, 4); offset_ += 4;
    if (info_.vertex_count == 0 || info_.vertex_count > 100000) return false;

    // Try different per-vertex stride sizes
    // Common format: position(12) + boneIndices(16=4*uint32) + weights(16=4*float) = 44 bytes
    // Fallback: position(12) + boneIndex(4) + weight(4) = 20 bytes (single bone)
    size_t remaining = data_.size() - offset_;
    
    // Detect stride: try to find clean division
    uint32_t stride = 0;
    if (remaining % info_.vertex_count == 0) {
        stride = static_cast<uint32_t>(remaining / info_.vertex_count);
    } else {
        // Try common strides
        const uint32_t common_strides[] = {20, 24, 28, 32, 36, 40, 44, 48};
        for (auto s : common_strides) {
            if (s * info_.vertex_count <= remaining && (remaining - s * info_.vertex_count) < 2048) {
                stride = s;
                break;
            }
        }
        if (stride == 0) {
            stride = 20; // best guess: single bone influence
        }
    }

    info_.vertices.reserve(info_.vertex_count);
    for (uint32_t i = 0; i < info_.vertex_count && offset_ + stride <= data_.size(); ++i) {
        SknVertex v;
        
        // Parse bone influences: assume packed uint32s then floats
        // Starting after position (12 bytes), try to read pairs
        size_t influence_start = offset_ + 12;
        if (influence_start + 4 > offset_ + stride) {
            info_.vertices.push_back(v);
            offset_ += stride;
            continue;
        }

        // Read as many bone-weight pairs as fit in remaining stride bytes
        size_t avail = stride - 12;
        uint32_t max_pairs = static_cast<uint32_t>(avail / 8); // each pair = uint32 + float
        
        for (uint32_t j = 0; j < max_pairs && j < 4; ++j) {
            SknWeight w;
            std::memcpy(&w.bone_index, data_.data() + influence_start, 4);
            influence_start += 4;
            std::memcpy(&w.weight, data_.data() + influence_start, 4);
            influence_start += 4;
            if (w.weight > 0.0f) {
                v.weights.push_back(w);
            }
        }
        
        info_.vertices.push_back(v);
        offset_ += stride;
    }

    info_.valid = !info_.vertices.empty();
    return info_.valid;
}

}
