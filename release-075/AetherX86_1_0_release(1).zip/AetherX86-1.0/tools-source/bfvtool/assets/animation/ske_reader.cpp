#include "ske_reader.h"
#include <cstring>
#include <iostream>

namespace openbfv::assets::animation {

SkeReader::SkeReader(const std::vector<uint8_t>& data) : data_(data) {}

bool SkeReader::parse() {
    if (data_.size() < 8) return false;
    offset_ = 0;

    std::memcpy(&info_.version, data_.data() + offset_, 4); offset_ += 4;
    if (info_.version != 1) return false;

    uint32_t bone_count = 0;
    std::memcpy(&bone_count, data_.data() + offset_, 4); offset_ += 4;
    if (bone_count == 0 || bone_count > 256) return false;
    if (data_.size() < offset_) return false;

    info_.bones.reserve(bone_count);
    for (uint32_t i = 0; i < bone_count; ++i) {
        SkeBone bone;
        if (offset_ + 2 > data_.size()) return false;

        uint16_t name_len = 0;
        std::memcpy(&name_len, data_.data() + offset_, 2); offset_ += 2;
        if (name_len == 0 || offset_ + name_len + 2 + 48 > data_.size()) return false;

        bone.name.assign(reinterpret_cast<const char*>(data_.data() + offset_), name_len);
        offset_ += name_len;

        // Read terminator (0xFFFF = root, otherwise parent bone index-1)
        uint16_t term = 0;
        std::memcpy(&term, data_.data() + offset_, 2);
        if (term == 0xFFFF) {
            bone.parent_index = 0xFFFFFFFF;
        } else {
            bone.parent_index = term;
        }
        offset_ += 2;

        // Read 12-float 4x3 transform matrix
        std::memcpy(bone.transform, data_.data() + offset_, 48); offset_ += 48;

        info_.bones.push_back(bone);
    }

    info_.valid = !info_.bones.empty();
    return info_.valid;
}

}
