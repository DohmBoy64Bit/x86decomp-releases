#include "baf_reader.h"
#include <cstring>

namespace openbfv::assets::animation {

BafReader::BafReader(const std::vector<uint8_t>& data) : data_(data) {}

bool BafReader::parse() {
    if (data_.size() < 8) return false;
    offset_ = 0;

    uint32_t bone_count = 0;
    std::memcpy(&bone_count, data_.data() + offset_, 4); offset_ += 4;
    if (bone_count == 0 || bone_count > 256) return false;

    // Next uint16 may be offset to keyframe data
    uint16_t frame_offset_hint = 0;
    if (offset_ + 2 <= data_.size()) {
        std::memcpy(&frame_offset_hint, data_.data() + offset_, 2); offset_ += 2;
    }

    info_.bones.reserve(bone_count);
    for (uint32_t i = 0; i < bone_count; ++i) {
        if (offset_ + 2 > data_.size()) break;
        uint16_t name_len = 0;
        std::memcpy(&name_len, data_.data() + offset_, 2); offset_ += 2;
        if (name_len == 0 || offset_ + name_len > data_.size()) break;
        
        // Name is null-terminated within length
        size_t actual_len = 0;
        for (uint16_t j = 0; j < name_len; ++j) {
            if (data_[offset_ + j] == 0) { actual_len = j; break; }
        }
        if (actual_len == 0) actual_len = name_len;
        
        BafBoneRef bone;
        bone.name.assign(reinterpret_cast<const char*>(data_.data() + offset_), actual_len);
        offset_ += name_len;
        info_.bones.push_back(bone);
    }

    // Remaining data is keyframe data
    info_.frame_data_offset = offset_;
    info_.frame_data_size = data_.size() - offset_;
    info_.record_count = static_cast<uint32_t>(info_.frame_data_size / 12); // 12 bytes per frame (3 floats)

    info_.valid = !info_.bones.empty();
    return info_.valid;
}

}
