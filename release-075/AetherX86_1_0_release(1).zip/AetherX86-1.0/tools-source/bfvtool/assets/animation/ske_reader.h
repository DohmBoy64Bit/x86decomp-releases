#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace openbfv::assets::animation {

struct SkeBone {
    std::string name;
    uint32_t parent_index; // 0xFFFFFFFF = root
    float transform[12];   // 4x3 affine matrix (row-major)
};

struct SkeInfo {
    uint32_t version;
    std::vector<SkeBone> bones;
    bool valid = false;
};

// .ske skeleton reader — format from FUN_006d0e80 decompiled export
// 4 bytes version(=1), 4 bytes boneCount
// per bone: uint16 nameLen, char[nameLen] name, uint16 terminator(0xFFFF), float[12] matrix
class SkeReader {
public:
    explicit SkeReader(const std::vector<uint8_t>& data);
    bool parse();
    const SkeInfo& info() const { return info_; }

private:
    const std::vector<uint8_t>& data_;
    SkeInfo info_;
    size_t offset_ = 0;
    bool parsed_ = false;
};

}
