#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace openbfv::assets::animation {

struct BafBoneRef {
    std::string name;
};

struct BafInfo {
    std::vector<BafBoneRef> bones;
    uint32_t record_count = 0;
    size_t frame_data_offset = 0;
    size_t frame_data_size = 0;
    bool valid = false;
};

// .baf animation reader
// Header: uint32 boneCount
// Per bone: uint16 nameLen + char[nameLen] name
// Remaining data: per-bone animation keyframes (12-byte frames: 3 floats = position)
class BafReader {
public:
    explicit BafReader(const std::vector<uint8_t>& data);
    bool parse();
    const BafInfo& info() const { return info_; }

private:
    const std::vector<uint8_t>& data_;
    BafInfo info_;
    size_t offset_ = 0;
    bool parsed_ = false;
};

}
