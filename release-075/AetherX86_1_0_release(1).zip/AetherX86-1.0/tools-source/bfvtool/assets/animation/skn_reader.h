#pragma once

#include <cstdint>
#include <vector>
#include <string>

namespace openbfv::assets::animation {

struct SknWeight {
    uint32_t bone_index;
    float weight;
};

struct SknVertex {
    std::vector<SknWeight> weights;
};

struct SknInfo {
    uint32_t version;
    uint32_t vertex_count;
    std::vector<SknVertex> vertices;
    bool valid = false;
};

// .skn skin reader — vertex-to-bone weight mapping
// Header: uint32 version(=1), uint32 vertexCount
// Per vertex: uint8 influenceCount, then influenceCount * (uint32 boneIndex + float weight)
class SknReader {
public:
    explicit SknReader(const std::vector<uint8_t>& data);
    bool parse();
    const SknInfo& info() const { return info_; }

private:
    const std::vector<uint8_t>& data_;
    SknInfo info_;
    size_t offset_ = 0;
    bool parsed_ = false;
};

}
