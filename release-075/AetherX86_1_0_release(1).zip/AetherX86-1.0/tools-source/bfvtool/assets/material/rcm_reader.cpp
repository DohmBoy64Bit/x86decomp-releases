#include "rcm_reader.h"
#include <sstream>
#include <algorithm>
#include <cctype>

namespace openbfv::assets::material {

RcmReader::RcmReader(const std::string& content) : content_(content) {}

static std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) ++start;
    size_t end = s.size();
    while (end > start && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\r')) --end;
    return s.substr(start, end - start);
}

bool RcmReader::parse() {
    std::istringstream stream(content_);
    std::string line;

    // .rcm format: text file with 6 lines, each containing a DDS path for one cube face
    // Order: +x, -x, +y, -y, +z, -z (or sequential)
    while (std::getline(stream, line)) {
        line = trim(line);
        if (line.empty()) continue;

        RcmFace face;
        face.texture_name = line;
        // Strip extension if present
        if (face.texture_name.size() > 4) {
            std::string ext = face.texture_name.substr(face.texture_name.size() - 4);
            std::transform(ext.begin(), ext.end(), ext.begin(),
                [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
            if (ext == ".dds") {
                face.texture_name = face.texture_name.substr(0, face.texture_name.size() - 4);
            }
        }
        info_.faces.push_back(face);
    }

    info_.valid = !info_.faces.empty();
    if (info_.faces.size() == 6 && !info_.faces[0].texture_name.empty()) {
        // Derive name from first face by stripping face suffix
        std::string n = info_.faces[0].texture_name;
        if (n.size() > 3) {
            std::string suffix = n.substr(n.size() - 3);
            std::transform(suffix.begin(), suffix.end(), suffix.begin(),
                [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
            if (suffix == "pos" || suffix == "neg" || suffix == "_px" || suffix == "_nx" || suffix == "_py" || suffix == "_ny" || suffix == "_pz" || suffix == "_nz") {
                info_.name = n.substr(0, n.size() - 3);
            } else {
                info_.name = n;
            }
        }
    }

    parsed_ = true;
    return true;
}

}
