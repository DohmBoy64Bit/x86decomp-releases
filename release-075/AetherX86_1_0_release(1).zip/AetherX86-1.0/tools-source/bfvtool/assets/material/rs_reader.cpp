#include "rs_reader.h"
#include <cctype>
#include <stdexcept>
#include <iostream>
#include <sstream>

namespace openbfv::assets::material {

RsReader::RsReader(const std::string& content)
    : content_(content) {
}

void RsReader::skip_whitespace() {
    while (pos_ < content_.size() && std::isspace(static_cast<unsigned char>(content_[pos_]))) {
        ++pos_;
    }
    // skip line comments (//)
    if (pos_ + 1 < content_.size() && content_[pos_] == '/' && content_[pos_ + 1] == '/') {
        while (pos_ < content_.size() && content_[pos_] != '\n') {
            ++pos_;
        }
        skip_whitespace();
    }
}

bool RsReader::expect(char c) {
    skip_whitespace();
    if (pos_ < content_.size() && content_[pos_] == c) {
        ++pos_;
        return true;
    }
    return false;
}

std::string RsReader::parse_string() {
    skip_whitespace();
    if (pos_ >= content_.size() || content_[pos_] != '"') {
        throw std::runtime_error("Expected string at pos " + std::to_string(pos_));
    }
    ++pos_; // skip opening quote
    std::string result;
    while (pos_ < content_.size() && content_[pos_] != '"') {
        if (content_[pos_] == '\\' && pos_ + 1 < content_.size()) {
            ++pos_;
        }
        result += content_[pos_];
        ++pos_;
    }
    if (pos_ >= content_.size()) {
        throw std::runtime_error("Unterminated string at pos " + std::to_string(pos_));
    }
    ++pos_; // skip closing quote
    return result;
}

std::string RsReader::parse_identifier() {
    skip_whitespace();
    size_t start = pos_;
    while (pos_ < content_.size() && (std::isalnum(static_cast<unsigned char>(content_[pos_])) || content_[pos_] == '_')) {
        ++pos_;
    }
    if (pos_ == start) {
        throw std::runtime_error("Expected identifier at pos " + std::to_string(pos_));
    }
    return content_.substr(start, pos_ - start);
}

bool RsReader::parse_bool() {
    std::string id = parse_identifier();
    if (id == "true") return true;
    if (id == "false") return false;
    throw std::runtime_error("Expected bool (true/false) at pos " + std::to_string(pos_));
}

float RsReader::parse_float() {
    skip_whitespace();
    size_t end = 0;
    float val;
    try {
        val = std::stof(content_.substr(pos_), &end);
    } catch (...) {
        throw std::runtime_error("Expected float at pos " + std::to_string(pos_));
    }
    if (end == 0) {
        throw std::runtime_error("Expected float at pos " + std::to_string(pos_));
    }
    pos_ += end;
    return val;
}

int RsReader::parse_int() {
    skip_whitespace();
    size_t end = 0;
    int val;
    try {
        val = std::stoi(content_.substr(pos_), &end);
    } catch (...) {
        throw std::runtime_error("Expected int at pos " + std::to_string(pos_));
    }
    if (end == 0) {
        throw std::runtime_error("Expected int at pos " + std::to_string(pos_));
    }
    pos_ += end;
    return val;
}

void RsReader::parse_property(RsSubShader& shader) {
    std::string key = parse_identifier();

    if (key == "texture") {
        shader.texture = parse_string();
    } else if (key == "transparent") {
        shader.transparent = parse_bool();
    } else if (key == "lighting") {
        shader.lighting = parse_bool();
    } else if (key == "lightingSpecular") {
        shader.lighting_specular = parse_bool();
    } else if (key == "twosided") {
        shader.twosided = parse_bool();
    } else if (key == "envmap") {
        shader.envmap = parse_bool();
    } else if (key == "textureFade") {
        shader.texture_fade = parse_bool();
    } else if (key == "depthWrite") {
        shader.depth_write = parse_bool();
    } else if (key == "blendSrc") {
        shader.blend_src = parse_string();
    } else if (key == "blendDest") {
        shader.blend_dest = parse_string();
    } else if (key == "alphaTestRef") {
        shader.alpha_test_ref = parse_int();
    } else if (key == "materialDiffuse") {
        shader.material_diffuse[0] = parse_float();
        shader.material_diffuse[1] = parse_float();
        shader.material_diffuse[2] = parse_float();
    } else if (key == "materialSpecular") {
        shader.material_specular[0] = parse_float();
        shader.material_specular[1] = parse_float();
        shader.material_specular[2] = parse_float();
    } else if (key == "materialSpecularPower") {
        shader.material_specular_power = parse_float();
    } else {
        // Unknown property — capture key and remaining value(s)
        skip_whitespace();
        size_t start = pos_;
        while (pos_ < content_.size() && content_[pos_] != ';') {
            ++pos_;
        }
        std::string val = content_.substr(start, pos_ - start);
        while (!val.empty() && std::isspace(static_cast<unsigned char>(val.back()))) {
            val.pop_back();
        }
        shader.unknown_properties.push_back({key, val});
    }

    if (!expect(';')) {
        throw std::runtime_error("Expected ';' after property '" + key + "' at pos " + std::to_string(pos_));
    }
}

bool RsReader::parse() {
    try {
        pos_ = 0;

        while (pos_ < content_.size()) {
            skip_whitespace();
            if (pos_ >= content_.size()) break;

            std::string keyword = parse_identifier();

            if (keyword == "subshader") {
                RsSubShader shader;
                shader.name = parse_string();
                shader.shader_type = parse_string();

                if (!expect('{')) {
                    throw std::runtime_error("Expected '{' after subshader header at pos " + std::to_string(pos_));
                }

                while (pos_ < content_.size()) {
                    skip_whitespace();
                    if (pos_ >= content_.size()) break;

                    if (content_[pos_] == '}') {
                        ++pos_;
                        break;
                    }

                    parse_property(shader);
                }

                info_.subshaders.push_back(std::move(shader));
            } else {
                // Skip unknown top-level content to end of line
                while (pos_ < content_.size() && content_[pos_] != '\n') {
                    ++pos_;
                }
                ++info_.unknown_lines;
            }
        }

        parsed_ = true;
        return true;
    } catch (const std::exception& e) {
        std::cerr << "RsReader error: " << e.what() << " at pos " << pos_ << std::endl;
        return false;
    }
}

const RsInfo& RsReader::info() const {
    return info_;
}

std::string RsReader::bool_str(bool v) {
    return v ? "true" : "false";
}

}
