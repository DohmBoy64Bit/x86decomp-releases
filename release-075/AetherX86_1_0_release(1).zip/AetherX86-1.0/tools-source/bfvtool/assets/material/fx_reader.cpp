#include "fx_reader.h"
#include <sstream>
#include <algorithm>
#include <cctype>

namespace openbfv::assets::material {

FxReader::FxReader(const std::string& content) : content_(content) {}

static std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) ++start;
    size_t end = s.size();
    while (end > start && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\r')) --end;
    return s.substr(start, end - start);
}

static std::string to_lower(const std::string& s) {
    std::string r;
    r.reserve(s.size());
    for (char c : s) r += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return r;
}

bool FxReader::parse() {
    std::istringstream stream(content_);
    std::string line;
    bool in_comment_block = false;
    info_.total_lines = 0;

    while (std::getline(stream, line)) {
        ++info_.total_lines;
        line = trim(line);

        // Handle block comments
        if (in_comment_block) {
            size_t end = line.find("*/");
            if (end != std::string::npos) {
                in_comment_block = false;
                line = trim(line.substr(end + 2));
            } else {
                continue;
            }
        }
        size_t comment_start = line.find("//");
        if (comment_start != std::string::npos) {
            line = trim(line.substr(0, comment_start));
        }
        size_t block_start = line.find("/*");
        if (block_start != std::string::npos) {
            size_t block_end = line.find("*/", block_start + 2);
            if (block_end != std::string::npos) {
                line = trim(line.substr(0, block_start) + line.substr(block_end + 2));
            } else {
                line = trim(line.substr(0, block_start));
                in_comment_block = true;
                if (line.empty()) continue;
            }
        }

        if (line.empty()) continue;

        // Detect includes
        if (line.find("#include") == 0) {
            size_t start = line.find('"');
            size_t end = line.find('"', start + 1);
            if (start != std::string::npos && end != std::string::npos) {
                FxInclude inc;
                inc.path = line.substr(start + 1, end - start - 1);
                info_.includes.push_back(inc);
            }
            continue;
        }

        // Detect techniques
        if (line.find("technique") == 0) {
            std::string rest = trim(line.substr(9));
            size_t space = rest.find(' ');
            FxTechnique tech;
            tech.name = (space != std::string::npos) ? rest.substr(0, space) : rest;
            info_.techniques.push_back(tech);
            continue;
        }

        // Detect shader model from string literals
        std::string lower = to_lower(line);
        if (lower.find("vs_") != std::string::npos || lower.find("ps_") != std::string::npos) {
            // Extract shader model from string like "vs_1_1" or "ps_2_0"
            size_t pos = lower.find("vs_");
            if (pos == std::string::npos) pos = lower.find("ps_");
            if (pos != std::string::npos) {
                info_.shader_model = line.substr(pos, 5);
            }
        }
    }

    info_.valid = true;
    return true;
}

}
