#pragma once

#include <string>
#include <vector>

namespace openbfv::assets::material {

struct RcmFace {
    std::string texture_name;
};

struct RcmInfo {
    std::vector<RcmFace> faces; // 6 faces: +x, -x, +y, -y, +z, -z
    std::string name;
    bool valid = false;
};

// Environment map (.rcm) reader — text format referencing 6 DDS cube faces
// Found in archives as environment maps (e.g. sky reflections)
class RcmReader {
public:
    explicit RcmReader(const std::string& content);
    bool parse();
    const RcmInfo& info() const { return info_; }

private:
    std::string content_;
    RcmInfo info_;
    bool parsed_ = false;
};

}
