#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <cstdint>

namespace openbfv::assets::material {

struct RsSubShader {
    std::string name;
    std::string shader_type;

    std::string texture;
    bool transparent = false;
    bool lighting = true;
    bool lighting_specular = false;
    bool twosided = false;
    bool envmap = false;
    bool texture_fade = false;
    bool depth_write = true;
    std::string blend_src = "invSourceAlpha";
    std::string blend_dest = "sourceAlpha";
    int alpha_test_ref = 0;
    float material_diffuse[3] = {1.0f, 1.0f, 1.0f};
    float material_specular[3] = {1.0f, 1.0f, 1.0f};
    float material_specular_power = 20.0f;

    std::vector<std::pair<std::string, std::string>> unknown_properties;
};

struct RsInfo {
    std::vector<RsSubShader> subshaders;
    size_t unknown_lines = 0;
};

class RsReader {
public:
    explicit RsReader(const std::string& content);

    bool parse();
    const RsInfo& info() const;

    static std::string bool_str(bool v);

private:
    void skip_whitespace();
    bool expect(char c);
    std::string parse_string();
    std::string parse_identifier();
    bool parse_bool();
    float parse_float();
    int parse_int();
    void parse_property(RsSubShader& shader);

    std::string content_;
    size_t pos_ = 0;
    RsInfo info_;
    bool parsed_ = false;
};

}
