#pragma once

#include <string>
#include <vector>

namespace openbfv::assets::material {

struct FxTechnique {
    std::string name;
};

struct FxInclude {
    std::string path;
};

struct FxInfo {
    std::vector<FxTechnique> techniques;
    std::vector<FxInclude> includes;
    std::string shader_model; // e.g. "vs_1_1", "ps_2_0"
    size_t total_lines = 0;
    bool valid = false;
};

// .fx shader effect file reader — text-based HLSL-like format
// Contains vertex/pixel shaders, render state, techniques
class FxReader {
public:
    explicit FxReader(const std::string& content);
    bool parse();
    const FxInfo& info() const { return info_; }

private:
    std::string content_;
    FxInfo info_;
    bool parsed_ = false;
};

}
