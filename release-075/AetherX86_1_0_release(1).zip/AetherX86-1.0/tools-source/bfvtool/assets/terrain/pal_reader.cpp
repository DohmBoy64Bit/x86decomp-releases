#include "pal_reader.h"

namespace openbfv::assets::terrain {

bool PalReader::load(const std::vector<uint8_t>& data) {
    if (data.empty()) return false;

    // Determine format from size:
    // 768 bytes = 256 RGB entries (3 bytes each)
    // 1024 bytes = 256 RGBA entries (4 bytes each)
    // Other sizes = variable entry count
    info_.entries.clear();

    if (data.size() == 768) {
        info_.entry_count = 256;
        info_.has_alpha = false;
        info_.entries.resize(256);
        for (uint32_t i = 0; i < 256; ++i) {
            info_.entries[i].r = data[i * 3 + 0];
            info_.entries[i].g = data[i * 3 + 1];
            info_.entries[i].b = data[i * 3 + 2];
            info_.entries[i].a = 255;
        }
    } else if (data.size() == 1024) {
        info_.entry_count = 256;
        info_.has_alpha = true;
        info_.entries.resize(256);
        for (uint32_t i = 0; i < 256; ++i) {
            info_.entries[i].r = data[i * 4 + 0];
            info_.entries[i].g = data[i * 4 + 1];
            info_.entries[i].b = data[i * 4 + 2];
            info_.entries[i].a = data[i * 4 + 3];
        }
    } else if (data.size() % 3 == 0) {
        // RGB with variable count
        info_.entry_count = static_cast<uint32_t>(data.size() / 3);
        info_.has_alpha = false;
        info_.entries.resize(info_.entry_count);
        for (uint32_t i = 0; i < info_.entry_count; ++i) {
            info_.entries[i].r = data[i * 3 + 0];
            info_.entries[i].g = data[i * 3 + 1];
            info_.entries[i].b = data[i * 3 + 2];
            info_.entries[i].a = 255;
        }
    } else if (data.size() % 4 == 0) {
        info_.entry_count = static_cast<uint32_t>(data.size() / 4);
        info_.has_alpha = true;
        info_.entries.resize(info_.entry_count);
        for (uint32_t i = 0; i < info_.entry_count; ++i) {
            info_.entries[i].r = data[i * 4 + 0];
            info_.entries[i].g = data[i * 4 + 1];
            info_.entries[i].b = data[i * 4 + 2];
            info_.entries[i].a = data[i * 4 + 3];
        }
    } else {
        return false;
    }

    info_.valid = true;
    return true;
}

}
