#include "heightmap_reader.h"
#include <cstring>
#include <algorithm>
#include <cmath>

namespace openbfv::assets::terrain {

uint32_t TerrainData::grid_size() const {
    if (heightmap_grid > 0) return heightmap_grid;
    if (!heightmap.empty()) {
        return static_cast<uint32_t>(std::sqrt(heightmap.size()));
    }
    return 0;
}

float TerrainData::cell_size() const {
    uint32_t gs = grid_size();
    return gs > 0 ? config.world_size / static_cast<float>(gs) : 0.0f;
}

bool TerrainReader::read_heightmap(const std::vector<uint8_t>& raw_data) {
    if (raw_data.empty()) return false;
    size_t total_elements = raw_data.size() / sizeof(uint16_t);
    uint32_t grid = static_cast<uint32_t>(std::sqrt(total_elements));
    if (grid * grid != total_elements || raw_data.size() != total_elements * sizeof(uint16_t)) {
        return false;
    }

    data_.heightmap_grid = grid;
    data_.heightmap.resize(total_elements);
    std::memcpy(data_.heightmap.data(), raw_data.data(), raw_data.size());
    heightmap_loaded_ = true;
    return true;
}

bool TerrainReader::read_material_map(const std::vector<uint8_t>& raw_data) {
    if (raw_data.empty()) return false;
    uint32_t grid = static_cast<uint32_t>(std::sqrt(raw_data.size()));
    if (grid * grid != raw_data.size()) {
        return false;
    }

    data_.material_grid = grid;
    data_.material_map = raw_data;
    material_map_loaded_ = true;
    return true;
}

std::optional<float> TerrainReader::height_at(uint32_t x, uint32_t z) const {
    uint32_t gs = data_.heightmap_grid;
    if (!heightmap_loaded_ || x >= gs || z >= gs) {
        return std::nullopt;
    }
    float raw = static_cast<float>(data_.heightmap[z * gs + x]);
    return (raw / 256.0f) * data_.config.y_scale;
}

std::optional<uint8_t> TerrainReader::material_at(uint32_t x, uint32_t z) const {
    uint32_t gs = data_.material_grid;
    if (!material_map_loaded_ || x >= gs || z >= gs) {
        return std::nullopt;
    }
    return data_.material_map[z * gs + x];
}

} // namespace openbfv::assets::terrain
