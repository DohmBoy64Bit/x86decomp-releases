#pragma once

#include <cstdint>
#include <vector>
#include <string>

namespace openbfv::assets::terrain {

struct PalEntry {
    uint8_t r, g, b, a;
};

struct PalInfo {
    std::vector<PalEntry> entries;
    uint32_t entry_count = 0;
    bool has_alpha = false;
    bool valid = false;
};

// TerrainPalette.pal reader — RGB/RGBA color palette
// Found in level archives with sizes 768 bytes (256*3, RGB) or 1024 bytes (256*4, RGBA)
class PalReader {
public:
    bool load(const std::vector<uint8_t>& data);
    const PalInfo& info() const { return info_; }

private:
    PalInfo info_;
};

}
