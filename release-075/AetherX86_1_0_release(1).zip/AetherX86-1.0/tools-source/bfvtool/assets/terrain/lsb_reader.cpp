#include "lsb_reader.h"
#include <cstring>
#include <cmath>

namespace openbfv::assets::terrain {

bool LsbReader::load(const std::vector<uint8_t>& data) {
    if (data.empty()) return false;

    // LightmapShadowBits.lsb — loaded at FUN_007226d0 alongside terrain tiles
    // Format hypothesis: square grid of shadow bits (1 byte per cell, 0=lit, >0=shadow)
    // Size matches terrain tile count squared
    size_t total = data.size();
    uint32_t side = static_cast<uint32_t>(std::sqrt(total));
    if (side * side != total) {
        // Try as power-of-two tiles (8x8 = 64 tiles)
        if (total == 64) side = 8;
        else return false;
    }

    info_.width = side;
    info_.height = side;
    info_.shadow_bits = data;
    info_.valid = true;
    return true;
}

}
