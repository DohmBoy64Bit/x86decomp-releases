#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <optional>

namespace openbfv::assets::terrain {

struct TerrainConfig {
    std::string heightmap_path;
    std::string material_map_path;
    std::string material_map_side_size_path;
    std::string tex_base_name;
    std::string detail_tex_name;
    uint32_t material_size = 512;
    uint32_t material_map_side_size = 0; // from GeometryTemplate.materialMapSideSize (FUN_0073d6a0 offset 0x84)
    uint32_t target_tri_count = 5000;
    float world_size = 0.0f;
    float y_scale = 1.0f;
    float water_level = 0.0f;
    float sea_floor_level = 0.0f;
    float wave_height = 1.0f;
    int32_t tex_offset_x = 0;
    int32_t tex_offset_y = 0;
};

struct TerrainData {
    TerrainConfig config;
    std::vector<uint16_t> heightmap;
    std::vector<uint8_t> material_map;
    uint32_t heightmap_grid = 0;
    uint32_t material_grid = 0;

    uint32_t grid_size() const;
    float cell_size() const;
};

class TerrainReader {
public:
    TerrainReader() = default;

    bool read_heightmap(const std::vector<uint8_t>& raw_data);
    bool read_material_map(const std::vector<uint8_t>& raw_data);
    void set_config(const TerrainConfig& config) { data_.config = config; }
    const TerrainConfig& config() const { return data_.config; }

    std::optional<float> height_at(uint32_t x, uint32_t z) const;
    std::optional<uint8_t> material_at(uint32_t x, uint32_t z) const;

    const TerrainData& data() const { return data_; }
    TerrainData take_data() { return std::move(data_); }

private:
    TerrainData data_;
    bool heightmap_loaded_ = false;
    bool material_map_loaded_ = false;
};

}
