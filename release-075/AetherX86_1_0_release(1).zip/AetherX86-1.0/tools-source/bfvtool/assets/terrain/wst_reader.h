#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace openbfv::assets::terrain {

struct WstEntry {
    std::string element_name;
    std::string geometry_name;
    float min_radius_dist_to_equals = 0.0f;
    float min_radius_dist_to_others = 0.0f;
    float normal_scale = 1.0f;
    float probability = 1.0f;
    float scale_min = 1.0f;
    float scale_max = 1.0f;

    float pick_scale() const;
};

struct WstMaterialGroup {
    std::string material_name;
    std::vector<WstEntry> entries;
};

struct WstData {
    std::string type;
    std::string version;
    std::string material_map_filename;
    uint32_t material_map_side_size = 0;
    float close_dist_fade = 0.0f;
    float close_dist_lod_factor = 0.0f;
    float close_dist_percentage = 0.0f;
    float view_distance = 100.0f;
    bool import_scene_objects = false;
    std::vector<WstMaterialGroup> material_groups;

    const WstMaterialGroup* find_material(const std::string& name) const;
};

class WstReader {
public:
    WstReader() = default;

    bool parse(const std::vector<uint8_t>& data);

    const WstData& data() const { return data_; }
    WstData take_data() { return std::move(data_); }

private:
    WstData data_;
    bool parsed_ = false;
};

struct GrowthMapData {
    uint32_t side_size = 0;
    std::vector<uint8_t> map;

    uint8_t value_at(uint32_t x, uint32_t z) const;
};

class GrowthMapReader {
public:
    GrowthMapReader() = default;

    bool parse(const std::vector<uint8_t>& raw_data, uint32_t side_size);

    const GrowthMapData& data() const { return data_; }

private:
    GrowthMapData data_;
    bool parsed_ = false;
};

} // namespace openbfv::assets::terrain
