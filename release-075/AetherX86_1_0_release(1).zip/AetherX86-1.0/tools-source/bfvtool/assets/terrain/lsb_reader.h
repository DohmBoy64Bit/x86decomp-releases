#pragma once

#include <cstdint>
#include <vector>
#include <string>

namespace openbfv::assets::terrain {

struct LsbInfo {
    std::vector<uint8_t> shadow_bits;
    uint32_t width = 0;
    uint32_t height = 0;
    bool valid = false;
};

// LightmapShadowBits.lsb reader (loaded in FUN_007226d0)
// Contains terrain lightmap shadow data with tile-based shadow coverage bits
class LsbReader {
public:
    bool load(const std::vector<uint8_t>& data);
    const LsbInfo& info() const { return info_; }

private:
    LsbInfo info_;
};

}
