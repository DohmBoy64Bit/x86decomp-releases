#include "wst_reader.h"

#include <algorithm>
#include <cctype>
#include <charconv>
#include <cstring>
#include <sstream>
#include <stdexcept>
#include <string_view>

namespace openbfv::assets::terrain {
namespace {

std::string_view trim(std::string_view s) {
    while (!s.empty() && (s.front() == ' ' || s.front() == '\t' || s.front() == '\r' || s.front() == '\n'))
        s.remove_prefix(1);
    while (!s.empty() && (s.back() == ' ' || s.back() == '\t' || s.back() == '\r' || s.back() == '\n'))
        s.remove_suffix(1);
    return s;
}

bool try_parse_float(std::string_view s, float& out) {
    s = trim(s);
    std::string tmp(s);
    const char* begin = tmp.data();
    const char* end = begin + tmp.size();
    auto [ptr, ec] = std::from_chars(begin, end, out);
    return ec == std::errc() && ptr == end;
}

void parse_scale_desc(const std::string& desc, float& min_out, float& max_out) {
    min_out = 1.0f;
    max_out = 1.0f;
    if (desc.empty() || desc.find("CRDUniform/") != 0) return;
    std::string rest = desc.substr(11);
    auto s1 = rest.find('/');
    if (s1 == std::string::npos) return;
    try_parse_float(std::string_view(rest.data(), s1), min_out);
    auto s2 = rest.find('/', s1 + 1);
    if (s2 == std::string::npos) return;
    try_parse_float(std::string_view(rest.data() + s1 + 1, s2 - s1 - 1), max_out);
}

// Minimal XML-like tag parser for WST format
// Expects: <tagName ... attr="value" ...> and </tagName>
class XmlMiniParser {
public:
    explicit XmlMiniParser(const std::vector<uint8_t>& data) {
        text_.assign(reinterpret_cast<const char*>(data.data()), data.size());
    }

    struct Tag {
        std::string name;
        bool is_closing = false;
        bool is_self_closing = false;
        std::vector<std::pair<std::string, std::string>> attrs;
    };

    Tag next_tag();

    struct TextBlock {
        std::string content;
    };

    bool done() const { return pos_ >= text_.size(); }

private:
    std::string text_;
    size_t pos_ = 0;
    void skip_ws();
    std::string read_quoted_string();
    std::string read_name();
    void skip_until(char c);
    void error(const std::string& msg);
};

void XmlMiniParser::skip_ws() {
    while (pos_ < text_.size() && (text_[pos_] == ' ' || text_[pos_] == '\t' || text_[pos_] == '\r' || text_[pos_] == '\n'))
        ++pos_;
}

std::string XmlMiniParser::read_name() {
    skip_ws();
    size_t start = pos_;
    while (pos_ < text_.size() && (std::isalnum(static_cast<unsigned char>(text_[pos_])) || text_[pos_] == '_' || text_[pos_] == '-' || text_[pos_] == '.'))
        ++pos_;
    return text_.substr(start, pos_ - start);
}

std::string XmlMiniParser::read_quoted_string() {
    skip_ws();
    if (pos_ < text_.size() && text_[pos_] == '"') {
        ++pos_;
        size_t start = pos_;
        while (pos_ < text_.size() && text_[pos_] != '"')
            ++pos_;
        std::string result = text_.substr(start, pos_ - start);
        if (pos_ < text_.size()) ++pos_;
        return result;
    }
    return "";
}

void XmlMiniParser::skip_until(char c) {
    while (pos_ < text_.size() && text_[pos_] != c)
        ++pos_;
    if (pos_ < text_.size()) ++pos_;
}

void XmlMiniParser::error(const std::string& msg) {
    throw std::runtime_error("WST parse error at " + std::to_string(pos_) + ": " + msg);
}

XmlMiniParser::Tag XmlMiniParser::next_tag() {
    skip_ws();
    while (pos_ < text_.size() && text_[pos_] != '<') {
        ++pos_;
        skip_ws();
    }
    if (pos_ >= text_.size()) return Tag{};

    ++pos_;

    // Skip XML processing instructions like <?xml ...?>
    if (pos_ < text_.size() && text_[pos_] == '?') {
        skip_until('>');  // consumes ?>
        return next_tag();
    }
    // Skip comments like <!-- ... -->
    if (pos_ + 2 < text_.size() && text_[pos_] == '!' && text_[pos_+1] == '-' && text_[pos_+2] == '-') {
        while (pos_ + 2 < text_.size()) {
            if (text_[pos_] == '-' && text_[pos_+1] == '-' && text_[pos_+2] == '>') {
                pos_ += 3;
                return next_tag();
            }
            ++pos_;
        }
        return next_tag();
    }

    Tag tag;
    if (pos_ < text_.size() && text_[pos_] == '/') {
        tag.is_closing = true;
        ++pos_;
    }
    tag.name = read_name();
    if (tag.name.empty()) error("empty tag name");

    if (!tag.is_closing) {
        while (true) {
            skip_ws();
            if (pos_ >= text_.size()) break;
            if (text_[pos_] == '>' || text_[pos_] == '/') {
                if (text_[pos_] == '/') {
                    tag.is_self_closing = true;
                    ++pos_;
                }
                if (pos_ < text_.size() && text_[pos_] == '>')
                    ++pos_;
                break;
            }
            std::string attr_name = read_name();
            if (attr_name.empty()) break;
            skip_ws();
            if (pos_ < text_.size() && text_[pos_] == '=') {
                ++pos_;
                skip_ws();
                std::string attr_val = read_quoted_string();
                tag.attrs.emplace_back(std::move(attr_name), std::move(attr_val));
            }
        }
    } else {
        skip_until('>');
    }
    return tag;
}

} // anonymous namespace

float WstEntry::pick_scale() const {
    if (scale_min >= scale_max) return scale_min;
    return scale_min + (scale_max - scale_min) * 0.5f;
}

const WstMaterialGroup* WstData::find_material(const std::string& name) const {
    for (const auto& mg : material_groups) {
        if (mg.material_name == name) return &mg;
    }
    return nullptr;
}

bool WstReader::parse(const std::vector<uint8_t>& data) {
    if (data.empty()) return false;

    WstData result;
    XmlMiniParser xml(data);

    XmlMiniParser::Tag root_tag = xml.next_tag();
    // Find the version attribute
    for (const auto& attr : root_tag.attrs) {
        if (attr.first == "VERS" || attr.first == "Vers") {
            result.version = attr.second;
        }
    }

    // Now parse children of WRAPPER_TREE
    XmlMiniParser::Tag type_tag = xml.next_tag();
    if (type_tag.name.empty()) return false;

    result.type = type_tag.name;

    // Parse attributes on overGrowth / underGrowth
    for (const auto& attr : type_tag.attrs) {
        if (attr.first == "materialMapFilename") result.material_map_filename = attr.second;
        else if (attr.first == "materialMapSideSize") {
            result.material_map_side_size = static_cast<uint32_t>(std::stoul(attr.second));
        }
        else if (attr.first == "closeDistFade") try_parse_float(attr.second, result.close_dist_fade);
        else if (attr.first == "closeDistLodFactor") try_parse_float(attr.second, result.close_dist_lod_factor);
        else if (attr.first == "closeDistPercentage") try_parse_float(attr.second, result.close_dist_percentage);
        else if (attr.first == "viewDistance") try_parse_float(attr.second, result.view_distance);
        else if (attr.first == "importSceneObjects") result.import_scene_objects = (attr.second == "true");
    }

    // Parse <materials> block
    XmlMiniParser::Tag tag;
    int depth = 0;
    while (true) {
        tag = xml.next_tag();
        if (tag.name.empty()) break;

        if (tag.name == "materials" && !tag.is_closing) {
            depth = 1;
            continue;
        }
        if (tag.name == "materials" && tag.is_closing) {
            break;
        }
        if (tag.name == type_tag.name && tag.is_closing) {
            break;
        }
        if (tag.name == "WRAPPER_TREE" && tag.is_closing) break;

        if (tag.name == "types") continue;

        if (tag.name == "types" && tag.is_closing) continue;

        // When we hit a material group name inside <materials>
        if (!tag.is_closing && !tag.is_self_closing) {
            if (tag.name == "materials" || tag.name == "types") continue;

            WstMaterialGroup group;
            group.material_name = tag.name;

            // Parse children of a material group — entries may be inside
            // <types> or directly as children
            bool in_types = false;
            while (true) {
                XmlMiniParser::Tag inner = xml.next_tag();
                if (inner.name.empty()) break;

                if (inner.name == "types" && !inner.is_closing) {
                    in_types = true;
                    continue;
                }
                if (inner.name == "types" && inner.is_closing) {
                    in_types = false;
                    continue;
                }

                if (inner.name == group.material_name && inner.is_closing) break;
                if (inner.name == "materials" && inner.is_closing) goto done;

                if (inner.is_closing) continue;

                // This is an entry element
                WstEntry entry;
                entry.element_name = inner.name;
                for (const auto& attr : inner.attrs) {
                    if (attr.first == "geometryName") entry.geometry_name = attr.second;
                    else if (attr.first == "minRadiusDistToEquals") try_parse_float(attr.second, entry.min_radius_dist_to_equals);
                    else if (attr.first == "minRadiusDistToOthers") try_parse_float(attr.second, entry.min_radius_dist_to_others);
                    else if (attr.first == "normalScale") try_parse_float(attr.second, entry.normal_scale);
                    else if (attr.first == "probability") try_parse_float(attr.second, entry.probability);
                    else if (attr.first == "scale") parse_scale_desc(attr.second, entry.scale_min, entry.scale_max);
                }
                if (!entry.geometry_name.empty()) {
                    group.entries.push_back(std::move(entry));
                }

                // Find the closing tag for this entry
                while (true) {
                    XmlMiniParser::Tag closer = xml.next_tag();
                    if (closer.name.empty()) break;
                    if (closer.name == inner.name && closer.is_closing) break;
                    if (!in_types && closer.name == group.material_name && closer.is_closing) {
                        result.material_groups.push_back(std::move(group));
                        goto next_material;
                    }
                    if (closer.name == "types" && closer.is_closing) { in_types = false; break; }
                    if (closer.name == group.material_name && closer.is_closing) {
                        result.material_groups.push_back(std::move(group));
                        goto next_material;
                    }
                    if (closer.name == "materials" && closer.is_closing) goto done;
                }
            }
            result.material_groups.push_back(std::move(group));
            next_material:
            continue;
        }
    }
    done:
    data_ = std::move(result);
    parsed_ = true;
    return true;
}

bool GrowthMapReader::parse(const std::vector<uint8_t>& raw_data, uint32_t side_size) {
    if (raw_data.empty()) return false;
    if (raw_data.size() != static_cast<size_t>(side_size) * side_size) return false;

    data_.side_size = side_size;
    data_.map = raw_data;
    parsed_ = true;
    return true;
}

uint8_t GrowthMapData::value_at(uint32_t x, uint32_t z) const {
    if (x >= side_size || z >= side_size || map.empty()) return 0;
    return map[static_cast<size_t>(z) * side_size + x];
}

} // namespace openbfv::assets::terrain
