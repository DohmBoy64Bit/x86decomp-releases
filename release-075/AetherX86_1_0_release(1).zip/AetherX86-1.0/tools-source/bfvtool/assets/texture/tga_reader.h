#pragma once

#include <cstdint>
#include <vector>
#include <string>

namespace openbfv::assets::texture {

struct TgaHeader {
    uint8_t id_length;
    uint8_t color_map_type;
    uint8_t image_type;
    uint16_t color_map_first;
    uint16_t color_map_length;
    uint8_t color_map_entry_size;
    uint16_t x_origin;
    uint16_t y_origin;
    uint16_t width;
    uint16_t height;
    uint8_t depth;
    uint8_t descriptor;
};

struct TgaInfo {
    uint32_t width;
    uint32_t height;
    uint32_t bpp;
    bool has_alpha;
    bool is_grayscale;
    bool top_left; // origin in top-left corner
    size_t data_offset;
};

struct RawImage {
    uint32_t width;
    uint32_t height;
    std::vector<uint8_t> pixels; // RGBA8
};

class TgaReader {
public:
    explicit TgaReader(const std::vector<uint8_t>& data);
    bool parse();
    const TgaInfo& info() const { return info_; }
    RawImage decode();

    static bool is_tga(const std::vector<uint8_t>& data);

private:
    bool parse_header();
    RawImage decode_truecolor();
    RawImage decode_grayscale();
    RawImage decode_color_mapped();
    RawImage decode_rle();

    const std::vector<uint8_t>& data_;
    TgaInfo info_;
    TgaHeader header_ = {};
    bool parsed_ = false;
};

}
