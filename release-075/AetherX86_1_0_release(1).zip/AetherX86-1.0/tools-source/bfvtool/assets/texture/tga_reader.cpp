#include "tga_reader.h"
#include <cstring>
#include <algorithm>

namespace openbfv::assets::texture {

TgaReader::TgaReader(const std::vector<uint8_t>& data) : data_(data) {}

bool TgaReader::is_tga(const std::vector<uint8_t>& data) {
    if (data.size() < 18) return false;
    // TGA has no magic number, but valid files have:
    // - id_length <= 255
    // - color_map_type == 0 or 1
    // - image_type in {1,2,3,9,10,11}
    // - width > 0, height > 0
    const uint8_t* h = data.data();
    if (h[0] > 255) return false;
    if (h[1] > 1) return false;
    if (h[2] != 1 && h[2] != 2 && h[2] != 3 && h[2] != 9 && h[2] != 10 && h[2] != 11) return false;
    uint16_t w = h[12] | (static_cast<uint16_t>(h[13]) << 8);
    uint16_t hh = h[14] | (static_cast<uint16_t>(h[15]) << 8);
    return w > 0 && w <= 8192 && hh > 0 && hh <= 8192;
}

bool TgaReader::parse() {
    if (!parse_header()) return false;
    parsed_ = true;
    return true;
}

bool TgaReader::parse_header() {
    if (data_.size() < 18) return false;

    header_.id_length = data_[0];
    header_.color_map_type = data_[1];
    header_.image_type = data_[2];
    header_.color_map_first = data_[3] | (static_cast<uint16_t>(data_[4]) << 8);
    header_.color_map_length = data_[5] | (static_cast<uint16_t>(data_[6]) << 8);
    header_.color_map_entry_size = data_[7];
    header_.x_origin = data_[8] | (static_cast<uint16_t>(data_[9]) << 8);
    header_.y_origin = data_[10] | (static_cast<uint16_t>(data_[11]) << 8);
    header_.width = data_[12] | (static_cast<uint16_t>(data_[13]) << 8);
    header_.height = data_[14] | (static_cast<uint16_t>(data_[15]) << 8);
    header_.depth = data_[16];
    header_.descriptor = data_[17];

    if (header_.width == 0 || header_.height == 0) return false;
    if (header_.depth != 8 && header_.depth != 16 && header_.depth != 24 && header_.depth != 32) return false;
    if (header_.image_type != 1 && header_.image_type != 2 && header_.image_type != 3 &&
        header_.image_type != 9 && header_.image_type != 10 && header_.image_type != 11) return false;
    if (header_.color_map_type > 1) return false;

    info_.width = header_.width;
    info_.height = header_.height;
    info_.bpp = header_.depth;
    info_.has_alpha = (header_.depth == 32) || (header_.depth == 16);
    info_.is_grayscale = (header_.image_type == 3 || header_.image_type == 11);
    info_.top_left = (header_.descriptor & 0x20) != 0;

    // Data starts after header + id field + color map
    size_t offset = 18 + header_.id_length;
    if (header_.color_map_type == 1) {
        size_t cm_size = (header_.color_map_entry_size / 8) * header_.color_map_length;
        offset += cm_size;
    }
    info_.data_offset = offset;

    return offset <= data_.size();
}

RawImage TgaReader::decode() {
    if (!parsed_) return {};

    switch (header_.image_type) {
        case 1: return decode_color_mapped();
        case 2: return decode_truecolor();
        case 3: return decode_grayscale();
        case 9:
        case 10:
        case 11: return decode_rle();
        default: return {};
    }
}

RawImage TgaReader::decode_truecolor() {
    RawImage img;
    img.width = header_.width;
    img.height = header_.height;
    img.pixels.resize(static_cast<size_t>(header_.width) * header_.height * 4);

    size_t src_row_size = static_cast<size_t>(header_.width) * (header_.depth / 8);
    size_t src_idx = info_.data_offset;

    for (uint32_t y = 0; y < header_.height; ++y) {
        uint32_t dst_y = info_.top_left ? y : (header_.height - 1 - y);
        for (uint32_t x = 0; x < header_.width; ++x) {
            size_t dst = (static_cast<size_t>(dst_y) * header_.width + x) * 4;
            if (header_.depth == 32) {
                img.pixels[dst + 0] = data_[src_idx + 2]; // B -> R
                img.pixels[dst + 1] = data_[src_idx + 1]; // G -> G
                img.pixels[dst + 2] = data_[src_idx + 0]; // R -> B
                img.pixels[dst + 3] = data_[src_idx + 3]; // A
                src_idx += 4;
            } else if (header_.depth == 24) {
                img.pixels[dst + 0] = data_[src_idx + 2];
                img.pixels[dst + 1] = data_[src_idx + 1];
                img.pixels[dst + 2] = data_[src_idx + 0];
                img.pixels[dst + 3] = 255;
                src_idx += 3;
            }
        }
    }

    return img;
}

RawImage TgaReader::decode_grayscale() {
    RawImage img;
    img.width = header_.width;
    img.height = header_.height;
    img.pixels.resize(static_cast<size_t>(header_.width) * header_.height * 4);

    size_t src_idx = info_.data_offset;
    for (uint32_t y = 0; y < header_.height; ++y) {
        uint32_t dst_y = info_.top_left ? y : (header_.height - 1 - y);
        for (uint32_t x = 0; x < header_.width; ++x) {
            size_t dst = (static_cast<size_t>(dst_y) * header_.width + x) * 4;
            uint8_t grey = data_[src_idx++];
            img.pixels[dst + 0] = grey;
            img.pixels[dst + 1] = grey;
            img.pixels[dst + 2] = grey;
            img.pixels[dst + 3] = 255;
        }
    }

    return img;
}

RawImage TgaReader::decode_color_mapped() {
    if (header_.color_map_type != 1) return {};
    if (data_.size() < info_.data_offset) return {};

    // Read color map
    size_t cm_entries = header_.color_map_length;
    size_t cm_entry_bytes = header_.color_map_entry_size / 8;
    size_t cm_offset = 18 + header_.id_length;

    std::vector<uint8_t> palette;
    palette.resize(cm_entries * 4);
    for (size_t i = 0; i < cm_entries; ++i) {
        size_t src = cm_offset + i * cm_entry_bytes;
        if (src + cm_entry_bytes > data_.size()) break;
        palette[i * 4 + 0] = data_[src + 2];
        palette[i * 4 + 1] = data_[src + 1];
        palette[i * 4 + 2] = data_[src + 0];
        palette[i * 4 + 3] = (cm_entry_bytes >= 4) ? data_[src + 3] : 255;
    }

    RawImage img;
    img.width = header_.width;
    img.height = header_.height;
    img.pixels.resize(static_cast<size_t>(header_.width) * header_.height * 4);

    size_t src_idx = info_.data_offset;
    for (uint32_t y = 0; y < header_.height; ++y) {
        uint32_t dst_y = info_.top_left ? y : (header_.height - 1 - y);
        for (uint32_t x = 0; x < header_.width; ++x) {
            size_t dst = (static_cast<size_t>(dst_y) * header_.width + x) * 4;
            uint8_t idx = data_[src_idx++];
            if (static_cast<size_t>(idx) * 4 + 3 < palette.size()) {
                std::memcpy(&img.pixels[dst], &palette[idx * 4], 4);
            }
        }
    }

    return img;
}

RawImage TgaReader::decode_rle() {
    RawImage img;
    img.width = header_.width;
    img.height = header_.height;
    img.pixels.resize(static_cast<size_t>(header_.width) * header_.height * 4);

    size_t src_idx = info_.data_offset;
    size_t total_pixels = static_cast<size_t>(header_.width) * header_.height;
    size_t pixel_idx = 0;
    int bytes_per_pixel = header_.depth / 8;

    std::vector<uint8_t> pixel(bytes_per_pixel);

    while (pixel_idx < total_pixels && src_idx < data_.size()) {
        uint8_t packet = data_[src_idx++];
        uint8_t count = (packet & 0x7F) + 1;

        // RLE packet (top bit set): repeat the same pixel
        // Raw packet (top bit clear): read 'count' pixels
        if ((packet & 0x80) != 0) {
            // RLE
            for (int i = 0; i < bytes_per_pixel; ++i) {
                pixel[i] = data_[src_idx++];
            }
            for (uint8_t r = 0; r < count && pixel_idx < total_pixels; ++r) {
                size_t px = pixel_idx++;
                uint32_t y = static_cast<uint32_t>(px / header_.width);
                uint32_t x = static_cast<uint32_t>(px % header_.width);
                uint32_t dst_y = info_.top_left ? y : (header_.height - 1 - y);
                size_t dst = (static_cast<size_t>(dst_y) * header_.width + x) * 4;
                if (header_.depth == 32) {
                    img.pixels[dst + 0] = pixel[2];
                    img.pixels[dst + 1] = pixel[1];
                    img.pixels[dst + 2] = pixel[0];
                    img.pixels[dst + 3] = pixel[3];
                } else if (header_.depth == 24) {
                    img.pixels[dst + 0] = pixel[2];
                    img.pixels[dst + 1] = pixel[1];
                    img.pixels[dst + 2] = pixel[0];
                    img.pixels[dst + 3] = 255;
                }
            }
        } else {
            // Raw
            for (uint8_t r = 0; r < count && pixel_idx < total_pixels; ++r) {
                for (int i = 0; i < bytes_per_pixel; ++i) {
                    pixel[i] = data_[src_idx++];
                }
                size_t px = pixel_idx++;
                uint32_t y = static_cast<uint32_t>(px / header_.width);
                uint32_t x = static_cast<uint32_t>(px % header_.width);
                uint32_t dst_y = info_.top_left ? y : (header_.height - 1 - y);
                size_t dst = (static_cast<size_t>(dst_y) * header_.width + x) * 4;
                if (header_.depth == 32) {
                    img.pixels[dst + 0] = pixel[2];
                    img.pixels[dst + 1] = pixel[1];
                    img.pixels[dst + 2] = pixel[0];
                    img.pixels[dst + 3] = pixel[3];
                } else if (header_.depth == 24) {
                    img.pixels[dst + 0] = pixel[2];
                    img.pixels[dst + 1] = pixel[1];
                    img.pixels[dst + 2] = pixel[0];
                    img.pixels[dst + 3] = 255;
                }
            }
        }
    }

    return img;
}

}
