#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <optional>
#include <memory>

namespace openbfv::assets::mesh {

struct SmVec3 {
    float x, y, z;
};

struct SmBoundingBox {
    SmVec3 min;
    SmVec3 max;
};

struct SmCollisionVertex {
    SmVec3 position;
    uint16_t unknown;
};

struct SmCollisionFace {
    uint16_t indices[3];
    uint16_t material_id;
};

struct SmBspNode {
    SmBoundingBox bounds;
    std::vector<uint32_t> face_indices;
    std::unique_ptr<SmBspNode> child_left;
    std::unique_ptr<SmBspNode> child_right;

    ~SmBspNode();
};

struct SmCollisionMesh {
    std::vector<SmCollisionVertex> vertices;
    std::vector<SmCollisionFace> faces;
    std::vector<SmVec3> face_normals;
    std::unique_ptr<SmBspNode> bsp_root;
};

struct SmMaterialBlock {
    std::string name;
    uint32_t render_type;
    uint32_t vertex_format;
    uint32_t vertex_byte_size;
    uint32_t num_vertices;
    uint32_t num_face_values;
    uint32_t material_settings;

    std::vector<SmVec3> positions;
    std::vector<SmVec3> normals;
    std::vector<float> texcoords0;
    std::vector<float> texcoords1;
    std::vector<uint16_t> indices;
};

struct SmLodMesh {
    std::vector<SmMaterialBlock> materials;
};

struct SmHeader {
    uint32_t version;
    uint32_t unknown1;
    SmBoundingBox bounds;
    uint8_t qflag;
    bool has_qflag;
};

// LOD override properties from StandardMeshTemplate (FUN_0074b210)
struct SmLodOverrides {
    bool only_use_highest_lod = false;   // offset +0x1a4 ("onlyUseHigestLod" - typo in original)
    float min_lod_step_percent = 0.0f;   // offset +0x1a8
    float cull_distance = 0.0f;          // offset +0x1ac
};

struct SmMeshInfo {
    SmHeader header;
    std::vector<SmCollisionMesh> collision_meshes;
    std::vector<SmLodMesh> lods;
    std::vector<SmLodMesh> shadow_lods;
    bool has_shadow_lods;
    uint32_t portal_block_size;
    SmLodOverrides lod_overrides;

    size_t vertex_count() const;
    size_t face_count() const;
    size_t collision_vertex_count() const;
    size_t collision_face_count() const;
};

class SmReader {
public:
    explicit SmReader(const std::vector<uint8_t>& data);

    bool parse();
    const SmMeshInfo& info() const;
    SmMeshInfo take_info() { return std::move(info_); }

    static std::string version_name(uint32_t version);
    static std::string render_type_name(uint32_t type);
    static std::string material_settings_desc(uint32_t settings);

private:
    bool read_header();
    bool read_collision_meshes();
    bool read_collision_mesh(SmCollisionMesh& mesh);
    std::unique_ptr<SmBspNode> read_bsp_node();
    bool read_lods();
    bool read_lod(SmLodMesh& lod);
    bool read_shadow_lods();
    bool read_portal_mesh();

    const std::vector<uint8_t>& data_;
    SmMeshInfo info_;
    size_t offset_ = 0;
    bool parsed_ = false;

    template<typename T>
    T read();
    template<typename T>
    std::vector<T> read_array(size_t count);
    std::string read_string(uint32_t len);
    void skip(size_t bytes);
    size_t remaining() const;
};

}
