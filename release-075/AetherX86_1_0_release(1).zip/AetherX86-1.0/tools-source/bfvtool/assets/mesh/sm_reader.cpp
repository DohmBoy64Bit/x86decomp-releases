#include "sm_reader.h"
#include <cstring>
#include <stdexcept>
#include <iostream>
#include <algorithm>

namespace openbfv::assets::mesh {

using namespace std;

// Read helpers

template<typename T>
T SmReader::read() {
    if (offset_ + sizeof(T) > data_.size()) {
        throw runtime_error("Unexpected end of .sm data");
    }
    T val;
    memcpy(&val, data_.data() + offset_, sizeof(T));
    offset_ += sizeof(T);
    return val;
}

template<typename T>
vector<T> SmReader::read_array(size_t count) {
    size_t byte_count = count * sizeof(T);
    if (offset_ + byte_count > data_.size()) {
        throw runtime_error("Unexpected end of .sm data reading array");
    }
    vector<T> result(count);
    memcpy(result.data(), data_.data() + offset_, byte_count);
    offset_ += byte_count;
    return result;
}

string SmReader::read_string(uint32_t len) {
    if (offset_ + len > data_.size()) {
        throw runtime_error("Unexpected end of .sm data reading string");
    }
    string s(reinterpret_cast<const char*>(data_.data() + offset_), len);
    offset_ += len;
    return s;
}

void SmReader::skip(size_t bytes) {
    if (offset_ + bytes > data_.size()) {
        throw runtime_error("Skip beyond end of .sm data");
    }
    offset_ += bytes;
}

size_t SmReader::remaining() const {
    return data_.size() - offset_;
}

// SmReader implementation

SmReader::SmReader(const vector<uint8_t>& data)
    : data_(data) {
}

bool SmReader::parse() {
    try {
        offset_ = 0;
        if (!read_header()) return false;
        if (!read_collision_meshes()) return false;
        if (!read_lods()) return false;
        if (!read_shadow_lods()) return false;
        if (!read_portal_mesh()) return false;
        parsed_ = true;
        return true;
    } catch (const exception& e) {
        cerr << "SmReader error: " << e.what() << " at offset " << offset_ << endl;
        return false;
    }
}

const SmMeshInfo& SmReader::info() const {
    return info_;
}

bool SmReader::read_header() {
    info_.header.version = read<uint32_t>();
    info_.header.unknown1 = read<uint32_t>();

    auto bb = read_array<float>(6);
    info_.header.bounds.min = {bb[0], bb[1], bb[2]};
    info_.header.bounds.max = {bb[3], bb[4], bb[5]};

    if (info_.header.version == 10) {
        info_.header.qflag = read<uint8_t>();
        info_.header.has_qflag = true;
    } else {
        info_.header.qflag = 0;
        info_.header.has_qflag = false;
    }

    return true;
}

bool SmReader::read_collision_meshes() {
    uint32_t num_col = read<uint32_t>();
    info_.collision_meshes.reserve(num_col);

    for (uint32_t i = 0; i < num_col; ++i) {
        uint32_t chunk_size = read<uint32_t>();
        size_t chunk_start = offset_;

        SmCollisionMesh mesh;
        if (!read_collision_mesh(mesh)) return false;

        size_t chunk_end = chunk_start + chunk_size;
        if (offset_ < chunk_end) {
            skip(chunk_end - offset_);
        } else if (offset_ > chunk_end) {
            cerr << "Warning: Overran collision chunk by " << (offset_ - chunk_end) << " bytes" << endl;
        }

        info_.collision_meshes.push_back(move(mesh));
    }

    return true;
}

bool SmReader::read_collision_mesh(SmCollisionMesh& mesh) {
    uint32_t magic = read<uint32_t>();
    if (magic != 0xEB97C2FA) {
        cerr << "Warning: Unexpected collision mesh magic: 0x" << hex << magic << dec << " at offset "
             << (offset_ - 4) << " (expected 0xEB97C2FA)" << endl;
        return false;
    }

    uint32_t unknown2 = read<uint32_t>();
    if (unknown2 != 5) {
        cerr << "Warning: Unexpected collision unknown2: " << unknown2 << " (expected 5)" << endl;
    }

    uint32_t num_verts = read<uint32_t>();
    mesh.vertices.reserve(num_verts);
    for (uint32_t i = 0; i < num_verts; ++i) {
        auto pos = read_array<float>(3);
        uint16_t vert_unk = read<uint16_t>();
        read<uint16_t>(); // padding
        mesh.vertices.push_back({{pos[0], pos[1], pos[2]}, vert_unk});
    }

    uint32_t num_faces = read<uint32_t>();
    mesh.faces.reserve(num_faces);
    for (uint32_t i = 0; i < num_faces; ++i) {
        auto idx = read_array<uint16_t>(3);
        uint16_t mat_id = read<uint16_t>();
        mesh.faces.push_back({{idx[0], idx[1], idx[2]}, mat_id});
    }

    uint32_t total_face_list_count = read<uint32_t>();
    uint32_t num_bsp_nodes = read<uint32_t>();
    uint32_t num_face_normals = read<uint32_t>();

    mesh.face_normals.reserve(num_face_normals);
    for (uint32_t i = 0; i < num_face_normals; ++i) {
        auto n = read_array<float>(3);
        read_array<uint32_t>(5);
        mesh.face_normals.push_back({n[0], n[1], n[2]});
    }

    mesh.bsp_root = read_bsp_node();

    return true;
}

unique_ptr<SmBspNode> SmReader::read_bsp_node() {
    auto node = make_unique<SmBspNode>();
    auto bb = read_array<float>(6);
    node->bounds = {{bb[0], bb[1], bb[2]}, {bb[3], bb[4], bb[5]}};

    uint32_t face_count = read<uint32_t>();
    node->face_indices = read_array<uint32_t>(face_count);

    uint8_t has_left = read<uint8_t>();
    if (has_left) {
        node->child_left = read_bsp_node();
    }

    uint8_t has_right = read<uint8_t>();
    if (has_right) {
        node->child_right = read_bsp_node();
    }

    return node;
}

SmBspNode::~SmBspNode() = default;

bool SmReader::read_lods() {
    uint32_t num_lods = read<uint32_t>();
    info_.lods.reserve(num_lods);

    for (uint32_t i = 0; i < num_lods; ++i) {
        SmLodMesh lod;
        if (!read_lod(lod)) return false;
        info_.lods.push_back(move(lod));
    }

    return true;
}

bool SmReader::read_lod(SmLodMesh& lod) {
    uint32_t num_materials = read<uint32_t>();
    lod.materials.reserve(num_materials);

    // Phase 1: read material headers
    for (uint32_t i = 0; i < num_materials; ++i) {
        SmMaterialBlock mat;
        uint32_t name_len = read<uint32_t>();
        mat.name = read_string(name_len);

        read_array<uint8_t>(12); // unknown padding (always 0)

        mat.render_type = read<uint32_t>();
        mat.vertex_format = read<uint32_t>();
        mat.vertex_byte_size = read<uint32_t>();
        mat.num_vertices = read<uint32_t>();
        mat.num_face_values = read<uint32_t>();
        mat.material_settings = read<uint32_t>();

        lod.materials.push_back(move(mat));
    }

    // Phase 2: read geometry data for each material
    for (uint32_t i = 0; i < num_materials; ++i) {
        auto& mat = lod.materials[i];
        bool has_lightmap = (mat.vertex_byte_size == 40);

        for (uint32_t v = 0; v < mat.num_vertices; ++v) {
            auto pos = read_array<float>(3);
            mat.positions.push_back({pos[0], pos[1], pos[2]});

            auto nrm = read_array<float>(3);
            mat.normals.push_back({nrm[0], nrm[1], nrm[2]});

            auto tc0 = read_array<float>(2);
            mat.texcoords0.push_back(tc0[0]);
            mat.texcoords0.push_back(tc0[1]);

            if (has_lightmap) {
                auto tc1 = read_array<float>(2);
                mat.texcoords1.push_back(tc1[0]);
                mat.texcoords1.push_back(tc1[1]);
            }
        }

        mat.indices = read_array<uint16_t>(mat.num_face_values);
    }

    return true;
}

bool SmReader::read_shadow_lods() {
    if (remaining() == 0) {
        info_.has_shadow_lods = false;
        return true;
    }

    uint32_t shadow_flag = read<uint32_t>();
    if (shadow_flag != 1) {
        // Not hasShadowLODs — could be garbage or next section.
        // Treat as no shadow LODs and backtrack so the next reader
        // sees this value as portalBlockSize.
        info_.has_shadow_lods = false;
        offset_ -= 4;
        return true;
    }

    info_.has_shadow_lods = true;
    uint32_t num_shadow = read<uint32_t>();
    info_.shadow_lods.reserve(num_shadow);

    for (uint32_t i = 0; i < num_shadow; ++i) {
        SmLodMesh lod;
        if (!read_lod(lod)) return false;
        info_.shadow_lods.push_back(move(lod));
    }

    return true;
}

bool SmReader::read_portal_mesh() {
    if (remaining() == 0) {
        info_.portal_block_size = 0;
        return true;
    }

    info_.portal_block_size = read<uint32_t>();
    if (info_.portal_block_size == 0) return true;

    // Portal mesh exists but format is not yet decoded
    // Skip the block for now
    if (remaining() < info_.portal_block_size) {
        cerr << "Warning: Portal mesh block size exceeds remaining data" << endl;
        return false;
    }
    skip(info_.portal_block_size);

    return true;
}

// SmMeshInfo stat accessors

size_t SmMeshInfo::vertex_count() const {
    size_t count = 0;
    for (const auto& lod : lods) {
        for (const auto& mat : lod.materials) {
            count += mat.num_vertices;
        }
    }
    return count;
}

size_t SmMeshInfo::face_count() const {
    size_t count = 0;
    for (const auto& lod : lods) {
        for (const auto& mat : lod.materials) {
            if (mat.render_type == 4) {
                count += mat.num_face_values / 3;
            } else if (mat.render_type == 5) {
                if (mat.num_face_values >= 3) {
                    count += mat.num_face_values - 2;
                }
            }
        }
    }
    return count;
}

size_t SmMeshInfo::collision_vertex_count() const {
    size_t count = 0;
    for (const auto& col : collision_meshes) {
        count += col.vertices.size();
    }
    return count;
}

size_t SmMeshInfo::collision_face_count() const {
    size_t count = 0;
    for (const auto& col : collision_meshes) {
        count += col.faces.size();
    }
    return count;
}

// Static helpers

string SmReader::version_name(uint32_t version) {
    switch (version) {
        case 9:     return "BF1942 kit/Rexman (v9)";
        case 10:    return "BF1942 standard/MDT (v10)";
        case 2573:  return "BF Vietnam (v2573/0x0A0D)";
        default:    return "Unknown (v" + to_string(version) + ")";
    }
}

string SmReader::render_type_name(uint32_t type) {
    switch (type) {
        case 4: return "TriangleList";
        case 5: return "TriangleStrip";
        default: return "Unknown (" + to_string(type) + ")";
    }
}

string SmReader::material_settings_desc(uint32_t settings) {
    string desc;
    if (settings & 1) desc += "bit0 ";
    if (settings & 2) desc += "transparent ";
    if (settings & 4) desc += "depthWrite ";
    if (settings & 8) desc += "bit3 ";
    if (desc.empty()) desc = "default";
    return desc;
}

}
