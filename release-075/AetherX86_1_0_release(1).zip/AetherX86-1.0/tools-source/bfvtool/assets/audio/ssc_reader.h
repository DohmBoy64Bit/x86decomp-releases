#pragma once

#include <string>
#include <vector>
#include <unordered_map>

namespace openbfv::assets::audio {

struct SscSoundDef {
    std::string name;
    std::string filename;
    float volume = 1.0f;
    float pitch = 1.0f;
    bool loop = false;
    float min_distance = 10.0f;
    float max_distance = 1000.0f;
    int priority = 0;

    std::vector<std::pair<std::string, std::string>> unknown_properties;
};

struct SscInfo {
    std::vector<SscSoundDef> sounds;
    std::vector<std::string> errors;
};

// Sound script (.ssc) reader — text format with sound definitions
// Found in objects/*/Sounds/*.ssc and objects/*/Sounds/*/GamePlay.ssc
class SscReader {
public:
    explicit SscReader(const std::string& content);
    bool parse();
    const SscInfo& info() const { return info_; }

private:
    std::string content_;
    SscInfo info_;
    bool parsed_ = false;
};

}
