#include "ssc_reader.h"
#include <sstream>
#include <algorithm>
#include <cctype>

namespace openbfv::assets::audio {

SscReader::SscReader(const std::string& content) : content_(content) {}

static std::string trim(const std::string& s) {
    size_t start = 0;
    while (start < s.size() && (s[start] == ' ' || s[start] == '\t' || s[start] == '\r')) ++start;
    size_t end = s.size();
    while (end > start && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\r')) --end;
    return s.substr(start, end - start);
}

static std::string to_lower(const std::string& s) {
    std::string r;
    r.reserve(s.size());
    for (char c : s) r += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return r;
}

bool SscReader::parse() {
    std::istringstream stream(content_);
    std::string line;
    SscSoundDef current;
    bool in_sound = false;
    bool in_effect = false;
    int effect_depth = 0;

    auto flush = [&]() {
        if (in_sound && !current.filename.empty()) {
            info_.sounds.push_back(current);
        }
        current = SscSoundDef{};
        in_sound = false;
        in_effect = false;
        effect_depth = 0;
    };

    while (std::getline(stream, line)) {
        line = trim(line);
        if (line.empty()) continue;

        // Skip comments
        if (line.find("***") == 0 || line.find("/*") == 0 || line.find("//") == 0) continue;

        // Close block comments
        if (line.find("*/") != std::string::npos) continue;

        std::string lower = to_lower(line);
        std::string first_word = line;
        {
            size_t sp = line.find(' ');
            if (sp != std::string::npos) first_word = line.substr(0, sp);
        }

        if (lower == "beginEffect" || lower == "begineffect") {
            in_effect = true;
            ++effect_depth;
            continue;
        }
        if (lower == "endEffect" || lower == "endeffect") {
            --effect_depth;
            if (effect_depth <= 0) in_effect = false;
            continue;
        }
        if (in_effect) continue;

        if (to_lower(first_word) == "newpatch") {
            flush();
            in_sound = true;
            continue;
        }

        if (!in_sound) continue;

        if (to_lower(first_word) == "load") {
            size_t sp = line.find(' ');
            if (sp != std::string::npos) {
                current.filename = trim(line.substr(sp));
            }
        } else if (to_lower(first_word) == "loop") {
            current.loop = true;
        } else if (to_lower(first_word) == "doppleron") {
            current.unknown_properties.push_back({"dopplerOn", ""});
        } else if (to_lower(first_word) == "stop") {
            size_t sp = line.find(' ');
            if (sp != std::string::npos) {
                current.unknown_properties.push_back({"stop", trim(line.substr(sp))});
            }
        } else if (to_lower(first_word) == "priority") {
            size_t sp = line.find(' ');
            if (sp != std::string::npos) {
                try { current.priority = std::stoi(trim(line.substr(sp))); }
                catch (...) {}
            }
        } else if (to_lower(first_word) == "mindistance") {
            size_t sp = line.find(' ');
            if (sp != std::string::npos) {
                try { current.min_distance = std::stof(trim(line.substr(sp))); }
                catch (...) {}
            }
        } else if (to_lower(first_word) == "volume") {
            size_t sp = line.find(' ');
            if (sp != std::string::npos) {
                try { current.volume = std::stof(trim(line.substr(sp))); }
                catch (...) {}
            }
        } else if (to_lower(first_word) == "randomstartpitch") {
            // Format: "randomStartPitch base/var"
            // Ignored for now, stored as unknown
            current.unknown_properties.push_back({"randomStartPitch", line.substr(16)});
        } else if (to_lower(first_word) == "donotusenewpatch") {
            // Just a flag
            current.unknown_properties.push_back({"doNotUseNewPatch", ""});
        } else if (to_lower(first_word) == "#templatelevel") {
            // Template level marker - new section
            flush();
            // Store as unknown rather than losing it
        }
    }

    flush();
    parsed_ = true;
    return true;
}

}
