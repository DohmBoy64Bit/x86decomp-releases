#include "static_asset_loader.h"
#include "rfa_reader.h"
#include "sm_reader.h"
#include "rs_reader.h"

#include <iostream>
#include <algorithm>
#include <cctype>

namespace openbfv::assets::loader {

using vfs::rfa::RfaReader;
using mesh::SmReader;
using material::RsReader;

StaticAssetLoader::StaticAssetLoader(const RfaReader& archive)
    : archive_(archive) {
}

std::string StaticAssetLoader::find_rs_path(const std::string& mesh_name) const {
    // .sm and .rs have the same basename; replace .sm with .rs
    std::string rs_name = mesh_name;
    // Remove directory prefix if any
    auto slash_pos = rs_name.find_last_of("/\\");
    if (slash_pos != std::string::npos) {
        rs_name = rs_name.substr(slash_pos + 1);
    }
    // Replace extension
    auto dot_pos = rs_name.rfind('.');
    if (dot_pos != std::string::npos) {
        rs_name = rs_name.substr(0, dot_pos) + ".rs";
    } else {
        rs_name += ".rs";
    }
    return rs_name;
}

LoadedMesh StaticAssetLoader::load_mesh(const std::string& mesh_name) const {
    LoadedMesh result;
    result.name = mesh_name;

    // Load .sm
    auto sm_data = archive_.extract(mesh_name);
    if (!sm_data) {
        errors_.push_back("Mesh not found in archive: " + mesh_name);
        return result;
    }

    SmReader sm_reader(*sm_data);
    if (!sm_reader.parse()) {
        errors_.push_back("Failed to parse .sm: " + mesh_name);
        return result;
    }
    result.mesh = std::make_unique<mesh::SmMeshInfo>(sm_reader.take_info());

    // Load corresponding .rs
    std::string rs_path = find_rs_path(mesh_name);
    auto rs_data = archive_.extract_string(rs_path);
    if (rs_data) {
        auto rs_info = std::make_unique<material::RsInfo>();
        RsReader rs_reader(*rs_data);
        if (rs_reader.parse()) {
            *rs_info = rs_reader.info();
            result.material = std::move(rs_info);

            // Collect referenced textures
            for (const auto& shader : result.material->subshaders) {
                if (!shader.texture.empty()) {
                    result.referenced_textures.push_back(shader.texture);
                }
            }
        } else {
            errors_.push_back("Failed to parse .rs: " + rs_path);
        }
    } else {
        errors_.push_back("No matching .rs found for: " + mesh_name + " (looked for: " + rs_path + ")");
    }

    return result;
}

AssetLoadResult StaticAssetLoader::load_all_from_template_db(const TemplateDatabase& db) const {
    AssetLoadResult result;

    for (const auto& [name, tmpl] : db.all()) {
        // Try mesh_name first, then geometry_name
        std::string mesh_ref;
        if (!tmpl.mesh_name.empty()) {
            mesh_ref = tmpl.mesh_name;
        } else if (!tmpl.geometry_name.empty()) {
            mesh_ref = tmpl.geometry_name;
        }

        if (mesh_ref.empty()) continue;

        LoadedMesh loaded = load_mesh(mesh_ref);
        if (loaded.mesh || loaded.material) {
            result.meshes.push_back(std::move(loaded));
            result.total_loaded++;
        }
    }

    result.errors = errors_;
    return result;
}

}
