#pragma once

#include "template_database.h"
#include <string>
#include <vector>
#include <memory>

namespace openbfv::vfs::rfa { class RfaReader; }

namespace openbfv::assets::mesh { struct SmMeshInfo; }
namespace openbfv::assets::material { struct RsInfo; }

namespace openbfv::assets::loader {

using openbfv::game::object_template::TemplateDatabase;

struct LoadedMesh {
    std::string name;
    std::unique_ptr<mesh::SmMeshInfo> mesh;
    std::unique_ptr<material::RsInfo> material;
    std::vector<std::string> referenced_textures;
};

struct AssetLoadResult {
    std::vector<LoadedMesh> meshes;
    std::vector<std::string> errors;
    size_t total_loaded = 0;
};

class StaticAssetLoader {
public:
    explicit StaticAssetLoader(const vfs::rfa::RfaReader& archive);

    LoadedMesh load_mesh(const std::string& mesh_name) const;
    AssetLoadResult load_all_from_template_db(const TemplateDatabase& db) const;

    const std::vector<std::string>& errors() const { return errors_; }

private:
    std::string find_rs_path(const std::string& mesh_name) const;

    const vfs::rfa::RfaReader& archive_;
    mutable std::vector<std::string> errors_;
};

}
