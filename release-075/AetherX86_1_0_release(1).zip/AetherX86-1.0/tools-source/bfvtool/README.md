# bfvtool — OpenBFVietnam Toolkit

`bfvtool` is the command-line inspection and debugging tool for the OpenBFVietnam engine. It reads original Battlefield Vietnam data files (RFA archives, .sm meshes, .rs materials, .dds textures, terrain data, vegetation WST files, lightmap shadow bits) and displays their contents in human-readable form.

## Purpose

- **Inspect** original game archives without extracting them
- **Debug** format parsers during engine development
- **Verify** that asset files parse correctly before runtime
- **Extract** individual files for analysis
- **Resolve** asset dependency chains (mesh → material → texture)
- **Diagnose** unknown fields in formats to improve clean-room spec coverage

## Commands

### `rfa` — RFA Archive Operations

Reads Refractor2 FlatArchive format (v1.0 and v1.1), the primary archive format of Battlefield Vietnam.

```
bfvtool rfa list <archive.rfa>
  List all files in the archive with sizes.
  Shows index, uncompressed size, compressed size (if applicable), and path.

bfvtool rfa info <archive.rfa>
  Show header information: format version, compression flag, XPack identity,
  file count, total sizes, and unknown file entry fields.

bfvtool rfa extract <archive.rfa> <path>
  Extract a single file to stdout (binary). Useful for piping into other tools.

bfvtool rfa extract-to <archive.rfa> <path> <output_file>
  Extract a single file to a named output file on disk.
```

### `sm` — Mesh Format (`.sm`)

Inspects Static Mesh files from `standardMesh.rfa`. Supports versions 9, 10, and 2573 (BF Vietnam).

```
bfvtool sm info <file.sm>
  Show mesh header: version, bounding box, collision meshes, LOD levels,
  material blocks (name, render type, vertex format, vertex count, index count,
  material settings), shadow LOD info, portal mesh size.
```

### `rs` — Render State Format (`.rs`)

Parses the text-based render state files that accompany `.sm` meshes.

```
bfvtool rs info <file.rs>
  Show all subshaders with: name, shader type, texture reference,
  transparency, lighting, specular, twosided, envmap, texture fade,
  depth write, blend modes, alpha test ref, material colors.
```

### `template` — Object Template System

Builds an object template database from CON scripts extracted from RFA archives.

```
bfvtool template build <archive.rfa> <con_path>
  Extract a .con file from the archive, parse ObjectTemplate.* commands,
  and display all created templates with their properties:
  - Skeleton, mesh, geometry references
  - Flags (saveInSeparateFile, hasMobilePhysics, createNotInGrid, etc.)
  - Child templates (addTemplate with inputId, position, rotation, LOD, 1p flag)
  - Weapon properties (fireDelay, deviation, recoil, heat, zoom, etc.)
  - Explosion properties (radius, damage, force)
  - Soldier camera/zoom positions
  - Unknown/unhandled properties
```

### `asset` — Static Asset Resolution

Resolves template references to actual game assets by loading .sm meshes and their associated .rs materials.

```
bfvtool asset resolve <archive.rfa> <con_path>
  Extract and parse a .con file, build template database, then resolve
  each template's geometry name to its .sm mesh and .rs material.
  Shows mesh metadata (version, LOD count, vertex/face counts) and
  referenced textures per material.
```

### `terrain` — Heightmap Inspection

Reads raw 16-bit heightmap files found in level archives.

```
bfvtool terrain info <heightmap.raw>
  Show grid size, data size, raw height range (min/max/avg),
  and scaled height range using default yScale=1.0.
```

### `wst` — Vegetation WST Format

Parses the XML-based WST (Wrapper Tree) vegetation definition files.

```
bfvtool wst info <file.wst>
  Show type (overGrowth/underGrowth), version, material map reference,
  view distance, LOD settings, and all material groups with their
  vegetation entries (geometry name, probability, scale range, radius).
```

### `tga` — Targa Image

Reads Truevision TGA image files (type 1 color-mapped, type 2 truecolor, type 3 grayscale, RLE variants 9/10/11).

```
bfvtool tga info <file.tga>
  Show image dimensions, bit depth, alpha channel presence, grayscale flag.
```

### `pal` — Color Palette

Reads RGB/RGBA color palette files (768-byte RGB, 1024-byte RGBA, or variable sizes).

```
bfvtool pal info <file.pal>
  Show entry count and alpha channel presence.
```

### `ssc` — Sound Script

Parses Sound Script Collection (.ssc) files that define audio patches with WAV files, volume, looping, priority, and effects.

```
bfvtool ssc info <file.ssc>
  Show all sound patches with their WAV file references, volume, and loop status.
```

### `rcm` — Environment Map

Reads environment map (.rcm) text files that reference 6 DDS cube face textures.

```
bfvtool rcm info <file.rcm>
  Show all 6 cube face texture references and derived map name.
```

### `ske` — Skeleton

Reads skeleton files (`.ske`) with bone hierarchy and 4x3 affine bone transforms.

```
bfvtool ske info <file.ske>
  Show all bones with hierarchy (parent indices) and count.
```

### `skn` — Skin Weights

Reads skin files (`.skn`) that map mesh vertices to skeleton bones with weights.

```
bfvtool skn info <file.skn>
  Show vertex count and total bone influence count.
```

### `baf` — Animation Keyframes

Reads animation files (`.baf`) containing bone name tables and per-bone keyframe data.

```
bfvtool baf info <file.baf>
  Show bone names and keyframe data size.
```

### `dif` — DICE Bitmap Font

Reads DICE bitmap font files (`.dif`) that describe glyph positions in a `.tga` texture atlas.

```
bfvtool dif info <file.dif>
  Show font name, texture dimensions, glyph count, texture file path.
```

### `fx` — Shader Effect

Parses DirectX FX shader files with includes, techniques, and shader model detection.

```
bfvtool fx info <file.fx>
  Show line count, includes, techniques, shader model.
```

### `lsb` — Lightmap Shadow Bits

Reads the LightmapShadowBits.lsb binary files found in level archives.

```
bfvtool lsb info <file.lsb>
  Show grid dimensions (width x height) and count of shadowed cells
  as a percentage of total cells.
```

## Typical Workflow

```sh
# Quickly inspect an archive's contents
bfvtool rfa list "C:\Program Files (x86)\...\objects.rfa"

# Show archive header details
bfvtool rfa info "C:\Program Files (x86)\...\standardMesh.rfa"

# Examine a specific mesh
bfvtool sm info skybox.sm

# Build and inspect templates from a CON file
bfvtool template build objects.rfa "Objects/Soldiers/USMarineA1/Objects.con"

# Resolve all assets for a set of templates
bfvtool asset resolve standardMesh.rfa "Objects/Common/Objects.con"

# Check vegetation setup
bfvtool wst info overGrowth.wst

# Inspect terrain height data
bfvtool terrain info Heightmap.raw

# Read lightmap shadow data
bfvtool lsb info LightmapShadowBits.lsb
```
