#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <optional>

namespace openbfv::vfs::rfa {

struct RfaFileEntry {
    std::string path;
    uint32_t compressed_size;
    uint32_t uncompressed_size;
    uint32_t data_offset; 
    uint32_t unknown[3];
};

struct RfaHeader {
    bool is_v1_1;
    bool compressed;
    uint32_t directory_offset;
    uint32_t xpack_header_id;
    std::string xpack_name;
    uint8_t random_bytes[143];
    uint8_t unknown_byte;
};

enum class XPackId : uint32_t {
    Default = 0x48128321,
    XPack1  = 0x52382184,
    XPack2  = 0x71629419,
    None    = 0x81671213
};

struct RfaArchiveInfo {
    RfaHeader header;
    std::vector<RfaFileEntry> files;
    std::string path;
};

class RfaReader {
public:
    explicit RfaReader(const std::string& archive_path);
    
    bool open();
    bool is_open() const { return opened_; }
    const RfaArchiveInfo& info() const;
    const std::vector<RfaFileEntry>& files() const;
    std::optional<std::vector<uint8_t>> extract(const std::string& path) const;
    std::optional<std::vector<uint8_t>> extract_by_index(size_t index) const;
    std::optional<std::string> extract_string(const std::string& path) const;
    
    static std::string xpack_name_for_id(uint32_t id);

private:
    bool read_directory();
    void build_index();
    
    std::string path_;
    RfaArchiveInfo info_;
    bool opened_ = false;

    // Binary-search index sorted by normalized path (FUN_008d0940)
    std::vector<size_t> sorted_indices_;
    static std::string normalize_path(const std::string& p);
};

} // namespace openbfv::vfs::rfa
