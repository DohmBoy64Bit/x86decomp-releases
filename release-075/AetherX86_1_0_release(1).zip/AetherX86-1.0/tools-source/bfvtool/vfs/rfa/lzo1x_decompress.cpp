#include "lzo1x_decompress.h"
#include "minilzo.h"

#include <cstring>
#include <cstdint>

namespace openbfv::vfs::rfa {

std::optional<std::vector<uint8_t>> lzo1x_decompress(
    const uint8_t* src, size_t src_len, size_t expected_uncompressed)
{
    if (src_len == 0 || expected_uncompressed == 0)
        return std::nullopt;

    std::vector<uint8_t> dst(expected_uncompressed);
    lzo_uint actual_out = expected_uncompressed;

    int ret = lzo1x_decompress_safe(src, static_cast<lzo_uint>(src_len),
        dst.data(), &actual_out, nullptr);
    if (ret != LZO_E_OK)
        return std::nullopt;

    dst.resize(actual_out);
    return dst;
}

} // namespace openbfv::vfs::rfa
