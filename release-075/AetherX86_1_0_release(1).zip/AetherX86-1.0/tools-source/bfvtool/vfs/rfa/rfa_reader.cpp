#include "rfa_reader.h"
#include "lzo1x_decompress.h"

#include <fstream>
#include <cstring>
#include <algorithm>

namespace openbfv::vfs::rfa {

static std::string rfa_normalize_path(const std::string& p) {
    std::string result;
    result.reserve(p.size());
    for (char c : p) {
        if (c == '\\') {
            result += '/';
        } else {
            result += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        }
    }
    return result;
}

static constexpr const char* V1_1_MAGIC = "Refractor2 FlatArchive 1.1  ";
static constexpr size_t V1_1_MAGIC_LEN = 28;

RfaReader::RfaReader(const std::string& archive_path)
    : path_(archive_path) {}

std::string RfaReader::xpack_name_for_id(uint32_t id) {
    switch (static_cast<XPackId>(id)) {
        case XPackId::Default: return "Default";
        case XPackId::XPack1:  return "XPack1";
        case XPackId::XPack2:  return "XPack2";
        case XPackId::None:    return "None";
        default:               return "Unknown";
    }
}

bool RfaReader::open() {
    std::ifstream f(path_, std::ios::binary);
    if (!f) return false;

    // Check v1.1 magic
    char magic[V1_1_MAGIC_LEN] = {};
    f.read(magic, V1_1_MAGIC_LEN);
    
    bool is_v1_1 = (std::memcmp(magic, V1_1_MAGIC, V1_1_MAGIC_LEN) == 0);
    
    if (is_v1_1) {
        info_.header.is_v1_1 = true;
    } else {
        f.seekg(0);
    }

    uint32_t directory_offset = 0;
    f.read(reinterpret_cast<char*>(&directory_offset), 4);
    info_.header.directory_offset = directory_offset;

    uint32_t compressed = 0;
    f.read(reinterpret_cast<char*>(&compressed), 4);
    info_.header.compressed = (compressed != 0);

    if (!is_v1_1) {
        f.read(reinterpret_cast<char*>(info_.header.random_bytes), 143);
        f.read(reinterpret_cast<char*>(&info_.header.unknown_byte), 1);

        uint32_t xpack_encrypted = 0;
        f.read(reinterpret_cast<char*>(&xpack_encrypted), 4);

        uint32_t sum = 0;
        for (int i = 0; i < 143; ++i) {
            sum += info_.header.random_bytes[i];
        }
        info_.header.xpack_header_id = xpack_encrypted - sum;
        info_.header.xpack_name = xpack_name_for_id(info_.header.xpack_header_id);
    } else {
        info_.header.xpack_header_id = 0;
        info_.header.xpack_name = "v1.1 (no xpack)";
        std::memset(info_.header.random_bytes, 0, 143);
        info_.header.unknown_byte = 0;
    }

    return read_directory();
}

bool RfaReader::read_directory() {
    std::ifstream f(path_, std::ios::binary);
    if (!f) return false;

    f.seekg(info_.header.directory_offset);

    uint32_t entry_count = 0;
    f.read(reinterpret_cast<char*>(&entry_count), 4);

    info_.files.reserve(entry_count);

    for (uint32_t i = 0; i < entry_count; ++i) {
        uint32_t path_len = 0;
        f.read(reinterpret_cast<char*>(&path_len), 4);
        
        std::string entry_path;
        entry_path.resize(path_len);
        f.read(entry_path.data(), path_len);

        RfaFileEntry entry;
        entry.path = std::move(entry_path);
        f.read(reinterpret_cast<char*>(&entry.compressed_size), 4);
        f.read(reinterpret_cast<char*>(&entry.uncompressed_size), 4);
        f.read(reinterpret_cast<char*>(&entry.data_offset), 4);
        f.read(reinterpret_cast<char*>(entry.unknown), 12);

        info_.files.push_back(std::move(entry));
    }

    info_.path = path_;
    if (f.good()) {
        build_index();
    }
    return f.good();
}

void RfaReader::build_index() {
    sorted_indices_.resize(info_.files.size());
    for (size_t i = 0; i < info_.files.size(); ++i) {
        sorted_indices_[i] = i;
    }
    std::sort(sorted_indices_.begin(), sorted_indices_.end(),
        [this](size_t a, size_t b) {
            return rfa_normalize_path(info_.files[a].path) < rfa_normalize_path(info_.files[b].path);
        });
}

const RfaArchiveInfo& RfaReader::info() const {
    return info_;
}

const std::vector<RfaFileEntry>& RfaReader::files() const {
    return info_.files;
}

std::optional<std::vector<uint8_t>> RfaReader::extract(const std::string& path) const {
    std::string target = rfa_normalize_path(path);
    // Binary search over sorted index (FUN_008d0940 style)
    auto it = std::lower_bound(sorted_indices_.begin(), sorted_indices_.end(), target,
        [this](size_t idx, const std::string& t) {
            return rfa_normalize_path(info_.files[idx].path) < t;
        });
    if (it != sorted_indices_.end() && rfa_normalize_path(info_.files[*it].path) == target) {
        return extract_by_index(*it);
    }
    return std::nullopt;
}

std::optional<std::vector<uint8_t>> RfaReader::extract_by_index(size_t index) const {
    if (index >= info_.files.size()) return std::nullopt;

    const auto& entry = info_.files[index];

    if (!info_.header.compressed) {
        std::ifstream f(path_, std::ios::binary);
        if (!f) return std::nullopt;

        std::vector<uint8_t> data(entry.uncompressed_size);
        f.seekg(entry.data_offset);
        f.read(reinterpret_cast<char*>(data.data()), entry.uncompressed_size);

        if (f.good()) return data;
        return std::nullopt;
    }

    std::ifstream f(path_, std::ios::binary);
    if (!f) return std::nullopt;

    f.seekg(entry.data_offset);

    // Read segment count
    uint32_t num_segments = 0;
    f.read(reinterpret_cast<char*>(&num_segments), 4);
    if (!f || num_segments == 0) return std::nullopt;

    // Read segment headers
    // Layout at data_offset:
    //   [4 bytes] num_segments
    //   [12 bytes per segment] compressed_size, uncompressed_size, data_offset
    //   [variable] compressed segment data
    struct SegmentInfo {
        uint32_t compressed_size;
        uint32_t uncompressed_size;
        uint32_t segment_data_offset; // relative to start of data blocks
    };

    std::vector<SegmentInfo> segments(num_segments);
    for (uint32_t i = 0; i < num_segments; ++i) {
        f.read(reinterpret_cast<char*>(&segments[i].compressed_size), 4);
        f.read(reinterpret_cast<char*>(&segments[i].uncompressed_size), 4);
        f.read(reinterpret_cast<char*>(&segments[i].segment_data_offset), 4);
    }
    if (!f) return std::nullopt;

    // Calculate offset to compressed data blocks
    // data_offset + 4 (count) + num_segments * 12 (headers)
    uint32_t data_blocks_start = entry.data_offset + 4 + num_segments * 12;

    // Decompress each segment
    std::vector<uint8_t> result;
    result.reserve(entry.uncompressed_size);

    for (const auto& seg : segments) {
        if (seg.compressed_size == 0 || seg.uncompressed_size == 0)
            continue;

        uint32_t seg_file_offset = data_blocks_start + seg.segment_data_offset;
        f.seekg(seg_file_offset);
        if (!f) return std::nullopt;

        std::vector<uint8_t> comp(seg.compressed_size);
        f.read(reinterpret_cast<char*>(comp.data()), seg.compressed_size);
        if (!f) return std::nullopt;

        auto decomp = lzo1x_decompress(comp.data(), seg.compressed_size, seg.uncompressed_size);
        if (!decomp) return std::nullopt;

        result.insert(result.end(), decomp->begin(), decomp->end());
    }

    return result;
}

std::optional<std::string> RfaReader::extract_string(const std::string& path) const {
    auto data = extract(path);
    if (!data) return std::nullopt;
    return std::string(reinterpret_cast<const char*>(data->data()), data->size());
}

} // namespace openbfv::vfs::rfa
