#pragma once

#include <cstdint>
#include <vector>
#include <optional>

namespace openbfv::vfs::rfa {

// Clean-room LZO1X decompressor based on the publicly documented algorithm.
// http://www.oberhumer.com/opensource/lzo/
// Returns decompressed data or nullopt on error.
std::optional<std::vector<uint8_t>> lzo1x_decompress(
    const uint8_t* src, size_t src_len, size_t expected_uncompressed);

} // namespace openbfv::vfs::rfa
