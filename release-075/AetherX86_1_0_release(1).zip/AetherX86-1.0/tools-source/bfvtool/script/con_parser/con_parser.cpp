#include "con_parser.h"

#include <cctype>
#include <sstream>
#include <unordered_set>

namespace openbfv::script::con {

// ---------------------------------------------------------------------------
// ConTokenizer
// ---------------------------------------------------------------------------

ConTokenizer::ConTokenizer(std::string_view source)
    : source_(source)
{
}

char ConTokenizer::peek_char() const {
    return pos_ < source_.size() ? source_[pos_] : '\0';
}

char ConTokenizer::advance() {
    char c = source_[pos_++];
    if (c == '\n') {
        ++line_;
        col_ = 1;
    } else {
        ++col_;
    }
    return c;
}

void ConTokenizer::skip_whitespace() {
    while (pos_ < source_.size()) {
        char c = source_[pos_];
        if (c == ' ' || c == '\t' || c == '\r') {
            advance();
        } else {
            break;
        }
    }
}

void ConTokenizer::skip_line_comment() {
    // Already consumed 'rem' (or after rem), skip rest of line
    while (pos_ < source_.size() && source_[pos_] != '\n') {
        advance();
    }
}

void ConTokenizer::skip_block_comment() {
    in_block_comment_ = true;
    const char* pat_end = "endrem";
    while (pos_ < source_.size()) {
        if (source_[pos_] == '\n') {
            advance();
            continue;
        }
        // Check for endRem (case-insensitive) at a word boundary
        if (source_.size() - pos_ >= 6) {
            bool match = true;
            for (size_t i = 0; i < 6; ++i) {
                if (std::tolower(static_cast<unsigned char>(source_[pos_ + i]))
                    != static_cast<unsigned char>(pat_end[i])) {
                    match = false;
                    break;
                }
            }
            if (match) {
                // Verify word boundary before and after
                if ((pos_ == 0 || std::isspace(static_cast<unsigned char>(source_[pos_ - 1]))
                    || source_[pos_ - 1] == '\n') &&
                    (pos_ + 6 >= source_.size()
                    || std::isspace(static_cast<unsigned char>(source_[pos_ + 6]))
                    || source_[pos_ + 6] == '\n'))
                {
                    pos_ += 6;
                    col_ += 6;
                    in_block_comment_ = false;
                    return;
                }
            }
        }
        advance();
    }
    in_block_comment_ = false;
}

ConToken ConTokenizer::read_string() {
    SourceLocation loc{line_, col_};
    advance(); // consume opening quote
    std::string text;
    while (pos_ < source_.size()) {
        char c = source_[pos_];
        if (c == '"') {
            advance(); // consume closing quote
            break;
        }
        text += advance();
    }
    return {ConToken::Type::String, text, loc};
}

ConToken ConTokenizer::read_word_or_command() {
    SourceLocation loc{line_, col_};
    std::string text;
    while (pos_ < source_.size()) {
        char c = source_[pos_];
        if (std::isspace(static_cast<unsigned char>(c)) || c == '"') {
            break;
        }
        text += advance();
    }

    // Detect dotted pair: contains '.' and is not a known unary keyword
    bool is_command = text.find('.') != std::string::npos;

    if (is_command) {
        return {ConToken::Type::Command, text, loc};
    }
    return {ConToken::Type::Word, text, loc};
}

ConToken ConTokenizer::next() {
    if (has_peeked_) {
        has_peeked_ = false;
        return peeked_;
    }

    // Handle block comment mode
    if (in_block_comment_) {
        skip_block_comment();
    }

    while (pos_ < source_.size()) {
        skip_whitespace();

        if (pos_ >= source_.size()) break;

        char c = source_[pos_];

        if (c == '\n') {
            SourceLocation loc{line_, col_};
            advance();
            return {ConToken::Type::Newline, "\n", loc};
        }

        if (c == '"') {
            return read_string();
        }

        // Check for 'rem' at word start
        if (c == 'r' || c == 'R') {
            std::string_view rest(source_.data() + pos_, source_.size() - pos_);
            if (rest.size() >= 3) {
                bool is_rem = true;
                std::string_view rem_pat = "rem";
                for (size_t i = 0; i < 3; ++i) {
                    if (std::tolower(static_cast<unsigned char>(rest[i])) != rem_pat[i]) {
                        is_rem = false;
                        break;
                    }
                }
                if (is_rem) {
                    // Must be at word boundary: rem followed by whitespace or newline
                    if (rest.size() == 3 || std::isspace(static_cast<unsigned char>(rest[3]))
                        || rest[3] == '\n') {
                        // Consume 'rem'
                        for (int i = 0; i < 3; ++i) advance();
                        skip_line_comment();
                        continue;
                    }
                }
            }
        }

        // Check for 'beginRem' or 'endRem'
        if (c == 'b' || c == 'B' || c == 'e' || c == 'E') {
            std::string_view rest(source_.data() + pos_, source_.size() - pos_);
            // beginRem (case-insensitive)
            if (rest.size() >= 8) {
                bool is_begin = true;
                const char* beg_pat = "beginrem";
                for (size_t i = 0; i < 8; ++i) {
                    if (std::tolower(static_cast<unsigned char>(rest[i])) != static_cast<unsigned char>(beg_pat[i])) {
                        is_begin = false;
                        break;
                    }
                }
                if (is_begin) {
                    if (rest.size() == 8 || std::isspace(static_cast<unsigned char>(rest[8]))
                        || rest[8] == '\n') {
                        for (int i = 0; i < 8; ++i) advance();
                        skip_block_comment();
                        continue;
                    }
                }
            }
            // endRem (handled inside skip_block_comment, but check here too)
            if (rest.size() >= 6 && in_block_comment_) {
                bool is_end = true;
                const char* end_pat = "endrem";
                for (size_t i = 0; i < 6; ++i) {
                    if (std::tolower(static_cast<unsigned char>(rest[i])) != static_cast<unsigned char>(end_pat[i])) {
                        is_end = false;
                        break;
                    }
                }
                if (is_end) {
                    for (int i = 0; i < 6; ++i) advance();
                    in_block_comment_ = false;
                    continue;
                }
            }
        }

        return read_word_or_command();
    }

    return {ConToken::Type::Eof, "", {line_, col_}};
}

const ConToken& ConTokenizer::peek() {
    if (!has_peeked_) {
        peeked_ = next();
        has_peeked_ = true;
    }
    return peeked_;
}

bool ConTokenizer::done() const {
    return pos_ >= source_.size() && !has_peeked_;
}

// ---------------------------------------------------------------------------
// ConParser
// ---------------------------------------------------------------------------

ConParser::ConParser(std::string_view source)
    : tokenizer_(source)
{
}

void ConParser::add_error(const std::string& msg, const SourceLocation& loc) {
    std::ostringstream oss;
    oss << "line " << loc.line << ": " << msg;
    errors_.push_back(oss.str());
}

ConToken ConParser::consume(ConToken::Type type) {
    ConToken tok = tokenizer_.next();
    if (tok.type != type) {
        add_error("expected " + std::to_string(static_cast<int>(type))
                  + " but got " + std::to_string(static_cast<int>(tok.type)), tok.loc);
    }
    return tok;
}

static bool ieq(std::string_view a, std::string_view b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(a[i]))
            != std::tolower(static_cast<unsigned char>(b[i])))
            return false;
    }
    return true;
}

static const std::unordered_set<std::string, std::hash<std::string>, std::equal_to<>>& control_keywords() {
    static const auto keywords = new std::unordered_set<std::string, std::hash<std::string>, std::equal_to<>>{
        "if", "else", "endif",
        "while", "endwhile",
        "include", "run",
        "var", "const",
        "return", "echo", "alias",
        "rem", "beginrem", "endrem"
    };
    return *keywords;
}

static bool is_control_keyword(const std::string& word) {
    if (word.empty()) return false;
    // Compare case-insensitively
    std::string lower;
    lower.reserve(word.size());
    for (char c : word) {
        lower += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }
    return control_keywords().count(lower) > 0;
}

ConScript ConParser::parse() {
    ConScript script;

    while (!tokenizer_.done()) {
        ConToken tok = tokenizer_.next();

        if (tok.type == ConToken::Type::Eof) break;
        if (tok.type == ConToken::Type::Newline) continue;

        // Handle control keywords
        if (tok.type == ConToken::Type::Word) {
            std::string lower_cmd;
            for (char c : tok.text) {
                lower_cmd += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            }

            if (lower_cmd == "if") {
                // Parse condition
                ConIfBlock if_block;
                if_block.condition = tokenizer_.next().text; // the condition
                // Collect tokens until endif (simple per-command tracking)
                // For now, just collect all remaining tokens on this line as the condition
                while (tokenizer_.peek().type != ConToken::Type::Newline
                       && tokenizer_.peek().type != ConToken::Type::Eof) {
                    ConToken cond_tok = tokenizer_.next();
                    if (!if_block.condition.empty()) if_block.condition += " ";
                    if_block.condition += cond_tok.text;
                }
                // Now read commands until endif
                int depth = 1;
                std::vector<ConCommand>* target = &if_block.then_commands;
                while (depth > 0 && tokenizer_.peek().type != ConToken::Type::Eof) {
                    ConToken ct = tokenizer_.peek();
                    if (ct.type == ConToken::Type::Newline) {
                        tokenizer_.next();
                        continue;
                    }
                    if (ct.type == ConToken::Type::Word) {
                        std::string cl = ct.text;
                        for (auto& c : cl) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
                        if (cl == "endif") {
                            tokenizer_.next(); // consume endif
                            --depth;
                            if (depth == 0) break;
                            if (depth == 1) target = &if_block.then_commands;
                            continue;
                        }
                        if (cl == "else" && depth == 1) {
                            tokenizer_.next(); // consume else
                            target = &if_block.else_commands;
                            // Parse condition after else (optional in BF1942)
                            while (tokenizer_.peek().type != ConToken::Type::Newline
                                   && tokenizer_.peek().type != ConToken::Type::Eof) {
                                tokenizer_.next();
                            }
                            continue;
                        }
                        if (cl == "if") {
                            ++depth;
                        }
                    }
                    // Parse as command
                    ConCommand cmd;
                    cmd.loc = ct.loc;
                    cmd.name = ct.text;
                    tokenizer_.next(); // consume command
                    // Collect args until newline or eof
                    while (tokenizer_.peek().type != ConToken::Type::Newline
                           && tokenizer_.peek().type != ConToken::Type::Eof) {
                        ConToken at = tokenizer_.next();
                        ConArg arg;
                        arg.value = at.text;
                        arg.quoted = (at.type == ConToken::Type::String);
                        cmd.args.push_back(std::move(arg));
                    }
                    target->push_back(std::move(cmd));
                }
                script.if_blocks.push_back(std::move(if_block));
                continue;
            }

            if (lower_cmd == "else" || lower_cmd == "endif" || lower_cmd == "endwhile") {
                // Stray control keyword — skip line
                while (tokenizer_.peek().type != ConToken::Type::Newline
                       && tokenizer_.peek().type != ConToken::Type::Eof) {
                    tokenizer_.next();
                }
                add_error("stray control keyword '" + tok.text + "'", tok.loc);
                continue;
            }

            if (lower_cmd == "while") {
                // Parse condition, skip to endwhile
                while (tokenizer_.peek().type != ConToken::Type::Newline
                       && tokenizer_.peek().type != ConToken::Type::Eof) {
                    tokenizer_.next();
                }
                // Skip the while body
                int depth = 1;
                while (depth > 0 && tokenizer_.peek().type != ConToken::Type::Eof) {
                    ConToken wt = tokenizer_.next();
                    if (wt.type == ConToken::Type::Word) {
                        std::string wl;
                        for (auto& c : wt.text) wl += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
                        if (wl == "while") ++depth;
                        else if (wl == "endwhile") --depth;
                    }
                }
                add_error("'while' not fully supported in permissive mode, body skipped", tok.loc);
                continue;
            }

            // include / run / var / const / return / echo / alias — parse as a command with args
            // These are "command-like" keywords that don't use dotted notation
            // We'll store them as commands in the flat list
        }

        // Regular command (dotted pair or standalone keyword treated as command)
        ConCommand cmd;
        cmd.loc = tok.loc;
        cmd.name = tok.text;

        // Collect arguments until newline or eof
        while (tokenizer_.peek().type != ConToken::Type::Newline
               && tokenizer_.peek().type != ConToken::Type::Eof) {
            ConToken at = tokenizer_.next();
            ConArg arg;
            arg.value = at.text;
            arg.quoted = (at.type == ConToken::Type::String);
            cmd.args.push_back(std::move(arg));
        }

        script.commands.push_back(std::move(cmd));
    }

    return script;
}

} // namespace openbfv::script::con
