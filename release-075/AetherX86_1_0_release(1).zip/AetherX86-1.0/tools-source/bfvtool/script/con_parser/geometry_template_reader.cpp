#include "geometry_template_reader.h"
#include <algorithm>
#include <cctype>

namespace openbfv::assets::script {

static std::string to_lower(const std::string& s) {
    std::string r;
    r.reserve(s.size());
    for (char c : s) r += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return r;
}

const GeometryTemplateEntry* GeometryTemplateDatabase::find(const std::string& virtual_name) const {
    auto it = entries.find(virtual_name);
    return it != entries.end() ? &it->second : nullptr;
}

std::string GeometryTemplateDatabase::resolve_file_name(const std::string& virtual_name) const {
    auto* e = find(virtual_name);
    return e ? e->file_name : virtual_name;
}

std::string GeometryTemplateDatabase::resolve_skin_path(const std::string& virtual_name) const {
    auto* e = find(virtual_name);
    return e ? e->skin_path : "";
}

size_t GeometryTemplateBuilder::build_from_script(const openbfv::script::con::ConScript& script,
                                                    GeometryTemplateDatabase& db) {
    size_t created = 0;
    GeometryTemplateEntry* current = nullptr;
    std::string current_name;

    for (const auto& cmd : script.commands) {
        std::string name = cmd.name;
        for (auto& c : name) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));

        if (name == "geometrytemplate.create" && cmd.args.size() >= 2) {
            current_name = cmd.args[1].value;
            GeometryTemplateEntry entry;
            entry.virtual_name = current_name;
            entry.type = cmd.args[0].value;
            db.entries[current_name] = entry;
            current = &db.entries[current_name];
            ++created;
            continue;
        }

        if (current == nullptr) continue;
        size_t dot = cmd.name.rfind('.');
        std::string prop = (dot != std::string::npos) ? cmd.name.substr(dot + 1) : cmd.name;
        std::string prop_lower = to_lower(prop);

        if (prop_lower == "file" && !cmd.args.empty()) {
            current->file_name = cmd.args[0].value;
        } else if (prop_lower == "setskin" && !cmd.args.empty()) {
            current->skin_path = cmd.args[0].value;
        } else if (prop_lower == "setlodrange") {
            if (cmd.args.size() >= 3) {
                float from = std::stof(cmd.args[1].value);
                float to = std::stof(cmd.args[2].value);
                current->lod_ranges.push_back({from, to});
            }
        }
    }

    return created;
}

}
