#pragma once

#include "con_parser.h"
#include <string>
#include <vector>
#include <unordered_map>

namespace openbfv::assets::script {

struct GeometryTemplateEntry {
    std::string virtual_name;      // e.g. "Soldier/3PUSMarineA1"
    std::string type;              // "AnimatedMesh" or "SimpleObject"
    std::string file_name;         // actual mesh filename (e.g. "CH_3PUSSoldierB_m1")
    std::string skin_path;         // .skn path (e.g. "animations/CH_3PUSSoldierB_m1.skn")
    std::vector<std::pair<float, float>> lod_ranges; // distance range per LOD
};

struct GeometryTemplateDatabase {
    std::unordered_map<std::string, GeometryTemplateEntry> entries;
    std::vector<std::string> errors;
    size_t file_count = 0;

    const GeometryTemplateEntry* find(const std::string& virtual_name) const;
    std::string resolve_file_name(const std::string& virtual_name) const;
    std::string resolve_skin_path(const std::string& virtual_name) const;
    size_t size() const { return entries.size(); }
};

// Parses Geometries.con files containing GeometryTemplate.* commands
class GeometryTemplateBuilder {
public:
    size_t build_from_script(const openbfv::script::con::ConScript& script,
                              GeometryTemplateDatabase& db);
};

}
