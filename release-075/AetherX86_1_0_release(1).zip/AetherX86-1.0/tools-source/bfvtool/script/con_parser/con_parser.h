#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <optional>

namespace openbfv::script::con {

struct SourceLocation {
    size_t line = 0;
    size_t column = 0;
};

struct ConToken {
    enum Type : uint8_t {
        Command,     // dotted pair: "ObjectTemplate.create"
        Word,        // unquoted word, number, or identifier
        String,      // quoted string
        Newline,     // end of line (LF / CRLF)
        Eof
    };
    Type type;
    std::string text;
    SourceLocation loc;
};

struct ConArg {
    std::string value;
    bool quoted = false;
};

struct ConCommand {
    std::string name;              // e.g. "ObjectTemplate.create"
    std::vector<ConArg> args;
    SourceLocation loc;
};

struct ConIfBlock {
    std::string condition;
    std::vector<ConCommand> then_commands;
    std::vector<ConCommand> else_commands;
};

struct ConScript {
    std::vector<ConCommand> commands;
    std::vector<ConIfBlock> if_blocks; // flat list for permissive mode
};

// Line-oriented CON tokenizer.
// Strips rem / beginRem..endRem comments.
// Handles quoted strings, preserves whitespace-separated tokens.
class ConTokenizer {
public:
    explicit ConTokenizer(std::string_view source);

    ConToken next();
    const ConToken& peek();
    bool done() const;

private:
    std::string source_;
    size_t pos_ = 0;
    size_t line_ = 1;
    size_t col_ = 1;
    bool in_block_comment_ = false;
    ConToken peeked_;
    bool has_peeked_ = false;

    char peek_char() const;
    char advance();
    void skip_whitespace();
    void skip_line_comment();
    void skip_block_comment();
    ConToken read_string();
    ConToken read_word_or_command();
};

// Permissive CON parser.
// Produces a flat list of commands with source locations.
// Known control keywords (rem, beginRem, endRem, if, else, endif, include,
// run, var, const, return, echo, while, endWhile) are parsed structurally
// but unknown keywords are preserved as commands.
class ConParser {
public:
    explicit ConParser(std::string_view source);

    ConScript parse();
    const std::vector<std::string>& errors() const { return errors_; }

private:
    ConTokenizer tokenizer_;
    std::vector<std::string> errors_;

    void add_error(const std::string& msg, const SourceLocation& loc);
    ConToken consume(ConToken::Type type);
};

} // namespace openbfv::script::con
