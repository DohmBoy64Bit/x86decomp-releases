#include "template_database.h"

#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <charconv>

namespace openbfv::game::object_template {

// ---------------------------------------------------------------------------
// TemplateDatabase
// ---------------------------------------------------------------------------

void TemplateDatabase::add_template(ObjectTemplate tmpl) {
    templates_[tmpl.name] = std::move(tmpl);
}

const ObjectTemplate* TemplateDatabase::find(const std::string& name) const {
    auto it = templates_.find(name);
    if (it != templates_.end()) {
        return &it->second;
    }
    return nullptr;
}

ObjectTemplate* TemplateDatabase::find_mut(const std::string& name) {
    auto it = templates_.find(name);
    if (it != templates_.end()) {
        return &it->second;
    }
    return nullptr;
}

bool TemplateDatabase::contains(const std::string& name) const {
    return templates_.find(name) != templates_.end();
}

size_t TemplateDatabase::size() const {
    return templates_.size();
}

const std::unordered_map<std::string, ObjectTemplate>& TemplateDatabase::all() const {
    return templates_;
}

// ---------------------------------------------------------------------------
// TemplateBuilder
// ---------------------------------------------------------------------------

static bool ieq(const std::string& a, const std::string& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(a[i]))
            != std::tolower(static_cast<unsigned char>(b[i])))
            return false;
    }
    return true;
}

static std::string to_lower(const std::string& s) {
    std::string r;
    r.reserve(s.size());
    for (char c : s) r += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return r;
}

static bool parse_bool(const std::string& s) {
    return s != "0" && !ieq(s, "false") && !ieq(s, "no");
}

static float parse_float(const std::string& s) {
    float v = 0.0f;
    std::from_chars(s.data(), s.data() + s.size(), v);
    return v;
}

static int parse_int(const std::string& s) {
    int v = 0;
    std::from_chars(s.data(), s.data() + s.size(), v);
    return v;
}

static bool parse_vec3(const std::string& s, float& x, float& y, float& z) {
    size_t s1 = s.find('/');
    if (s1 == std::string::npos) return false;
    size_t s2 = s.find('/', s1 + 1);
    if (s2 == std::string::npos) return false;
    std::from_chars(s.data(), s.data() + s1, x);
    std::from_chars(s.data() + s1 + 1, s.data() + s2, y);
    std::from_chars(s.data() + s2 + 1, s.data() + s.size(), z);
    return true;
}

bool TemplateBuilder::is_object_template_cmd(const std::string& name) const {
    return to_lower(name).substr(0, 15) == "objecttemplate.";
}

void TemplateBuilder::apply_property(ObjectTemplate& tmpl, const std::string& cmd,
                                      const std::vector<ConArg>& args) {
    std::string prop = to_lower(cmd.substr(15));

    if (prop == "create" || prop == "createskeleton") {
        return;
    }

    if (prop == "setmesh" || prop == "setmeshname") {
        if (!args.empty()) tmpl.mesh_name = args[0].value;
    } else if (prop == "geometry") {
        if (!args.empty()) tmpl.geometry_name = args[0].value;
    } else if (prop == "setobjecttemplate") {
        if (args.size() >= 2) {
            tmpl.parent_template_type = args[0].value;
            tmpl.parent_template_name = args[1].value;
        }
    } else if (prop == "aitemplate") {
        if (!args.empty()) tmpl.ai_template = args[0].value;
    } else if (prop == "setnetworkableinfo") {
        if (!args.empty()) tmpl.networkable_info = args[0].value;

    // Template flags
    } else if (prop == "hasmobilephysics") {
        if (!args.empty()) tmpl.has_mobile_physics = parse_bool(args[0].value);
    } else if (prop == "saveinseparatefile") {
        if (!args.empty()) tmpl.save_in_separate_file = parse_bool(args[0].value);
    } else if (prop == "createnotingrid") {
        if (!args.empty()) tmpl.create_not_in_grid = parse_bool(args[0].value);
    } else if (prop == "createinvisible") {
        if (!args.empty()) tmpl.create_invisible = parse_bool(args[0].value);
    } else if (prop == "createvisibleineditor") {
        if (!args.empty()) tmpl.create_visible_in_editor = parse_bool(args[0].value);
    } else if (prop == "isnotsaveable") {
        if (!args.empty()) tmpl.is_not_saveable = parse_bool(args[0].value);
    } else if (prop == "templatehasbeenused") {
        if (!args.empty()) tmpl.template_has_been_used = parse_bool(args[0].value);
    } else if (prop == "removeatrestart") {
        if (!args.empty()) tmpl.remove_at_restart = parse_bool(args[0].value);
    } else if (prop == "alwaysusecomplexcollisionlod") {
        if (!args.empty()) tmpl.always_use_complex_collision_lod = parse_bool(args[0].value);
    } else if (prop == "hasmap") {
        if (!args.empty()) tmpl.has_map = parse_bool(args[0].value);
    } else if (prop == "isbelowground") {
        if (!args.empty()) tmpl.is_below_ground = parse_bool(args[0].value);
    } else if (prop == "isentrypoint") {
        if (!args.empty()) tmpl.is_entry_point = parse_bool(args[0].value);
    } else if (prop == "hasdynamicshadows" || prop == "hasdynamicshadow") {
        if (!args.empty()) tmpl.has_dynamic_shadows = parse_bool(args[0].value);

    // Base numeric
    } else if (prop == "cullradiusscale") {
        if (!args.empty()) tmpl.cull_radius_scale = parse_float(args[0].value);
    } else if (prop == "setstrength") {
        if (!args.empty()) tmpl.strength = parse_float(args[0].value);
    } else if (prop == "team") {
        if (!args.empty()) tmpl.team = parse_int(args[0].value);
    } else if (prop == "hardcodedat") {
        if (!args.empty()) tmpl.hardcoded_at = parse_float(args[0].value);

    // Child template (addTemplate) — FUN_006a3b50
    } else if (prop == "addtemplate") {
        if (!args.empty()) {
            ChildTemplate child;
            child.name = args[0].value;
            tmpl.children.push_back(child);
        }
    } else if (prop == "setinputid") {
        if (!args.empty() && !tmpl.children.empty()) {
            tmpl.children.back().input_id = parse_int(args[0].value);
        }
    } else if (prop == "setposition") {
        if (!args.empty() && !tmpl.children.empty()) {
            parse_vec3(args[0].value,
                       tmpl.children.back().position_x,
                       tmpl.children.back().position_y,
                       tmpl.children.back().position_z);
        }
    } else if (prop == "setrotation") {
        if (!args.empty() && !tmpl.children.empty()) {
            parse_vec3(args[0].value,
                       tmpl.children.back().rotation_pitch,
                       tmpl.children.back().rotation_yaw,
                       tmpl.children.back().rotation_roll);
        }
    } else if (prop == "setisfirstpersonpart") {
        if (!args.empty() && !tmpl.children.empty()) {
            tmpl.children.back().is_first_person_part = parse_bool(args[0].value);
        }
    } else if (prop == "setlodvalue") {
        if (!args.empty() && !tmpl.children.empty()) {
            tmpl.children.back().lod_value = parse_float(args[0].value);
        }

    // Weapon properties — FUN_005204a0
    } else if (prop == "firedelay") {
        if (!args.empty()) tmpl.fire_delay = parse_float(args[0].value);
    } else if (prop == "delaytouse") {
        if (!args.empty()) tmpl.delay_to_use = parse_float(args[0].value);
    } else if (prop == "fireonce") {
        if (!args.empty()) tmpl.fire_once = parse_bool(args[0].value);
    } else if (prop == "altfireonce") {
        if (!args.empty()) tmpl.alt_fire_once = parse_bool(args[0].value);
    } else if (prop == "selfdestroy") {
        if (!args.empty()) tmpl.self_destroy = parse_bool(args[0].value);
    } else if (prop == "heataddwhenfire") {
        if (!args.empty()) tmpl.heat_add_when_fire = parse_float(args[0].value);
    } else if (prop == "cooldownpersec") {
        if (!args.empty()) tmpl.cool_down_per_sec = parse_float(args[0].value);
    } else if (prop == "changeweaponwhennoammo") {
        if (!args.empty()) tmpl.change_weapon_when_no_ammo = parse_bool(args[0].value);
    } else if (prop == "timetonotallowchange") {
        if (!args.empty()) tmpl.time_to_not_allow_change = parse_float(args[0].value);

    // Deviation/recoil
    } else if (prop == "setmindev") {
        if (!args.empty()) tmpl.min_deviation = parse_float(args[0].value);
    } else if (prop == "setfiredev") {
        if (args.size() >= 1) {
            parse_vec3(args[0].value, tmpl.fire_deviation[0], tmpl.fire_deviation[1], tmpl.fire_deviation[2]);
        }
    } else if (prop == "sethasrecoilforce") {
        if (!args.empty()) tmpl.has_recoil_force = parse_bool(args[0].value);
    } else if (prop == "setgobackonrecoil") {
        if (!args.empty()) tmpl.go_back_on_recoil = parse_bool(args[0].value);
    } else if (prop == "setrecoilforceup") {
        if (!args.empty()) tmpl.recoil_force_up = parse_float(args[0].value);
    } else if (prop == "setrecoilforceleftright") {
        if (!args.empty()) tmpl.recoil_force_left_right = parse_float(args[0].value);
    } else if (prop == "addrootspeed") {
        if (!args.empty()) tmpl.add_root_speed = parse_bool(args[0].value);
    } else if (prop == "velocitydependentonheat") {
        if (!args.empty()) tmpl.velocity_dependent_on_heat = parse_bool(args[0].value);

    // Rotation/velocity
    } else if (prop == "rotationalspeed") {
        if (args.size() >= 1) {
            parse_vec3(args[0].value, tmpl.rotational_speed[0], tmpl.rotational_speed[1], tmpl.rotational_speed[2]);
        }
    } else if (prop == "velocity") {
        if (!args.empty()) tmpl.velocity = parse_float(args[0].value);

    // Explosion
    } else if (prop == "explosionradius") {
        if (!args.empty()) tmpl.explosion_radius = parse_float(args[0].value);
    } else if (prop == "explosiondamage") {
        if (!args.empty()) tmpl.explosion_damage = parse_float(args[0].value);
    } else if (prop == "explosionmaterial") {
        if (!args.empty()) tmpl.explosion_material = parse_int(args[0].value);
    } else if (prop == "explosionforce") {
        if (!args.empty()) tmpl.explosion_force = parse_float(args[0].value);
    } else if (prop == "explosionforcemax") {
        if (!args.empty()) tmpl.explosion_force_max = parse_float(args[0].value);
    } else if (prop == "explosionforcemod") {
        if (!args.empty()) tmpl.explosion_force_mod = parse_float(args[0].value);

    // Soldier zoom/camera — offsets +0x3f0..+0x418
    } else if (prop == "soldierzoomfov") {
        if (!args.empty()) tmpl.soldier_zoom_fov = parse_float(args[0].value);
    } else if (prop == "soldierzoomposition") {
        if (!args.empty()) {
            parse_vec3(args[0].value, tmpl.soldier_zoom_position_x,
                       tmpl.soldier_zoom_position_y, tmpl.soldier_zoom_position_z);
        }
    } else if (prop == "soldiercameraposition") {
        if (!args.empty()) {
            parse_vec3(args[0].value, tmpl.soldier_camera_position_x,
                       tmpl.soldier_camera_position_y, tmpl.soldier_camera_position_z);
        }
    } else if (prop == "usescope") {
        if (!args.empty()) tmpl.use_scope = parse_bool(args[0].value);
    } else if (prop == "unzoombetweenfiretime") {
        if (!args.empty()) tmpl.un_zoom_between_fire_time = parse_float(args[0].value);
    } else if (prop == "fireincameradof") {
        if (!args.empty()) tmpl.fire_in_camera_dof = parse_bool(args[0].value);

    } else {
        // Unknown property — preserve
        std::vector<std::string> arg_values;
        for (const auto& a : args) arg_values.push_back(a.value);
        tmpl.unknown_properties.push_back({cmd, std::move(arg_values)});
    }
}

size_t TemplateBuilder::build_from_script(const ConScript& script, TemplateDatabase& db) {
    size_t created = 0;
    ObjectTemplate* current = nullptr;

    auto process_cmd = [&](const ConCommand& cmd) {
        if (!is_object_template_cmd(cmd.name)) return;

        std::string prop = to_lower(cmd.name).substr(15);

        if (prop == "create") {
            if (cmd.args.size() >= 2) {
                ObjectTemplate tmpl;
                tmpl.type = cmd.args[0].value;
                tmpl.name = cmd.args[1].value;
                std::string saved_name = tmpl.name;
                db.add_template(std::move(tmpl));
                current = db.find_mut(saved_name);
                ++created;
            }
            return;
        }

        if (prop == "createskeleton") {
            if (!cmd.args.empty() && current) {
                current->skeleton_name = cmd.args[0].value;
            }
            return;
        }

        if (prop == "saveobjecttemplate") {
            current = nullptr;
            return;
        }

        if (current == nullptr) return;
        apply_property(*current, cmd.name, cmd.args);
    };

    for (const auto& cmd : script.commands) {
        process_cmd(cmd);
    }

    for (const auto& ifb : script.if_blocks) {
        for (const auto& cmd : ifb.then_commands) {
            process_cmd(cmd);
        }
        for (const auto& cmd : ifb.else_commands) {
            process_cmd(cmd);
        }
    }

    return created;
}

// ---------------------------------------------------------------------------
// TemplateLoader
// ---------------------------------------------------------------------------

TemplateLoader::TemplateLoader() {
}

void TemplateLoader::set_archive_path(const std::string& archive_path) {
    archive_path_ = archive_path;
}

bool TemplateLoader::load_file(const std::string& con_path, TemplateDatabase& db) {
    std::ifstream file(con_path);
    if (file) {
        std::stringstream ss;
        ss << file.rdbuf();
        std::string content = ss.str();

        ConParser parser(content);
        ConScript script = parser.parse();

        for (const auto& e : parser.errors()) errors_.push_back(e);

        TemplateBuilder builder;
        builder.build_from_script(script, db);
        return true;
    }

    if (!archive_path_.empty()) {
        errors_.push_back("File not found: " + con_path + " (RFA loading not yet integrated)");
        return false;
    }

    errors_.push_back("File not found: " + con_path);
    return false;
}

}
