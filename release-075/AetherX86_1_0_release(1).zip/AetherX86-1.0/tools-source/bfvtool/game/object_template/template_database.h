#pragma once

#include "con_parser.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <cstdint>
#include <memory>

namespace openbfv::game::object_template {

using openbfv::script::con::ConScript;
using openbfv::script::con::ConCommand;
using openbfv::script::con::ConArg;
using openbfv::script::con::ConParser;

struct ChildTemplate {
    std::string name;
    float position_x = 0.0f, position_y = 0.0f, position_z = 0.0f;
    float rotation_pitch = 0.0f, rotation_yaw = 0.0f, rotation_roll = 0.0f;
    int32_t input_id = -1;
    float lod_value = 0.0f;
    bool is_first_person_part = false;
};

struct ObjectTemplate {
    std::string name;
    std::string type;

    std::string mesh_name;
    std::string geometry_name;
    std::string skeleton_name;

    std::string parent_template_type;
    std::string parent_template_name;

    std::string ai_template;
    std::string networkable_info;

    // Template flags — from FUN_005204a0 string constants
    bool has_mobile_physics = false;
    bool save_in_separate_file = false;
    bool create_not_in_grid = false;
    bool create_invisible = false;
    bool create_visible_in_editor = false;
    bool is_not_saveable = false;
    bool template_has_been_used = false;
    bool remove_at_restart = false;
    bool always_use_complex_collision_lod = false;
    bool has_map = false;
    bool is_below_ground = false;
    bool is_entry_point = false;
    bool has_dynamic_shadows = false;

    // Base properties
    float cull_radius_scale = 0.0f;
    float strength = 0.0f;
    int team = -1;
    float hardcoded_at = 0.0f;

    // Child templates (ObjectTemplate.addTemplate)
    std::vector<ChildTemplate> children;

    // Weapon properties — offsets from FUN_005204a0 / FUN_006a3b50 / BFSoldierTemplate
    float fire_delay = 0.0f;
    float delay_to_use = 0.0f;
    bool fire_once = false;
    bool alt_fire_once = false;
    bool self_destroy = false;
    float heat_add_when_fire = 0.0f;
    float cool_down_per_sec = 0.0f;
    bool change_weapon_when_no_ammo = false;
    float time_to_not_allow_change = 0.0f;

    // Deviation/recoil — offsets +0x50c..+0x54c
    float min_deviation = 0.0f;
    float fire_deviation[3] = {};
    bool has_recoil_force = false;
    bool go_back_on_recoil = false;
    float recoil_force_up = 0.0f;
    float recoil_force_left_right = 0.0f;
    bool add_root_speed = false;
    bool velocity_dependent_on_heat = false;

    // Rotation/velocity
    float rotational_speed[3] = {};
    float velocity = 0.0f;

    // Explosion defaults (from decompiled: radius=15, damage=10, force=150, forceMax=300)
    float explosion_radius = 15.0f;
    float explosion_damage = 10.0f;
    int32_t explosion_material = 204;
    float explosion_force = 150.0f;
    float explosion_force_max = 300.0f;
    float explosion_force_mod = 1.0f;

    // Soldier zoom/camera — offsets +0x3f0..+0x418
    float soldier_zoom_fov = 0.0f;
    float soldier_zoom_position_x = 0.0f;
    float soldier_zoom_position_y = 0.0f;
    float soldier_zoom_position_z = 0.0f;
    float soldier_camera_position_x = 0.0f;
    float soldier_camera_position_y = 0.0f;
    float soldier_camera_position_z = 0.0f;
    bool use_scope = false;
    float un_zoom_between_fire_time = 0.0f;
    bool fire_in_camera_dof = false;

    std::vector<std::pair<std::string, std::vector<std::string>>> unknown_properties;
};

class TemplateDatabase {
public:
    void add_template(ObjectTemplate tmpl);
    const ObjectTemplate* find(const std::string& name) const;
    ObjectTemplate* find_mut(const std::string& name);
    bool contains(const std::string& name) const;
    size_t size() const;

    const std::unordered_map<std::string, ObjectTemplate>& all() const;

private:
    std::unordered_map<std::string, ObjectTemplate> templates_;
};

class TemplateBuilder {
public:
    size_t build_from_script(const ConScript& script, TemplateDatabase& db);

private:
    bool is_object_template_cmd(const std::string& name) const;
    void apply_property(ObjectTemplate& tmpl, const std::string& cmd,
                        const std::vector<ConArg>& args);
};

class TemplateLoader {
public:
    TemplateLoader();

    void set_archive_path(const std::string& archive_path);
    bool load_file(const std::string& con_path, TemplateDatabase& db);

    const std::vector<std::string>& errors() const { return errors_; }

private:
    std::string archive_path_;
    std::vector<std::string> errors_;
};

}
