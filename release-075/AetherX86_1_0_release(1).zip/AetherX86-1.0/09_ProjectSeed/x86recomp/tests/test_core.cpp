#include "core.hpp"
#include "runtime.hpp"

#include <algorithm>
#include <cassert>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#ifdef _MSC_VER
#include <crtdbg.h>
#endif

static void put16(std::vector<uint8_t>& b, size_t off, uint16_t v) {
    b[off] = uint8_t(v & 0xff);
    b[off + 1] = uint8_t(v >> 8);
}

static void put32(std::vector<uint8_t>& b, size_t off, uint32_t v) {
    b[off] = uint8_t(v & 0xff);
    b[off + 1] = uint8_t((v >> 8) & 0xff);
    b[off + 2] = uint8_t((v >> 16) & 0xff);
    b[off + 3] = uint8_t(v >> 24);
}

static void bytes(std::vector<uint8_t>& b, size_t off, const char* s) {
    for (size_t i = 0; s[i]; ++i) b[off + i] = uint8_t(s[i]);
}

static std::filesystem::path write_tmp(const std::string& name, const std::vector<uint8_t>& b) {
    auto p = std::filesystem::temp_directory_path() / name;
    std::ofstream f(p, std::ios::binary);
    f.write(reinterpret_cast<const char*>(b.data()), static_cast<std::streamsize>(b.size()));
    return p;
}

static void add_section(std::vector<uint8_t>& b, size_t off, const char* name,
                        uint32_t va, uint32_t vsize, uint32_t raw, uint32_t raw_size,
                        uint32_t chars) {
    bytes(b, off, name);
    put32(b, off + 8, vsize);
    put32(b, off + 12, va);
    put32(b, off + 16, raw_size);
    put32(b, off + 20, raw);
    put32(b, off + 36, chars);
}

static std::vector<uint8_t> make_pe(bool imports, bool exports) {
    std::vector<uint8_t> b(0x900, 0);
    b[0] = 'M';
    b[1] = 'Z';
    put32(b, 0x3c, 0x80);
    b[0x80] = 'P';
    b[0x81] = 'E';
    put16(b, 0x84, 0x14c);
    put16(b, 0x86, 3);
    put32(b, 0x88, 0x12345678);
    put16(b, 0x94, 0xe0);
    const size_t opt = 0x98;
    put16(b, opt, 0x10b);
    b[opt + 2] = 7;
    b[opt + 3] = 10;
    put32(b, opt + 16, 0x1010);
    put32(b, opt + 28, 0x400000);
    put32(b, opt + 32, 0x1000);
    put32(b, opt + 36, 0x200);
    put32(b, opt + 56, 0x4000);
    put32(b, opt + 60, 0x200);
    put16(b, opt + 68, 2);
    put16(b, opt + 70, 0x8100);
    put32(b, opt + 92, 16);
    if (exports) {
        put32(b, opt + 96, 0x3000);
        put32(b, opt + 100, 0x100);
    }
    if (imports) {
        put32(b, opt + 104, 0x2000);
        put32(b, opt + 108, 0x28);
        put32(b, opt + 200, 0x20A0);
        put32(b, opt + 204, 0x40);
    }
    put32(b, opt + 136, 0x3090);
    put32(b, opt + 140, 0x0c);
    put32(b, opt + 168, 0x30C0);
    put32(b, opt + 172, 0x18);
    const size_t text = opt + 0xe0;
    add_section(b, text, ".text", 0x1000, 0x80, 0x200, 0x100, 0x60000020);
    add_section(b, text + 40, ".idata", 0x2000, 0x120, 0x300, 0x200, 0x40000040);
    add_section(b, text + 80, ".edata", 0x3000, 0x120, 0x500, 0x200, 0x40000040);
    b[0x200] = 0x90;
    b[0x201] = 0xC3;
    bytes(b, 0x620, "AddD");

    if (imports) {
        put32(b, 0x300, 0x2060);
        put32(b, 0x30c, 0x2050);
        put32(b, 0x310, 0x2070);
        bytes(b, 0x350, "KERNEL32.dll");
        put32(b, 0x360, 0x2080);
        put32(b, 0x364, 0x2090);
        put32(b, 0x368, 0);
        put32(b, 0x370, 0x2080);
        put32(b, 0x374, 0x2090);
        put32(b, 0x378, 0);
        put16(b, 0x380, 17);
        bytes(b, 0x382, "ExitProcess");
        put16(b, 0x390, 18);
        bytes(b, 0x392, "GetLastError");
        put32(b, 0x3A0, 1);
        put32(b, 0x3A4, 0x2120);
        put32(b, 0x3AC, 0x2140);
        put32(b, 0x3B0, 0x2148);
        bytes(b, 0x420, "delay.dll");
        put32(b, 0x448, 0x2150);
        put32(b, 0x44C, 0);
        put16(b, 0x450, 3);
        bytes(b, 0x452, "DelayFunc");
    }

    if (exports) {
        put32(b, 0x50c, 0x3040);
        put32(b, 0x510, 1);
        put32(b, 0x514, 1);
        put32(b, 0x518, 1);
        put32(b, 0x51c, 0x3050);
        put32(b, 0x520, 0x3060);
        put32(b, 0x524, 0x3070);
        bytes(b, 0x540, "sample.dll");
        put32(b, 0x550, 0x1010);
        put32(b, 0x560, 0x3080);
        put16(b, 0x570, 0);
        bytes(b, 0x580, "ExportedFunc");
    }
    put32(b, 0x590, 0x1000);
    put32(b, 0x594, 0x0c);
    put16(b, 0x598, 0x3001);
    put16(b, 0x59a, 0x3002);
    put32(b, 0x5C0, 0x00405000);
    put32(b, 0x5C4, 0x00405008);
    put32(b, 0x5C8, 0x000030D8);
    put32(b, 0x5CC, 0x000030E0);
    return b;
}

template <typename F>
static void expect_throw(F f, const std::string& text) {
    try {
        f();
        assert(false);
    } catch (const std::runtime_error& e) {
        assert(std::string(e.what()).find(text) != std::string::npos);
    }
}

static bool cb_set_eax(xr::runtime_context&, xr::cpu_state& ctx, uint32_t va, const char*) {
    ctx.eax = va;
    return true;
}

static bool cb_set_ebx(xr::runtime_context&, xr::cpu_state& ctx, uint32_t va, const char*) {
    ctx.ebx = va;
    return true;
}

static bool cb_inc_ecx(xr::runtime_context&, xr::cpu_state& ctx, uint32_t, const char*) {
    ++ctx.ecx;
    return false;
}

static bool cb_skip_original(xr::runtime_context&, xr::cpu_state& ctx, uint32_t, const char*) {
    ctx.edx = 0x51515151u;
    return true;
}

static bool cb_get_version_ex_a(xr::runtime_context& rt, xr::cpu_state& ctx, uint32_t, const char* symbol) {
    assert(std::string(symbol) == "GetVersionExA");
    uint32_t out_va = 0;
    if (!xr::runtime_read32(rt, ctx.esp + 4, out_va)) return false;
    uint32_t size = 0;
    if (!xr::runtime_read32(rt, out_va, size)) return false;
    if (size < 20) return false;
    if (!xr::runtime_write32(rt, out_va + 4, 5)) return false;
    if (!xr::runtime_write32(rt, out_va + 8, 1)) return false;
    if (!xr::runtime_write32(rt, out_va + 12, 2600)) return false;
    if (!xr::runtime_write32(rt, out_va + 16, 2)) return false;
    ctx.eax = 1;
    return true;
}

int main() {
#ifdef _MSC_VER
    _CrtSetReportMode(_CRT_ASSERT, _CRTDBG_MODE_FILE);
    _CrtSetReportFile(_CRT_ASSERT, _CRTDBG_FILE_STDERR);
#endif

    auto b = xr::parse_hex("55 8B EC B8 2A 00 00 00 5D C3");
    auto ins = xr::decode(b, 0x401000);
    assert(ins.size() == 5);
    assert(ins[2].m == "mov");
    assert(ins[1].operands.size() == 2);
    assert(ins[1].operands[0].kind == xr::OperandKind::Reg);
    assert(ins[1].operands[0].reg == 5);
    assert(ins[1].operands[1].kind == xr::OperandKind::Reg);
    assert(ins[1].operands[1].reg == 4);
    assert(xr::lift_text(ins).find("mov eax") != std::string::npos);
    assert(xr::emit_c(ins).find("return") != std::string::npos);
    auto bad = xr::decode(xr::parse_hex("0F"), 0);
    assert(!bad[0].ok);
    assert(bad[0].d.find("unsupported two-byte") != std::string::npos);

    auto stack_decode = xr::decode(xr::parse_hex("50 56 58 5E 68 78 56 34 12 6A FC"), 0x401100);
    assert(stack_decode.size() == 6);
    assert(stack_decode[0].m == "push");
    assert(stack_decode[0].o == "eax");
    assert(stack_decode[1].m == "push");
    assert(stack_decode[1].o == "esi");
    assert(stack_decode[2].m == "pop");
    assert(stack_decode[2].o == "eax");
    assert(stack_decode[3].m == "pop");
    assert(stack_decode[3].o == "esi");
    assert(stack_decode[4].m == "push");
    assert(stack_decode[4].operands[0].kind == xr::OperandKind::Imm);
    assert(stack_decode[4].operands[0].imm == 0x12345678u);
    assert(stack_decode[4].operands[0].width == 32);
    assert(stack_decode[5].m == "push");
    assert(stack_decode[5].operands[0].imm == 0xFFFFFFFCu);
    assert(stack_decode[5].operands[0].width == 32);
    auto stack_ir = xr::lift_ir(stack_decode);
    assert(stack_ir[0].op == xr::IrOp::Push);
    assert(stack_ir[2].op == xr::IrOp::Pop);
    assert(stack_ir[5].op == xr::IrOp::Push);
    auto truncated_push = xr::decode(xr::parse_hex("68 01"), 0);
    assert(!truncated_push[0].ok);
    assert(truncated_push[0].d.find("u32") != std::string::npos);

    auto phase31_decode = xr::decode(xr::parse_hex("B0 7F 04 01 0C 02 80 C0 03 84 C0 C9 C2 08 00"), 0x401200);
    assert(phase31_decode.size() == 7);
    assert(phase31_decode[0].m == "mov" && phase31_decode[0].o == "al, 0x7F");
    assert(phase31_decode[1].m == "add" && phase31_decode[1].o == "al, 0x1");
    assert(phase31_decode[2].m == "or" && phase31_decode[2].o == "al, 0x2");
    assert(phase31_decode[3].m == "add" && phase31_decode[3].o == "al, 0x3");
    assert(phase31_decode[4].m == "test");
    assert(phase31_decode[5].m == "leave");
    assert(phase31_decode[6].m == "ret" && phase31_decode[6].operands[0].imm == 8);
    auto phase31_ir = xr::lift_ir(phase31_decode);
    assert(phase31_ir[5].op == xr::IrOp::Leave);
    assert(phase31_ir[6].op == xr::IrOp::Return);
    auto phase31_generated = xr::emit_cfg_c(xr::build_cfg(xr::parse_hex("B0 7F C9 C2 08 00"), 0x402000, 0x402000));
    assert(phase31_generated.find("ctx.eax = (ctx.eax & 0xFFFFFF00u)") != std::string::npos);
    assert(phase31_generated.find("ctx.esp += 0x00000008u") != std::string::npos);

    auto modrm_reg = xr::decode(xr::parse_hex("89 D8"), 0x1000);
    assert(modrm_reg.size() == 1);
    assert(modrm_reg[0].m == "mov");
    assert(modrm_reg[0].o == "eax, ebx");
    assert(modrm_reg[0].operands[0].kind == xr::OperandKind::Reg);
    assert(modrm_reg[0].operands[0].reg == 0);
    assert(modrm_reg[0].operands[1].reg == 3);

    auto modrm_mem = xr::decode(xr::parse_hex("8B 45 FC"), 0x2000);
    assert(modrm_mem[0].m == "mov");
    assert(modrm_mem[0].o == "eax, [ebp - 0x4]");
    assert(modrm_mem[0].operands[1].kind == xr::OperandKind::Mem);
    assert(modrm_mem[0].operands[1].has_base);
    assert(modrm_mem[0].operands[1].base == 5);
    assert(modrm_mem[0].operands[1].has_disp);
    assert(modrm_mem[0].operands[1].disp == -4);

    auto sib_mem = xr::decode(xr::parse_hex("8B 84 88 78 56 34 12"), 0x3000);
    assert(sib_mem[0].m == "mov");
    assert(sib_mem[0].o == "eax, [eax + ecx*4 + 0x12345678]");
    assert(sib_mem[0].operands[1].has_base);
    assert(sib_mem[0].operands[1].base == 0);
    assert(sib_mem[0].operands[1].has_index);
    assert(sib_mem[0].operands[1].index == 1);
    assert(sib_mem[0].operands[1].scale == 4);
    assert(sib_mem[0].operands[1].disp == 0x12345678);

    auto lea_sib = xr::decode(xr::parse_hex("8D 04 8D 00 10 00 00"), 0x4000);
    assert(lea_sib[0].m == "lea");
    assert(lea_sib[0].o == "eax, [ecx*4 + 0x1000]");
    assert(lea_sib[0].operands[1].kind == xr::OperandKind::Mem);
    assert(!lea_sib[0].operands[1].has_base);
    assert(lea_sib[0].operands[1].has_index);

    auto call_rel = xr::decode(xr::parse_hex("E8 01 00 00 00"), 0x5000);
    assert(call_rel[0].m == "call");
    assert(call_rel[0].t == 0x5006);
    assert(call_rel[0].operands[0].kind == xr::OperandKind::Rel);
    assert(call_rel[0].operands[0].target == 0x5006);

    auto jmp_short = xr::decode(xr::parse_hex("EB FE"), 0x6000);
    assert(jmp_short[0].m == "jmp");
    assert(jmp_short[0].t == 0x6000);

    auto jcc_short = xr::decode(xr::parse_hex("74 05"), 0x7000);
    assert(jcc_short[0].m == "je");
    assert(jcc_short[0].t == 0x7007);

    auto jcc_near = xr::decode(xr::parse_hex("0F 85 78 56 34 12"), 0x8000);
    assert(jcc_near[0].m == "jne");
    assert(jcc_near[0].t == 0x1234D67E);
    assert(jcc_near[0].operands[0].width == 32);

    auto truncated_modrm = xr::decode(xr::parse_hex("8B"), 0);
    assert(!truncated_modrm[0].ok);
    assert(truncated_modrm[0].d.find("modrm") != std::string::npos);

    auto mov16 = xr::decode(xr::parse_hex("66 B8 34 12"), 0x9000);
    assert(mov16[0].m == "mov");
    assert(mov16[0].o == "ax, 0x00001234");
    assert(mov16[0].operands[0].width == 16);
    assert(mov16[0].operands[1].width == 16);

    auto mov8 = xr::decode(xr::parse_hex("8A C3"), 0x9100);
    assert(mov8[0].m == "mov");
    assert(mov8[0].o == "al, bl");
    assert(mov8[0].operands[0].width == 8);

    auto mov_moffs = xr::decode(xr::parse_hex("A1 78 56 34 12 A3 78 56 34 12"), 0x9180);
    assert(mov_moffs.size() == 2);
    assert(mov_moffs[0].m == "mov");
    assert(mov_moffs[0].o == "eax, [0x12345678]");
    assert(mov_moffs[0].operands[0].kind == xr::OperandKind::Reg);
    assert(mov_moffs[0].operands[1].kind == xr::OperandKind::Mem);
    assert(mov_moffs[0].operands[1].has_disp);
    assert(uint32_t(mov_moffs[0].operands[1].disp) == 0x12345678u);
    assert(mov_moffs[1].m == "mov");
    assert(mov_moffs[1].o == "[0x12345678], eax");
    auto truncated_moffs = xr::decode(xr::parse_hex("A3 78 56"), 0);
    assert(!truncated_moffs[0].ok);
    assert(truncated_moffs[0].d.find("u32") != std::string::npos);

    auto group5 = xr::decode(xr::parse_hex("FF 15 78 56 34 12 FF 35 78 56 34 12 FF 25 78 56 34 12"), 0x91A0);
    assert(group5.size() == 3);
    assert(group5[0].m == "call");
    assert(group5[0].o == "[0x12345678]");
    assert(group5[0].operands[0].kind == xr::OperandKind::Mem);
    assert(group5[1].m == "push");
    assert(group5[1].o == "[0x12345678]");
    assert(group5[2].m == "jmp");
    assert(group5[2].o == "[0x12345678]");
    auto group5_ir = xr::lift_ir(group5);
    assert(group5_ir[0].op == xr::IrOp::IndirectCall);
    assert(group5_ir[0].ok);
    assert(group5_ir[0].diagnostic.find("indirect call") != std::string::npos);
    assert(group5_ir[1].op == xr::IrOp::Push);
    assert(group5_ir[2].op == xr::IrOp::IndirectJump);
    assert(group5_ir[2].ok);
    assert(group5_ir[2].diagnostic.find("indirect jump") != std::string::npos);
    auto truncated_group5 = xr::decode(xr::parse_hex("FF"), 0);
    assert(!truncated_group5[0].ok);
    assert(truncated_group5[0].d.find("modrm") != std::string::npos);

    auto phase15_decode = xr::decode(xr::parse_hex("40 48 FF 00 FF 08 87 D8 0F B6 C3 0F BF C3"), 0x91B0);
    assert(phase15_decode.size() == 7);
    assert(phase15_decode[0].m == "inc");
    assert(phase15_decode[0].o == "eax");
    assert(phase15_decode[1].m == "dec");
    assert(phase15_decode[1].o == "eax");
    assert(phase15_decode[2].m == "inc");
    assert(phase15_decode[2].o == "[eax]");
    assert(phase15_decode[3].m == "dec");
    assert(phase15_decode[3].o == "[eax]");
    assert(phase15_decode[4].m == "xchg");
    assert(phase15_decode[4].o == "eax, ebx");
    assert(phase15_decode[5].m == "movzx");
    assert(phase15_decode[5].o == "eax, bl");
    assert(phase15_decode[6].m == "movsx");
    assert(phase15_decode[6].o == "eax, bx");
    auto phase15_ir = xr::lift_ir(phase15_decode);
    assert(phase15_ir[0].op == xr::IrOp::Inc);
    assert(phase15_ir[0].flags.cf == xr::FlagState::Unchanged);
    assert(phase15_ir[0].flags.zf == xr::FlagState::Defined);
    assert(phase15_ir[1].op == xr::IrOp::Dec);
    assert(phase15_ir[4].op == xr::IrOp::Xchg);
    assert(phase15_ir[5].op == xr::IrOp::Movzx);
    assert(phase15_ir[6].op == xr::IrOp::Movsx);
    auto truncated_movzx = xr::decode(xr::parse_hex("0F B6"), 0);
    assert(!truncated_movzx[0].ok);
    assert(truncated_movzx[0].d.find("modrm") != std::string::npos);

    auto phase17_decode = xr::decode(
        xr::parse_hex("F7 D0 F7 D8 11 D8 83 D8 01 D1 E0 D1 E8 D1 F8 D1 C0 D1 C8 0F 94 C0 0F 45 C3 C1 E0 02 D3 E0"),
        0x91D0);
    assert(phase17_decode.size() == 13);
    assert(phase17_decode[0].m == "not");
    assert(phase17_decode[0].o == "eax");
    assert(phase17_decode[1].m == "neg");
    assert(phase17_decode[2].m == "adc");
    assert(phase17_decode[2].o == "eax, ebx");
    assert(phase17_decode[3].m == "sbb");
    assert(phase17_decode[3].o == "eax, 0x00000001");
    assert(phase17_decode[4].m == "shl");
    assert(phase17_decode[4].o == "eax, 0x00000001");
    assert(phase17_decode[5].m == "shr");
    assert(phase17_decode[6].m == "sar");
    assert(phase17_decode[7].m == "rol");
    assert(phase17_decode[8].m == "ror");
    assert(phase17_decode[9].m == "sete");
    assert(phase17_decode[9].o == "al");
    assert(phase17_decode[10].m == "cmovne");
    assert(phase17_decode[10].o == "eax, ebx");
    assert(phase17_decode[11].m == "shl");
    assert(phase17_decode[11].o == "eax, 0x00000002");
    assert(phase17_decode[12].m == "shl");
    assert(phase17_decode[12].o == "eax, cl");
    auto phase17_ir = xr::lift_ir(phase17_decode);
    assert(phase17_ir[0].op == xr::IrOp::Not);
    assert(phase17_ir[1].op == xr::IrOp::Neg);
    assert(phase17_ir[1].flags.cf == xr::FlagState::Defined);
    assert(phase17_ir[2].op == xr::IrOp::Adc);
    assert(phase17_ir[2].flags.reads.size() == 1);
    assert(phase17_ir[2].flags.reads[0] == "CF");
    assert(phase17_ir[3].op == xr::IrOp::Sbb);
    assert(phase17_ir[4].op == xr::IrOp::Shl);
    assert(phase17_ir[4].flags.af == xr::FlagState::Undefined);
    assert(phase17_ir[7].op == xr::IrOp::Rol);
    assert(phase17_ir[7].flags.zf == xr::FlagState::Unchanged);
    assert(phase17_ir[9].op == xr::IrOp::Setcc);
    assert(phase17_ir[9].condition == "je");
    assert(phase17_ir[9].flags.reads[0] == "ZF");
    assert(phase17_ir[10].op == xr::IrOp::Cmovcc);
    assert(phase17_ir[10].condition == "jne");
    assert(phase17_ir[10].flags.reads[0] == "ZF");
    auto truncated_setcc = xr::decode(xr::parse_hex("0F 94"), 0);
    assert(!truncated_setcc[0].ok);
    assert(truncated_setcc[0].d.find("modrm") != std::string::npos);
    auto unsupported_group2 = xr::decode(xr::parse_hex("D1 D0"), 0);
    assert(!unsupported_group2[0].ok);
    assert(unsupported_group2[0].d.find("group2") != std::string::npos);

    auto mov_imm_rm = xr::decode(xr::parse_hex("C7 01 78 56 34 12"), 0x91C0);
    assert(mov_imm_rm.size() == 1);
    assert(mov_imm_rm[0].m == "mov");
    assert(mov_imm_rm[0].o == "[ecx], 0x12345678");
    assert(mov_imm_rm[0].operands[0].kind == xr::OperandKind::Mem);
    assert(mov_imm_rm[0].operands[0].has_base);
    assert(mov_imm_rm[0].operands[0].base == 1);
    assert(mov_imm_rm[0].operands[1].kind == xr::OperandKind::Imm);
    assert(mov_imm_rm[0].operands[1].imm == 0x12345678u);
    auto truncated_mov_imm_rm = xr::decode(xr::parse_hex("C7 01 78"), 0);
    assert(!truncated_mov_imm_rm[0].ok);
    assert(truncated_mov_imm_rm[0].d.find("u32") != std::string::npos);

    auto arith = xr::decode(xr::parse_hex("01 D8 23 45 FC 83 E8 01 83 7D FC 01"), 0x9200);
    assert(arith.size() == 4);
    assert(arith[0].m == "add");
    assert(arith[0].o == "eax, ebx");
    assert(arith[1].m == "and");
    assert(arith[1].o == "eax, [ebp - 0x4]");
    assert(arith[2].m == "sub");
    assert(arith[2].o == "eax, 0x00000001");
    assert(arith[3].m == "cmp");
    assert(arith[3].o == "[ebp - 0x4], 0x00000001");

    auto add_flags = xr::flags_add(0xffffffffu, 1u, 32);
    assert(add_flags.cf);
    assert(add_flags.zf);
    assert(add_flags.af);
    assert(!add_flags.sf);
    assert(!add_flags.of);
    assert(add_flags.pf);
    auto add_overflow = xr::flags_add(0x7fffffffu, 1u, 32);
    assert(!add_overflow.cf);
    assert(add_overflow.of);
    assert(add_overflow.sf);
    auto adc_wrap = xr::flags_adc(0xffffffffu, 0u, 32, true);
    assert(adc_wrap.cf);
    assert(adc_wrap.zf);
    assert(adc_wrap.af);
    auto adc_overflow = xr::flags_adc(0x7fffffffu, 0u, 32, true);
    assert(!adc_overflow.cf);
    assert(adc_overflow.of);
    assert(adc_overflow.sf);
    auto sub_flags = xr::flags_sub(0u, 1u, 32);
    assert(sub_flags.cf);
    assert(sub_flags.af);
    assert(sub_flags.sf);
    assert(!sub_flags.zf);
    assert(!sub_flags.of);
    auto sub_overflow = xr::flags_sub(0x80000000u, 1u, 32);
    assert(!sub_overflow.cf);
    assert(sub_overflow.of);
    assert(!sub_overflow.sf);
    auto sbb_borrow = xr::flags_sbb(0u, 0u, 32, true);
    assert(sbb_borrow.cf);
    assert(sbb_borrow.af);
    assert(sbb_borrow.sf);
    auto sbb_overflow = xr::flags_sbb(0x80000000u, 0u, 32, true);
    assert(!sbb_overflow.cf);
    assert(sbb_overflow.of);
    assert(!sbb_overflow.sf);
    auto inc_wrap = xr::flags_inc(0xffffffffu, 32, true);
    assert(inc_wrap.cf);
    assert(inc_wrap.zf);
    assert(inc_wrap.af);
    assert(!inc_wrap.of);
    auto inc_overflow = xr::flags_inc(0x7fffffffu, 32, false);
    assert(!inc_overflow.cf);
    assert(inc_overflow.of);
    assert(inc_overflow.sf);
    auto dec_overflow = xr::flags_dec(0x80000000u, 32, true);
    assert(dec_overflow.cf);
    assert(dec_overflow.of);
    assert(!dec_overflow.sf);
    auto logic_flags = xr::flags_logic(0u, 32);
    assert(!logic_flags.cf);
    assert(!logic_flags.of);
    assert(logic_flags.zf);
    assert(logic_flags.pf);

    auto ir_source = xr::decode(xr::parse_hex("B8 01 00 00 00 83 C0 01 83 F8 02 74 02 90 C3"), 0x9300);
    auto ir = xr::lift_ir(ir_source);
    assert(ir.size() == 6);
    assert(ir[0].op == xr::IrOp::Move);
    assert(ir[1].op == xr::IrOp::Add);
    assert(ir[1].flags.cf == xr::FlagState::Defined);
    assert(ir[1].flags.of == xr::FlagState::Defined);
    assert(ir[2].op == xr::IrOp::Cmp);
    assert(ir[2].flags.zf == xr::FlagState::Defined);
    assert(ir[3].op == xr::IrOp::Branch);
    assert(ir[3].condition == "je");
    assert(ir[3].flags.reads.size() == 1);
    assert(ir[3].flags.reads[0] == "ZF");
    assert(ir[4].op == xr::IrOp::Nop);
    assert(ir[5].op == xr::IrOp::Return);
    auto test_ir = xr::lift_ir(xr::decode(xr::parse_hex("85 C0"), 0x9400));
    assert(test_ir[0].op == xr::IrOp::Test);
    assert(test_ir[0].flags.cf == xr::FlagState::Cleared);
    assert(test_ir[0].flags.af == xr::FlagState::Undefined);
    assert(test_ir[0].flags.of == xr::FlagState::Cleared);
    auto unsupported_ir = xr::lift_ir(xr::decode(xr::parse_hex("F4"), 0x9500));
    assert(!unsupported_ir[0].ok);
    assert(unsupported_ir[0].op == xr::IrOp::Unsupported);
    auto ir_text = xr::format_ir(ir);
    assert(ir_text.find("ir.add.i32 eax, 0x00000001") != std::string::npos);
    assert(ir_text.find("flags{CF=defined") != std::string::npos);
    assert(ir_text.find("ir.branch.i8.je") != std::string::npos);
    assert(ir_text.find("reads{ZF}") != std::string::npos);

    xr::runtime_context rt;
    xr::cpu_state ctx;
    xr::runtime_map_memory(rt, 0x1000, 0x100);
    assert(xr::runtime_write32(rt, 0x1010, 0xAABBCCDDu));
    uint32_t mem_value = 0;
    assert(xr::runtime_read32(rt, 0x1010, mem_value));
    assert(mem_value == 0xAABBCCDDu);
    ctx.esp = 0x1100;
    assert(xr::runtime_push32(rt, ctx, 0x12345678u));
    assert(ctx.esp == 0x10FC);
    assert(xr::runtime_pop32(rt, ctx, mem_value));
    assert(mem_value == 0x12345678u);
    assert(ctx.esp == 0x1100);
    assert(!xr::runtime_read32(rt, 0x2000, mem_value));
    assert(rt.events.back().kind == xr::RuntimeEventKind::MemoryFault);
    rt.events.clear();

    assert(xr::runtime_register_direct_call(rt, 0x4000, "direct_4000", cb_set_eax));
    assert(xr::runtime_direct_call(rt, ctx, 0x4000));
    assert(ctx.eax == 0x4000);
    assert(!xr::runtime_direct_call(rt, ctx, 0x4004));
    assert(rt.events.back().kind == xr::RuntimeEventKind::MissingDirectCall);
    assert(xr::format_runtime_events(rt).find("missing_direct_call") != std::string::npos);
    rt.events.clear();

    assert(xr::runtime_indirect_call(rt, ctx, 0x4010, 0x4000));
    assert(ctx.eax == 0x4000);
    assert(!xr::runtime_indirect_call(rt, ctx, 0x4014, 0x4444));
    assert(rt.events.back().kind == xr::RuntimeEventKind::UnresolvedIndirectCall);
    assert(rt.events.back().va == 0x4014);
    assert(rt.events.back().aux == 0x4444);
    xr::runtime_indirect_jump(rt, ctx, 0x4018, 0x5555);
    assert(rt.events.back().kind == xr::RuntimeEventKind::UnresolvedIndirectJump);
    assert(xr::format_runtime_events(rt).find("unresolved_indirect_jump") != std::string::npos);
    rt.events.clear();

    assert(xr::runtime_register_import_shim(rt, 0x5000, "shim_5000", cb_set_eax));
    assert(xr::runtime_import_shim(rt, ctx, 0x5000, "shim_5000"));
    assert(ctx.eax == 0x5000);
    assert(!xr::runtime_import_shim(rt, ctx, 0x5004, "missing_shim"));
    assert(rt.events.back().kind == xr::RuntimeEventKind::MissingImportShim);
    rt.events.clear();
    assert(xr::runtime_import_pointer_shim(rt, ctx, 0x401C, 0x5000, "shim_5000"));
    assert(ctx.eax == 0x5000);
    assert(!xr::runtime_import_pointer_shim(rt, ctx, 0x4020, 0x5008, "missing_pointer_shim"));
    assert(rt.events.back().kind == xr::RuntimeEventKind::MissingImportShim);
    assert(rt.events.back().va == 0x4020);
    assert(rt.events.back().aux == 0x5008);
    assert(rt.events.back().symbol == "missing_pointer_shim");
    rt.events.clear();

    assert(xr::runtime_register_import_shim_abi(rt, 0x5100, "GetVersionExA", "stdcall", cb_get_version_ex_a));
    ctx.esp = 0x1080;
    const uint32_t version_info_va = 0x10C0;
    assert(xr::runtime_write32(rt, ctx.esp + 4, version_info_va));
    assert(xr::runtime_write32(rt, version_info_va, 20));
    assert(xr::runtime_import_shim_abi(rt, ctx, 0x5100, "GetVersionExA", "stdcall"));
    assert(ctx.eax == 1);
    assert(xr::runtime_read32(rt, version_info_va + 4, mem_value));
    assert(mem_value == 5);
    assert(xr::runtime_read32(rt, version_info_va + 8, mem_value));
    assert(mem_value == 1);
    assert(xr::runtime_read32(rt, version_info_va + 12, mem_value));
    assert(mem_value == 2600);
    assert(xr::runtime_read32(rt, version_info_va + 16, mem_value));
    assert(mem_value == 2);
    assert(!xr::runtime_import_shim_abi(rt, ctx, 0x5100, "GetVersionExA", "cdecl"));
    assert(rt.events.back().kind == xr::RuntimeEventKind::ImportAbiMismatch);
    assert(xr::format_runtime_events(rt).find("import_abi_mismatch") != std::string::npos);
    rt.events.clear();
    assert(!xr::runtime_import_pointer_shim_abi(rt, ctx, 0x4024, 0x5100, "GetVersionExA", "cdecl"));
    assert(rt.events.back().kind == xr::RuntimeEventKind::ImportAbiMismatch);
    assert(rt.events.back().va == 0x4024);
    assert(rt.events.back().aux == 0x5100);
    rt.events.clear();
    assert(xr::runtime_bind_import_pointer_shim_abi(rt, 0x1020, 0x5200, "GetVersionExA", "stdcall", cb_get_version_ex_a));
    assert(xr::runtime_read32(rt, 0x1020, mem_value));
    assert(mem_value == 0x5200);
    assert(xr::runtime_write32(rt, ctx.esp + 4, version_info_va));
    assert(xr::runtime_write32(rt, version_info_va, 20));
    assert(xr::runtime_import_pointer_shim_abi(rt, ctx, 0x4028, mem_value, "GetVersionExA", "stdcall"));
    assert(ctx.eax == 1);
    xr::runtime_import_pointer_init init;
    init.iat_va = 0x1024;
    init.shim_target = 0x5400;
    init.symbol = "GetVersionExA";
    init.abi = "stdcall";
    init.callback = cb_get_version_ex_a;
    assert(xr::runtime_apply_import_pointer_init(rt, init));
    assert(xr::runtime_read32(rt, 0x1024, mem_value));
    assert(mem_value == 0x5400);
    assert(xr::runtime_write32(rt, ctx.esp + 4, version_info_va));
    assert(xr::runtime_write32(rt, version_info_va, 20));
    assert(xr::runtime_import_pointer_shim_abi(rt, ctx, 0x402C, mem_value, "GetVersionExA", "stdcall"));
    xr::runtime_context builtin_rt;
    xr::runtime_map_memory(builtin_rt, 0x0000, 0x10000);
    xr::runtime_import_pointer_init builtin_init;
    builtin_init.iat_va = 0x1030;
    builtin_init.shim_target = 0x5400;
    builtin_init.symbol = "KERNEL32.dll!GetVersionExA";
    builtin_init.abi = "stdcall";
    assert(xr::runtime_apply_builtin_import_pointer_init(builtin_rt, builtin_init));
    xr::cpu_state builtin_ctx;
    builtin_ctx.esp = 0x2000;
    assert(xr::runtime_write32(builtin_rt, 0x2004, 0x3100));
    assert(xr::runtime_write32(builtin_rt, 0x3100, 20));
    assert(xr::runtime_import_pointer_shim_abi(builtin_rt, builtin_ctx, 0x4030, 0x5400, "KERNEL32.dll!GetVersionExA", "stdcall"));
    uint32_t builtin_major = 0;
    assert(xr::runtime_read32(builtin_rt, 0x3104, builtin_major));
    assert(builtin_major == 5);
    init.iat_va = 0x2000;
    assert(!xr::runtime_apply_import_pointer_init(rt, init));
    assert(rt.events.back().kind == xr::RuntimeEventKind::MemoryFault);
    rt.events.clear();
    assert(!xr::runtime_bind_import_pointer_shim_abi(rt, 0x2000, 0x5300, "GetVersionExA", "stdcall", cb_get_version_ex_a));
    assert(rt.events.back().kind == xr::RuntimeEventKind::MemoryFault);
    rt.events.clear();
    xr::runtime_unsupported_side_effect(rt, ctx, 0x4028, "KERNEL32.dll!GetVersionExA");
    assert(rt.events.back().kind == xr::RuntimeEventKind::UnsupportedSideEffect);
    assert(xr::format_runtime_events(rt).find("unsupported_side_effect") != std::string::npos);
    rt.events.clear();

    auto runtime_start_manifest = xr::parse_runtime_start_manifest_text(
        "runtime_start entry_va=0x00401000 stack_base=0x00010000 stack_size=0x1000 "
        "initial_esp=0x00010800 expected_abi=cdecl evidence=unit_runtime_start rollback=drop_record enabled=true\n"
        "argument offset=4 value=0x12345678 size=4\n");
    assert(xr::validate_runtime_start_manifest(runtime_start_manifest).empty());
    assert(xr::format_runtime_start_manifest(runtime_start_manifest).find("runtime_start_issues: 0") != std::string::npos);
    xr::runtime_start_config start_config;
    start_config.entry_va = runtime_start_manifest.entry_va;
    start_config.stack_base = runtime_start_manifest.stack_base;
    start_config.stack_size = runtime_start_manifest.stack_size;
    start_config.initial_esp = runtime_start_manifest.initial_esp;
    start_config.abi = runtime_start_manifest.expected_abi;
    start_config.arguments.push_back({runtime_start_manifest.arguments[0].offset,
                                      runtime_start_manifest.arguments[0].value,
                                      runtime_start_manifest.arguments[0].size});
    xr::runtime_context start_rt;
    xr::cpu_state start_ctx;
    auto start_result = xr::runtime_prepare_start(start_rt, start_ctx, start_config);
    assert(start_result.ok);
    assert(start_ctx.esp == 0x10800);
    assert(xr::runtime_read32(start_rt, 0x10804, mem_value));
    assert(mem_value == 0x12345678);
    xr::runtime_context pre_mapped_start_rt;
    xr::runtime_map_memory(pre_mapped_start_rt, 0x00400000, 0x20000);
    assert(xr::runtime_write32(pre_mapped_start_rt, 0x00402070, 0xAABBCCDD));
    start_config.stack_base = 0x00410000;
    start_config.stack_size = 0x8000;
    start_config.initial_esp = 0x00412000;
    auto pre_mapped_start = xr::runtime_prepare_start(pre_mapped_start_rt, start_ctx, start_config);
    assert(pre_mapped_start.ok);
    assert(xr::runtime_read32(pre_mapped_start_rt, 0x00402070, mem_value));
    assert(mem_value == 0xAABBCCDD);
    auto bad_abi_start = xr::parse_runtime_start_manifest_text(
        "runtime_start entry_va=0x00401000 stack_base=0x00010000 stack_size=0x1000 "
        "initial_esp=0x00010800 expected_abi=fastcall evidence=unit rollback=drop enabled=true\n");
    assert(xr::format_runtime_start_manifest(bad_abi_start).find("unsupported ABI") != std::string::npos);
    auto bad_arg_start = xr::parse_runtime_start_manifest_text(
        "runtime_start entry_va=0x00401000 stack_base=0x00010000 stack_size=0x1000 "
        "initial_esp=0x00010FFC expected_abi=cdecl evidence=unit rollback=drop enabled=true\n"
        "argument offset=4 value=0x12345678 size=4\n");
    assert(xr::format_runtime_start_manifest(bad_arg_start).find("argument write outside stack") != std::string::npos);
    auto unaligned_arg_start = xr::parse_runtime_start_manifest_text(
        "runtime_start entry_va=0x00401000 stack_base=0x00010000 stack_size=0x1000 "
        "initial_esp=0x00010800 expected_abi=cdecl evidence=unit rollback=drop enabled=true\n"
        "argument offset=2 value=0x12345678 size=4\n");
    assert(xr::format_runtime_start_manifest(unaligned_arg_start).find("unaligned argument") != std::string::npos);

    assert(xr::runtime_register_patch_replace(rt, 0x6000, "replace_6000", cb_set_ebx));
    assert(xr::runtime_patch_replace(rt, ctx, 0x6000, "replace_6000"));
    assert(ctx.ebx == 0x6000);
    assert(xr::runtime_register_patch_before(rt, 0x6000, "before_6000", cb_inc_ecx));
    assert(xr::runtime_register_patch_after(rt, 0x6000, "after_6000", cb_inc_ecx));
    uint32_t before_hooks = ctx.ecx;
    xr::runtime_patch_before(rt, ctx, 0x6000, "before_6000");
    xr::runtime_patch_after(rt, ctx, 0x6000, "after_6000");
    assert(ctx.ecx == before_hooks + 2);
    assert(xr::runtime_register_patch_skip_original(rt, 0x6000, "skip_6000", cb_skip_original));
    assert(xr::runtime_patch_skip_original(rt, ctx, 0x6000, "skip_6000"));
    assert(ctx.edx == 0x51515151u);
    xr::runtime_patch_trap(rt, ctx, 0x7000, "trap_7000");
    assert(rt.events.back().kind == xr::RuntimeEventKind::PatchTrap);
    assert(xr::format_runtime_events(rt).find("patch_trap") != std::string::npos);

    auto cfg_bytes = xr::parse_hex("83 F8 02 74 02 90 C3 B8 01 00 00 00 C3");
    auto cfg = xr::build_cfg(cfg_bytes, 0xA000, 0xA000);
    assert(cfg.entry == 0xA000);
    assert(cfg.range_start == 0xA000);
    assert(cfg.range_end == 0xA000 + cfg_bytes.size());
    assert(cfg.blocks.size() == 3);
    assert(cfg.blocks[0].start == 0xA000);
    assert(cfg.blocks[0].instructions.size() == 2);
    assert(cfg.blocks[0].edges.size() == 2);
    assert(cfg.blocks[0].edges[0].kind == xr::CfgEdgeKind::BranchTaken);
    assert(cfg.blocks[0].edges[0].to == 0xA007);
    assert(cfg.blocks[0].edges[1].kind == xr::CfgEdgeKind::Fallthrough);
    assert(cfg.blocks[0].edges[1].to == 0xA005);
    assert(cfg.blocks[1].start == 0xA005);
    assert(cfg.blocks[1].exits);
    assert(cfg.blocks[2].start == 0xA007);
    assert(cfg.blocks[2].exits);
    auto cfg_text = xr::format_cfg(cfg);
    assert(cfg_text.find("cfg_blocks: 3") != std::string::npos);
    assert(cfg_text.find("edge: branch_taken from=0x0000A003 to=0x0000A007 detail=je") != std::string::npos);
    assert(cfg_text.find("edge: fallthrough from=0x0000A003 to=0x0000A005") != std::string::npos);
    auto generated = xr::emit_cfg_c(cfg);
    assert(generated.find("Auto-generated by x86recomp - DO NOT EDIT") != std::string::npos);
    assert(generated.find("#include \"runtime.hpp\"") != std::string::npos);
    assert(generated.find("void sub_0000A000(cpu_state& ctx, xr::runtime_context& rt)") != std::string::npos);
    assert(generated.find("L_0000A000:") != std::string::npos);
    assert(generated.find("if (ctx.zf) goto L_0000A007;") != std::string::npos);
    assert(generated.find("xr::runtime_set_sub_flags") != std::string::npos);
    assert(generated.find("return;") != std::string::npos);
    auto stack_cfg = xr::build_cfg(xr::parse_hex("68 78 56 34 12 58 C3"), 0xA100, 0xA100);
    auto stack_generated = xr::emit_cfg_c(stack_cfg);
    assert(stack_generated.find("ctx.esp = 0x10000u") != std::string::npos);
    assert(stack_generated.find("xr::runtime_push32(rt, ctx, 0x12345678u)") != std::string::npos);
    assert(stack_generated.find("xr::runtime_pop32(rt, ctx, v)") != std::string::npos);
    assert(stack_generated.find("ctx.eax = uint32_t(v);") != std::string::npos);
    auto moffs_cfg = xr::build_cfg(xr::parse_hex("A1 10 00 00 00 A3 14 00 00 00 C3"), 0xA180, 0xA180);
    auto moffs_generated = xr::emit_cfg_c(moffs_cfg);
    assert(moffs_generated.find("ctx.eax = uint32_t(xr::runtime_read_mem32(rt, ctx, 0x00000010u));") != std::string::npos);
    assert(moffs_generated.find("xr::runtime_write_mem32(rt, ctx, 0x00000014u, uint32_t(ctx.eax));") != std::string::npos);
    auto mov_imm_rm_cfg = xr::build_cfg(xr::parse_hex("C7 01 78 56 34 12 C3"), 0xA1C0, 0xA1C0);
    auto mov_imm_rm_generated = xr::emit_cfg_c(mov_imm_rm_cfg);
    assert(mov_imm_rm_generated.find("xr::runtime_write_mem32(rt, ctx, ctx.ecx, uint32_t(0x12345678u));") != std::string::npos);
    auto phase15_cfg = xr::build_cfg(xr::parse_hex("40 48 87 D8 0F B6 C3 0F BF C3 C3"), 0xA1D0, 0xA1D0);
    auto phase15_generated = xr::emit_cfg_c(phase15_cfg);
    assert(phase15_generated.find("bool old_cf = ctx.cf") != std::string::npos);
    assert(phase15_generated.find("ctx.cf = old_cf") != std::string::npos);
    assert(phase15_generated.find("uint32_t a = ctx.eax; uint32_t b = ctx.ebx;") != std::string::npos);
    assert(phase15_generated.find("ctx.eax = uint32_t((ctx.ebx & 0xFFu));") != std::string::npos);
    assert(phase15_generated.find("ctx.eax = uint32_t((((ctx.ebx & 0xFFFFu) & 0x8000u)") != std::string::npos);
    auto phase17_cfg = xr::build_cfg(xr::parse_hex("B8 01 00 00 80 BB 02 00 00 00 F7 D0 F7 D8 83 D0 01 83 D8 01 D1 E0 D1 E8 D1 F8 D1 C0 D1 C8 0F 94 C0 0F 45 C3 C3"), 0xA1E0, 0xA1E0);
    auto phase17_generated = xr::emit_cfg_c(phase17_cfg);
    assert(phase17_generated.find("xr::runtime_set_adc_flags") != std::string::npos);
    assert(phase17_generated.find("xr::runtime_set_sbb_flags") != std::string::npos);
    assert(phase17_generated.find("uint32_t r = uint32_t(int32_t(a) >> 1);") != std::string::npos);
    assert(phase17_generated.find("ctx.eax = (ctx.eax & 0xFFFFFF00u) | (uint32_t((ctx.zf) ? 1u : 0u) & 0xFFu);") != std::string::npos);
    assert(phase17_generated.find("if (!ctx.zf) { ctx.eax = uint32_t(ctx.ebx); }") != std::string::npos);
    auto unsupported_count_cfg = xr::build_cfg(xr::parse_hex("C1 E0 02 C3"), 0xA1F0, 0xA1F0);
    auto unsupported_count_generated = xr::emit_cfg_c(unsupported_count_cfg);
    assert(unsupported_count_generated.find("xr::runtime_unsupported(rt, ctx, 0x0000A1F0u);") != std::string::npos);
    std::vector<xr::CfgFunction> pack_cfgs;
    pack_cfgs.push_back(xr::build_cfg(xr::parse_hex("90 C3"), 0xA300, 0xA300));
    pack_cfgs.push_back(xr::build_cfg(xr::parse_hex("B8 2A 00 00 00 40 C3"), 0xA400, 0xA400));
    pack_cfgs.push_back(xr::build_cfg(xr::parse_hex("87 D8 0F B6 C3 C3"), 0xA500, 0xA500));
    auto pack_generated = xr::emit_cfg_c_pack(pack_cfgs);
    assert(pack_generated.find("debug_function_pack_count: 3") != std::string::npos);
    assert(pack_generated.find("debug_function_map: sub_0000A300") != std::string::npos);
    assert(pack_generated.find("debug_function_map: sub_0000A400") != std::string::npos);
    assert(pack_generated.find("debug_function_map: sub_0000A500") != std::string::npos);
    assert(pack_generated.find("k_generated_functions") != std::string::npos);
    auto dispatch_summary = xr::format_generated_dispatch_table(pack_cfgs);
    assert(dispatch_summary.find("generated_dispatch_entries: 3") != std::string::npos);
    assert(dispatch_summary.find("generated_dispatch_entry: entry=0x0000A300") != std::string::npos);
    auto pack_call_cfg = xr::build_cfg(xr::parse_hex("E8 FB 00 00 00 C3"), 0xA600, 0xA600);
    auto pack_callee_cfg = xr::build_cfg(xr::parse_hex("B8 2A 00 00 00 C3"), 0xA700, 0xA700);
    auto call_pack_generated = xr::emit_cfg_c_pack({pack_call_cfg, pack_callee_cfg});
    assert(call_pack_generated.find("void sub_0000A700(cpu_state& ctx, xr::runtime_context& rt);") != std::string::npos);
    assert(call_pack_generated.find("debug_direct_call_map: from=sub_0000A600 target=0x0000A700u resolved=generated") != std::string::npos);
    assert(call_pack_generated.find("generated_dispatch(ctx, rt, 0x0000A700u)") != std::string::npos);
    auto missing_call_pack_generated = xr::emit_cfg_c_pack({pack_call_cfg});
    assert(missing_call_pack_generated.find("debug_direct_call_map: from=sub_0000A600 target=0x0000A700u resolved=runtime_direct_call") != std::string::npos);
    assert(missing_call_pack_generated.find("xr::runtime_direct_call(rt, ctx, 0x0000A700u);") != std::string::npos);
    xr::PatchManifest pack_patch;
    pack_patch.records.push_back({xr::PatchKind::BeforeHook, 0xA300, "pack_before_A300", "cdecl",
                                  "unit generated pack boundary", "synthetic pack entry", "disable record"});
    auto patched_pack_generated = xr::emit_cfg_c_pack({pack_cfgs[0]}, pack_patch);
    assert(patched_pack_generated.find("xr::runtime_patch_before(rt, ctx, 0x0000A300u, \"pack_before_A300\")") != std::string::npos);
    assert(patched_pack_generated.find("debug_patch_boundary: kind=before_hook va=0x0000A300u symbol=pack_before_A300 abi=cdecl") != std::string::npos);
    expect_throw([&] { xr::emit_cfg_c_pack({pack_cfgs[0], pack_cfgs[0]}); }, "duplicate generated function entry");

    auto indirect_cfg = xr::build_cfg(xr::parse_hex("FF 15 78 56 34 12 90 C3 FF 25 78 56 34 12"), 0xA200, 0xA200);
    assert(indirect_cfg.indirect_call_sites.size() == 1);
    assert(indirect_cfg.indirect_call_sites[0] == 0xA200);
    assert(indirect_cfg.indirect_jump_sites.empty());
    assert(indirect_cfg.blocks[0].edges[0].kind == xr::CfgEdgeKind::IndirectCall);
    assert(indirect_cfg.blocks[0].edges[0].detail == "[0x12345678]");
    auto indirect_generated = xr::emit_cfg_c(indirect_cfg);
    assert(indirect_generated.find("xr::runtime_indirect_call(rt, ctx, 0x0000A200u, xr::runtime_read_mem32(rt, ctx, 0x12345678u));") != std::string::npos);
    xr::PatchManifest indirect_import_patch;
    indirect_import_patch.records.push_back({xr::PatchKind::IndirectImportShim, 0xA200, "shim_indirect_A200", "stdcall",
                                             "unit indirect import shim", "synthetic indirect callsite", "disable shim"});
    assert(xr::validate_patch_manifest(indirect_import_patch).empty());
    auto indirect_patch_text = xr::format_patch_manifest(indirect_import_patch);
    assert(indirect_patch_text.find("kind=indirect_import_shim") != std::string::npos);
    auto indirect_import_generated = xr::emit_cfg_c(indirect_cfg, indirect_import_patch);
    assert(indirect_import_generated.find("uint32_t target = xr::runtime_read_mem32(rt, ctx, 0x12345678u);") != std::string::npos);
    assert(indirect_import_generated.find("xr::runtime_import_pointer_shim_abi(rt, ctx, 0x0000A200u, target, \"shim_indirect_A200\", \"stdcall\")") != std::string::npos);
    assert(indirect_import_generated.find("xr::runtime_indirect_call(rt, ctx, 0x0000A200u, target)") != std::string::npos);
    xr::PatchManifest bad_indirect_import_patch;
    bad_indirect_import_patch.records.push_back({xr::PatchKind::IndirectImportShim, 0xA200, "", "", "", "", ""});
    auto bad_indirect_import_issues = xr::validate_patch_manifest(bad_indirect_import_patch);
    assert(!bad_indirect_import_issues.empty());
    expect_throw([&] { xr::emit_cfg_c(indirect_cfg, bad_indirect_import_patch); }, "invalid patch manifest");
    auto parsed_manifest = xr::parse_patch_manifest_text(
        "# synthetic manifest\n"
        "patch kind=indirect_import_shim va=0x0000A200 symbol=shim_indirect_A200 abi=stdcall reason=unit_manifest evidence=synthetic_hex rollback=drop_record enabled=true\n");
    assert(parsed_manifest.records.size() == 1);
    assert(parsed_manifest.records[0].kind == xr::PatchKind::IndirectImportShim);
    assert(parsed_manifest.records[0].va == 0xA200);
    assert(parsed_manifest.records[0].symbol == "shim_indirect_A200");
    assert(parsed_manifest.records[0].enabled);
    assert(xr::validate_patch_manifest(parsed_manifest).empty());
    auto parsed_text = xr::format_patch_manifest(parsed_manifest);
    assert(parsed_text.find("kind=indirect_import_shim") != std::string::npos);
    assert(xr::emit_cfg_c(indirect_cfg, parsed_manifest).find("runtime_import_pointer_shim_abi") != std::string::npos);
    expect_throw([&] { xr::parse_patch_manifest_text("patch kind=nope va=0x1000 symbol=x reason=r evidence=e rollback=b\n"); }, "unsupported kind");
    expect_throw([&] { xr::parse_patch_manifest_text("patch kind=indirect_import_shim va=0x1000 rva=0x1000 symbol=x reason=r evidence=e rollback=b\n"); }, "both va and rva");
    auto missing_evidence_manifest = xr::parse_patch_manifest_text(
        "patch kind=indirect_import_shim va=0x1000 symbol=x abi=stdcall reason=r rollback=b\n");
    assert(!xr::validate_patch_manifest(missing_evidence_manifest).empty());
    auto missing_abi_manifest = xr::parse_patch_manifest_text(
        "patch kind=indirect_import_shim va=0x1000 symbol=x reason=r evidence=e rollback=b\n");
    assert(!xr::validate_patch_manifest(missing_abi_manifest).empty());
    auto entry_import_manifest = xr::parse_entry_import_shim_manifest_text(
        "entry_import_shim dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x00000010 iat_rva=0x00000010 "
        "callsite_va=0x0000A200 callsite_rva=0x0000A200 abi=stdcall side_effects=version_info_write "
        "evidence=unit_entry_import_metadata rollback=drop_record enabled=true\n");
    assert(entry_import_manifest.records.size() == 1);
    assert(entry_import_manifest.records[0].dll == "KERNEL32.dll");
    assert(entry_import_manifest.records[0].symbol == "GetVersionExA");
    assert(entry_import_manifest.records[0].iat_va == 0x10);
    assert(entry_import_manifest.records[0].iat_rva == 0x10);
    assert(entry_import_manifest.records[0].callsite_va == 0xA200);
    assert(entry_import_manifest.records[0].callsite_rva == 0xA200);
    assert(xr::validate_entry_import_shim_manifest(entry_import_manifest).empty());
    auto entry_import_summary = xr::format_entry_import_shim_manifest(entry_import_manifest);
    assert(entry_import_summary.find("entry_import_shim_issues: 0") != std::string::npos);
    assert(entry_import_summary.find("side_effects=version_info_write") != std::string::npos);
    auto entry_import_patches = xr::patch_manifest_from_entry_import_shims(entry_import_manifest);
    assert(entry_import_patches.records.size() == 1);
    assert(entry_import_patches.records[0].kind == xr::PatchKind::IndirectImportShim);
    assert(entry_import_patches.records[0].symbol == "KERNEL32.dll!GetVersionExA");
    assert(entry_import_patches.records[0].dll == "KERNEL32.dll");
    assert(entry_import_patches.records[0].side_effects == "version_info_write");
    assert(xr::emit_cfg_c(indirect_cfg, entry_import_patches).find("KERNEL32.dll!GetVersionExA") != std::string::npos);
    expect_throw([&] { xr::parse_entry_import_shim_manifest_text("patch dll=KERNEL32.dll\n"); }, "unsupported record kind");
    auto missing_side_effects_entry_import = xr::parse_entry_import_shim_manifest_text(
        "entry_import_shim dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x10 callsite_va=0xA200 "
        "abi=stdcall evidence=unit rollback=drop enabled=true\n");
    assert(xr::format_entry_import_shim_manifest(missing_side_effects_entry_import).find("missing side_effects") != std::string::npos);
    auto unsupported_side_effects_entry_import = xr::parse_entry_import_shim_manifest_text(
        "entry_import_shim dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x10 callsite_va=0xA200 "
        "abi=stdcall side_effects=process_environment evidence=unit rollback=drop enabled=true\n");
    assert(xr::format_entry_import_shim_manifest(unsupported_side_effects_entry_import).find("unsupported side_effects") != std::string::npos);
    auto duplicate_entry_import = xr::parse_entry_import_shim_manifest_text(
        "entry_import_shim dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x10 callsite_va=0xA200 "
        "abi=stdcall side_effects=version_info_write evidence=unit rollback=drop enabled=true\n"
        "entry_import_shim dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x10 callsite_va=0xA200 "
        "abi=stdcall side_effects=version_info_write evidence=unit rollback=drop enabled=true\n");
    assert(xr::format_entry_import_shim_manifest(duplicate_entry_import).find("duplicate entry import shim") != std::string::npos);
    auto indirect_jump_cfg = xr::build_cfg(xr::parse_hex("FF 25 78 56 34 12"), 0xA240, 0xA240);
    assert(indirect_jump_cfg.indirect_jump_sites.size() == 1);
    assert(indirect_jump_cfg.indirect_jump_sites[0] == 0xA240);
    assert(indirect_jump_cfg.blocks[0].edges[0].kind == xr::CfgEdgeKind::IndirectJump);
    auto indirect_jump_generated = xr::emit_cfg_c(indirect_jump_cfg);
    assert(indirect_jump_generated.find("xr::runtime_indirect_jump(rt, ctx, 0x0000A240u, xr::runtime_read_mem32(rt, ctx, 0x12345678u)); return;") != std::string::npos);

    xr::PatchManifest patches;
    patches.records.push_back({xr::PatchKind::Replace, 0xA000, "replace_A000", "cdecl",
                               "unit replacement", "synthetic cfg entry", "disable record"});
    patches.records.push_back({xr::PatchKind::BeforeHook, 0xA000, "before_A000", "cdecl",
                               "unit before hook", "synthetic cfg entry", "disable record"});
    patches.records.push_back({xr::PatchKind::AfterHook, 0xA000, "after_A000", "cdecl",
                               "unit after hook", "synthetic cfg entry", "disable record"});
    patches.records.push_back({xr::PatchKind::SkipOriginal, 0xA000, "skip_A000", "cdecl",
                               "unit skip original", "synthetic cfg entry", "disable record"});
    assert(xr::validate_patch_manifest(patches).empty());
    auto patch_text = xr::format_patch_manifest(patches);
    assert(patch_text.find("kind=replace") != std::string::npos);
    assert(patch_text.find("symbol=before_A000") != std::string::npos);
    assert(patch_text.find("patch_issues: 0") != std::string::npos);
    auto patched_generated = xr::emit_cfg_c(cfg, patches);
    assert(patched_generated.find("xr::runtime_patch_replace(rt, ctx, 0x0000A000u, \"replace_A000\")") != std::string::npos);
    assert(patched_generated.find("xr::runtime_patch_before(rt, ctx, 0x0000A000u, \"before_A000\")") != std::string::npos);
    assert(patched_generated.find("xr::runtime_patch_after(rt, ctx, 0x0000A000u, \"after_A000\")") != std::string::npos);
    assert(patched_generated.find("xr::runtime_patch_skip_original(rt, ctx, 0x0000A000u, \"skip_A000\")") != std::string::npos);

    auto call_cfg = xr::build_cfg(xr::parse_hex("E8 01 00 00 00 90 C3 C3"), 0xB000, 0xB000);
    assert(call_cfg.blocks.size() == 1);
    assert(call_cfg.direct_call_targets.size() == 1);
    assert(call_cfg.direct_call_targets[0] == 0xB006);
    assert(call_cfg.blocks[0].edges[0].kind == xr::CfgEdgeKind::CallTarget);
    assert(call_cfg.blocks[0].edges[0].to == 0xB006);
    assert(call_cfg.blocks[0].edges.back().kind == xr::CfgEdgeKind::Return);
    xr::PatchManifest import_patch;
    import_patch.records.push_back({xr::PatchKind::ImportShim, 0xB006, "shim_call_B006", "stdcall",
                                    "unit import shim", "synthetic direct call", "disable shim"});
    assert(xr::validate_patch_manifest(import_patch).empty());
    auto call_generated = xr::emit_cfg_c(call_cfg, import_patch);
    assert(call_generated.find("xr::runtime_import_shim_abi(rt, ctx, 0x0000B006u, \"shim_call_B006\", \"stdcall\")") != std::string::npos);
    assert(call_generated.find("xr::runtime_direct_call(rt, ctx, 0x0000B006u)") != std::string::npos);
    xr::PatchManifest bad_patch;
    bad_patch.records.push_back({xr::PatchKind::ImportShim, 0xB006, "", "", "", "", ""});
    auto bad_patch_issues = xr::validate_patch_manifest(bad_patch);
    assert(!bad_patch_issues.empty());
    assert(xr::format_patch_manifest(bad_patch).find("patch_issues: ") != std::string::npos);
    expect_throw([&] { xr::emit_cfg_c(call_cfg, bad_patch); }, "invalid patch manifest");

    auto loop_cfg = xr::build_cfg(xr::parse_hex("EB FE"), 0xC000, 0xC000);
    assert(loop_cfg.blocks.size() == 1);
    assert(loop_cfg.blocks[0].edges.size() == 1);
    assert(loop_cfg.blocks[0].edges[0].kind == xr::CfgEdgeKind::BranchTaken);
    assert(loop_cfg.blocks[0].edges[0].to == 0xC000);

    auto unsupported_cfg = xr::build_cfg(xr::parse_hex("F4"), 0xD000, 0xD000);
    assert(unsupported_cfg.blocks.size() == 1);
    assert(unsupported_cfg.blocks[0].has_unsupported);
    assert(unsupported_cfg.blocks[0].edges[0].kind == xr::CfgEdgeKind::Unresolved);
    auto outside_cfg = xr::build_cfg(xr::parse_hex("90 C3"), 0xE000, 0xE100);
    assert(outside_cfg.blocks.empty());
    assert(!outside_cfg.diagnostics.empty());
    assert(outside_cfg.diagnostics[0].find("entry outside") != std::string::npos);

    auto pe_bytes = make_pe(true, true);
    auto pe_path = write_tmp("x86recomp_pe_imports_exports.bin", pe_bytes);
    auto parsed = xr::inspect_pe_info(pe_path);
    assert(parsed.machine == 0x14c);
    assert(parsed.section_count == 3);
    assert(parsed.image_base == 0x400000);
    assert(parsed.entrypoint_rva == 0x1010);
    assert(parsed.linker_major == 7);
    assert(parsed.linker_minor == 10);
    assert(parsed.timestamp == 0x12345678);
    assert(parsed.subsystem == 2);
    assert(parsed.sections.size() == 3);
    assert(parsed.imports.size() == 1);
    assert(parsed.imports[0].name == "KERNEL32.dll");
    assert(parsed.imports[0].functions.size() == 2);
    assert(parsed.imports[0].functions[0].name == "ExitProcess");
    assert(parsed.imports[0].functions[0].iat_rva == 0x2070);
    assert(parsed.delay_imports.size() == 1);
    assert(parsed.delay_imports[0].name == "delay.dll");
    assert(parsed.delay_imports[0].functions.size() == 1);
    assert(parsed.delay_imports[0].functions[0].name == "DelayFunc");
    assert(parsed.exports.size() == 1);
    assert(parsed.exports[0].name == "ExportedFunc");
    assert(parsed.exports[0].ordinal == 1);
    assert(parsed.exports[0].rva == 0x1010);
    assert(parsed.relocations.size() == 1);
    assert(parsed.relocations[0].page_rva == 0x1000);
    assert(parsed.relocations[0].entry_count == 2);
    assert(parsed.tls.present);
    assert(parsed.tls.start_raw == 0x00405000);
    assert(parsed.overlay_size == 0x200);
    assert(!parsed.issues.empty());

    auto info = xr::format_pe_summary(parsed);
    assert(info.find("machine: 0x014C") != std::string::npos);
    assert(info.find("linker_version: 7.10") != std::string::npos);
    assert(info.find("timestamp: 0x12345678") != std::string::npos);
    assert(info.find("section: .text") != std::string::npos);
    assert(info.find("section: .idata") != std::string::npos);
    assert(info.find("section: .edata") != std::string::npos);
    assert(info.find("exports: 1") != std::string::npos);
    assert(info.find("export: ordinal=1 rva=0x00001010 name=ExportedFunc") != std::string::npos);
    assert(info.find("imports: 1") != std::string::npos);
    assert(info.find("import_functions: 2") != std::string::npos);
    assert(info.find("import_function: KERNEL32.dll iat=0x00002070 hint=17 name=ExitProcess") != std::string::npos);
    assert(info.find("delay_imports: 1") != std::string::npos);
    assert(info.find("delay_import: delay.dll functions=1") != std::string::npos);
    assert(info.find("relocation_blocks: 1") != std::string::npos);
    assert(info.find("relocation_entries: 2") != std::string::npos);
    assert(info.find("tls_present: true") != std::string::npos);
    assert(info.find("overlay_size: 512") != std::string::npos);
    assert(info.find("issue: protection_signature detail=AddD") != std::string::npos);

    auto json = xr::format_pe_json(parsed);
    assert(json.find("\"imports\"") != std::string::npos);
    assert(json.find("\"ExportedFunc\"") != std::string::npos);
    assert(json.find("\"import_function_count\": 2") != std::string::npos);
    assert(json.find("\"delay_import_function_count\": 1") != std::string::npos);
    assert(json.find("\"tls_present\": true") != std::string::npos);

    auto image_map_summary = xr::format_pe_image_map_summary(parsed);
    assert(image_map_summary.find("pe_image_map_sections: 3") != std::string::npos);
    assert(image_map_summary.find("pe_image_map_section: name=.text") != std::string::npos);
    assert(image_map_summary.find("readable=true writable=false executable=true") != std::string::npos);
    assert(image_map_summary.find("pe_image_map_issues: 0") != std::string::npos);

    auto runtime_sections_from_pe = [&](const xr::PeInfo& pe, const std::vector<uint8_t>& bytes_in) {
        std::vector<xr::runtime_image_section> sections;
        for (const auto& section : pe.sections) {
            xr::runtime_image_section out;
            out.name = section.name;
            out.va = pe.image_base + section.virtual_address;
            out.rva = section.virtual_address;
            out.raw_size = section.raw_size;
            out.virtual_size = section.virtual_size;
            out.readable = (section.characteristics & 0x40000000u) != 0;
            out.writable = (section.characteristics & 0x80000000u) != 0;
            out.executable = (section.characteristics & 0x20000000u) != 0;
            if (section.raw_ptr < bytes_in.size()) {
                size_t available = bytes_in.size() - section.raw_ptr;
                size_t count = std::min<size_t>(section.raw_size, available);
                out.raw_data.assign(bytes_in.begin() + section.raw_ptr, bytes_in.begin() + section.raw_ptr + count);
            }
            sections.push_back(out);
        }
        return sections;
    };
    auto runtime_sections = runtime_sections_from_pe(parsed, pe_bytes);
    xr::runtime_context image_rt;
    auto image_map = xr::runtime_map_image(image_rt, parsed.image_base, parsed.size_of_image, runtime_sections);
    assert(image_map.ok);
    assert(image_rt.memory_base == parsed.image_base);
    assert(image_rt.memory.size() == parsed.size_of_image);
    assert(image_rt.image_ranges.size() == parsed.sections.size());
    assert(image_rt.memory[0x1000] == 0x90);
    assert(image_rt.memory[0x1001] == 0xC3);
    uint32_t image_value = 0;
    assert(xr::runtime_write32(image_rt, parsed.image_base + 0x2000, 0x12345678));
    assert(xr::runtime_read32(image_rt, parsed.image_base + 0x2000, image_value));
    assert(image_value == 0x12345678);
    assert(!xr::runtime_write32(image_rt, parsed.image_base + parsed.size_of_image + 4, 0x12345678));
    assert(image_rt.events.back().kind == xr::RuntimeEventKind::MemoryFault);
    auto runtime_image_summary = xr::format_runtime_image_map(image_rt);
    assert(runtime_image_summary.find("runtime_image_ranges: 3") != std::string::npos);
    assert(runtime_image_summary.find("name=.text") != std::string::npos);

    auto reloc_pe = pe_bytes;
    put32(reloc_pe, 0x204, parsed.image_base + 0x1234);
    put16(reloc_pe, 0x598, 0x3004);
    put16(reloc_pe, 0x59A, 0x0000);
    auto reloc_path = write_tmp("x86recomp_phase28_reloc.bin", reloc_pe);
    auto loaded_rebased = xr::map_pe_image(reloc_path, 0x00500000);
    assert(loaded_rebased.ok);
    assert(loaded_rebased.reloc_highlow == 1);
    assert(loaded_rebased.image[0x1004] == 0x34);
    assert(loaded_rebased.image[0x1005] == 0x12);
    assert(loaded_rebased.image[0x1006] == 0x50);
    assert(xr::format_pe_loaded_image(loaded_rebased).find("pe_loaded_image_reloc_highlow: 1") != std::string::npos);

    std::ostringstream apply_manifest_text;
    apply_manifest_text << "image path=\"" << pe_path.string() << "\" image_base=0x" << std::hex << parsed.image_base
                        << " file_hash=0x" << parsed.fnv1a64 << "\n"
                        << "runtime_init_import_pointer dll=KERNEL32.dll symbol=ExitProcess iat_va=0x00402070 iat_rva=0x00002070 "
                        << "shim_target_va=0x00510000 abi=stdcall side_effects=terminates_process evidence=unit_import_apply rollback=drop enabled=true\n"
                        << "runtime_init_import_pointer dll=KERNEL32.dll symbol=GetLastError iat_va=0x00402074 iat_rva=0x00002074 "
                        << "shim_target_va=0x00510004 abi=stdcall side_effects=reads_runtime_state evidence=unit_import_apply rollback=drop enabled=true\n"
                        << "runtime_init_import_pointer dll=delay.dll symbol=DelayFunc iat_va=0x00402140 iat_rva=0x00002140 "
                        << "shim_target_va=0x00510008 abi=stdcall side_effects=unknown_safe_stub evidence=unit_import_apply rollback=drop enabled=true\n";
    auto apply_manifest = xr::parse_runtime_init_manifest_text(apply_manifest_text.str());
    auto loaded_for_imports = xr::map_pe_image(pe_path);
    auto apply_result = xr::apply_imports_to_loaded_image(loaded_for_imports, apply_manifest);
    assert(apply_result.ok);
    assert(apply_result.applied_iat_writes == 3);
    assert(loaded_for_imports.image[0x2070] == 0x00);
    assert(loaded_for_imports.image[0x2071] == 0x00);
    assert(loaded_for_imports.image[0x2072] == 0x51);
    assert(xr::format_pe_import_apply_result(apply_result).find("pe_import_apply_iat_writes: 3") != std::string::npos);
    auto ordinal_pe = make_pe(true, false);
    put32(ordinal_pe, 0x360, 0x80000005u);
    auto ordinal_loaded = xr::map_pe_image(write_tmp("x86recomp_phase29_ordinal.bin", ordinal_pe));
    auto ordinal_apply = xr::apply_imports_to_loaded_image(ordinal_loaded, apply_manifest);
    assert(!ordinal_apply.ok);
    assert(xr::format_pe_import_apply_result(ordinal_apply).find("ordinal import requires explicit non-name policy") != std::string::npos);

    xr::runtime_image_section zero_section;
    zero_section.name = ".zero";
    zero_section.va = parsed.image_base + 0x1000;
    zero_section.rva = 0x1000;
    zero_section.raw_size = 2;
    zero_section.virtual_size = 8;
    zero_section.readable = true;
    zero_section.raw_data = {0xAA, 0xBB};
    xr::runtime_context zero_rt;
    auto zero_map = xr::runtime_map_image(zero_rt, parsed.image_base, 0x2000, {zero_section});
    assert(zero_map.ok);
    assert(zero_rt.memory[0x1000] == 0xAA);
    assert(zero_rt.memory[0x1001] == 0xBB);
    assert(zero_rt.memory[0x1002] == 0x00);
    auto overlap_sections = runtime_sections;
    overlap_sections[1].rva = overlap_sections[0].rva + 0x10;
    overlap_sections[1].va = parsed.image_base + overlap_sections[1].rva;
    assert(!xr::runtime_map_image(zero_rt, parsed.image_base, parsed.size_of_image, overlap_sections).ok);
    auto truncated_sections = runtime_sections;
    truncated_sections[0].raw_data.resize(1);
    auto truncated_map = xr::runtime_map_image(zero_rt, parsed.image_base, parsed.size_of_image, truncated_sections);
    assert(!truncated_map.ok);
    assert(truncated_map.diagnostics[0].find("truncated raw data") != std::string::npos);
    auto overflow_sections = runtime_sections;
    overflow_sections[0].rva = parsed.size_of_image - 1;
    overflow_sections[0].va = parsed.image_base + overflow_sections[0].rva;
    auto overflow_map = xr::runtime_map_image(zero_rt, parsed.image_base, parsed.size_of_image, overflow_sections);
    assert(!overflow_map.ok);
    auto invalid_base_map = xr::runtime_map_image(zero_rt, 0, parsed.size_of_image, runtime_sections);
    assert(!invalid_base_map.ok);

    auto catalog = xr::build_function_catalog(parsed);
    auto catalog_text = xr::format_function_catalog(catalog);
    assert(catalog_text.find("function_catalog_entries: 5") != std::string::npos);
    assert(catalog_text.find("kind=entrypoint source=pe_entrypoint confidence=high section=.text") != std::string::npos);
    assert(catalog_text.find("kind=export source=pe_export confidence=high section=.text symbol=ExportedFunc") != std::string::npos);
    assert(catalog_text.find("kind=import_iat source=pe_import confidence=high section=.idata symbol=KERNEL32.dll!ExitProcess") != std::string::npos);
    assert(catalog_text.find("kind=delay_import_iat source=pe_delay_import confidence=high section=.idata symbol=delay.dll!DelayFunc") != std::string::npos);
    auto catalog_cfg = xr::build_cfg(xr::parse_hex("E8 07 00 00 00 FF 15 70 20 40 00 C3 C3"), 0x401000, 0x401000);
    xr::PatchManifest catalog_manifest;
    catalog_manifest.records.push_back({xr::PatchKind::IndirectImportShim, 0x401005, "GetVersionExA", "stdcall",
                                         "catalog import pointer classification", "synthetic cfg callsite", "disable record"});
    auto combined_catalog_text = xr::format_function_catalog(xr::build_function_catalog(parsed, catalog_cfg, catalog_manifest));
    assert(combined_catalog_text.find("kind=bounded_cfg_entry source=cfg_entry confidence=medium section=.text") != std::string::npos);
    assert(combined_catalog_text.find("kind=direct_call_target source=cfg_direct_call confidence=medium section=.text") != std::string::npos);
    assert(combined_catalog_text.find("kind=indirect_callsite source=cfg_indirect_callsite confidence=medium section=.text") != std::string::npos);
    assert(combined_catalog_text.find("kind=manifest_import_pointer_callsite source=manifest confidence=high section=.text symbol=GetVersionExA") != std::string::npos);

    auto runtime_init_manifest_text = [&](uint32_t image_base, uint64_t file_hash, const std::string& records) {
        std::ostringstream o;
        o << "image path=\"" << pe_path.string() << "\" image_base=0x" << std::hex << image_base
          << " file_hash=0x" << file_hash << "\n"
          << records;
        return o.str();
    };
    std::string good_runtime_init_record =
        "runtime_init_import_pointer dll=KERNEL32.dll symbol=ExitProcess iat_va=0x00402070 iat_rva=0x00002070 "
        "shim_target_va=0x00510000 abi=stdcall side_effects=version_info_write "
        "evidence=unit_runtime_init_metadata rollback=drop_record enabled=true\n";
    auto runtime_init_manifest = xr::parse_runtime_init_manifest_text(
        runtime_init_manifest_text(parsed.image_base, parsed.fnv1a64, good_runtime_init_record));
    assert(runtime_init_manifest.import_pointers.size() == 1);
    assert(runtime_init_manifest.import_pointers[0].iat_va == 0x00402070);
    assert(runtime_init_manifest.import_pointers[0].iat_rva == 0x2070);
    assert(runtime_init_manifest.import_pointers[0].shim_target_va == 0x00510000);
    assert(xr::validate_runtime_init_manifest(runtime_init_manifest, parsed.image_base, parsed.size_of_image).empty());
    auto runtime_init_summary = xr::format_runtime_init_manifest(runtime_init_manifest, parsed.image_base, parsed.size_of_image);
    assert(runtime_init_summary.find("runtime_init_issues: 0") != std::string::npos);
    assert(runtime_init_summary.find("shim_target_va=0x00510000") != std::string::npos);
    expect_throw([&] { xr::parse_runtime_init_manifest_text("patch dll=KERNEL32.dll\n"); }, "unsupported record kind");
    expect_throw([&] { xr::parse_runtime_init_manifest_text("runtime_init_import_pointer badfield=x\n"); }, "unknown import pointer field");
    auto duplicate_runtime_init = xr::parse_runtime_init_manifest_text(runtime_init_manifest_text(
        parsed.image_base, parsed.fnv1a64, good_runtime_init_record + good_runtime_init_record));
    assert(xr::format_runtime_init_manifest(duplicate_runtime_init, parsed.image_base, parsed.size_of_image).find("duplicate runtime init import pointer") != std::string::npos);
    auto missing_evidence_runtime_init = xr::parse_runtime_init_manifest_text(runtime_init_manifest_text(
        parsed.image_base, parsed.fnv1a64,
        "runtime_init_import_pointer dll=KERNEL32.dll symbol=ExitProcess iat_rva=0x2070 "
        "shim_target_va=0x00510000 abi=stdcall side_effects=version_info_write rollback=drop enabled=true\n"));
    assert(xr::format_runtime_init_manifest(missing_evidence_runtime_init, parsed.image_base, parsed.size_of_image).find("missing evidence") != std::string::npos);
    auto unsupported_side_effect_runtime_init = xr::parse_runtime_init_manifest_text(runtime_init_manifest_text(
        parsed.image_base, parsed.fnv1a64,
        "runtime_init_import_pointer dll=KERNEL32.dll symbol=ExitProcess iat_rva=0x2070 "
        "shim_target_va=0x00510000 abi=stdcall side_effects=process_environment evidence=unit rollback=drop enabled=true\n"));
    assert(xr::format_runtime_init_manifest(unsupported_side_effect_runtime_init, parsed.image_base, parsed.size_of_image).find("unsupported side_effects") != std::string::npos);
    auto missing_abi_runtime_init = xr::parse_runtime_init_manifest_text(runtime_init_manifest_text(
        parsed.image_base, parsed.fnv1a64,
        "runtime_init_import_pointer dll=KERNEL32.dll symbol=ExitProcess iat_rva=0x2070 "
        "shim_target_va=0x00510000 side_effects=version_info_write evidence=unit rollback=drop enabled=true\n"));
    assert(xr::format_runtime_init_manifest(missing_abi_runtime_init, parsed.image_base, parsed.size_of_image).find("missing abi") != std::string::npos);
    auto unmapped_runtime_init = xr::parse_runtime_init_manifest_text(
        runtime_init_manifest_text(parsed.image_base, parsed.fnv1a64, good_runtime_init_record));
    assert(xr::format_runtime_init_manifest(unmapped_runtime_init, parsed.image_base, 0x1000).find("unmapped iat") != std::string::npos);
    auto base_mismatch_runtime_init = xr::parse_runtime_init_manifest_text(
        runtime_init_manifest_text(0x500000, parsed.fnv1a64, good_runtime_init_record));
    assert(xr::format_runtime_init_manifest(base_mismatch_runtime_init, parsed.image_base, parsed.size_of_image).find("image_base mismatch") != std::string::npos);
    auto hash_mismatch_runtime_init = xr::parse_runtime_init_manifest_text(
        runtime_init_manifest_text(parsed.image_base, 0x1234, good_runtime_init_record));
    assert(xr::format_runtime_init_manifest(hash_mismatch_runtime_init, parsed.image_base, parsed.size_of_image).find("file_hash mismatch") != std::string::npos);

    auto exit_entry_import = xr::parse_entry_import_shim_manifest_text(
        "entry_import_shim dll=KERNEL32.dll symbol=ExitProcess iat_va=0x00402070 iat_rva=0x00002070 "
        "callsite_va=0x00401000 callsite_rva=0x00001000 abi=stdcall side_effects=version_info_write "
        "evidence=unit_import_binding_entry rollback=drop_record enabled=true\n");
    auto exit_runtime_init = xr::parse_runtime_init_manifest_text(runtime_init_manifest_text(
        parsed.image_base, parsed.fnv1a64,
        "runtime_init_import_pointer dll=KERNEL32.dll symbol=ExitProcess iat_va=0x00402070 iat_rva=0x00002070 "
        "shim_target_va=0x00510000 abi=stdcall side_effects=version_info_write "
        "evidence=unit_import_binding_runtime rollback=drop_record enabled=true\n"));
    auto import_bindings = xr::resolve_import_bindings(parsed, exit_entry_import, exit_runtime_init);
    assert(import_bindings.bindings.size() == 1);
    assert(import_bindings.diagnostics.empty());
    auto import_binding_text = xr::format_import_bindings(import_bindings);
    assert(import_binding_text.find("import_bindings: 1") != std::string::npos);
    assert(import_binding_text.find("dll=KERNEL32.dll symbol=ExitProcess") != std::string::npos);
    assert(import_binding_text.find("shim_target_va=0x00510000") != std::string::npos);
    auto duplicate_import_info = parsed;
    duplicate_import_info.imports[0].functions.push_back(duplicate_import_info.imports[0].functions[0]);
    auto duplicate_import_bindings = xr::resolve_import_bindings(duplicate_import_info, exit_entry_import, exit_runtime_init);
    assert(xr::format_import_bindings(duplicate_import_bindings).find("duplicate import name") != std::string::npos);
    auto ordinal_import_info = parsed;
    ordinal_import_info.imports[0].functions[0].by_ordinal = true;
    ordinal_import_info.imports[0].functions[0].ordinal = 77;
    ordinal_import_info.imports[0].functions[0].name.clear();
    auto ordinal_import_bindings = xr::resolve_import_bindings(ordinal_import_info, exit_entry_import, exit_runtime_init);
    auto ordinal_binding_text = xr::format_import_bindings(ordinal_import_bindings);
    assert(ordinal_binding_text.find("ordinal-only import") != std::string::npos);
    assert(ordinal_binding_text.find("missing import KERNEL32.dll!ExitProcess") != std::string::npos);
    auto missing_import_entry = xr::parse_entry_import_shim_manifest_text(
        "entry_import_shim dll=KERNEL32.dll symbol=MissingSymbol iat_va=0x00402074 iat_rva=0x00002074 "
        "callsite_va=0x00401000 callsite_rva=0x00001000 abi=stdcall side_effects=version_info_write "
        "evidence=unit rollback=drop enabled=true\n");
    auto missing_import_runtime = xr::parse_runtime_init_manifest_text(runtime_init_manifest_text(
        parsed.image_base, parsed.fnv1a64,
        "runtime_init_import_pointer dll=KERNEL32.dll symbol=MissingSymbol iat_va=0x00402074 iat_rva=0x00002074 "
        "shim_target_va=0x00510000 abi=stdcall side_effects=version_info_write evidence=unit rollback=drop enabled=true\n"));
    assert(xr::format_import_bindings(xr::resolve_import_bindings(parsed, missing_import_entry, missing_import_runtime)).find("missing import") != std::string::npos);
    auto abi_mismatch_runtime = xr::parse_runtime_init_manifest_text(runtime_init_manifest_text(
        parsed.image_base, parsed.fnv1a64,
        "runtime_init_import_pointer dll=KERNEL32.dll symbol=ExitProcess iat_va=0x00402070 iat_rva=0x00002070 "
        "shim_target_va=0x00510000 abi=cdecl side_effects=version_info_write evidence=unit rollback=drop enabled=true\n"));
    assert(xr::format_import_bindings(xr::resolve_import_bindings(parsed, exit_entry_import, abi_mismatch_runtime)).find("ABI mismatch") != std::string::npos);
    auto bad_side_effect_entry = xr::parse_entry_import_shim_manifest_text(
        "entry_import_shim dll=KERNEL32.dll symbol=ExitProcess iat_va=0x00402070 iat_rva=0x00002070 "
        "callsite_va=0x00401000 callsite_rva=0x00001000 abi=stdcall side_effects=process_environment "
        "evidence=unit rollback=drop enabled=true\n");
    assert(xr::format_import_bindings(xr::resolve_import_bindings(parsed, bad_side_effect_entry, exit_runtime_init)).find("unsupported side_effects") != std::string::npos);

    auto hist = xr::unsupported_opcode_histogram(pe_path);
    assert(hist.total > 0);
    assert(hist.supported >= 2);
    assert(hist.unsupported > 0);
    auto hist_text = xr::format_opcode_histogram(hist);
    assert(hist_text.find("unsupported_opcode: 0x00000000") != std::string::npos);

    auto slice = xr::analyze_pe_slice(pe_path, 0x1000, 2);
    assert(slice.rva == 0x1000);
    assert(slice.va == 0x401000);
    assert(slice.file_offset == 0x200);
    assert(slice.section_name == ".text");
    assert(slice.instructions == 2);
    assert(slice.supported == 2);
    assert(slice.unsupported == 0);
    assert(slice.unsupported_ir == 0);
    assert(slice.cfg.blocks.size() == 1);
    assert(slice.cfg_complete);
    assert(slice.generated_candidate);
    auto slice_text = xr::format_pe_slice_analysis(slice);
    assert(slice_text.find("slice_rva: 0x00001000") != std::string::npos);
    assert(slice_text.find("slice_generated_candidate: true") != std::string::npos);

    auto function_pack_manifest_text_for = [&](const std::filesystem::path& path, uint32_t image_base,
                                               uint64_t file_hash, const std::string& function_lines) {
        std::ostringstream o;
        o << "image path=\"" << path.string() << "\" image_base=0x" << std::hex << image_base
          << " file_hash=0x" << file_hash << "\n"
          << function_lines;
        return o.str();
    };
    auto function_pack_manifest_text = [&](uint32_t image_base, uint64_t file_hash, const std::string& function_lines) {
        return function_pack_manifest_text_for(pe_path, image_base, file_hash, function_lines);
    };
    std::string good_function_record =
        "function va=0x401000 rva=0x1000 size=2 source=synthetic confidence=high "
        "section=.text evidence=unit_pe_slice rollback=drop_record enabled=true\n";
    auto function_pack_manifest = xr::parse_function_pack_manifest_text(
        function_pack_manifest_text(parsed.image_base, parsed.fnv1a64, good_function_record));
    auto function_pack_issues = xr::validate_function_pack_manifest(function_pack_manifest);
    assert(function_pack_issues.empty());
    auto function_pack_summary = xr::format_function_pack_manifest(function_pack_manifest);
    assert(function_pack_summary.find("function_pack_issues: 0") != std::string::npos);
    assert(function_pack_summary.find("function_pack_function: va=0x00401000 rva=0x00001000") != std::string::npos);
    auto manifest_cfgs = xr::build_function_pack_from_manifest(function_pack_manifest);
    assert(manifest_cfgs.size() == 1);
    auto manifest_pack_generated = xr::emit_cfg_c_pack_manifest(function_pack_manifest);
    assert(manifest_pack_generated.find("debug_function_pack_count") != std::string::npos);

    auto ghidra_boundary_text = [&](const std::string& function_lines) {
        std::ostringstream o;
        o << function_lines;
        return o.str();
    };
    std::string good_ghidra_record =
        "ghidra_function va=0x401000 rva=0x1000 size=2 name=FUN_00401000 source_tool=ghidra_mcp "
        "confidence=high evidence=synthetic_boundary verifier=capstone_x86recomp enabled=true\n";
    auto ghidra_import = xr::parse_ghidra_boundary_import_text(ghidra_boundary_text(good_ghidra_record));
    assert(xr::validate_ghidra_boundary_import(ghidra_import, parsed).empty());
    auto ghidra_summary = xr::format_ghidra_boundary_import(ghidra_import, parsed);
    assert(ghidra_summary.find("ghidra_boundary_issues: 0") != std::string::npos);
    assert(ghidra_summary.find("name=FUN_00401000") != std::string::npos);
    auto ghidra_catalog_text = xr::format_function_catalog(xr::build_function_catalog(parsed, ghidra_import));
    assert(ghidra_catalog_text.find("kind=ghidra_function_boundary") != std::string::npos);
    assert(ghidra_catalog_text.find("symbol=FUN_00401000") != std::string::npos);
    auto ghidra_pack_manifest = xr::function_pack_manifest_from_ghidra(pe_path, ghidra_import);
    assert(xr::validate_function_pack_manifest(ghidra_pack_manifest).empty());
    auto ghidra_pack_generated = xr::emit_cfg_c_pack_ghidra(pe_path, ghidra_import);
    assert(ghidra_pack_generated.find("debug_function_map: sub_00401000") != std::string::npos);

    expect_throw([&] { xr::parse_ghidra_boundary_import_text("function va=0x401000\n"); }, "unsupported record kind");
    auto duplicate_ghidra = xr::parse_ghidra_boundary_import_text(good_ghidra_record + good_ghidra_record);
    assert(xr::format_ghidra_boundary_import(duplicate_ghidra, parsed).find("duplicate ghidra function") != std::string::npos);
    auto missing_evidence_ghidra = xr::parse_ghidra_boundary_import_text(
        "ghidra_function rva=0x1000 size=2 name=FUN_00401000 source_tool=ghidra_mcp confidence=high verifier=capstone_x86recomp\n");
    assert(xr::format_ghidra_boundary_import(missing_evidence_ghidra, parsed).find("missing evidence") != std::string::npos);
    auto unsupported_tool_ghidra = xr::parse_ghidra_boundary_import_text(
        "ghidra_function rva=0x1000 size=2 name=FUN_00401000 source_tool=ida confidence=high evidence=unit verifier=capstone_x86recomp\n");
    assert(xr::format_ghidra_boundary_import(unsupported_tool_ghidra, parsed).find("unsupported source_tool") != std::string::npos);
    auto no_verifier_ghidra = xr::parse_ghidra_boundary_import_text(
        "ghidra_function rva=0x1000 size=2 name=FUN_00401000 source_tool=ghidra_mcp confidence=high evidence=unit\n");
    assert(xr::format_ghidra_boundary_import(no_verifier_ghidra, parsed).find("size lacks capstone_x86recomp verifier") != std::string::npos);
    auto conflicting_ghidra = xr::parse_ghidra_boundary_import_text(
        good_ghidra_record +
        "ghidra_function rva=0x1002 name=FUN_00401000 source_tool=ghidra_mcp confidence=medium evidence=other_boundary enabled=true\n");
    assert(xr::format_ghidra_boundary_import(conflicting_ghidra, parsed).find("conflicting ghidra function name") != std::string::npos);
    auto unbounded_ghidra = xr::parse_ghidra_boundary_import_text(
        "ghidra_function rva=0x1000 name=FUN_00401000 source_tool=ghidra_mcp confidence=medium evidence=unbounded_boundary enabled=true\n");
    expect_throw([&] { xr::function_pack_manifest_from_ghidra(pe_path, unbounded_ghidra); }, "missing bounded size");
    auto ghidra_unsupported_pe = make_pe(false, false);
    ghidra_unsupported_pe[0x202] = 0xF4;
    auto ghidra_unsupported_pe_path = write_tmp("x86recomp_ghidra_unsupported.bin", ghidra_unsupported_pe);
    auto bad_candidate_ghidra = xr::parse_ghidra_boundary_import_text(
        "ghidra_function rva=0x1002 size=1 name=FUN_00401002 source_tool=ghidra_mcp confidence=high evidence=unit verifier=capstone_x86recomp enabled=true\n");
    expect_throw([&] { xr::function_pack_manifest_from_ghidra(ghidra_unsupported_pe_path, bad_candidate_ghidra); }, "not a generated candidate");

    expect_throw([&] { xr::parse_function_pack_manifest_text("asset path=x\n"); }, "unsupported record kind");
    auto duplicate_manifest = xr::parse_function_pack_manifest_text(
        function_pack_manifest_text(parsed.image_base, parsed.fnv1a64, good_function_record + good_function_record));
    assert(xr::format_function_pack_manifest(duplicate_manifest).find("duplicate function rva=0x00001000") != std::string::npos);
    auto missing_evidence_pack_manifest = xr::parse_function_pack_manifest_text(function_pack_manifest_text(
        parsed.image_base, parsed.fnv1a64,
        "function rva=0x1000 size=2 source=synthetic confidence=high section=.text rollback=drop_record enabled=true\n"));
    assert(xr::format_function_pack_manifest(missing_evidence_pack_manifest).find("missing evidence") != std::string::npos);
    auto base_mismatch_manifest = xr::parse_function_pack_manifest_text(
        function_pack_manifest_text(0x500000, parsed.fnv1a64, good_function_record));
    assert(xr::format_function_pack_manifest(base_mismatch_manifest).find("image_base mismatch") != std::string::npos);
    auto hash_mismatch_manifest = xr::parse_function_pack_manifest_text(
        function_pack_manifest_text(parsed.image_base, 0x1234, good_function_record));
    assert(xr::format_function_pack_manifest(hash_mismatch_manifest).find("file_hash mismatch") != std::string::npos);
    auto out_of_section_manifest = xr::parse_function_pack_manifest_text(function_pack_manifest_text(
        parsed.image_base, parsed.fnv1a64,
        "function rva=0x1100 size=2 source=synthetic confidence=high section=.text evidence=unit rollback=drop enabled=true\n"));
    assert(xr::format_function_pack_manifest(out_of_section_manifest).find("slice outside section") != std::string::npos);
    auto unsupported_pe = make_pe(false, false);
    unsupported_pe[0x202] = 0xF4;
    auto unsupported_pe_path = write_tmp("x86recomp_unsupported_pack_manifest.bin", unsupported_pe);
    auto unsupported_info = xr::inspect_pe_info(unsupported_pe_path);
    auto unsupported_ir_manifest = xr::parse_function_pack_manifest_text(function_pack_manifest_text_for(
        unsupported_pe_path, unsupported_info.image_base, unsupported_info.fnv1a64,
        "function rva=0x1002 size=1 source=synthetic confidence=high section=.text evidence=unit rollback=drop enabled=true\n"));
    assert(xr::format_function_pack_manifest(unsupported_ir_manifest).find("not a generated candidate") != std::string::npos);

    auto indirect_slice = make_pe(false, false);
    indirect_slice[0x200] = 0xFF;
    indirect_slice[0x201] = 0x15;
    put32(indirect_slice, 0x202, 0x12345678);
    indirect_slice[0x206] = 0xC3;
    auto indirect_slice_result = xr::analyze_pe_slice(write_tmp("x86recomp_indirect_slice.bin", indirect_slice), 0x1000, 7);
    assert(indirect_slice_result.unsupported == 0);
    assert(indirect_slice_result.unsupported_ir == 0);
    assert(indirect_slice_result.cfg.indirect_call_sites.size() == 1);
    assert(!indirect_slice_result.cfg_complete);
    assert(!indirect_slice_result.generated_candidate);
    auto indirect_slice_text = xr::format_pe_slice_analysis(indirect_slice_result);
    assert(indirect_slice_text.find("slice_cfg_indirect_calls: 1") != std::string::npos);
    assert(indirect_slice_text.find("slice_cfg_complete: false") != std::string::npos);
    auto indirect_info = xr::inspect_pe_info(write_tmp("x86recomp_indirect_pack_manifest.bin", indirect_slice));
    std::ostringstream indirect_manifest_text;
    indirect_manifest_text << "image path=\"" << (std::filesystem::temp_directory_path() / "x86recomp_indirect_pack_manifest.bin").string()
                           << "\" image_base=0x" << std::hex << indirect_info.image_base
                           << " file_hash=0x" << indirect_info.fnv1a64 << "\n"
                           << "function rva=0x1000 size=7 source=synthetic confidence=high section=.text "
                           << "evidence=indirect_call_slice rollback=drop enabled=true\n";
    auto indirect_manifest = xr::parse_function_pack_manifest_text(indirect_manifest_text.str());
    assert(xr::format_function_pack_manifest(indirect_manifest).find("not a generated candidate") != std::string::npos);
    auto bad_slice = make_pe(false, false);
    expect_throw([&] { xr::analyze_pe_slice(write_tmp("x86recomp_bad_slice.bin", bad_slice), 0x1000, 0x1000); }, "slice exceeds");

    auto no_import_path = write_tmp("x86recomp_pe_no_imports.bin", make_pe(false, false));
    auto no_imports = xr::inspect_pe_info(no_import_path);
    assert(no_imports.imports.empty());
    assert(no_imports.exports.empty());
    assert(xr::format_pe_summary(no_imports).find("imports: 0") != std::string::npos);

    expect_throw([] { xr::inspect_pe(write_tmp("x86recomp_not_mz.bin", {'N','O'})); }, "not MZ");
    auto truncated = make_pe(false, false);
    truncated.resize(0x180);
    expect_throw([&] { xr::inspect_pe(write_tmp("x86recomp_truncated_sections.bin", truncated)); }, "section table");
    auto bad_import = make_pe(true, false);
    put32(bad_import, 0x98 + 104, 0x5000);
    expect_throw([&] { xr::inspect_pe(write_tmp("x86recomp_bad_import_rva.bin", bad_import)); }, "rva not mapped");
    auto bad_export = make_pe(false, true);
    put16(bad_export, 0x570, 7);
    expect_throw([&] { xr::inspect_pe(write_tmp("x86recomp_bad_export_ordinal.bin", bad_export)); }, "export ordinal");
}
