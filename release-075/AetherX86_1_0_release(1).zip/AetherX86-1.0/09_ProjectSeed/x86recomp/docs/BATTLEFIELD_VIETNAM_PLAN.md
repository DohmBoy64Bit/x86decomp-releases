# Battlefield Vietnam target plan

Record local PE facts, imports, unsupported opcodes, runtime blockers, and trace milestones. Do not commit game files.

<!-- AETHERX86-1.0:Phase 28 PE image loader completion -->
## Phase 28 PE image loader completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: promote Phase 27 metadata-only PE image planning into a loader-owned image map that can copy headers/sections and apply PE32 base relocations for synthetic and supported PE32 inputs.

Implemented surface:
- `map-pe-image <pe> [mapped_base]` CLI.
- `xr::map_pe_image` and `xr::format_pe_loaded_image` API.
- PE32 section copy into a loader-owned image buffer.
- Relocation directory walking with `IMAGE_REL_BASED_ABSOLUTE` skip and `IMAGE_REL_BASED_HIGHLOW` adjustment.
- Hard diagnostics for unsupported relocation types, malformed relocation blocks, out-of-image relocation targets, and rebased images that lack relocation data.

Verification:
- Synthetic relocation unit test maps a PE at a non-preferred base and verifies a HIGHLOW target is adjusted by the base delta.
- Supplied mock `BfVietnam.exe` maps cleanly at its preferred base and reports a diagnostic when deliberately rebased because its relocation directory is absent.

<!-- AETHERX86-1.0:Phase 29 import IAT application completion -->
## Phase 29 import IAT application completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move import handling from binding summaries into controlled loaded-image IAT writes, while keeping ordinal imports explicit and non-silent.

Implemented surface:
- `apply-pe-imports <pe> <runtime_init_manifest> [mapped_base]` CLI.
- `xr::apply_imports_to_loaded_image` and `xr::format_pe_import_apply_result` API.
- Name-import and delay-import IAT writes sourced from validated runtime-init manifests.
- Duplicate, missing, and malformed manifest validation before image mutation.
- Ordinal-only imports produce explicit diagnostics and do not receive guessed addresses.

Verification:
- Synthetic ordinary import and delay-import IAT writes are checked byte-for-byte in the loaded image.
- Synthetic ordinal import fixture fails with the diagnostic `ordinal import requires explicit non-name policy`.

<!-- AETHERX86-1.0:Phase 30 generated dispatch completion -->
## Phase 30 generated dispatch completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: replace pack-local direct-call emission with a deterministic generated dispatch boundary that can grow into chunked generated functions.

Implemented surface:
- Generated packs now emit `generated_function_record`, `k_generated_functions`, and `generated_dispatch(ctx, rt, target)`.
- Pack-local direct calls route through `generated_dispatch` instead of hardwired direct subroutine calls.
- Runtime direct-call fallback is retained when the target is outside the generated pack.
- `format-generated-dispatch-raw` CLI exposes dispatch metadata for raw fixtures.

Verification:
- Existing direct-call generated-pack tests now assert dispatch-table output and generated dispatch invocation.
- New CLI smoke evidence writes a generated dispatch summary for a tiny raw pack.

<!-- AETHERX86-1.0:Phase 31 IA-32 semantic expansion completion -->
## Phase 31 IA-32 semantic expansion completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: reduce the next high-value BFV blockers with universal IA-32 semantics only, not BFV-specific decoding branches.

Implemented surface:
- `ret imm16` (`C2 iw`).
- `leave` (`C9`) lifted to explicit frame teardown code.
- `mov r8, imm8` (`B0..B7`) with partial-register-safe write emission for generated C.
- Accumulator immediate arithmetic/logic forms (`04/05/0C/0D/14/15/1C/1D/24/25/2C/2D/34/35/3C/3D`).
- 8-bit ModRM arithmetic/logic forms and `test r/m8, r8` (`84 /r`).
- `mov r/m8, imm8` (`C6 /0 ib`) in addition to existing 32-bit immediate moves.

Verification:
- Unit tests cover decode, lift, and generated C output for the newly supported forms.
- Capstone decode and PE-slice verifier tests pass with Capstone 5.0.7 available in the environment.
- Mock BFV unsupported histogram improved from the earlier baseline of 3,004,248 decoded slots / 2,189,413 supported / 814,835 unsupported to 2,750,940 decoded slots / 2,310,829 supported / 440,111 unsupported in this build.

<!-- AETHERX86-1.0:Phase 32 Win32 shim boundary completion -->
## Phase 32 Win32 shim boundary completion

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

Goal: move the synthetic `GetVersionExA` import-pointer callback into a small tested Win32 shim boundary without claiming full Windows emulation.

Implemented surface:
- `runtime_win32_builtin_callback` resolves builtin callbacks by case-insensitive Win32 symbol name.
- `runtime_apply_builtin_import_pointer_init` applies runtime-init records and fills builtin callbacks when available.
- `runtime_win32_get_version_ex_a` implements a minimal stdcall-shaped `OSVERSIONINFOA` write: success return, Windows XP-era version fields, and unchanged behavior when memory validation fails.
- Byte-level runtime memory helpers support shim structure writes.

Verification:
- Runtime unit test initializes a `KERNEL32.dll!GetVersionExA` import pointer through the builtin resolver, calls it, and checks that the version structure is written.
- Scope remains intentionally narrow: no BFV execution/playability claim and no broad Win32 API emulation claim.

