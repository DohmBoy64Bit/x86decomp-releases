# AetherX86 / x86recomp 1.0 verification record

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

## Implemented phase scope

- Phase 28: loader-owned PE32 image mapping plus HIGHLOW relocation support for rebased images with explicit diagnostics.
- Phase 29: validated import/delay-import IAT application from runtime-init manifests; ordinal imports remain blocked unless a future explicit ordinal policy is added.
- Phase 30: deterministic generated function dispatch table and generated dispatch boundary for pack-local calls.
- Phase 31: universal IA-32 semantic expansion selected from BFV blocker evidence.
- Phase 32: minimal builtin Win32 `GetVersionExA` shim boundary.

## Verified commands

```text
cmake -S 09_ProjectSeed/x86recomp -B /mnt/data/aetherx86_1_0_build -DCMAKE_BUILD_TYPE=Release
cmake --build /mnt/data/aetherx86_1_0_build --parallel 2
/mnt/data/aetherx86_1_0_build/x86tests
ctest --test-dir /mnt/data/aetherx86_1_0_build -I 1,5 --output-on-failure --timeout 120
ctest --test-dir /mnt/data/aetherx86_1_0_build -I 6,11 --output-on-failure --timeout 120
ctest --test-dir /mnt/data/aetherx86_1_0_build -I 12,14 --output-on-failure --timeout 120
ctest --test-dir /mnt/data/aetherx86_1_0_build -I 15,17 --output-on-failure --timeout 120
ctest --test-dir /mnt/data/aetherx86_1_0_build -I 18,21 --output-on-failure --timeout 120
```

## Observed test result

All 21 CTest tests passed in the chunked run. Capstone tests were active and passed in this environment. A prior unchunked CTest wrapper exceeded the tool wall-clock window after several passing tests; the chunked run is the recorded complete result.

## Mock BFV evidence

- `inspect /mnt/data/BfVietnam.exe` succeeded and produced safe metadata evidence only.
- Preferred-base `map-pe-image /mnt/data/BfVietnam.exe` succeeded.
- Rebased `map-pe-image /mnt/data/BfVietnam.exe 0x00500000` correctly reported that relocation data is absent and did not claim a valid rebased image.
- Unsupported histogram after Phase 31: 2,750,940 decoded slots, 2,310,829 supported, 440,111 unsupported, 109 unsupported opcode kinds.

## Explicit non-claims

- No BFV executable bytes are committed to the repository.
- No BFV full execution or playability claim is made.
- No complete Win32 API emulation claim is made.
- No ordinal import address guessing is performed.

<!-- AETHERX86-1.0:mandatory-hash-followup -->
## Mandatory documentation/hash follow-up

After the user clarified the mandatory workflow, the 1.0 package was re-opened and updated with the following release-control hardening:

- `AGENTS.md` now explicitly requires a re-read after each major code edit.
- `SKILL.md` and `skill/SKILL.md` now carry the same mandatory post-edit rule refresh and `00` through `09` synchronization requirement.
- The mandatory numbered folders `00_Governance/` through `09_ProjectSeed/` are now included in the documented release-integrity scope.
- `09_ProjectSeed/x86recomp/tools/doc_hash_check.py` now covers release-relevant docs, source, tests, CMake/config files, tools, target manifests, and text evidence, rather than only Markdown/text docs.
- Generated `tools/bfvtool` build outputs were removed from the source release; reproducible source remains under `tools-source/bfvtool`.

Follow-up verification commands:

```text
cmake -S 09_ProjectSeed/x86recomp -B /mnt/data/aetherx86_resume_build -DCMAKE_BUILD_TYPE=Release
cmake --build /mnt/data/aetherx86_resume_build --parallel 2
ctest --test-dir /mnt/data/aetherx86_resume_build -I 1,7 --output-on-failure
ctest --test-dir /mnt/data/aetherx86_resume_build -R <remaining-test-name> --output-on-failure
python 09_ProjectSeed/x86recomp/tools/doc_hash_check.py --root . --output 02_Verification/doc_hash_final_1_0.sha256
sha256sum -c 02_Verification/doc_hash_final_1_0.sha256
cmp -s SKILL.md skill/SKILL.md
```

Follow-up result: configure/build passed; all 21 tests passed through timeout-safe chunks/individual runs; the widened integrity manifest passed `sha256sum -c`; `SKILL.md` and `skill/SKILL.md` are byte-identical. The earlier deferred Windows/MSVC and full target execution gates remain deferred.
