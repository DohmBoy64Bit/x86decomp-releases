# x86recomp seed

Buildable C++20 seed with a tiny raw-byte decode/lift demo, C-like emitter, minimal PE inspector, and CTest coverage.

This is not a full recompiler yet. It is the compiling vertical slice that future work must preserve.

## Build

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

## Current commands

```bash
x86recomp inspect <pe>
x86recomp lift-raw "55 8B EC B8 2A 00 00 00 5D C3"
x86recomp emit-c-raw "55 8B EC B8 2A 00 00 00 5D C3"
```

## Next engineering step

Replace string operands with structured operands, then add ModRM/SIB decoding tests.

<!-- AETHERX86-1.0:1.0 release candidate status -->
## 1.0 release candidate status

Status: verified in the Linux seed build unless explicitly marked deferred. The 1.0 release candidate keeps BFV target bytes out of the repository; the supplied mock executable was used only as local evidence input.

Source changes are intentionally split by concern: PE image loading lives in `src/pe_image.cpp`, Win32 builtin runtime shims live in `src/runtime_shims.cpp`, and existing decode/lift/codegen logic remains in `src/core.cpp`.

1.0 usable-state means the seed is no longer only a planning skeleton: it has a buildable C++20 CLI/library/test surface, PE inspection, PE image mapping, relocation diagnostics, controlled import IAT application, generated-pack dispatch metadata, expanded IA-32 semantics, and a minimal tested Win32 import shim boundary.

Verified local commands:
- CMake configure/build passed in Release mode.
- `x86tests` passed.
- All 21 CTest tests passed when run in timeout-safe chunks.
- Capstone-backed decode and PE-slice verification tests passed with Capstone 5.0.7 available.
- Mock BFV PE inspection and preferred-base image mapping completed as safe metadata evidence.

Deferred local/user-environment gates:
- Windows/MSVC rebuild and test run.
- Any full target/game execution or playability test.
- Any import application against the mock BFV executable without a complete, explicit runtime-init manifest covering its imports.

