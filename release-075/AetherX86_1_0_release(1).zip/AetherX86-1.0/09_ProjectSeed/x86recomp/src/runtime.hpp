#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace xr {

struct cpu_state {
    uint32_t eax = 0, ecx = 0, edx = 0, ebx = 0, esp = 0, ebp = 0, esi = 0, edi = 0;
    bool cf = false, pf = false, af = false, zf = false, sf = false, of = false;
};

enum class RuntimeEventKind {
    MemoryFault,
    MissingDirectCall,
    MissingImportShim,
    ImportAbiMismatch,
    UnresolvedIndirectCall,
    UnresolvedIndirectJump,
    PatchTrap,
    Unsupported,
    UnresolvedJump,
    UnsupportedSideEffect
};

struct runtime_context;
using runtime_callback = bool (*)(runtime_context&, cpu_state&, uint32_t, const char*);

struct runtime_binding {
    uint32_t va = 0;
    std::string symbol;
    std::string abi;
    runtime_callback callback = nullptr;
    bool enabled = true;
};

struct runtime_import_pointer_init {
    uint32_t iat_va = 0;
    uint32_t shim_target = 0;
    std::string symbol;
    std::string abi;
    runtime_callback callback = nullptr;
    bool enabled = true;
};

struct runtime_event {
    RuntimeEventKind kind = RuntimeEventKind::Unsupported;
    uint32_t va = 0;
    uint32_t aux = 0;
    std::string symbol;
};

struct runtime_image_range {
    uint32_t va = 0;
    uint32_t rva = 0;
    uint32_t raw_size = 0;
    uint32_t virtual_size = 0;
    bool readable = false;
    bool writable = false;
    bool executable = false;
    std::string name;
};

struct runtime_image_section {
    uint32_t va = 0;
    uint32_t rva = 0;
    uint32_t raw_size = 0;
    uint32_t virtual_size = 0;
    bool readable = false;
    bool writable = false;
    bool executable = false;
    std::string name;
    std::vector<uint8_t> raw_data;
};

struct runtime_image_map_result {
    bool ok = true;
    std::vector<std::string> diagnostics;
};

struct runtime_start_argument {
    uint32_t offset = 0;
    uint32_t value = 0;
    uint32_t size = 4;
};

struct runtime_start_config {
    uint32_t entry_va = 0;
    uint32_t stack_base = 0;
    uint32_t stack_size = 0;
    uint32_t initial_esp = 0;
    std::string abi;
    std::vector<runtime_start_argument> arguments;
    bool enabled = true;
};

struct runtime_start_result {
    bool ok = true;
    std::vector<std::string> diagnostics;
};

struct runtime_context {
    uint32_t memory_base = 0;
    std::vector<uint8_t> memory;
    std::vector<runtime_image_range> image_ranges;
    std::vector<runtime_binding> direct_calls;
    std::vector<runtime_binding> import_shims;
    std::vector<runtime_binding> replacements;
    std::vector<runtime_binding> before_hooks;
    std::vector<runtime_binding> after_hooks;
    std::vector<runtime_binding> skip_originals;
    std::vector<runtime_binding> traps;
    std::vector<runtime_event> events;
};

void runtime_map_memory(runtime_context&, uint32_t base, uint32_t size);
runtime_image_map_result runtime_map_image(runtime_context&, uint32_t image_base, uint32_t image_size,
                                           const std::vector<runtime_image_section>&);
std::string format_runtime_image_map(const runtime_context&);
runtime_start_result runtime_prepare_start(runtime_context&, cpu_state&, const runtime_start_config&);
bool runtime_read8(runtime_context&, uint32_t va, uint8_t& out);
bool runtime_write8(runtime_context&, uint32_t va, uint8_t value);
bool runtime_read32(runtime_context&, uint32_t va, uint32_t& out);
bool runtime_write32(runtime_context&, uint32_t va, uint32_t value);
uint32_t runtime_read_mem8(runtime_context&, cpu_state&, uint32_t va);
uint32_t runtime_read_mem32(runtime_context&, cpu_state&, uint32_t va);
bool runtime_write_mem8(runtime_context&, cpu_state&, uint32_t va, uint8_t value);
bool runtime_write_mem32(runtime_context&, cpu_state&, uint32_t va, uint32_t value);
bool runtime_push32(runtime_context&, cpu_state&, uint32_t value);
bool runtime_pop32(runtime_context&, cpu_state&, uint32_t& value);

bool runtime_register_direct_call(runtime_context&, uint32_t va, const std::string& symbol, runtime_callback);
bool runtime_register_import_shim(runtime_context&, uint32_t va, const std::string& symbol, runtime_callback);
bool runtime_register_import_shim_abi(runtime_context&, uint32_t va, const std::string& symbol,
                                      const std::string& abi, runtime_callback);
bool runtime_bind_import_pointer_shim_abi(runtime_context&, uint32_t iat_va, uint32_t shim_target,
                                          const std::string& symbol, const std::string& abi,
                                          runtime_callback);
bool runtime_apply_import_pointer_init(runtime_context&, const runtime_import_pointer_init&);
runtime_callback runtime_win32_builtin_callback(const std::string& symbol);
bool runtime_apply_builtin_import_pointer_init(runtime_context&, const runtime_import_pointer_init&);
bool runtime_win32_get_version_ex_a(runtime_context&, cpu_state&, uint32_t va, const char* symbol);
bool runtime_register_patch_replace(runtime_context&, uint32_t va, const std::string& symbol, runtime_callback);
bool runtime_register_patch_before(runtime_context&, uint32_t va, const std::string& symbol, runtime_callback);
bool runtime_register_patch_after(runtime_context&, uint32_t va, const std::string& symbol, runtime_callback);
bool runtime_register_patch_skip_original(runtime_context&, uint32_t va, const std::string& symbol, runtime_callback);
bool runtime_register_patch_trap(runtime_context&, uint32_t va, const std::string& symbol, runtime_callback);

bool runtime_direct_call(runtime_context&, cpu_state&, uint32_t target);
bool runtime_indirect_call(runtime_context&, cpu_state&, uint32_t from, uint32_t target);
void runtime_indirect_jump(runtime_context&, cpu_state&, uint32_t from, uint32_t target);
bool runtime_import_shim(runtime_context&, cpu_state&, uint32_t va, const char* symbol);
bool runtime_import_shim_abi(runtime_context&, cpu_state&, uint32_t va, const char* symbol, const char* abi);
bool runtime_import_pointer_shim(runtime_context&, cpu_state&, uint32_t from, uint32_t target, const char* symbol);
bool runtime_import_pointer_shim_abi(runtime_context&, cpu_state&, uint32_t from, uint32_t target,
                                     const char* symbol, const char* abi);
bool runtime_patch_replace(runtime_context&, cpu_state&, uint32_t va, const char* symbol);
void runtime_patch_before(runtime_context&, cpu_state&, uint32_t va, const char* symbol);
void runtime_patch_after(runtime_context&, cpu_state&, uint32_t va, const char* symbol);
bool runtime_patch_skip_original(runtime_context&, cpu_state&, uint32_t va, const char* symbol);
void runtime_patch_trap(runtime_context&, cpu_state&, uint32_t va, const char* symbol);

void runtime_unsupported(runtime_context&, cpu_state&, uint32_t va);
void runtime_unsupported_side_effect(runtime_context&, cpu_state&, uint32_t va, const char* symbol);
void runtime_unresolved_jump(runtime_context&, cpu_state&, uint32_t from, uint32_t to);
void runtime_set_add_flags(cpu_state&, uint32_t a, uint32_t b, uint32_t r);
void runtime_set_adc_flags(cpu_state&, uint32_t a, uint32_t b, bool carry_in, uint32_t r);
void runtime_set_sub_flags(cpu_state&, uint32_t a, uint32_t b, uint32_t r);
void runtime_set_sbb_flags(cpu_state&, uint32_t a, uint32_t b, bool carry_in, uint32_t r);
void runtime_set_logic_flags(cpu_state&, uint32_t r);
const char* runtime_event_name(RuntimeEventKind);
std::string format_runtime_events(const runtime_context&);

}
