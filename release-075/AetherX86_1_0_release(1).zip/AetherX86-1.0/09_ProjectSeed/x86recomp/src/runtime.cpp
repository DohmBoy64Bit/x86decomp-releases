#include "runtime.hpp"

#include <algorithm>
#include <iomanip>
#include <sstream>

namespace xr {

static bool even_parity8(uint32_t value) {
    value &= 0xffu;
    bool even = true;
    while (value) {
        even = !even;
        value &= value - 1;
    }
    return even;
}

static bool memory_offset(const runtime_context& rt, uint32_t va, uint32_t size, size_t& off) {
    if (size > rt.memory.size() || va < rt.memory_base) return false;
    uint64_t delta = uint64_t(va) - uint64_t(rt.memory_base);
    if (delta + size > rt.memory.size()) return false;
    off = static_cast<size_t>(delta);
    return true;
}

static void add_event(runtime_context& rt, RuntimeEventKind kind, uint32_t va, uint32_t aux = 0,
                      const char* symbol = nullptr) {
    runtime_event event;
    event.kind = kind;
    event.va = va;
    event.aux = aux;
    if (symbol) event.symbol = symbol;
    rt.events.push_back(event);
}

static bool add_binding(std::vector<runtime_binding>& bindings, uint32_t va, const std::string& symbol,
                        const std::string& abi, runtime_callback callback) {
    if (!callback) return false;
    runtime_binding binding;
    binding.va = va;
    binding.symbol = symbol;
    binding.abi = abi;
    binding.callback = callback;
    bindings.push_back(binding);
    return true;
}

static bool symbol_matches(const runtime_binding& binding, const char* symbol) {
    if (!symbol || !*symbol) return true;
    return binding.symbol.empty() || binding.symbol == symbol;
}

static bool abi_matches(const runtime_binding& binding, const char* abi) {
    if (!abi || !*abi) return true;
    return binding.abi.empty() || binding.abi == abi;
}

static runtime_binding* find_binding(std::vector<runtime_binding>& bindings, uint32_t va, const char* symbol,
                                     const char* abi = nullptr) {
    auto it = std::find_if(bindings.begin(), bindings.end(), [&](const runtime_binding& binding) {
        return binding.enabled && binding.va == va && symbol_matches(binding, symbol) && abi_matches(binding, abi);
    });
    return it == bindings.end() ? nullptr : &*it;
}

static bool has_symbol_binding(std::vector<runtime_binding>& bindings, uint32_t va, const char* symbol) {
    return std::any_of(bindings.begin(), bindings.end(), [&](const runtime_binding& binding) {
        return binding.enabled && binding.va == va && symbol_matches(binding, symbol);
    });
}

static bool call_binding(runtime_binding& binding, runtime_context& rt, cpu_state& ctx, uint32_t va,
                         const char* symbol) {
    return binding.callback ? binding.callback(rt, ctx, va, symbol ? symbol : binding.symbol.c_str()) : false;
}

void runtime_map_memory(runtime_context& rt, uint32_t base, uint32_t size) {
    rt.memory_base = base;
    rt.memory.assign(size, 0);
    rt.image_ranges.clear();
}

runtime_image_map_result runtime_map_image(runtime_context& rt, uint32_t image_base, uint32_t image_size,
                                           const std::vector<runtime_image_section>& sections) {
    runtime_image_map_result result;
    auto issue = [&](const std::string& text) {
        result.ok = false;
        result.diagnostics.push_back(text);
    };
    if (!image_base) issue("invalid image base");
    if (!image_size) issue("invalid image size");

    std::vector<std::pair<uint32_t, uint32_t>> mapped_ranges;
    for (const auto& section : sections) {
        std::string name = section.name.empty() ? "<unnamed>" : section.name;
        if (section.va != image_base + section.rva) {
            issue("section " + name + " va/rva mismatch");
        }
        uint32_t mapped_size = std::max(section.raw_size, section.virtual_size);
        if (!mapped_size) {
            issue("section " + name + " empty mapped size");
            continue;
        }
        uint64_t section_end_rva = uint64_t(section.rva) + uint64_t(mapped_size);
        uint64_t section_end_va = uint64_t(section.va) + uint64_t(mapped_size);
        if (section_end_rva > image_size || section_end_va > 0xffffffffull) {
            issue("section " + name + " section overflow");
        }
        if (section.raw_data.size() < section.raw_size) {
            issue("section " + name + " truncated raw data");
        }
        uint32_t begin = section.rva;
        uint32_t end = uint32_t(std::min<uint64_t>(section_end_rva, 0xffffffffull));
        for (const auto& [other_begin, other_end] : mapped_ranges) {
            if (begin < other_end && other_begin < end) {
                issue("section " + name + " overlaps another section");
                break;
            }
        }
        mapped_ranges.push_back({begin, end});
    }

    if (!result.ok) return result;
    runtime_map_memory(rt, image_base, image_size);
    for (const auto& section : sections) {
        size_t offset = section.rva;
        for (uint32_t i = 0; i < section.raw_size; ++i) {
            rt.memory[offset + i] = section.raw_data[i];
        }
        runtime_image_range range;
        range.va = section.va;
        range.rva = section.rva;
        range.raw_size = section.raw_size;
        range.virtual_size = section.virtual_size;
        range.readable = section.readable;
        range.writable = section.writable;
        range.executable = section.executable;
        range.name = section.name;
        rt.image_ranges.push_back(range);
    }
    return result;
}

std::string format_runtime_image_map(const runtime_context& rt) {
    std::ostringstream o;
    o << "runtime_image_base: 0x" << std::uppercase << std::hex << std::setw(8) << std::setfill('0')
      << rt.memory_base << "\n"
      << "runtime_image_size: " << std::dec << rt.memory.size() << "\n"
      << "runtime_image_ranges: " << rt.image_ranges.size() << "\n";
    for (const auto& range : rt.image_ranges) {
        o << "runtime_image_range: name=" << range.name
          << " va=0x" << std::uppercase << std::hex << std::setw(8) << std::setfill('0') << range.va
          << " rva=0x" << std::setw(8) << range.rva
          << " raw_size=" << std::dec << range.raw_size
          << " virtual_size=" << range.virtual_size
          << " readable=" << (range.readable ? "true" : "false")
          << " writable=" << (range.writable ? "true" : "false")
          << " executable=" << (range.executable ? "true" : "false") << "\n";
    }
    return o.str();
}

runtime_start_result runtime_prepare_start(runtime_context& rt, cpu_state& ctx, const runtime_start_config& config) {
    runtime_start_result result;
    auto issue = [&](const std::string& text) {
        result.ok = false;
        result.diagnostics.push_back(text);
    };
    if (!config.enabled) return result;
    if (!config.entry_va) issue("missing entry");
    if (config.abi != "cdecl" && config.abi != "stdcall") issue("unsupported ABI " + config.abi);
    if (!config.stack_base || !config.stack_size) issue("invalid stack");
    uint64_t stack_end = uint64_t(config.stack_base) + uint64_t(config.stack_size);
    if (stack_end > 0xffffffffull) issue("stack overflow");
    if (config.initial_esp < config.stack_base || uint64_t(config.initial_esp) > stack_end) {
        issue("initial ESP outside stack");
    }
    for (const auto& arg : config.arguments) {
        if (arg.size != 4) issue("unsupported argument size");
        if (arg.offset % 4) issue("unaligned argument");
        uint64_t arg_va = uint64_t(config.initial_esp) + uint64_t(arg.offset);
        if (arg_va < config.stack_base || arg_va + arg.size > stack_end) {
            issue("argument write outside stack");
        }
    }
    if (!result.ok) return result;
    if (rt.memory.empty()) {
        runtime_map_memory(rt, config.stack_base, config.stack_size);
    } else {
        size_t stack_off = 0;
        if (!memory_offset(rt, config.stack_base, config.stack_size, stack_off)) {
            issue("stack outside mapped memory");
            return result;
        }
    }
    ctx = cpu_state{};
    ctx.esp = config.initial_esp;
    for (const auto& arg : config.arguments) {
        if (!runtime_write32(rt, config.initial_esp + arg.offset, arg.value)) {
            issue("unsafe memory access");
        }
    }
    return result;
}

bool runtime_read8(runtime_context& rt, uint32_t va, uint8_t& out) {
    size_t off = 0;
    if (!memory_offset(rt, va, 1, off)) {
        out = 0;
        add_event(rt, RuntimeEventKind::MemoryFault, va);
        return false;
    }
    out = rt.memory[off];
    return true;
}

bool runtime_write8(runtime_context& rt, uint32_t va, uint8_t value) {
    size_t off = 0;
    if (!memory_offset(rt, va, 1, off)) {
        add_event(rt, RuntimeEventKind::MemoryFault, va);
        return false;
    }
    rt.memory[off] = value;
    return true;
}

bool runtime_read32(runtime_context& rt, uint32_t va, uint32_t& out) {
    size_t off = 0;
    if (!memory_offset(rt, va, 4, off)) {
        out = 0;
        add_event(rt, RuntimeEventKind::MemoryFault, va);
        return false;
    }
    out = uint32_t(rt.memory[off]) |
          (uint32_t(rt.memory[off + 1]) << 8) |
          (uint32_t(rt.memory[off + 2]) << 16) |
          (uint32_t(rt.memory[off + 3]) << 24);
    return true;
}

bool runtime_write32(runtime_context& rt, uint32_t va, uint32_t value) {
    size_t off = 0;
    if (!memory_offset(rt, va, 4, off)) {
        add_event(rt, RuntimeEventKind::MemoryFault, va);
        return false;
    }
    rt.memory[off] = uint8_t(value & 0xffu);
    rt.memory[off + 1] = uint8_t((value >> 8) & 0xffu);
    rt.memory[off + 2] = uint8_t((value >> 16) & 0xffu);
    rt.memory[off + 3] = uint8_t((value >> 24) & 0xffu);
    return true;
}

uint32_t runtime_read_mem8(runtime_context& rt, cpu_state&, uint32_t va) {
    uint8_t out = 0;
    runtime_read8(rt, va, out);
    return out;
}

uint32_t runtime_read_mem32(runtime_context& rt, cpu_state&, uint32_t va) {
    uint32_t out = 0;
    runtime_read32(rt, va, out);
    return out;
}

bool runtime_write_mem8(runtime_context& rt, cpu_state&, uint32_t va, uint8_t value) {
    return runtime_write8(rt, va, value);
}

bool runtime_write_mem32(runtime_context& rt, cpu_state&, uint32_t va, uint32_t value) {
    return runtime_write32(rt, va, value);
}

bool runtime_push32(runtime_context& rt, cpu_state& ctx, uint32_t value) {
    uint32_t old_esp = ctx.esp;
    ctx.esp -= 4;
    if (!runtime_write32(rt, ctx.esp, value)) {
        ctx.esp = old_esp;
        return false;
    }
    return true;
}

bool runtime_pop32(runtime_context& rt, cpu_state& ctx, uint32_t& value) {
    if (!runtime_read32(rt, ctx.esp, value)) return false;
    ctx.esp += 4;
    return true;
}

bool runtime_register_direct_call(runtime_context& rt, uint32_t va, const std::string& symbol,
                                  runtime_callback callback) {
    return add_binding(rt.direct_calls, va, symbol, "", callback);
}

bool runtime_register_import_shim(runtime_context& rt, uint32_t va, const std::string& symbol,
                                  runtime_callback callback) {
    return runtime_register_import_shim_abi(rt, va, symbol, "cdecl", callback);
}

bool runtime_register_import_shim_abi(runtime_context& rt, uint32_t va, const std::string& symbol,
                                      const std::string& abi, runtime_callback callback) {
    return add_binding(rt.import_shims, va, symbol, abi, callback);
}

bool runtime_bind_import_pointer_shim_abi(runtime_context& rt, uint32_t iat_va, uint32_t shim_target,
                                          const std::string& symbol, const std::string& abi,
                                          runtime_callback callback) {
    if (!callback) return false;
    if (!runtime_write32(rt, iat_va, shim_target)) return false;
    return runtime_register_import_shim_abi(rt, shim_target, symbol, abi, callback);
}

bool runtime_apply_import_pointer_init(runtime_context& rt, const runtime_import_pointer_init& init) {
    if (!init.enabled) return true;
    return runtime_bind_import_pointer_shim_abi(rt, init.iat_va, init.shim_target, init.symbol,
                                               init.abi, init.callback);
}

bool runtime_register_patch_replace(runtime_context& rt, uint32_t va, const std::string& symbol,
                                    runtime_callback callback) {
    return add_binding(rt.replacements, va, symbol, "", callback);
}

bool runtime_register_patch_before(runtime_context& rt, uint32_t va, const std::string& symbol,
                                   runtime_callback callback) {
    return add_binding(rt.before_hooks, va, symbol, "", callback);
}

bool runtime_register_patch_after(runtime_context& rt, uint32_t va, const std::string& symbol,
                                  runtime_callback callback) {
    return add_binding(rt.after_hooks, va, symbol, "", callback);
}

bool runtime_register_patch_skip_original(runtime_context& rt, uint32_t va, const std::string& symbol,
                                          runtime_callback callback) {
    return add_binding(rt.skip_originals, va, symbol, "", callback);
}

bool runtime_register_patch_trap(runtime_context& rt, uint32_t va, const std::string& symbol,
                                 runtime_callback callback) {
    return add_binding(rt.traps, va, symbol, "", callback);
}

bool runtime_direct_call(runtime_context& rt, cpu_state& ctx, uint32_t target) {
    if (auto* binding = find_binding(rt.direct_calls, target, nullptr)) {
        return call_binding(*binding, rt, ctx, target, nullptr);
    }
    add_event(rt, RuntimeEventKind::MissingDirectCall, target);
    return false;
}

bool runtime_indirect_call(runtime_context& rt, cpu_state& ctx, uint32_t from, uint32_t target) {
    if (auto* binding = find_binding(rt.direct_calls, target, nullptr)) {
        return call_binding(*binding, rt, ctx, target, nullptr);
    }
    if (auto* binding = find_binding(rt.import_shims, target, nullptr)) {
        return call_binding(*binding, rt, ctx, target, nullptr);
    }
    add_event(rt, RuntimeEventKind::UnresolvedIndirectCall, from, target);
    return false;
}

void runtime_indirect_jump(runtime_context& rt, cpu_state&, uint32_t from, uint32_t target) {
    add_event(rt, RuntimeEventKind::UnresolvedIndirectJump, from, target);
}

bool runtime_import_shim(runtime_context& rt, cpu_state& ctx, uint32_t va, const char* symbol) {
    return runtime_import_shim_abi(rt, ctx, va, symbol, nullptr);
}

bool runtime_import_shim_abi(runtime_context& rt, cpu_state& ctx, uint32_t va, const char* symbol, const char* abi) {
    if (auto* binding = find_binding(rt.import_shims, va, symbol, abi)) {
        return call_binding(*binding, rt, ctx, va, symbol);
    }
    if (has_symbol_binding(rt.import_shims, va, symbol)) {
        add_event(rt, RuntimeEventKind::ImportAbiMismatch, va, 0, symbol);
        return false;
    }
    add_event(rt, RuntimeEventKind::MissingImportShim, va, 0, symbol);
    return false;
}

bool runtime_import_pointer_shim(runtime_context& rt, cpu_state& ctx, uint32_t from, uint32_t target,
                                 const char* symbol) {
    return runtime_import_pointer_shim_abi(rt, ctx, from, target, symbol, nullptr);
}

bool runtime_import_pointer_shim_abi(runtime_context& rt, cpu_state& ctx, uint32_t from, uint32_t target,
                                     const char* symbol, const char* abi) {
    if (auto* binding = find_binding(rt.import_shims, target, symbol, abi)) {
        return call_binding(*binding, rt, ctx, target, symbol);
    }
    if (has_symbol_binding(rt.import_shims, target, symbol)) {
        add_event(rt, RuntimeEventKind::ImportAbiMismatch, from, target, symbol);
        return false;
    }
    add_event(rt, RuntimeEventKind::MissingImportShim, from, target, symbol);
    return false;
}

bool runtime_patch_replace(runtime_context& rt, cpu_state& ctx, uint32_t va, const char* symbol) {
    if (auto* binding = find_binding(rt.replacements, va, symbol)) {
        return call_binding(*binding, rt, ctx, va, symbol);
    }
    return false;
}

void runtime_patch_before(runtime_context& rt, cpu_state& ctx, uint32_t va, const char* symbol) {
    for (auto& binding : rt.before_hooks) {
        if (binding.enabled && binding.va == va && symbol_matches(binding, symbol)) {
            call_binding(binding, rt, ctx, va, symbol);
        }
    }
}

void runtime_patch_after(runtime_context& rt, cpu_state& ctx, uint32_t va, const char* symbol) {
    for (auto& binding : rt.after_hooks) {
        if (binding.enabled && binding.va == va && symbol_matches(binding, symbol)) {
            call_binding(binding, rt, ctx, va, symbol);
        }
    }
}

bool runtime_patch_skip_original(runtime_context& rt, cpu_state& ctx, uint32_t va, const char* symbol) {
    if (auto* binding = find_binding(rt.skip_originals, va, symbol)) {
        return call_binding(*binding, rt, ctx, va, symbol);
    }
    return false;
}

void runtime_patch_trap(runtime_context& rt, cpu_state& ctx, uint32_t va, const char* symbol) {
    if (auto* binding = find_binding(rt.traps, va, symbol)) {
        call_binding(*binding, rt, ctx, va, symbol);
        return;
    }
    add_event(rt, RuntimeEventKind::PatchTrap, va, 0, symbol);
}

void runtime_unsupported(runtime_context& rt, cpu_state&, uint32_t va) {
    add_event(rt, RuntimeEventKind::Unsupported, va);
}

void runtime_unsupported_side_effect(runtime_context& rt, cpu_state&, uint32_t va, const char* symbol) {
    add_event(rt, RuntimeEventKind::UnsupportedSideEffect, va, 0, symbol);
}

void runtime_unresolved_jump(runtime_context& rt, cpu_state&, uint32_t from, uint32_t to) {
    add_event(rt, RuntimeEventKind::UnresolvedJump, from, to);
}

void runtime_set_add_flags(cpu_state& ctx, uint32_t a, uint32_t b, uint32_t r) {
    ctx.cf = uint64_t(a) + uint64_t(b) > 0xffffffffull;
    ctx.pf = even_parity8(r);
    ctx.af = ((a ^ b ^ r) & 0x10u) != 0;
    ctx.zf = r == 0;
    ctx.sf = (r & 0x80000000u) != 0;
    ctx.of = ((~(a ^ b) & (a ^ r) & 0x80000000u) != 0);
}

void runtime_set_adc_flags(cpu_state& ctx, uint32_t a, uint32_t b, bool carry_in, uint32_t r) {
    uint64_t carry = carry_in ? 1ull : 0ull;
    uint64_t full = uint64_t(a) + uint64_t(b) + carry;
    uint32_t bb = uint32_t(uint64_t(b) + carry);
    ctx.cf = full > 0xffffffffull;
    ctx.pf = even_parity8(r);
    ctx.af = ((a ^ bb ^ r) & 0x10u) != 0;
    ctx.zf = r == 0;
    ctx.sf = (r & 0x80000000u) != 0;
    ctx.of = ((~(a ^ bb) & (a ^ r) & 0x80000000u) != 0);
}

void runtime_set_sub_flags(cpu_state& ctx, uint32_t a, uint32_t b, uint32_t r) {
    ctx.cf = a < b;
    ctx.pf = even_parity8(r);
    ctx.af = ((a ^ b ^ r) & 0x10u) != 0;
    ctx.zf = r == 0;
    ctx.sf = (r & 0x80000000u) != 0;
    ctx.of = (((a ^ b) & (a ^ r) & 0x80000000u) != 0);
}

void runtime_set_sbb_flags(cpu_state& ctx, uint32_t a, uint32_t b, bool carry_in, uint32_t r) {
    uint64_t carry = carry_in ? 1ull : 0ull;
    uint64_t subtrahend = uint64_t(b) + carry;
    uint32_t bb = uint32_t(subtrahend);
    ctx.cf = uint64_t(a) < subtrahend;
    ctx.pf = even_parity8(r);
    ctx.af = ((a ^ bb ^ r) & 0x10u) != 0;
    ctx.zf = r == 0;
    ctx.sf = (r & 0x80000000u) != 0;
    ctx.of = (((a ^ bb) & (a ^ r) & 0x80000000u) != 0);
}

void runtime_set_logic_flags(cpu_state& ctx, uint32_t r) {
    ctx.cf = false;
    ctx.of = false;
    ctx.af = false;
    ctx.pf = even_parity8(r);
    ctx.zf = r == 0;
    ctx.sf = (r & 0x80000000u) != 0;
}

const char* runtime_event_name(RuntimeEventKind kind) {
    switch (kind) {
    case RuntimeEventKind::MemoryFault: return "memory_fault";
    case RuntimeEventKind::MissingDirectCall: return "missing_direct_call";
    case RuntimeEventKind::MissingImportShim: return "missing_import_shim";
    case RuntimeEventKind::ImportAbiMismatch: return "import_abi_mismatch";
    case RuntimeEventKind::UnresolvedIndirectCall: return "unresolved_indirect_call";
    case RuntimeEventKind::UnresolvedIndirectJump: return "unresolved_indirect_jump";
    case RuntimeEventKind::PatchTrap: return "patch_trap";
    case RuntimeEventKind::Unsupported: return "unsupported";
    case RuntimeEventKind::UnresolvedJump: return "unresolved_jump";
    case RuntimeEventKind::UnsupportedSideEffect: return "unsupported_side_effect";
    }
    return "unknown";
}

std::string format_runtime_events(const runtime_context& rt) {
    std::ostringstream o;
    o << "runtime_events: " << rt.events.size() << "\n";
    for (const auto& event : rt.events) {
        o << "runtime_event: kind=" << runtime_event_name(event.kind)
          << " va=0x" << std::uppercase << std::hex << std::setw(8) << std::setfill('0') << event.va;
        if (event.aux) o << " aux=0x" << std::setw(8) << event.aux;
        if (!event.symbol.empty()) o << " symbol=" << event.symbol;
        o << "\n";
    }
    return o.str();
}

}
