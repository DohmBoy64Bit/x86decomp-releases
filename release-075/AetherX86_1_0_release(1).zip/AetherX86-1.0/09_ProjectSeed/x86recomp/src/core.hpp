#pragma once
#include <cstdint>
#include <filesystem>
#include <string>
#include <utility>
#include <vector>
namespace xr {
enum class OperandKind{None,Reg,Imm,Mem,Rel};
enum class IrOp{Nop,Move,Movzx,Movsx,Lea,Xchg,Inc,Dec,Not,Neg,Add,Adc,Or,And,Sub,Sbb,Xor,Cmp,Test,Shl,Shr,Sar,Rol,Ror,Setcc,Cmovcc,Push,Pop,Leave,Call,IndirectCall,Jump,IndirectJump,Branch,Return,Unsupported};
enum class FlagState{Unchanged,Defined,Cleared,Undefined};
enum class CfgEdgeKind{Fallthrough,BranchTaken,CallTarget,IndirectCall,IndirectJump,Return,Unresolved};
enum class PatchKind{Replace,BeforeHook,AfterHook,SkipOriginal,ImportShim,IndirectImportShim,Trap};
struct Operand{
    OperandKind kind=OperandKind::None;
    uint8_t width=0,reg=0,base=0,index=0,scale=1;
    bool has_base=false,has_index=false,has_disp=false;
    int32_t disp=0;
    uint32_t imm=0,target=0;
};
struct Ins{uint32_t a;std::vector<uint8_t>b;std::string m,o,d;std::vector<Operand> operands;uint32_t t=0;bool ok=true;};
struct CpuFlags{bool cf=false,pf=false,af=false,zf=false,sf=false,of=false;};
struct IrFlagEffects{
    FlagState cf=FlagState::Unchanged,pf=FlagState::Unchanged,af=FlagState::Unchanged;
    FlagState zf=FlagState::Unchanged,sf=FlagState::Unchanged,of=FlagState::Unchanged;
    std::vector<std::string> reads;
};
struct IrInst{
    uint32_t address=0,target=0;
    uint8_t width=0;
    std::vector<uint8_t> bytes;
    IrOp op=IrOp::Unsupported;
    std::string mnemonic,condition,diagnostic;
    std::vector<Operand> operands;
    IrFlagEffects flags;
    bool ok=true;
};
struct CfgEdge{CfgEdgeKind kind=CfgEdgeKind::Unresolved;uint32_t from=0,to=0;std::string detail;};
struct CfgBlock{
    uint32_t start=0,end=0;
    std::vector<IrInst> instructions;
    std::vector<CfgEdge> edges;
    bool exits=false,has_unsupported=false;
};
struct CfgFunction{
    uint32_t entry=0,range_start=0,range_end=0;
    std::vector<CfgBlock> blocks;
    std::vector<uint32_t> direct_call_targets;
    std::vector<uint32_t> indirect_call_sites;
    std::vector<uint32_t> indirect_jump_sites;
    std::vector<std::string> diagnostics;
};
struct PatchRecord{
    PatchKind kind=PatchKind::Replace;
    uint32_t va=0;
    std::string symbol,abi,reason,evidence,rollback;
    bool enabled=true;
    uint32_t iat_va=0,iat_rva=0,callsite_rva=0;
    std::string dll,side_effects;
};
struct PatchManifest{std::vector<PatchRecord> records;};
struct EntryImportShimRecord{
    uint32_t iat_va=0,iat_rva=0,callsite_va=0,callsite_rva=0;
    bool has_iat_va=false,has_iat_rva=false,has_callsite_va=false,has_callsite_rva=false,enabled=true;
    std::string dll,symbol,abi,side_effects,evidence,rollback;
};
struct EntryImportShimManifest{std::vector<EntryImportShimRecord> records;};
struct RuntimeInitImportPointerRecord{
    uint32_t iat_va=0,iat_rva=0,shim_target_va=0;
    bool has_iat_va=false,has_iat_rva=false,has_shim_target_va=false,enabled=true;
    std::string dll,symbol,abi,side_effects,evidence,rollback;
};
struct RuntimeInitManifest{
    std::string image_path;
    uint32_t image_base=0;
    uint64_t file_hash=0;
    std::vector<RuntimeInitImportPointerRecord> import_pointers;
};
struct ImportBindingRecord{
    std::string dll,symbol,abi,side_effects,evidence,rollback;
    uint32_t iat_va=0,iat_rva=0,callsite_va=0,callsite_rva=0,shim_target_va=0;
    bool has_callsite=false,has_runtime_init=false,enabled=true;
};
struct ImportBindingSummary{
    std::vector<ImportBindingRecord> bindings;
    std::vector<std::string> diagnostics;
};
struct RuntimeStartArgumentRecord{uint32_t offset=0,value=0,size=4;};
struct RuntimeStartManifest{
    uint32_t entry_va=0,stack_base=0,stack_size=0,initial_esp=0;
    bool has_entry_va=false,enabled=true;
    std::string expected_abi,evidence,rollback;
    std::vector<RuntimeStartArgumentRecord> arguments;
};
struct FunctionPackManifestFunction{
    uint32_t va=0,rva=0,size=0;
    bool has_va=false,has_rva=false,enabled=true;
    std::string source,confidence,section,evidence,rollback;
};
struct FunctionPackManifest{
    std::string image_path;
    uint32_t image_base=0;
    uint64_t file_hash=0;
    std::vector<FunctionPackManifestFunction> functions;
};
struct GhidraFunctionBoundary{
    uint32_t va=0,rva=0,size=0;
    bool has_va=false,has_rva=false,has_size=false,enabled=true;
    std::string name,source_tool,confidence,evidence,verifier;
};
struct GhidraBoundaryImport{std::vector<GhidraFunctionBoundary> functions;};
struct PeDataDirectory{uint32_t rva=0,size=0;};
struct PeSection{std::string name;uint32_t virtual_size=0,virtual_address=0,raw_size=0,raw_ptr=0,characteristics=0;};
struct PeImportFunction{std::string name;uint16_t hint=0;uint16_t ordinal=0;uint32_t iat_rva=0;bool by_ordinal=false;};
struct PeImportDll{std::string name;uint32_t descriptor_rva=0,first_thunk_rva=0,original_first_thunk_rva=0;std::vector<PeImportFunction> functions;};
struct PeDelayImportDll{std::string name;uint32_t descriptor_rva=0,iat_rva=0,import_name_table_rva=0;std::vector<PeImportFunction> functions;};
struct PeExport{std::string name,forwarder;uint16_t ordinal=0;uint32_t rva=0;};
struct PeRelocationBlock{uint32_t page_rva=0,block_size=0,entry_count=0;};
struct PeTlsInfo{bool present=false;uint32_t start_raw=0,end_raw=0,index_rva=0,callbacks_rva=0,size_zero_fill=0,characteristics=0;};
struct PeIssue{std::string code,detail;};
struct PeInfo{
    uint16_t machine=0,section_count=0,optional_magic=0,subsystem=0,dll_characteristics=0;
    uint8_t linker_major=0,linker_minor=0;
    uint32_t timestamp=0,image_base=0,entrypoint_rva=0,section_alignment=0,file_alignment=0,size_of_image=0,size_of_headers=0,checksum=0,overlay_size=0;
    uint64_t fnv1a64=0;
    std::vector<PeDataDirectory> directories;
    std::vector<PeSection> sections;
    std::vector<PeImportDll> imports;
    std::vector<PeDelayImportDll> delay_imports;
    std::vector<PeExport> exports;
    std::vector<PeRelocationBlock> relocations;
    PeTlsInfo tls;
    std::vector<PeIssue> issues;
};
struct OpcodeHistogram{uint64_t total=0,supported=0,unsupported=0;std::vector<std::pair<uint8_t,uint64_t>> unsupported_opcodes;};
struct PeSliceAnalysis{
    uint32_t rva=0,va=0,size=0,file_offset=0;
    std::string section_name;
    uint64_t instructions=0,supported=0,unsupported=0,unsupported_ir=0;
    bool cfg_complete=false,generated_candidate=false;
    std::vector<std::pair<uint8_t,uint64_t>> unsupported_opcodes;
    CfgFunction cfg;
};
struct FunctionCatalogEntry{
    uint32_t entry_va=0,entry_rva=0;
    std::string source,confidence,section,kind,evidence,symbol;
};
struct FunctionCatalog{std::vector<FunctionCatalogEntry> entries;};

struct PeLoadedImage{
    PeInfo info;
    uint32_t preferred_base=0,mapped_base=0,relocation_delta=0;
    uint64_t file_hash=0;
    std::vector<uint8_t> image;
    uint32_t headers_copied=0,sections_mapped=0;
    uint32_t reloc_abs=0,reloc_highlow=0,reloc_unsupported=0,reloc_out_of_range=0;
    bool ok=true;
    std::vector<std::string> diagnostics;
};
struct PeImportApplyResult{
    bool ok=true;
    uint32_t name_imports=0,ordinal_imports=0,delay_name_imports=0,delay_ordinal_imports=0;
    uint32_t applied_iat_writes=0,missing_bindings=0,duplicate_bindings=0,unmapped_iat=0;
    std::vector<std::string> diagnostics;
};
std::vector<uint8_t> parse_hex(const std::string&);
std::vector<Ins> decode(const std::vector<uint8_t>&,uint32_t);
std::string lift_text(const std::vector<Ins>&);
std::vector<IrInst> lift_ir(const std::vector<Ins>&);
std::string format_ir(const std::vector<IrInst>&);
CpuFlags flags_add(uint32_t,uint32_t,uint8_t);
CpuFlags flags_adc(uint32_t,uint32_t,uint8_t,bool);
CpuFlags flags_sub(uint32_t,uint32_t,uint8_t);
CpuFlags flags_sbb(uint32_t,uint32_t,uint8_t,bool);
CpuFlags flags_inc(uint32_t,uint8_t,bool);
CpuFlags flags_dec(uint32_t,uint8_t,bool);
CpuFlags flags_logic(uint32_t,uint8_t);
CfgFunction build_cfg(const std::vector<uint8_t>&,uint32_t,uint32_t);
std::string format_cfg(const CfgFunction&);
std::string emit_cfg_c(const CfgFunction&);
std::string emit_cfg_c(const CfgFunction&,const PatchManifest&);
std::string emit_cfg_c_pack(const std::vector<CfgFunction>&,const PatchManifest& = PatchManifest{});
std::string format_generated_dispatch_table(const std::vector<CfgFunction>&);
std::vector<std::string> validate_patch_manifest(const PatchManifest&);
std::string format_patch_manifest(const PatchManifest&);
PatchManifest parse_patch_manifest_text(const std::string&);
PatchManifest load_patch_manifest(const std::filesystem::path&);
EntryImportShimManifest parse_entry_import_shim_manifest_text(const std::string&);
EntryImportShimManifest load_entry_import_shim_manifest(const std::filesystem::path&);
std::vector<std::string> validate_entry_import_shim_manifest(const EntryImportShimManifest&);
std::string format_entry_import_shim_manifest(const EntryImportShimManifest&);
PatchManifest patch_manifest_from_entry_import_shims(const EntryImportShimManifest&);
RuntimeInitManifest parse_runtime_init_manifest_text(const std::string&);
RuntimeInitManifest load_runtime_init_manifest(const std::filesystem::path&);
std::vector<std::string> validate_runtime_init_manifest(const RuntimeInitManifest&,uint32_t mapped_base=0,uint32_t mapped_size=0);
std::string format_runtime_init_manifest(const RuntimeInitManifest&,uint32_t mapped_base=0,uint32_t mapped_size=0);
ImportBindingSummary resolve_import_bindings(const PeInfo&,const EntryImportShimManifest&,const RuntimeInitManifest&);
std::string format_import_bindings(const ImportBindingSummary&);
PeLoadedImage map_pe_image(const std::filesystem::path&,uint32_t mapped_base=0);
std::string format_pe_loaded_image(const PeLoadedImage&);
PeImportApplyResult apply_imports_to_loaded_image(PeLoadedImage&,const RuntimeInitManifest&);
std::string format_pe_import_apply_result(const PeImportApplyResult&);
RuntimeStartManifest parse_runtime_start_manifest_text(const std::string&);
RuntimeStartManifest load_runtime_start_manifest(const std::filesystem::path&);
std::vector<std::string> validate_runtime_start_manifest(const RuntimeStartManifest&);
std::string format_runtime_start_manifest(const RuntimeStartManifest&);
FunctionPackManifest parse_function_pack_manifest_text(const std::string&);
FunctionPackManifest load_function_pack_manifest(const std::filesystem::path&);
std::vector<std::string> validate_function_pack_manifest(const FunctionPackManifest&);
std::string format_function_pack_manifest(const FunctionPackManifest&);
std::vector<CfgFunction> build_function_pack_from_manifest(const FunctionPackManifest&);
std::string emit_cfg_c_pack_manifest(const FunctionPackManifest&);
GhidraBoundaryImport parse_ghidra_boundary_import_text(const std::string&);
GhidraBoundaryImport load_ghidra_boundary_import(const std::filesystem::path&);
std::vector<std::string> validate_ghidra_boundary_import(const GhidraBoundaryImport&,const PeInfo&);
std::string format_ghidra_boundary_import(const GhidraBoundaryImport&,const PeInfo&);
FunctionPackManifest function_pack_manifest_from_ghidra(const std::filesystem::path&,const GhidraBoundaryImport&);
std::string emit_cfg_c_pack_ghidra(const std::filesystem::path&,const GhidraBoundaryImport&);
std::string emit_c(const std::vector<Ins>&);
PeInfo inspect_pe_info(const std::filesystem::path&);
std::string format_pe_summary(const PeInfo&);
std::string format_pe_json(const PeInfo&);
std::string format_pe_image_map_summary(const PeInfo&);
std::string inspect_pe(const std::filesystem::path&);
OpcodeHistogram unsupported_opcode_histogram(const std::filesystem::path&);
std::string format_opcode_histogram(const OpcodeHistogram&);
PeSliceAnalysis analyze_pe_slice(const std::filesystem::path&,uint32_t,uint32_t);
std::string format_pe_slice_analysis(const PeSliceAnalysis&);
FunctionCatalog build_function_catalog(const PeInfo&);
FunctionCatalog build_function_catalog(const PeInfo&,const CfgFunction&,const PatchManifest&);
FunctionCatalog build_function_catalog(const PeInfo&,const GhidraBoundaryImport&);
std::string format_function_catalog(const FunctionCatalog&);
}
