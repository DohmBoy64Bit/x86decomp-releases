#include "core.hpp"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <map>
#include <sstream>
#include <stdexcept>

namespace xr {
namespace {

std::vector<uint8_t> read_binary(const std::filesystem::path& p) {
    std::ifstream f(p, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open file");
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)), {});
}

uint16_t rd16(const std::vector<uint8_t>& b, size_t off) {
    if (off + 2 > b.size()) throw std::runtime_error("truncated u16");
    return uint16_t(b[off] | (uint16_t(b[off + 1]) << 8));
}

uint32_t rd32(const std::vector<uint8_t>& b, size_t off) {
    if (off + 4 > b.size()) throw std::runtime_error("truncated u32");
    return uint32_t(b[off]) | (uint32_t(b[off + 1]) << 8) |
           (uint32_t(b[off + 2]) << 16) | (uint32_t(b[off + 3]) << 24);
}

void wr32(std::vector<uint8_t>& b, size_t off, uint32_t value) {
    if (off + 4 > b.size()) throw std::runtime_error("truncated write u32");
    b[off] = uint8_t(value & 0xffu);
    b[off + 1] = uint8_t((value >> 8) & 0xffu);
    b[off + 2] = uint8_t((value >> 16) & 0xffu);
    b[off + 3] = uint8_t((value >> 24) & 0xffu);
}

std::string hex32(uint32_t value) {
    std::ostringstream o;
    o << "0x" << std::uppercase << std::hex << std::setw(8) << std::setfill('0') << value;
    return o.str();
}

std::string hex64(uint64_t value) {
    std::ostringstream o;
    o << "0x" << std::uppercase << std::hex << std::setw(16) << std::setfill('0') << value;
    return o.str();
}

std::string lower(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) { return char(std::tolower(c)); });
    return value;
}

bool rva_in_section_local(const PeSection& section, uint32_t rva) {
    uint32_t size = std::max(section.virtual_size, section.raw_size);
    if (!size) return false;
    return rva >= section.virtual_address && uint64_t(rva) < uint64_t(section.virtual_address) + size;
}

size_t rva_to_file_local(const std::vector<PeSection>& sections, uint32_t rva) {
    for (const auto& section : sections) {
        if (!rva_in_section_local(section, rva)) continue;
        uint64_t delta = uint64_t(rva) - section.virtual_address;
        uint64_t off = uint64_t(section.raw_ptr) + delta;
        if (off > SIZE_MAX) break;
        return static_cast<size_t>(off);
    }
    throw std::runtime_error("rva not mapped");
}

bool rva_range_in_image(const PeLoadedImage& loaded, uint32_t rva, uint32_t size) {
    return uint64_t(rva) + uint64_t(size) <= loaded.image.size();
}

std::string import_key(const std::string& dll, const std::string& symbol) {
    return lower(dll) + "!" + lower(symbol);
}

void add_diag(bool hard, std::vector<std::string>& diagnostics, bool& ok, const std::string& text) {
    diagnostics.push_back(text);
    if (hard) ok = false;
}

} // namespace

PeLoadedImage map_pe_image(const std::filesystem::path& p, uint32_t requested_base) {
    PeLoadedImage loaded;
    loaded.info = inspect_pe_info(p);
    loaded.preferred_base = loaded.info.image_base;
    loaded.mapped_base = requested_base ? requested_base : loaded.info.image_base;
    loaded.file_hash = loaded.info.fnv1a64;
    loaded.relocation_delta = loaded.mapped_base - loaded.info.image_base;
    auto file = read_binary(p);
    auto issue = [&](const std::string& text) { add_diag(true, loaded.diagnostics, loaded.ok, text); };

    if (!loaded.info.size_of_image) issue("invalid size_of_image");
    if (!loaded.mapped_base) issue("invalid mapped base");
    if (!loaded.ok) return loaded;

    loaded.image.assign(loaded.info.size_of_image, 0);
    uint32_t header_copy = std::min<uint32_t>(loaded.info.size_of_headers, uint32_t(file.size()));
    if (header_copy > loaded.image.size()) header_copy = uint32_t(loaded.image.size());
    std::copy_n(file.begin(), header_copy, loaded.image.begin());
    loaded.headers_copied = header_copy;

    for (const auto& section : loaded.info.sections) {
        uint32_t mapped_size = std::max(section.virtual_size, section.raw_size);
        if (!mapped_size) {
            issue("section " + section.name + " empty mapped size");
            continue;
        }
        if (uint64_t(section.virtual_address) + mapped_size > loaded.image.size()) {
            issue("section " + section.name + " exceeds image");
            continue;
        }
        if (section.raw_size) {
            if (uint64_t(section.raw_ptr) + section.raw_size > file.size()) {
                issue("section " + section.name + " raw data truncated");
                continue;
            }
            std::copy_n(file.begin() + section.raw_ptr, section.raw_size,
                        loaded.image.begin() + section.virtual_address);
        }
        ++loaded.sections_mapped;
    }
    if (!loaded.ok) return loaded;

    if (loaded.relocation_delta != 0) {
        if (loaded.info.directories.size() <= 5 || !loaded.info.directories[5].rva || !loaded.info.directories[5].size) {
            issue("mapped base differs from preferred base but relocation directory is absent");
            return loaded;
        }
        const auto& dir = loaded.info.directories[5];
        size_t off = rva_to_file_local(loaded.info.sections, dir.rva);
        size_t end = off + dir.size;
        if (end > file.size()) issue("relocation directory truncated");
        while (loaded.ok && off + 8 <= end) {
            uint32_t page_rva = rd32(file, off);
            uint32_t block_size = rd32(file, off + 4);
            if (!page_rva && !block_size) break;
            if (block_size < 8 || off + block_size > end) {
                issue("malformed relocation block");
                break;
            }
            size_t entries = (block_size - 8) / 2;
            for (size_t i = 0; i < entries; ++i) {
                uint16_t entry = rd16(file, off + 8 + i * 2);
                uint16_t type = uint16_t(entry >> 12);
                uint16_t rel_off = uint16_t(entry & 0x0fffu);
                if (type == 0) {
                    ++loaded.reloc_abs;
                    continue;
                }
                uint32_t patch_rva = page_rva + rel_off;
                if (!rva_range_in_image(loaded, patch_rva, 4)) {
                    ++loaded.reloc_out_of_range;
                    add_diag(true, loaded.diagnostics, loaded.ok, "relocation outside image at rva=" + hex32(patch_rva));
                    continue;
                }
                if (type == 3) {
                    uint32_t original = rd32(loaded.image, patch_rva);
                    wr32(loaded.image, patch_rva, original + loaded.relocation_delta);
                    ++loaded.reloc_highlow;
                } else {
                    ++loaded.reloc_unsupported;
                    add_diag(true, loaded.diagnostics, loaded.ok,
                             "unsupported relocation type " + std::to_string(type) + " at rva=" + hex32(patch_rva));
                }
            }
            off += block_size;
        }
    }
    return loaded;
}

std::string format_pe_loaded_image(const PeLoadedImage& loaded) {
    std::ostringstream o;
    o << "pe_loaded_image_ok: " << (loaded.ok ? "true" : "false") << "\n"
      << "pe_loaded_image_preferred_base: " << hex32(loaded.preferred_base) << "\n"
      << "pe_loaded_image_mapped_base: " << hex32(loaded.mapped_base) << "\n"
      << "pe_loaded_image_relocation_delta: " << hex32(loaded.relocation_delta) << "\n"
      << "pe_loaded_image_size: " << loaded.image.size() << "\n"
      << "pe_loaded_image_file_hash: " << hex64(loaded.file_hash) << "\n"
      << "pe_loaded_image_headers_copied: " << loaded.headers_copied << "\n"
      << "pe_loaded_image_sections_mapped: " << loaded.sections_mapped << "\n"
      << "pe_loaded_image_reloc_abs: " << loaded.reloc_abs << "\n"
      << "pe_loaded_image_reloc_highlow: " << loaded.reloc_highlow << "\n"
      << "pe_loaded_image_reloc_unsupported: " << loaded.reloc_unsupported << "\n"
      << "pe_loaded_image_reloc_out_of_range: " << loaded.reloc_out_of_range << "\n"
      << "pe_loaded_image_diagnostics: " << loaded.diagnostics.size() << "\n";
    for (const auto& diagnostic : loaded.diagnostics) o << "pe_loaded_image_diagnostic: " << diagnostic << "\n";
    return o.str();
}

PeImportApplyResult apply_imports_to_loaded_image(PeLoadedImage& loaded, const RuntimeInitManifest& manifest) {
    PeImportApplyResult result;
    auto issue = [&](const std::string& text) { add_diag(true, result.diagnostics, result.ok, text); };
    if (!loaded.ok) issue("loaded image is not valid");
    auto manifest_issues = validate_runtime_init_manifest(manifest, loaded.mapped_base, uint32_t(loaded.image.size()));
    for (const auto& text : manifest_issues) issue("runtime init manifest: " + text);
    if (!result.ok) return result;

    std::map<std::string, const RuntimeInitImportPointerRecord*> bindings;
    for (const auto& record : manifest.import_pointers) {
        if (!record.enabled) continue;
        std::string key = import_key(record.dll, record.symbol);
        if (!bindings.emplace(key, &record).second) {
            ++result.duplicate_bindings;
            issue("duplicate binding " + record.dll + "!" + record.symbol);
        }
    }
    if (!result.ok) return result;

    auto apply_one = [&](const std::string& dll_name, const PeImportFunction& fn, bool delay) {
        if (fn.by_ordinal) {
            if (delay) ++result.delay_ordinal_imports;
            else ++result.ordinal_imports;
            issue("ordinal import requires explicit non-name policy: " + dll_name + "!#" + std::to_string(fn.ordinal));
            return;
        }
        if (delay) ++result.delay_name_imports;
        else ++result.name_imports;
        auto it = bindings.find(import_key(dll_name, fn.name));
        if (it == bindings.end()) {
            ++result.missing_bindings;
            issue("missing import binding: " + dll_name + "!" + fn.name);
            return;
        }
        uint32_t rva = it->second->has_iat_rva ? it->second->iat_rva : (it->second->iat_va - loaded.mapped_base);
        if (rva != fn.iat_rva) {
            issue("IAT mismatch for " + dll_name + "!" + fn.name + ": manifest=" + hex32(rva) + " pe=" + hex32(fn.iat_rva));
            return;
        }
        if (!rva_range_in_image(loaded, fn.iat_rva, 4)) {
            ++result.unmapped_iat;
            issue("IAT outside loaded image for " + dll_name + "!" + fn.name);
            return;
        }
        wr32(loaded.image, fn.iat_rva, it->second->shim_target_va);
        ++result.applied_iat_writes;
    };

    for (const auto& dll : loaded.info.imports) {
        for (const auto& fn : dll.functions) apply_one(dll.name, fn, false);
    }
    for (const auto& dll : loaded.info.delay_imports) {
        for (const auto& fn : dll.functions) apply_one(dll.name, fn, true);
    }
    return result;
}

std::string format_pe_import_apply_result(const PeImportApplyResult& result) {
    std::ostringstream o;
    o << "pe_import_apply_ok: " << (result.ok ? "true" : "false") << "\n"
      << "pe_import_apply_name_imports: " << result.name_imports << "\n"
      << "pe_import_apply_ordinal_imports: " << result.ordinal_imports << "\n"
      << "pe_import_apply_delay_name_imports: " << result.delay_name_imports << "\n"
      << "pe_import_apply_delay_ordinal_imports: " << result.delay_ordinal_imports << "\n"
      << "pe_import_apply_iat_writes: " << result.applied_iat_writes << "\n"
      << "pe_import_apply_missing_bindings: " << result.missing_bindings << "\n"
      << "pe_import_apply_duplicate_bindings: " << result.duplicate_bindings << "\n"
      << "pe_import_apply_unmapped_iat: " << result.unmapped_iat << "\n"
      << "pe_import_apply_diagnostics: " << result.diagnostics.size() << "\n";
    for (const auto& diagnostic : result.diagnostics) o << "pe_import_apply_diagnostic: " << diagnostic << "\n";
    return o.str();
}

} // namespace xr
