#include "core.hpp"

#include <iostream>
#include <stdexcept>
#include <string>

static uint32_t parse_u32_arg(const char* text) {
    std::string s = text;
    size_t pos = 0;
    unsigned long value = std::stoul(s, &pos, 0);
    if (pos != s.size() || value > 0xfffffffful) throw std::runtime_error("invalid u32 argument");
    return static_cast<uint32_t>(value);
}

static xr::PatchRecord patch_record(xr::PatchKind kind, uint32_t va, std::string symbol,
                                    std::string abi = "cdecl") {
    xr::PatchRecord patch;
    patch.kind = kind;
    patch.va = va;
    patch.symbol = std::move(symbol);
    patch.abi = std::move(abi);
    patch.reason = "synthetic phase5 CLI smoke fixture";
    patch.evidence = "user-provided hex bytes, not target binary evidence";
    patch.rollback = "drop this CLI fixture record";
    return patch;
}

static xr::PatchManifest demo_patch_manifest() {
    xr::PatchManifest manifest;
    manifest.records.push_back(patch_record(xr::PatchKind::Replace, 0x401000, "demo_replace"));
    manifest.records.push_back(patch_record(xr::PatchKind::BeforeHook, 0x401000, "demo_before"));
    manifest.records.push_back(patch_record(xr::PatchKind::AfterHook, 0x401000, "demo_after"));
    manifest.records.push_back(patch_record(xr::PatchKind::SkipOriginal, 0x401000, "demo_skip"));
    manifest.records.push_back(patch_record(xr::PatchKind::ImportShim, 0x401006, "demo_import_shim", "stdcall"));
    return manifest;
}

static xr::PatchManifest demo_indirect_import_manifest() {
    xr::PatchManifest manifest;
    manifest.records.push_back(patch_record(xr::PatchKind::IndirectImportShim, 0x401000,
                                            "demo_indirect_import_shim", "stdcall"));
    return manifest;
}

static void usage() {
    std::cerr << "usage: x86recomp inspect <pe>|inspect-json <pe>|format-pe-image-map <pe>|unsupported-histogram <pe>|analyze-pe-slice <pe> <rva> <size>|"
              << "function-catalog <pe>|function-catalog-slice <pe> <rva> <size> [manifest]|function-catalog-ghidra <pe> <manifest>|"
              << "map-pe-image <pe> [mapped_base]|apply-pe-imports <pe> <runtime_init_manifest> [mapped_base]|"
              << "lift-raw <hex>|lift-ir-raw <hex>|cfg-raw <hex>|emit-cfg-c-raw <hex>|"
              << "emit-cfg-c-pack-raw <hex> [hex...]|format-generated-dispatch-raw <hex> [hex...]|"
              << "emit-cfg-c-pack-slices <pe> <rva> <size> [rva size...]|"
              << "emit-cfg-c-pack-manifest <manifest>|emit-cfg-c-pack-ghidra <pe> <manifest>|"
              << "emit-cfg-c-patched-raw <hex>|emit-cfg-c-indirect-import-raw <hex>|"
              << "emit-cfg-c-entry-import-raw <hex> <manifest>|emit-cfg-c-pack-entry-import-raw <manifest> <hex> [hex...]|"
              << "emit-cfg-c-manifest-raw <hex> <manifest>|format-patch-manifest <manifest>|"
              << "format-entry-import-shims <manifest>|format-function-pack-manifest <manifest>|"
              << "format-runtime-init <manifest> [mapped_base mapped_size]|"
              << "format-import-bindings <pe> <entry_import_manifest> <runtime_init_manifest>|"
              << "format-runtime-start <manifest>|"
              << "format-ghidra-boundaries <pe> <manifest>|emit-c-raw <hex>\n";
}

int main(int argc, char** argv) {
    try {
        if (argc < 3) {
            usage();
            return 2;
        }
        std::string cmd = argv[1];
        if (cmd == "inspect") {
            std::cout << xr::inspect_pe(argv[2]);
        } else if (cmd == "inspect-json") {
            std::cout << xr::format_pe_json(xr::inspect_pe_info(argv[2]));
        } else if (cmd == "format-pe-image-map") {
            std::cout << xr::format_pe_image_map_summary(xr::inspect_pe_info(argv[2]));
        } else if (cmd == "unsupported-histogram") {
            std::cout << xr::format_opcode_histogram(xr::unsupported_opcode_histogram(argv[2]));
        } else if (cmd == "analyze-pe-slice") {
            if (argc < 5) {
                usage();
                return 2;
            }
            std::cout << xr::format_pe_slice_analysis(
                xr::analyze_pe_slice(argv[2], parse_u32_arg(argv[3]), parse_u32_arg(argv[4])));
        } else if (cmd == "function-catalog") {
            std::cout << xr::format_function_catalog(xr::build_function_catalog(xr::inspect_pe_info(argv[2])));
        } else if (cmd == "function-catalog-slice") {
            if (argc < 5) {
                usage();
                return 2;
            }
            auto info = xr::inspect_pe_info(argv[2]);
            auto slice = xr::analyze_pe_slice(argv[2], parse_u32_arg(argv[3]), parse_u32_arg(argv[4]));
            xr::PatchManifest manifest;
            if (argc >= 6) manifest = xr::load_patch_manifest(argv[5]);
            std::cout << xr::format_function_catalog(xr::build_function_catalog(info, slice.cfg, manifest));
        } else if (cmd == "function-catalog-ghidra") {
            if (argc < 4) {
                usage();
                return 2;
            }
            auto info = xr::inspect_pe_info(argv[2]);
            std::cout << xr::format_function_catalog(xr::build_function_catalog(info, xr::load_ghidra_boundary_import(argv[3])));
        } else if (cmd == "map-pe-image") {
            uint32_t mapped_base = 0;
            if (argc >= 4) mapped_base = parse_u32_arg(argv[3]);
            std::cout << xr::format_pe_loaded_image(xr::map_pe_image(argv[2], mapped_base));
        } else if (cmd == "apply-pe-imports") {
            if (argc < 4) {
                usage();
                return 2;
            }
            uint32_t mapped_base = 0;
            if (argc >= 5) mapped_base = parse_u32_arg(argv[4]);
            auto loaded = xr::map_pe_image(argv[2], mapped_base);
            std::cout << xr::format_pe_loaded_image(loaded);
            std::cout << xr::format_pe_import_apply_result(
                xr::apply_imports_to_loaded_image(loaded, xr::load_runtime_init_manifest(argv[3])));
        } else if (cmd == "lift-raw") {
            std::cout << xr::lift_text(xr::decode(xr::parse_hex(argv[2]), 0x401000));
        } else if (cmd == "lift-ir-raw") {
            std::cout << xr::format_ir(xr::lift_ir(xr::decode(xr::parse_hex(argv[2]), 0x401000)));
        } else if (cmd == "cfg-raw") {
            std::cout << xr::format_cfg(xr::build_cfg(xr::parse_hex(argv[2]), 0x401000, 0x401000));
        } else if (cmd == "emit-cfg-c-raw") {
            std::cout << xr::emit_cfg_c(xr::build_cfg(xr::parse_hex(argv[2]), 0x401000, 0x401000));
        } else if (cmd == "emit-cfg-c-pack-raw") {
            std::vector<xr::CfgFunction> cfgs;
            for (int i = 2; i < argc; ++i) {
                uint32_t base = 0x401000u + static_cast<uint32_t>(i - 2) * 0x1000u;
                cfgs.push_back(xr::build_cfg(xr::parse_hex(argv[i]), base, base));
            }
            std::cout << xr::emit_cfg_c_pack(cfgs);
        } else if (cmd == "format-generated-dispatch-raw") {
            std::vector<xr::CfgFunction> cfgs;
            for (int i = 2; i < argc; ++i) {
                uint32_t base = 0x401000u + static_cast<uint32_t>(i - 2) * 0x1000u;
                cfgs.push_back(xr::build_cfg(xr::parse_hex(argv[i]), base, base));
            }
            std::cout << xr::format_generated_dispatch_table(cfgs);
        } else if (cmd == "emit-cfg-c-pack-slices") {
            if (argc < 5 || ((argc - 3) % 2) != 0) {
                usage();
                return 2;
            }
            std::vector<xr::CfgFunction> cfgs;
            for (int i = 3; i < argc; i += 2) {
                auto slice = xr::analyze_pe_slice(argv[2], parse_u32_arg(argv[i]), parse_u32_arg(argv[i + 1]));
                if (!slice.generated_candidate) {
                    throw std::runtime_error("slice is not a generated candidate");
                }
                cfgs.push_back(slice.cfg);
            }
            std::cout << xr::emit_cfg_c_pack(cfgs);
        } else if (cmd == "emit-cfg-c-pack-manifest") {
            std::cout << xr::emit_cfg_c_pack_manifest(xr::load_function_pack_manifest(argv[2]));
        } else if (cmd == "emit-cfg-c-pack-ghidra") {
            if (argc < 4) {
                usage();
                return 2;
            }
            std::cout << xr::emit_cfg_c_pack_ghidra(argv[2], xr::load_ghidra_boundary_import(argv[3]));
        } else if (cmd == "emit-cfg-c-patched-raw") {
            std::cout << xr::emit_cfg_c(xr::build_cfg(xr::parse_hex(argv[2]), 0x401000, 0x401000),
                                        demo_patch_manifest());
        } else if (cmd == "emit-cfg-c-indirect-import-raw") {
            std::cout << xr::emit_cfg_c(xr::build_cfg(xr::parse_hex(argv[2]), 0x401000, 0x401000),
                                        demo_indirect_import_manifest());
        } else if (cmd == "emit-cfg-c-manifest-raw") {
            if (argc < 4) {
                usage();
                return 2;
            }
            std::cout << xr::emit_cfg_c(xr::build_cfg(xr::parse_hex(argv[2]), 0x401000, 0x401000),
                                        xr::load_patch_manifest(argv[3]));
        } else if (cmd == "emit-cfg-c-entry-import-raw") {
            if (argc < 4) {
                usage();
                return 2;
            }
            std::cout << xr::emit_cfg_c(
                xr::build_cfg(xr::parse_hex(argv[2]), 0x401000, 0x401000),
                xr::patch_manifest_from_entry_import_shims(xr::load_entry_import_shim_manifest(argv[3])));
        } else if (cmd == "emit-cfg-c-pack-entry-import-raw") {
            if (argc < 4) {
                usage();
                return 2;
            }
            std::vector<xr::CfgFunction> cfgs;
            for (int i = 3; i < argc; ++i) {
                uint32_t base = 0x401000u + static_cast<uint32_t>(i - 3) * 0x1000u;
                cfgs.push_back(xr::build_cfg(xr::parse_hex(argv[i]), base, base));
            }
            std::cout << xr::emit_cfg_c_pack(
                cfgs, xr::patch_manifest_from_entry_import_shims(xr::load_entry_import_shim_manifest(argv[2])));
        } else if (cmd == "format-patch-manifest") {
            std::cout << xr::format_patch_manifest(xr::load_patch_manifest(argv[2]));
        } else if (cmd == "format-entry-import-shims") {
            std::cout << xr::format_entry_import_shim_manifest(xr::load_entry_import_shim_manifest(argv[2]));
        } else if (cmd == "format-function-pack-manifest") {
            std::cout << xr::format_function_pack_manifest(xr::load_function_pack_manifest(argv[2]));
        } else if (cmd == "format-runtime-init") {
            uint32_t mapped_base = 0;
            uint32_t mapped_size = 0;
            if (argc >= 5) {
                mapped_base = parse_u32_arg(argv[3]);
                mapped_size = parse_u32_arg(argv[4]);
            }
            std::cout << xr::format_runtime_init_manifest(xr::load_runtime_init_manifest(argv[2]),
                                                           mapped_base, mapped_size);
        } else if (cmd == "format-import-bindings") {
            if (argc < 5) {
                usage();
                return 2;
            }
            std::cout << xr::format_import_bindings(xr::resolve_import_bindings(
                xr::inspect_pe_info(argv[2]),
                xr::load_entry_import_shim_manifest(argv[3]),
                xr::load_runtime_init_manifest(argv[4])));
        } else if (cmd == "format-runtime-start") {
            std::cout << xr::format_runtime_start_manifest(xr::load_runtime_start_manifest(argv[2]));
        } else if (cmd == "format-ghidra-boundaries") {
            if (argc < 4) {
                usage();
                return 2;
            }
            std::cout << xr::format_ghidra_boundary_import(xr::load_ghidra_boundary_import(argv[3]),
                                                           xr::inspect_pe_info(argv[2]));
        } else if (cmd == "emit-c-raw") {
            std::cout << xr::emit_c(xr::decode(xr::parse_hex(argv[2]), 0x401000));
        } else {
            usage();
            return 2;
        }
    } catch (std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    }
}
