#include "runtime.hpp"

#include <algorithm>
#include <cctype>

namespace xr {
namespace {

std::string lower_symbol(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) { return char(std::tolower(c)); });
    return value;
}

bool symbol_is_get_version_ex_a(const std::string& symbol) {
    std::string s = lower_symbol(symbol);
    return s == "getversionexa" || s == "kernel32.dll!getversionexa" || s == "kernel32!getversionexa";
}

} // namespace

bool runtime_win32_get_version_ex_a(runtime_context& rt, cpu_state& ctx, uint32_t, const char*) {
    uint32_t out_va = 0;
    if (!runtime_read32(rt, ctx.esp + 4, out_va)) return false;
    uint32_t size = 0;
    if (!runtime_read32(rt, out_va, size)) return false;
    if (size < 20) return false;
    if (!runtime_write32(rt, out_va + 4, 5)) return false;    // dwMajorVersion
    if (!runtime_write32(rt, out_va + 8, 1)) return false;    // dwMinorVersion
    if (!runtime_write32(rt, out_va + 12, 2600)) return false; // dwBuildNumber
    if (!runtime_write32(rt, out_va + 16, 2)) return false;   // dwPlatformId = VER_PLATFORM_WIN32_NT
    ctx.eax = 1;
    return true;
}

runtime_callback runtime_win32_builtin_callback(const std::string& symbol) {
    if (symbol_is_get_version_ex_a(symbol)) return runtime_win32_get_version_ex_a;
    return nullptr;
}

bool runtime_apply_builtin_import_pointer_init(runtime_context& rt, const runtime_import_pointer_init& init) {
    runtime_import_pointer_init resolved = init;
    if (!resolved.callback) resolved.callback = runtime_win32_builtin_callback(resolved.symbol);
    return runtime_apply_import_pointer_init(rt, resolved);
}

} // namespace xr
