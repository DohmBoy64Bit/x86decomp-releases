#include "core.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <deque>
#include <fstream>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>

using namespace std;

namespace xr {
static string hx(uint32_t v) {
    ostringstream o;
    o << "0x" << uppercase << hex << setw(8) << setfill('0') << v;
    return o.str();
}

static string hx16(uint16_t v) {
    ostringstream o;
    o << "0x" << uppercase << hex << setw(4) << setfill('0') << v;
    return o.str();
}

static void need(const vector<uint8_t>& b, size_t i, size_t n, const char* w) {
    if (i > b.size() || n > b.size() - i) throw runtime_error(string("truncated ") + w);
}

static uint16_t u16(const vector<uint8_t>& b, size_t i) {
    need(b, i, 2, "u16");
    return uint16_t(b[i] | (b[i + 1] << 8));
}

static uint32_t u32(const vector<uint8_t>& b, size_t i) {
    need(b, i, 4, "u32");
    return uint32_t(b[i]) | (uint32_t(b[i + 1]) << 8) |
           (uint32_t(b[i + 2]) << 16) | (uint32_t(b[i + 3]) << 24);
}

static int8_t s8(const vector<uint8_t>& b, size_t i) {
    need(b, i, 1, "s8");
    return static_cast<int8_t>(b[i]);
}

static int32_t s32(const vector<uint8_t>& b, size_t i) {
    return static_cast<int32_t>(u32(b, i));
}

static string reg(int x, uint8_t width = 32) {
    const char* r32[] = {"eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi"};
    const char* r16[] = {"ax", "cx", "dx", "bx", "sp", "bp", "si", "di"};
    const char* r8[] = {"al", "cl", "dl", "bl", "ah", "ch", "dh", "bh"};
    if (width == 8) return r8[x & 7];
    if (width == 16) return r16[x & 7];
    return r32[x & 7];
}

static Operand reg_op(uint8_t r, uint8_t width = 32) {
    Operand op;
    op.kind = OperandKind::Reg;
    op.width = width;
    op.reg = r;
    return op;
}

static Operand imm_op(uint32_t value, uint8_t width = 32) {
    Operand op;
    op.kind = OperandKind::Imm;
    op.width = width;
    op.imm = value;
    return op;
}

static Operand rel_op(uint32_t target, uint8_t width) {
    Operand op;
    op.kind = OperandKind::Rel;
    op.width = width;
    op.target = target;
    return op;
}

static Operand abs_mem_op(uint32_t address, uint8_t width = 32) {
    Operand op;
    op.kind = OperandKind::Mem;
    op.width = width;
    op.has_disp = true;
    op.disp = static_cast<int32_t>(address);
    return op;
}

static string fmt_disp(int32_t disp) {
    if (disp < 0) {
        ostringstream o;
        o << "- 0x" << uppercase << hex << uint32_t(-disp);
        return o.str();
    }
    ostringstream o;
    o << "+ 0x" << uppercase << hex << uint32_t(disp);
    return o.str();
}

static string fmt_operand(const Operand& op) {
    switch (op.kind) {
    case OperandKind::Reg:
        return reg(op.reg, op.width);
    case OperandKind::Imm:
        return hx(op.imm);
    case OperandKind::Rel:
        return hx(op.target);
    case OperandKind::Mem: {
        ostringstream o;
        o << "[";
        bool wrote = false;
        if (op.has_base) {
            o << reg(op.base);
            wrote = true;
        }
        if (op.has_index) {
            if (wrote) o << " + ";
            o << reg(op.index);
            if (op.scale != 1) o << "*" << unsigned(op.scale);
            wrote = true;
        }
        if (op.has_disp) {
            if (wrote) o << " " << fmt_disp(op.disp);
            else if (op.disp < 0) o << "-0x" << uppercase << hex << uint32_t(-op.disp);
            else o << hx(uint32_t(op.disp));
            wrote = true;
        }
        if (!wrote) o << "0";
        o << "]";
        return o.str();
    }
    case OperandKind::None:
        break;
    }
    return "";
}

static string fmt_operands(const vector<Operand>& ops) {
    ostringstream o;
    for (size_t i = 0; i < ops.size(); ++i) {
        if (i) o << ", ";
        o << fmt_operand(ops[i]);
    }
    return o.str();
}

struct ModRMDecode {
    uint8_t mod = 0, reg = 0, rm = 0;
    size_t size = 0;
    Operand reg_operand;
    Operand rm_operand;
};

static ModRMDecode decode_modrm(const vector<uint8_t>& b, size_t pos, uint8_t width = 32) {
    need(b, pos, 1, "modrm");
    uint8_t m = b[pos];
    ModRMDecode out;
    out.mod = uint8_t((m >> 6) & 3);
    out.reg = uint8_t((m >> 3) & 7);
    out.rm = uint8_t(m & 7);
    out.size = 1;
    out.reg_operand = reg_op(out.reg, width);
    if (out.mod == 3) {
        out.rm_operand = reg_op(out.rm, width);
        return out;
    }

    Operand mem;
    mem.kind = OperandKind::Mem;
    mem.width = width;
    size_t p = pos + 1;
    if (out.rm == 4) {
        need(b, p, 1, "sib");
        uint8_t sib = b[p++];
        out.size++;
        uint8_t scale_bits = uint8_t((sib >> 6) & 3);
        uint8_t index = uint8_t((sib >> 3) & 7);
        uint8_t base = uint8_t(sib & 7);
        mem.scale = uint8_t(1u << scale_bits);
        if (index != 4) {
            mem.has_index = true;
            mem.index = index;
        }
        if (!(out.mod == 0 && base == 5)) {
            mem.has_base = true;
            mem.base = base;
        }
        if (out.mod == 0 && base == 5) {
            mem.has_disp = true;
            mem.disp = s32(b, p);
            p += 4;
            out.size += 4;
        }
    } else if (out.mod == 0 && out.rm == 5) {
        mem.has_disp = true;
        mem.disp = s32(b, p);
        p += 4;
        out.size += 4;
    } else {
        mem.has_base = true;
        mem.base = out.rm;
    }

    if (out.mod == 1) {
        mem.has_disp = true;
        mem.disp = s8(b, p);
        p += 1;
        out.size += 1;
    } else if (out.mod == 2) {
        mem.has_disp = true;
        mem.disp = s32(b, p);
        p += 4;
        out.size += 4;
    }
    out.rm_operand = mem;
    return out;
}

static string jcc_name(uint8_t cc) {
    const char* names[] = {"jo", "jno", "jb", "jae", "je", "jne", "jbe", "ja",
                           "js", "jns", "jp", "jnp", "jl", "jge", "jle", "jg"};
    return names[cc & 0xf];
}

static string setcc_name(uint8_t cc) {
    const char* names[] = {"seto", "setno", "setb", "setae", "sete", "setne", "setbe", "seta",
                           "sets", "setns", "setp", "setnp", "setl", "setge", "setle", "setg"};
    return names[cc & 0xf];
}

static string cmovcc_name(uint8_t cc) {
    const char* names[] = {"cmovo", "cmovno", "cmovb", "cmovae", "cmove", "cmovne", "cmovbe", "cmova",
                           "cmovs", "cmovns", "cmovp", "cmovnp", "cmovl", "cmovge", "cmovle", "cmovg"};
    return names[cc & 0xf];
}

static string group2_name(uint8_t subop) {
    const char* names[] = {"rol", "ror", "rcl", "rcr", "shl", "shr", "sal", "sar"};
    return names[subop & 7];
}

static string group1_name(uint8_t subop) {
    const char* names[] = {"add", "or", "adc", "sbb", "and", "sub", "xor", "cmp"};
    return names[subop & 7];
}

static string cstr(const vector<uint8_t>& d, size_t off, const char* w) {
    need(d, off, 1, w);
    size_t end = off;
    while (end < d.size() && d[end]) ++end;
    if (end == d.size()) throw runtime_error(string("unterminated ") + w);
    return string(reinterpret_cast<const char*>(&d[off]), end - off);
}

static string json_escape(const string& s) {
    ostringstream o;
    for (unsigned char c : s) {
        switch (c) {
        case '\\': o << "\\\\"; break;
        case '"': o << "\\\""; break;
        case '\n': o << "\\n"; break;
        case '\r': o << "\\r"; break;
        case '\t': o << "\\t"; break;
        default:
            if (c < 0x20) {
                o << "\\u" << hex << uppercase << setw(4) << setfill('0') << unsigned(c);
            } else {
                o << char(c);
            }
        }
    }
    return o.str();
}

static string section_name(const vector<uint8_t>& d, size_t off) {
    need(d, off, 8, "section name");
    array<char, 9> n{};
    for (size_t i = 0; i < 8 && d[off + i]; ++i) n[i] = char(d[off + i]);
    return string(n.data());
}

static bool rva_in_section(const PeSection& s, uint32_t rva) {
    uint32_t span = max(s.virtual_size, s.raw_size);
    return span && rva >= s.virtual_address && rva - s.virtual_address < span;
}

static bool rva_in_range(uint32_t rva, uint32_t start, uint32_t size) {
    return size && rva >= start && rva - start < size;
}

static size_t rva_to_file(const vector<PeSection>& secs, uint32_t rva) {
    for (const auto& s : secs) {
        if (rva_in_section(s, rva)) {
            uint32_t delta = rva - s.virtual_address;
            if (delta >= s.raw_size) throw runtime_error("rva outside raw section data");
            return size_t(s.raw_ptr) + delta;
        }
    }
    throw runtime_error("rva not mapped " + hx(rva));
}

static vector<uint8_t> read_file(const filesystem::path& p) {
    ifstream f(p, ios::binary);
    if (!f) throw runtime_error("open failed");
    return vector<uint8_t>((istreambuf_iterator<char>(f)), {});
}

static uint64_t fnv1a64(const vector<uint8_t>& d) {
    uint64_t h = 14695981039346656037ull;
    for (uint8_t b : d) {
        h ^= b;
        h *= 1099511628211ull;
    }
    return h;
}

static string hx64(uint64_t v) {
    ostringstream o;
    o << "0x" << uppercase << hex << setw(16) << setfill('0') << v;
    return o.str();
}

static string bytes_to_ascii(const vector<uint8_t>& d, size_t off, size_t n) {
    if (off >= d.size()) return "";
    n = min(n, d.size() - off);
    string s;
    s.reserve(n);
    for (size_t i = 0; i < n; ++i) s.push_back(char(d[off + i]));
    return s;
}

static bool contains_bytes(const vector<uint8_t>& d, const string& needle) {
    if (needle.empty() || d.size() < needle.size()) return false;
    return search(d.begin(), d.end(), needle.begin(), needle.end()) != d.end();
}

vector<uint8_t> parse_hex(const string& s) {
    vector<uint8_t> r;
    int hi = -1;
    for (char c : s) {
        int v = (c >= '0' && c <= '9') ? c - '0' :
                (c >= 'a' && c <= 'f') ? c - 'a' + 10 :
                (c >= 'A' && c <= 'F') ? c - 'A' + 10 : -1;
        if (v < 0) continue;
        if (hi < 0) hi = v;
        else {
            r.push_back(uint8_t((hi << 4) | v));
            hi = -1;
        }
    }
    if (hi >= 0) throw runtime_error("odd hex");
    return r;
}

vector<Ins> decode(const vector<uint8_t>& b, uint32_t base) {
    vector<Ins> v;
    for (size_t i = 0; i < b.size();) {
        Ins n;
        n.a = base + uint32_t(i);
        auto take = [&](size_t k) {
            n.b.assign(b.begin() + i, b.begin() + i + k);
            i += k;
        };
        auto unsupported = [&](size_t k, const string& why, uint8_t op_byte) {
            size_t safe_k = min(k, b.size() - i);
            take(safe_k ? safe_k : 1);
            n.ok = false;
            n.m = "db";
            n.o = hx(op_byte);
            n.d = why;
        };
        size_t start = i;
        uint8_t width = 32;
        bool operand_size_prefix = false;
        while (i < b.size() && b[i] == 0x66) {
            operand_size_prefix = true;
            width = 16;
            ++i;
        }
        if (i >= b.size()) {
            i = start;
            uint8_t op = b[i];
            unsupported(1, "truncated prefix", op);
            v.push_back(n);
            continue;
        }
        uint8_t op = b[i];
        auto take_insn = [&](size_t end) {
            n.b.assign(b.begin() + start, b.begin() + end);
            i = end;
        };
        if (op == 0x90) {
            take_insn(i + 1); n.m = "nop";
        } else if (op == 0xC3) {
            take_insn(i + 1); n.m = "ret";
        } else if (op == 0xC2) {
            try {
                uint32_t imm = u16(b, i + 1);
                take_insn(i + 3);
                n.m = "ret"; n.operands = {imm_op(imm, 16)}; n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0xC9) {
            take_insn(i + 1); n.m = "leave";
        } else if (op >= 0x40 && op <= 0x47) {
            take_insn(i + 1); n.m = "inc"; n.operands = {reg_op(uint8_t(op - 0x40), width)}; n.o = fmt_operands(n.operands);
        } else if (op >= 0x48 && op <= 0x4F) {
            take_insn(i + 1); n.m = "dec"; n.operands = {reg_op(uint8_t(op - 0x48), width)}; n.o = fmt_operands(n.operands);
        } else if (op >= 0x50 && op <= 0x57) {
            take_insn(i + 1); n.m = "push"; n.operands = {reg_op(uint8_t(op - 0x50), width)}; n.o = fmt_operands(n.operands);
        } else if (op >= 0x58 && op <= 0x5F) {
            take_insn(i + 1); n.m = "pop"; n.operands = {reg_op(uint8_t(op - 0x58), width)}; n.o = fmt_operands(n.operands);
        } else if (op == 0x68) {
            try {
                uint32_t imm = width == 16 ? u16(b, i + 1) : u32(b, i + 1);
                take_insn(i + 1 + (width == 16 ? 2 : 4));
                n.m = "push"; n.operands = {imm_op(imm, width)}; n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0x6A) {
            try {
                uint32_t imm = width == 16 ? uint32_t(uint16_t(int16_t(s8(b, i + 1))))
                                           : uint32_t(int32_t(s8(b, i + 1)));
                take_insn(i + 2);
                n.m = "push"; n.operands = {imm_op(imm, width)}; n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0xA0 || op == 0xA1 || op == 0xA2 || op == 0xA3) {
            try {
                uint8_t op_width = (op == 0xA0 || op == 0xA2) ? 8 : width;
                uint32_t addr = u32(b, i + 1);
                take_insn(i + 5);
                n.m = "mov";
                if (op == 0xA0 || op == 0xA1) n.operands = {reg_op(0, op_width), abs_mem_op(addr, op_width)};
                else n.operands = {abs_mem_op(addr, op_width), reg_op(0, op_width)};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0x88 || op == 0x89 || op == 0x8A || op == 0x8B || op == 0x8D) {
            try {
                uint8_t op_width = (op == 0x88 || op == 0x8A) ? 8 : width;
                auto m = decode_modrm(b, i + 1, op_width);
                take_insn(i + 1 + m.size);
                if (op == 0x8D && m.rm_operand.kind != OperandKind::Mem) {
                    n.ok = false;
                    n.d = "lea source must be memory";
                }
                n.m = op == 0x8D ? "lea" : "mov";
                if (op == 0x88 || op == 0x89) n.operands = {m.rm_operand, m.reg_operand};
                else n.operands = {m.reg_operand, m.rm_operand};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0x87) {
            try {
                auto m = decode_modrm(b, i + 1, width);
                take_insn(i + 1 + m.size);
                n.m = "xchg";
                n.operands = {m.rm_operand, m.reg_operand};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op >= 0xB0 && op <= 0xB7) {
            try {
                uint32_t imm = uint8_t(s8(b, i + 1));
                take_insn(i + 2);
                n.m = "mov"; n.operands = {reg_op(uint8_t(op - 0xB0), 8), imm_op(imm, 8)}; n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op >= 0xB8 && op <= 0xBF && i + (width == 16 ? 2 : 4) < b.size()) {
            uint32_t imm = width == 16 ? u16(b, i + 1) : u32(b, i + 1);
            take_insn(i + 1 + (width == 16 ? 2 : 4));
            n.m = "mov"; n.operands = {reg_op(uint8_t(op - 0xB8), width), imm_op(imm, width)}; n.o = fmt_operands(n.operands);
        } else if (op >= 0xB8 && op <= 0xBF) {
            i = start;
            unsupported(1, "truncated imm32", op);
        } else if (op == 0x04 || op == 0x05 || op == 0x0C || op == 0x0D || op == 0x14 || op == 0x15 ||
                   op == 0x1C || op == 0x1D || op == 0x24 || op == 0x25 || op == 0x2C || op == 0x2D ||
                   op == 0x34 || op == 0x35 || op == 0x3C || op == 0x3D) {
            try {
                bool imm8 = (op & 1u) == 0;
                uint8_t op_width = imm8 ? 8 : width;
                uint32_t imm = imm8 ? uint8_t(s8(b, i + 1)) : (width == 16 ? u16(b, i + 1) : u32(b, i + 1));
                take_insn(i + 1 + (imm8 ? 1 : (width == 16 ? 2 : 4)));
                uint8_t group = uint8_t((op >> 3) & 7);
                n.m = group1_name(group);
                n.operands = {reg_op(0, op_width), imm_op(imm, op_width)};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if ((op >= 0x00 && op <= 0x3B && op != 0x0F && (op & 0x06u) != 0x04u) || op == 0x84 || op == 0x85) {
            try {
                uint8_t op_width = ((op & 1u) == 0 || op == 0x84) ? 8 : width;
                auto m = decode_modrm(b, i + 1, op_width);
                take_insn(i + 1 + m.size);
                uint8_t family = op == 0x84 || op == 0x85 ? 8 : uint8_t((op >> 3) & 7);
                if (family == 0) n.m = "add";
                else if (family == 1) n.m = "or";
                else if (family == 2) n.m = "adc";
                else if (family == 3) n.m = "sbb";
                else if (family == 4) n.m = "and";
                else if (family == 5) n.m = "sub";
                else if (family == 6) n.m = "xor";
                else if (family == 7) n.m = "cmp";
                else n.m = "test";
                if ((op & 0x02u) != 0 && family != 8) n.operands = {m.reg_operand, m.rm_operand};
                else n.operands = {m.rm_operand, m.reg_operand};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0x80 || op == 0x81 || op == 0x83) {
            try {
                auto m = decode_modrm(b, i + 1, op == 0x80 ? 8 : width);
                size_t imm_off = i + 1 + m.size;
                uint32_t imm = 0;
                if (op == 0x80) {
                    imm = uint8_t(s8(b, imm_off));
                    take_insn(imm_off + 1);
                } else if (op == 0x81) {
                    imm = width == 16 ? u16(b, imm_off) : u32(b, imm_off);
                    take_insn(imm_off + (width == 16 ? 2 : 4));
                } else {
                    imm = uint32_t(int32_t(s8(b, imm_off)));
                    take_insn(imm_off + 1);
                }
                n.m = group1_name(m.reg);
                n.operands = {m.rm_operand, imm_op(imm, op == 0x80 || op == 0x83 ? 8 : width)};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0xC1 || op == 0xD1 || op == 0xD3) {
            try {
                auto m = decode_modrm(b, i + 1, width);
                uint8_t subop = m.reg;
                size_t operand_end = i + 1 + m.size;
                Operand count = imm_op(1, 8);
                if (op == 0xC1) {
                    uint8_t imm = uint8_t(s8(b, operand_end));
                    count = imm_op(imm, 8);
                    operand_end += 1;
                } else if (op == 0xD3) {
                    count = reg_op(1, 8);
                }
                take_insn(operand_end);
                n.m = group2_name(subop);
                if (subop == 2 || subop == 3 || subop == 6) {
                    n.ok = false;
                    n.d = "unsupported group2 subop";
                }
                n.operands = {m.rm_operand, count};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0xF6 || op == 0xF7) {
            try {
                uint8_t op_width = op == 0xF6 ? 8 : width;
                auto m = decode_modrm(b, i + 1, op_width);
                size_t operand_end = i + 1 + m.size;
                if (m.reg == 0 || m.reg == 1) operand_end += op == 0xF6 ? 1 : (width == 16 ? 2 : 4);
                take_insn(operand_end);
                if (m.reg == 2) n.m = "not";
                else if (m.reg == 3) n.m = "neg";
                else {
                    n.ok = false;
                    n.m = "db";
                    n.d = "unsupported group3 subop";
                }
                n.operands = {m.rm_operand};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0xC6 || op == 0xC7) {
            try {
                uint8_t op_width = op == 0xC6 ? 8 : width;
                auto m = decode_modrm(b, i + 1, op_width);
                size_t imm_off = i + 1 + m.size;
                uint32_t imm = op == 0xC6 ? uint8_t(s8(b, imm_off)) : (width == 16 ? u16(b, imm_off) : u32(b, imm_off));
                take_insn(imm_off + (op == 0xC6 ? 1 : (width == 16 ? 2 : 4)));
                if (m.reg == 0) {
                    n.m = "mov";
                    n.operands = {m.rm_operand, imm_op(imm, op_width)};
                    n.o = fmt_operands(n.operands);
                } else {
                    n.ok = false;
                    n.m = "db";
                    n.d = "unsupported group11 subop";
                    n.operands = {m.rm_operand};
                    n.o = fmt_operands(n.operands);
                }
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0xFF) {
            try {
                auto m = decode_modrm(b, i + 1, width);
                take_insn(i + 1 + m.size);
                if (m.reg == 0) n.m = "inc";
                else if (m.reg == 1) n.m = "dec";
                else if (m.reg == 2) n.m = "call";
                else if (m.reg == 4) n.m = "jmp";
                else if (m.reg == 6) n.m = "push";
                else {
                    n.ok = false;
                    n.m = "db";
                    n.d = "unsupported group5 subop";
                }
                n.operands = {m.rm_operand};
                n.o = fmt_operands(n.operands);
            } catch (const runtime_error& e) {
                i = start;
                unsupported(1, e.what(), op);
            }
        } else if (op == 0xE8 || op == 0xE9) {
            if (i + 4 < b.size()) {
                int32_t rel = s32(b, i + 1);
                uint32_t target = uint32_t(n.a + 5 + rel);
                take_insn(i + 5);
                n.m = op == 0xE8 ? "call" : "jmp";
                n.t = target;
                n.operands = {rel_op(target, 32)};
                n.o = fmt_operands(n.operands);
            } else {
                i = start;
                unsupported(1, "truncated rel32", op);
            }
        } else if (op == 0xEB) {
            if (i + 1 < b.size()) {
                int8_t rel = s8(b, i + 1);
                uint32_t target = uint32_t(n.a + 2 + rel);
                take_insn(i + 2);
                n.m = "jmp";
                n.t = target;
                n.operands = {rel_op(target, 8)};
                n.o = fmt_operands(n.operands);
            } else {
                i = start;
                unsupported(1, "truncated rel8", op);
            }
        } else if (op >= 0x70 && op <= 0x7F) {
            if (i + 1 < b.size()) {
                int8_t rel = s8(b, i + 1);
                uint32_t target = uint32_t(n.a + 2 + rel);
                take_insn(i + 2);
                n.m = jcc_name(uint8_t(op - 0x70));
                n.t = target;
                n.operands = {rel_op(target, 8)};
                n.o = fmt_operands(n.operands);
            } else {
                i = start;
                unsupported(1, "truncated jcc rel8", op);
            }
        } else if (op == 0x0F) {
            if (i + 1 < b.size() && b[i + 1] >= 0x80 && b[i + 1] <= 0x8F) {
                if (i + 5 < b.size()) {
                    uint8_t cc = uint8_t(b[i + 1] - 0x80);
                    int32_t rel = s32(b, i + 2);
                    uint32_t target = uint32_t(n.a + 6 + rel);
                    take_insn(i + 6);
                    n.m = jcc_name(cc);
                    n.t = target;
                    n.operands = {rel_op(target, 32)};
                    n.o = fmt_operands(n.operands);
                } else {
                    i = start;
                    unsupported(2, "truncated jcc rel32", op);
                }
            } else if (i + 1 < b.size() && b[i + 1] >= 0x40 && b[i + 1] <= 0x4F) {
                try {
                    uint8_t ext_op = b[i + 1];
                    auto m = decode_modrm(b, i + 2, width);
                    take_insn(i + 2 + m.size);
                    n.m = cmovcc_name(uint8_t(ext_op - 0x40));
                    n.operands = {reg_op(m.reg, width), m.rm_operand};
                    n.o = fmt_operands(n.operands);
                } catch (const runtime_error& e) {
                    i = start;
                    unsupported(2, e.what(), op);
                }
            } else if (i + 1 < b.size() && b[i + 1] >= 0x90 && b[i + 1] <= 0x9F) {
                try {
                    uint8_t ext_op = b[i + 1];
                    auto m = decode_modrm(b, i + 2, 8);
                    take_insn(i + 2 + m.size);
                    n.m = setcc_name(uint8_t(ext_op - 0x90));
                    n.operands = {m.rm_operand};
                    n.o = fmt_operands(n.operands);
                } catch (const runtime_error& e) {
                    i = start;
                    unsupported(2, e.what(), op);
                }
            } else if (i + 1 < b.size() && (b[i + 1] == 0xB6 || b[i + 1] == 0xB7 ||
                                            b[i + 1] == 0xBE || b[i + 1] == 0xBF)) {
                try {
                    uint8_t ext_op = b[i + 1];
                    uint8_t src_width = (ext_op == 0xB6 || ext_op == 0xBE) ? 8 : 16;
                    auto m = decode_modrm(b, i + 2, src_width);
                    take_insn(i + 2 + m.size);
                    n.m = (ext_op == 0xB6 || ext_op == 0xB7) ? "movzx" : "movsx";
                    n.operands = {reg_op(m.reg, width), m.rm_operand};
                    n.o = fmt_operands(n.operands);
                } catch (const runtime_error& e) {
                    i = start;
                    unsupported(2, e.what(), op);
                }
            } else {
                i = start;
                unsupported(min<size_t>(2, b.size() - i), "unsupported two-byte opcode", op);
            }
        } else {
            i = start;
            unsupported(1, "unsupported", op);
        }
        v.push_back(n);
    }
    return v;
}

string lift_text(const vector<Ins>& is) {
    ostringstream o;
    for (auto& i : is) {
        o << hx(i.a) << ": " << (i.ok ? "" : "UNSUPPORTED ") << i.m
          << (i.o.empty() ? "" : " " + i.o)
          << (i.d.empty() ? "" : " ; " + i.d) << "\n";
    }
    return o.str();
}

static uint32_t width_mask(uint8_t width) {
    if (width == 8) return 0xffu;
    if (width == 16) return 0xffffu;
    return 0xffffffffu;
}

static uint32_t sign_bit(uint8_t width) {
    if (width == 8) return 0x80u;
    if (width == 16) return 0x8000u;
    return 0x80000000u;
}

static bool even_parity8(uint32_t value) {
    value &= 0xffu;
    bool even = true;
    while (value) {
        even = !even;
        value &= value - 1;
    }
    return even;
}

CpuFlags flags_add(uint32_t a, uint32_t b, uint8_t width) {
    uint32_t mask = width_mask(width);
    uint32_t sign = sign_bit(width);
    uint64_t full = uint64_t(a & mask) + uint64_t(b & mask);
    uint32_t r = uint32_t(full) & mask;
    CpuFlags f;
    f.cf = full > mask;
    f.pf = even_parity8(r);
    f.af = ((a ^ b ^ r) & 0x10u) != 0;
    f.zf = r == 0;
    f.sf = (r & sign) != 0;
    f.of = ((~(a ^ b) & (a ^ r) & sign) != 0);
    return f;
}

CpuFlags flags_adc(uint32_t a, uint32_t b, uint8_t width, bool carry_in) {
    uint32_t mask = width_mask(width);
    uint32_t sign = sign_bit(width);
    uint64_t carry = carry_in ? 1ull : 0ull;
    uint64_t full = uint64_t(a & mask) + uint64_t(b & mask) + carry;
    uint32_t bb = uint32_t((uint64_t(b & mask) + carry) & mask);
    uint32_t r = uint32_t(full) & mask;
    CpuFlags f;
    f.cf = full > mask;
    f.pf = even_parity8(r);
    f.af = ((a ^ bb ^ r) & 0x10u) != 0;
    f.zf = r == 0;
    f.sf = (r & sign) != 0;
    f.of = ((~(a ^ bb) & (a ^ r) & sign) != 0);
    return f;
}

CpuFlags flags_sub(uint32_t a, uint32_t b, uint8_t width) {
    uint32_t mask = width_mask(width);
    uint32_t sign = sign_bit(width);
    uint32_t aa = a & mask;
    uint32_t bb = b & mask;
    uint32_t r = (aa - bb) & mask;
    CpuFlags f;
    f.cf = aa < bb;
    f.pf = even_parity8(r);
    f.af = ((aa ^ bb ^ r) & 0x10u) != 0;
    f.zf = r == 0;
    f.sf = (r & sign) != 0;
    f.of = (((aa ^ bb) & (aa ^ r) & sign) != 0);
    return f;
}

CpuFlags flags_sbb(uint32_t a, uint32_t b, uint8_t width, bool carry_in) {
    uint32_t mask = width_mask(width);
    uint32_t sign = sign_bit(width);
    uint32_t aa = a & mask;
    uint64_t carry = carry_in ? 1ull : 0ull;
    uint64_t subtrahend = uint64_t(b & mask) + carry;
    uint32_t bb = uint32_t(subtrahend & mask);
    uint32_t r = (aa - bb) & mask;
    CpuFlags f;
    f.cf = uint64_t(aa) < subtrahend;
    f.pf = even_parity8(r);
    f.af = ((aa ^ bb ^ r) & 0x10u) != 0;
    f.zf = r == 0;
    f.sf = (r & sign) != 0;
    f.of = (((aa ^ bb) & (aa ^ r) & sign) != 0);
    return f;
}

CpuFlags flags_inc(uint32_t a, uint8_t width, bool carry_in) {
    CpuFlags f = flags_add(a, 1, width);
    f.cf = carry_in;
    return f;
}

CpuFlags flags_dec(uint32_t a, uint8_t width, bool carry_in) {
    CpuFlags f = flags_sub(a, 1, width);
    f.cf = carry_in;
    return f;
}

CpuFlags flags_logic(uint32_t result, uint8_t width) {
    uint32_t r = result & width_mask(width);
    CpuFlags f;
    f.cf = false;
    f.pf = even_parity8(r);
    f.af = false;
    f.zf = r == 0;
    f.sf = (r & sign_bit(width)) != 0;
    f.of = false;
    return f;
}

static void set_all_defined(IrFlagEffects& f) {
    f.cf = FlagState::Defined;
    f.pf = FlagState::Defined;
    f.af = FlagState::Defined;
    f.zf = FlagState::Defined;
    f.sf = FlagState::Defined;
    f.of = FlagState::Defined;
}

static void set_logic_flags(IrFlagEffects& f) {
    f.cf = FlagState::Cleared;
    f.pf = FlagState::Defined;
    f.af = FlagState::Undefined;
    f.zf = FlagState::Defined;
    f.sf = FlagState::Defined;
    f.of = FlagState::Cleared;
}

static void set_adc_sbb_flags(IrFlagEffects& f) {
    set_all_defined(f);
    f.reads.push_back("CF");
}

static void set_incdec_flags(IrFlagEffects& f) {
    f.cf = FlagState::Unchanged;
    f.pf = FlagState::Defined;
    f.af = FlagState::Defined;
    f.zf = FlagState::Defined;
    f.sf = FlagState::Defined;
    f.of = FlagState::Defined;
}

static void set_shift_flags(IrFlagEffects& f) {
    f.cf = FlagState::Defined;
    f.pf = FlagState::Defined;
    f.af = FlagState::Undefined;
    f.zf = FlagState::Defined;
    f.sf = FlagState::Defined;
    f.of = FlagState::Defined;
}

static void set_rotate_flags(IrFlagEffects& f) {
    f.cf = FlagState::Defined;
    f.of = FlagState::Defined;
}

static string condition_from_cc_suffix(const string& suffix) {
    if (suffix == "o") return "jo";
    if (suffix == "no") return "jno";
    if (suffix == "b") return "jb";
    if (suffix == "ae") return "jae";
    if (suffix == "e") return "je";
    if (suffix == "ne") return "jne";
    if (suffix == "be") return "jbe";
    if (suffix == "a") return "ja";
    if (suffix == "s") return "js";
    if (suffix == "ns") return "jns";
    if (suffix == "p") return "jp";
    if (suffix == "np") return "jnp";
    if (suffix == "l") return "jl";
    if (suffix == "ge") return "jge";
    if (suffix == "le") return "jle";
    if (suffix == "g") return "jg";
    return suffix;
}

static string condition_from_set_or_cmov(const string& mnemonic) {
    if (mnemonic.rfind("set", 0) == 0) return condition_from_cc_suffix(mnemonic.substr(3));
    if (mnemonic.rfind("cmov", 0) == 0) return condition_from_cc_suffix(mnemonic.substr(4));
    return mnemonic;
}

static vector<string> condition_reads(const string& cc) {
    if (cc == "jo" || cc == "jno") return {"OF"};
    if (cc == "jb" || cc == "jae") return {"CF"};
    if (cc == "je" || cc == "jne") return {"ZF"};
    if (cc == "jbe" || cc == "ja") return {"CF", "ZF"};
    if (cc == "js" || cc == "jns") return {"SF"};
    if (cc == "jp" || cc == "jnp") return {"PF"};
    if (cc == "jl" || cc == "jge") return {"SF", "OF"};
    if (cc == "jle" || cc == "jg") return {"ZF", "SF", "OF"};
    return {};
}

static IrOp ir_op_for(const Ins& ins) {
    if (!ins.ok) return IrOp::Unsupported;
    if (ins.m == "nop") return IrOp::Nop;
    if (ins.m == "mov") return IrOp::Move;
    if (ins.m == "movzx") return IrOp::Movzx;
    if (ins.m == "movsx") return IrOp::Movsx;
    if (ins.m == "lea") return IrOp::Lea;
    if (ins.m == "xchg") return IrOp::Xchg;
    if (ins.m == "inc") return IrOp::Inc;
    if (ins.m == "dec") return IrOp::Dec;
    if (ins.m == "not") return IrOp::Not;
    if (ins.m == "neg") return IrOp::Neg;
    if (ins.m == "add") return IrOp::Add;
    if (ins.m == "adc") return IrOp::Adc;
    if (ins.m == "or") return IrOp::Or;
    if (ins.m == "and") return IrOp::And;
    if (ins.m == "sub") return IrOp::Sub;
    if (ins.m == "sbb") return IrOp::Sbb;
    if (ins.m == "xor") return IrOp::Xor;
    if (ins.m == "cmp") return IrOp::Cmp;
    if (ins.m == "test") return IrOp::Test;
    if (ins.m == "shl") return IrOp::Shl;
    if (ins.m == "shr") return IrOp::Shr;
    if (ins.m == "sar") return IrOp::Sar;
    if (ins.m == "rol") return IrOp::Rol;
    if (ins.m == "ror") return IrOp::Ror;
    if (ins.m.rfind("set", 0) == 0) return IrOp::Setcc;
    if (ins.m.rfind("cmov", 0) == 0) return IrOp::Cmovcc;
    if (ins.m == "push") return IrOp::Push;
    if (ins.m == "pop") return IrOp::Pop;
    if (ins.m == "leave") return IrOp::Leave;
    if (ins.m == "call") return IrOp::Call;
    if (ins.m == "jmp") return IrOp::Jump;
    if (ins.m == "ret") return IrOp::Return;
    if (!ins.m.empty() && ins.m[0] == 'j') return IrOp::Branch;
    return IrOp::Unsupported;
}

static string ir_name(IrOp op) {
    switch (op) {
    case IrOp::Nop: return "nop";
    case IrOp::Move: return "move";
    case IrOp::Movzx: return "movzx";
    case IrOp::Movsx: return "movsx";
    case IrOp::Lea: return "lea";
    case IrOp::Xchg: return "xchg";
    case IrOp::Inc: return "inc";
    case IrOp::Dec: return "dec";
    case IrOp::Not: return "not";
    case IrOp::Neg: return "neg";
    case IrOp::Add: return "add";
    case IrOp::Adc: return "adc";
    case IrOp::Or: return "or";
    case IrOp::And: return "and";
    case IrOp::Sub: return "sub";
    case IrOp::Sbb: return "sbb";
    case IrOp::Xor: return "xor";
    case IrOp::Cmp: return "cmp";
    case IrOp::Test: return "test";
    case IrOp::Shl: return "shl";
    case IrOp::Shr: return "shr";
    case IrOp::Sar: return "sar";
    case IrOp::Rol: return "rol";
    case IrOp::Ror: return "ror";
    case IrOp::Setcc: return "setcc";
    case IrOp::Cmovcc: return "cmovcc";
    case IrOp::Push: return "push";
    case IrOp::Pop: return "pop";
    case IrOp::Leave: return "leave";
    case IrOp::Call: return "call";
    case IrOp::IndirectCall: return "indirect_call";
    case IrOp::Jump: return "jump";
    case IrOp::IndirectJump: return "indirect_jump";
    case IrOp::Branch: return "branch";
    case IrOp::Return: return "return";
    case IrOp::Unsupported: return "unsupported";
    }
    return "unsupported";
}

static uint8_t instruction_width(const Ins& ins) {
    for (const auto& op : ins.operands) {
        if (op.width) return op.width;
    }
    return 32;
}

vector<IrInst> lift_ir(const vector<Ins>& is) {
    vector<IrInst> out;
    out.reserve(is.size());
    for (const auto& ins : is) {
        IrInst ir;
        ir.address = ins.a;
        ir.target = ins.t;
        ir.bytes = ins.b;
        ir.mnemonic = ins.m;
        ir.operands = ins.operands;
        ir.diagnostic = ins.d;
        ir.ok = ins.ok;
        ir.width = instruction_width(ins);
        ir.op = ir_op_for(ins);
        switch (ir.op) {
        case IrOp::Inc:
        case IrOp::Dec:
            set_incdec_flags(ir.flags);
            break;
        case IrOp::Neg:
        case IrOp::Add:
            set_all_defined(ir.flags);
            break;
        case IrOp::Adc:
        case IrOp::Sbb:
            set_adc_sbb_flags(ir.flags);
            break;
        case IrOp::Sub:
        case IrOp::Cmp:
            set_all_defined(ir.flags);
            break;
        case IrOp::And:
        case IrOp::Or:
        case IrOp::Xor:
        case IrOp::Test:
            set_logic_flags(ir.flags);
            break;
        case IrOp::Shl:
        case IrOp::Shr:
        case IrOp::Sar:
            set_shift_flags(ir.flags);
            break;
        case IrOp::Rol:
        case IrOp::Ror:
            set_rotate_flags(ir.flags);
            break;
        case IrOp::Setcc:
        case IrOp::Cmovcc:
            ir.condition = condition_from_set_or_cmov(ins.m);
            ir.flags.reads = condition_reads(ir.condition);
            break;
        case IrOp::Branch:
            ir.condition = ins.m;
            ir.flags.reads = condition_reads(ins.m);
            break;
        case IrOp::Call:
            if (ir.operands.empty() || ir.operands[0].kind != OperandKind::Rel) {
                ir.op = IrOp::IndirectCall;
                ir.diagnostic = "unresolved indirect call requires runtime dispatch";
            }
            break;
        case IrOp::Jump:
            if (ir.operands.empty() || ir.operands[0].kind != OperandKind::Rel) {
                ir.op = IrOp::IndirectJump;
                ir.diagnostic = "unresolved indirect jump requires runtime dispatch";
            }
            break;
        case IrOp::Unsupported:
            ir.ok = false;
            if (ir.diagnostic.empty()) ir.diagnostic = "unsupported lifter opcode";
            break;
        default:
            break;
        }
        out.push_back(ir);
    }
    return out;
}

static string flag_state_name(FlagState state) {
    switch (state) {
    case FlagState::Unchanged: return "unchanged";
    case FlagState::Defined: return "defined";
    case FlagState::Cleared: return "cleared";
    case FlagState::Undefined: return "undefined";
    }
    return "unknown";
}

static string format_flag_effects(const IrFlagEffects& f) {
    bool any_write = f.cf != FlagState::Unchanged || f.pf != FlagState::Unchanged ||
                     f.af != FlagState::Unchanged || f.zf != FlagState::Unchanged ||
                     f.sf != FlagState::Unchanged || f.of != FlagState::Unchanged;
    ostringstream o;
    if (any_write) {
        o << "flags{CF=" << flag_state_name(f.cf)
          << ",PF=" << flag_state_name(f.pf)
          << ",AF=" << flag_state_name(f.af)
          << ",ZF=" << flag_state_name(f.zf)
          << ",SF=" << flag_state_name(f.sf)
          << ",OF=" << flag_state_name(f.of) << "}";
    }
    if (!f.reads.empty()) {
        if (any_write) o << " ";
        o << "reads{";
        for (size_t i = 0; i < f.reads.size(); ++i) {
            if (i) o << ",";
            o << f.reads[i];
        }
        o << "}";
    }
    if (!any_write && f.reads.empty()) o << "flags{unchanged}";
    return o.str();
}

string format_ir(const vector<IrInst>& irs) {
    ostringstream o;
    for (const auto& ir : irs) {
        o << hx(ir.address) << ": ir." << ir_name(ir.op);
        if (ir.width) o << ".i" << unsigned(ir.width);
        if (!ir.condition.empty()) o << "." << ir.condition;
        string ops = fmt_operands(ir.operands);
        if (!ops.empty()) o << " " << ops;
        if (ir.target && (ir.operands.empty() || ir.operands[0].kind != OperandKind::Rel)) o << " -> " << hx(ir.target);
        o << " ; " << format_flag_effects(ir.flags);
        if (!ir.ok && !ir.diagnostic.empty()) o << " ; " << ir.diagnostic;
        o << "\n";
    }
    return o.str();
}

static bool in_range(uint32_t va, uint32_t start, uint32_t end) {
    return va >= start && va < end;
}

static bool ends_block(IrOp op) {
    return op == IrOp::Jump || op == IrOp::IndirectJump || op == IrOp::Branch ||
           op == IrOp::Return || op == IrOp::Unsupported;
}

static uint32_t ir_end(const IrInst& ir) {
    return ir.address + uint32_t(ir.bytes.size());
}

static bool add_unique(vector<uint32_t>& values, uint32_t value) {
    if (find(values.begin(), values.end(), value) != values.end()) return false;
    values.push_back(value);
    return true;
}

static string edge_name(CfgEdgeKind kind) {
    switch (kind) {
    case CfgEdgeKind::Fallthrough: return "fallthrough";
    case CfgEdgeKind::BranchTaken: return "branch_taken";
    case CfgEdgeKind::CallTarget: return "call_target";
    case CfgEdgeKind::IndirectCall: return "indirect_call";
    case CfgEdgeKind::IndirectJump: return "indirect_jump";
    case CfgEdgeKind::Return: return "return";
    case CfgEdgeKind::Unresolved: return "unresolved";
    }
    return "unresolved";
}

static string patch_kind_name(PatchKind kind) {
    switch (kind) {
    case PatchKind::Replace: return "replace";
    case PatchKind::BeforeHook: return "before_hook";
    case PatchKind::AfterHook: return "after_hook";
    case PatchKind::SkipOriginal: return "skip_original";
    case PatchKind::ImportShim: return "import_shim";
    case PatchKind::IndirectImportShim: return "indirect_import_shim";
    case PatchKind::Trap: return "trap";
    }
    return "unknown";
}

static bool patch_kind_from_name(const string& name, PatchKind& kind) {
    if (name == "replace") kind = PatchKind::Replace;
    else if (name == "before_hook") kind = PatchKind::BeforeHook;
    else if (name == "after_hook") kind = PatchKind::AfterHook;
    else if (name == "skip_original") kind = PatchKind::SkipOriginal;
    else if (name == "import_shim") kind = PatchKind::ImportShim;
    else if (name == "indirect_import_shim") kind = PatchKind::IndirectImportShim;
    else if (name == "trap") kind = PatchKind::Trap;
    else return false;
    return true;
}

static vector<const PatchRecord*> patches_for(const PatchManifest& manifest, uint32_t va, PatchKind kind) {
    vector<const PatchRecord*> out;
    for (const auto& patch : manifest.records) {
        if (patch.enabled && patch.va == va && patch.kind == kind) out.push_back(&patch);
    }
    return out;
}

static string c_string(const string& s) {
    ostringstream o;
    o << '"';
    for (unsigned char c : s) {
        switch (c) {
        case '\\': o << "\\\\"; break;
        case '"': o << "\\\""; break;
        case '\n': o << "\\n"; break;
        case '\r': o << "\\r"; break;
        case '\t': o << "\\t"; break;
        default:
            if (c < 0x20) o << "\\x" << uppercase << hex << setw(2) << setfill('0') << unsigned(c);
            else o << char(c);
        }
    }
    o << '"';
    return o.str();
}

static string trim_copy(const string& s) {
    size_t first = 0;
    while (first < s.size() && isspace(static_cast<unsigned char>(s[first]))) ++first;
    size_t last = s.size();
    while (last > first && isspace(static_cast<unsigned char>(s[last - 1]))) --last;
    return s.substr(first, last - first);
}

static vector<string> split_manifest_tokens(const string& line) {
    vector<string> tokens;
    string current;
    bool quoted = false;
    for (char c : line) {
        if (c == '"') {
            quoted = !quoted;
            continue;
        }
        if (!quoted && isspace(static_cast<unsigned char>(c))) {
            if (!current.empty()) {
                tokens.push_back(current);
                current.clear();
            }
            continue;
        }
        current.push_back(c);
    }
    if (quoted) throw runtime_error("unterminated quote in manifest line");
    if (!current.empty()) tokens.push_back(current);
    return tokens;
}

static uint32_t parse_manifest_u32(const string& text, const string& field) {
    size_t pos = 0;
    unsigned long value = stoul(text, &pos, 0);
    if (pos != text.size() || value > 0xfffffffful) throw runtime_error("invalid manifest u32 field " + field);
    return static_cast<uint32_t>(value);
}

static uint64_t parse_manifest_u64(const string& text, const string& field) {
    size_t pos = 0;
    unsigned long long value = stoull(text, &pos, 0);
    if (pos != text.size()) throw runtime_error("invalid manifest u64 field " + field);
    return static_cast<uint64_t>(value);
}

static bool parse_manifest_bool(const string& text, const string& field) {
    if (text == "true" || text == "1") return true;
    if (text == "false" || text == "0") return false;
    throw runtime_error("invalid manifest bool field " + field);
}

vector<string> validate_patch_manifest(const PatchManifest& manifest) {
    vector<string> issues;
    set<string> seen;
    for (const auto& patch : manifest.records) {
        if (!patch.enabled) continue;
        string key = patch_kind_name(patch.kind) + ":" + hx(patch.va) + ":" + patch.symbol;
        if (!seen.insert(key).second) issues.push_back("duplicate patch " + key);
        if (patch.reason.empty()) issues.push_back("patch " + key + " missing reason");
        if (patch.evidence.empty()) issues.push_back("patch " + key + " missing evidence");
        if (patch.rollback.empty()) issues.push_back("patch " + key + " missing rollback");
        if (patch.abi.empty()) {
            issues.push_back("patch " + key + " missing abi");
        }
        if ((patch.kind == PatchKind::ImportShim || patch.kind == PatchKind::IndirectImportShim) &&
            patch.symbol.empty()) {
            issues.push_back("import shim " + key + " missing symbol");
        }
    }
    return issues;
}

PatchManifest parse_patch_manifest_text(const string& text) {
    PatchManifest manifest;
    istringstream input(text);
    string line;
    uint32_t line_no = 0;
    while (getline(input, line)) {
        ++line_no;
        auto comment = line.find('#');
        if (comment != string::npos) line = line.substr(0, comment);
        line = trim_copy(line);
        if (line.empty()) continue;
        auto tokens = split_manifest_tokens(line);
        if (tokens.empty()) continue;
        if (tokens[0] != "patch") throw runtime_error("manifest line " + to_string(line_no) + " must start with patch");

        PatchRecord patch;
        bool have_kind = false, have_va = false, have_rva = false;
        for (size_t i = 1; i < tokens.size(); ++i) {
            auto eq = tokens[i].find('=');
            if (eq == string::npos) throw runtime_error("manifest line " + to_string(line_no) + " token missing '='");
            string key = tokens[i].substr(0, eq);
            string value = tokens[i].substr(eq + 1);
            if (key == "kind") {
                if (!patch_kind_from_name(value, patch.kind)) {
                    throw runtime_error("manifest line " + to_string(line_no) + " unsupported kind " + value);
                }
                have_kind = true;
            } else if (key == "va") {
                patch.va = parse_manifest_u32(value, key);
                have_va = true;
            } else if (key == "rva") {
                patch.va = parse_manifest_u32(value, key);
                have_rva = true;
            } else if (key == "symbol" || key == "import") {
                patch.symbol = value;
            } else if (key == "abi") {
                patch.abi = value;
            } else if (key == "reason") {
                patch.reason = value;
            } else if (key == "evidence") {
                patch.evidence = value;
            } else if (key == "rollback") {
                patch.rollback = value;
            } else if (key == "enabled") {
                patch.enabled = parse_manifest_bool(value, key);
            } else {
                throw runtime_error("manifest line " + to_string(line_no) + " unknown field " + key);
            }
        }
        if (!have_kind) throw runtime_error("manifest line " + to_string(line_no) + " missing kind");
        if (have_va && have_rva) throw runtime_error("manifest line " + to_string(line_no) + " has both va and rva");
        if (!have_va && !have_rva) throw runtime_error("manifest line " + to_string(line_no) + " missing va or rva");
        manifest.records.push_back(patch);
    }
    return manifest;
}

PatchManifest load_patch_manifest(const filesystem::path& p) {
    vector<uint8_t> bytes = read_file(p);
    return parse_patch_manifest_text(string(bytes.begin(), bytes.end()));
}

string format_patch_manifest(const PatchManifest& manifest) {
    ostringstream o;
    o << "patches: " << manifest.records.size() << "\n";
    for (const auto& patch : manifest.records) {
        o << "patch: kind=" << patch_kind_name(patch.kind)
          << " va=" << hx(patch.va)
          << " enabled=" << (patch.enabled ? "true" : "false");
        if (!patch.symbol.empty()) o << " symbol=" << patch.symbol;
        if (!patch.dll.empty()) o << " dll=" << patch.dll;
        if (!patch.abi.empty()) o << " abi=" << patch.abi;
        if (patch.iat_va) o << " iat_va=" << hx(patch.iat_va);
        if (patch.iat_rva) o << " iat_rva=" << hx(patch.iat_rva);
        if (patch.callsite_rva) o << " callsite_rva=" << hx(patch.callsite_rva);
        if (!patch.side_effects.empty()) o << " side_effects=" << patch.side_effects;
        if (!patch.reason.empty()) o << " reason=" << patch.reason;
        if (!patch.evidence.empty()) o << " evidence=" << patch.evidence;
        if (!patch.rollback.empty()) o << " rollback=" << patch.rollback;
        o << "\n";
    }
    auto issues = validate_patch_manifest(manifest);
    o << "patch_issues: " << issues.size() << "\n";
    for (const auto& issue : issues) o << "patch_issue: " << issue << "\n";
    return o.str();
}

static string entry_import_key(const EntryImportShimRecord& record) {
    uint32_t callsite = record.has_callsite_va ? record.callsite_va : record.callsite_rva;
    string symbol = record.dll.empty() ? record.symbol : record.dll + "!" + record.symbol;
    return hx(callsite) + ":" + symbol;
}

static bool entry_side_effect_supported(const string& side_effects) {
    return side_effects == "version_info_write";
}

EntryImportShimManifest parse_entry_import_shim_manifest_text(const string& text) {
    EntryImportShimManifest manifest;
    istringstream input(text);
    string line;
    uint32_t line_no = 0;
    while (getline(input, line)) {
        ++line_no;
        auto comment = line.find('#');
        if (comment != string::npos) line = line.substr(0, comment);
        line = trim_copy(line);
        if (line.empty()) continue;
        auto tokens = split_manifest_tokens(line);
        if (tokens.empty()) continue;
        if (tokens[0] != "entry_import_shim") {
            throw runtime_error("entry import shim line " + to_string(line_no) + " unsupported record kind " + tokens[0]);
        }

        EntryImportShimRecord record;
        for (size_t i = 1; i < tokens.size(); ++i) {
            auto eq = tokens[i].find('=');
            if (eq == string::npos) throw runtime_error("entry import shim line " + to_string(line_no) + " token missing '='");
            string key = tokens[i].substr(0, eq);
            string value = tokens[i].substr(eq + 1);
            if (key == "dll") {
                record.dll = value;
            } else if (key == "symbol" || key == "import") {
                record.symbol = value;
            } else if (key == "iat_va") {
                record.iat_va = parse_manifest_u32(value, key);
                record.has_iat_va = true;
            } else if (key == "iat_rva") {
                record.iat_rva = parse_manifest_u32(value, key);
                record.has_iat_rva = true;
            } else if (key == "callsite_va") {
                record.callsite_va = parse_manifest_u32(value, key);
                record.has_callsite_va = true;
            } else if (key == "callsite_rva") {
                record.callsite_rva = parse_manifest_u32(value, key);
                record.has_callsite_rva = true;
            } else if (key == "abi") {
                record.abi = value;
            } else if (key == "side_effects") {
                record.side_effects = value;
            } else if (key == "evidence") {
                record.evidence = value;
            } else if (key == "rollback") {
                record.rollback = value;
            } else if (key == "enabled") {
                record.enabled = parse_manifest_bool(value, key);
            } else {
                throw runtime_error("entry import shim line " + to_string(line_no) + " unknown field " + key);
            }
        }
        manifest.records.push_back(record);
    }
    return manifest;
}

EntryImportShimManifest load_entry_import_shim_manifest(const filesystem::path& p) {
    vector<uint8_t> bytes = read_file(p);
    return parse_entry_import_shim_manifest_text(string(bytes.begin(), bytes.end()));
}

vector<string> validate_entry_import_shim_manifest(const EntryImportShimManifest& manifest) {
    vector<string> issues;
    set<string> seen_callsite;
    set<string> seen_iat;
    for (const auto& record : manifest.records) {
        if (!record.enabled) continue;
        string key = entry_import_key(record);
        if (!seen_callsite.insert(key).second) issues.push_back("duplicate entry import shim " + key);
        string iat_key = hx(record.has_iat_va ? record.iat_va : record.iat_rva) + ":" + record.dll + "!" + record.symbol;
        if (!seen_iat.insert(iat_key).second) issues.push_back("duplicate entry import shim iat " + iat_key);
        if (record.dll.empty()) issues.push_back("entry import shim " + key + " missing dll");
        if (record.symbol.empty()) issues.push_back("entry import shim " + key + " missing symbol");
        if (record.abi.empty()) issues.push_back("entry import shim " + key + " missing abi");
        if (record.side_effects.empty()) issues.push_back("entry import shim " + key + " missing side_effects");
        else if (!entry_side_effect_supported(record.side_effects)) {
            issues.push_back("entry import shim " + key + " unsupported side_effects " + record.side_effects);
        }
        if (record.evidence.empty()) issues.push_back("entry import shim " + key + " missing evidence");
        if (record.rollback.empty()) issues.push_back("entry import shim " + key + " missing rollback");
        if (!record.has_iat_va && !record.has_iat_rva) issues.push_back("entry import shim " + key + " missing iat_va or iat_rva");
        if (!record.has_callsite_va && !record.has_callsite_rva) {
            issues.push_back("entry import shim " + key + " missing callsite_va or callsite_rva");
        }
    }
    return issues;
}

string format_entry_import_shim_manifest(const EntryImportShimManifest& manifest) {
    ostringstream o;
    o << "entry_import_shims: " << manifest.records.size() << "\n";
    for (const auto& record : manifest.records) {
        o << "entry_import_shim:"
          << " dll=" << record.dll
          << " symbol=" << record.symbol;
        if (record.has_iat_va) o << " iat_va=" << hx(record.iat_va);
        if (record.has_iat_rva) o << " iat_rva=" << hx(record.iat_rva);
        if (record.has_callsite_va) o << " callsite_va=" << hx(record.callsite_va);
        if (record.has_callsite_rva) o << " callsite_rva=" << hx(record.callsite_rva);
        o << " abi=" << record.abi
          << " side_effects=" << record.side_effects
          << " enabled=" << (record.enabled ? "true" : "false");
        if (!record.evidence.empty()) o << " evidence=" << record.evidence;
        if (!record.rollback.empty()) o << " rollback=" << record.rollback;
        o << "\n";
    }
    auto issues = validate_entry_import_shim_manifest(manifest);
    o << "entry_import_shim_issues: " << issues.size() << "\n";
    for (const auto& issue : issues) o << "entry_import_shim_issue: " << issue << "\n";
    return o.str();
}

PatchManifest patch_manifest_from_entry_import_shims(const EntryImportShimManifest& manifest) {
    auto issues = validate_entry_import_shim_manifest(manifest);
    if (!issues.empty()) throw runtime_error("invalid entry import shim manifest: " + issues.front());
    PatchManifest patches;
    for (const auto& record : manifest.records) {
        PatchRecord patch;
        patch.kind = PatchKind::IndirectImportShim;
        patch.va = record.has_callsite_va ? record.callsite_va : record.callsite_rva;
        patch.callsite_rva = record.callsite_rva;
        patch.iat_va = record.iat_va;
        patch.iat_rva = record.iat_rva;
        patch.symbol = record.dll + "!" + record.symbol;
        patch.dll = record.dll;
        patch.abi = record.abi;
        patch.side_effects = record.side_effects;
        patch.reason = "entry import shim metadata";
        patch.evidence = record.evidence;
        patch.rollback = record.rollback;
        patch.enabled = record.enabled;
        patches.records.push_back(patch);
    }
    return patches;
}

static string runtime_init_import_pointer_key(const RuntimeInitManifest& manifest,
                                              const RuntimeInitImportPointerRecord& record) {
    uint32_t iat_va = record.has_iat_va ? record.iat_va :
        (record.has_iat_rva && manifest.image_base ? manifest.image_base + record.iat_rva : record.iat_rva);
    return hx(iat_va) + ":" + record.dll + "!" + record.symbol;
}

RuntimeInitManifest parse_runtime_init_manifest_text(const string& text) {
    RuntimeInitManifest manifest;
    istringstream input(text);
    string line;
    uint32_t line_no = 0;
    bool have_image = false;
    while (getline(input, line)) {
        ++line_no;
        auto comment = line.find('#');
        if (comment != string::npos) line = line.substr(0, comment);
        line = trim_copy(line);
        if (line.empty()) continue;
        auto tokens = split_manifest_tokens(line);
        if (tokens.empty()) continue;
        if (tokens[0] == "image") {
            if (have_image) throw runtime_error("runtime init manifest line " + to_string(line_no) + " duplicate image record");
            have_image = true;
            for (size_t i = 1; i < tokens.size(); ++i) {
                auto eq = tokens[i].find('=');
                if (eq == string::npos) throw runtime_error("runtime init manifest line " + to_string(line_no) + " token missing '='");
                string key = tokens[i].substr(0, eq);
                string value = tokens[i].substr(eq + 1);
                if (key == "path" || key == "pe") {
                    manifest.image_path = value;
                } else if (key == "image_base") {
                    manifest.image_base = parse_manifest_u32(value, key);
                } else if (key == "file_hash" || key == "fnv1a64") {
                    manifest.file_hash = parse_manifest_u64(value, key);
                } else {
                    throw runtime_error("runtime init manifest line " + to_string(line_no) + " unknown image field " + key);
                }
            }
        } else if (tokens[0] == "runtime_init_import_pointer") {
            RuntimeInitImportPointerRecord record;
            for (size_t i = 1; i < tokens.size(); ++i) {
                auto eq = tokens[i].find('=');
                if (eq == string::npos) throw runtime_error("runtime init manifest line " + to_string(line_no) + " token missing '='");
                string key = tokens[i].substr(0, eq);
                string value = tokens[i].substr(eq + 1);
                if (key == "dll") {
                    record.dll = value;
                } else if (key == "symbol" || key == "import") {
                    record.symbol = value;
                } else if (key == "iat_va") {
                    record.iat_va = parse_manifest_u32(value, key);
                    record.has_iat_va = true;
                } else if (key == "iat_rva") {
                    record.iat_rva = parse_manifest_u32(value, key);
                    record.has_iat_rva = true;
                } else if (key == "shim_target_va") {
                    record.shim_target_va = parse_manifest_u32(value, key);
                    record.has_shim_target_va = true;
                } else if (key == "abi") {
                    record.abi = value;
                } else if (key == "side_effects" || key == "side_effect_model") {
                    record.side_effects = value;
                } else if (key == "evidence") {
                    record.evidence = value;
                } else if (key == "rollback") {
                    record.rollback = value;
                } else if (key == "enabled") {
                    record.enabled = parse_manifest_bool(value, key);
                } else {
                    throw runtime_error("runtime init manifest line " + to_string(line_no) + " unknown import pointer field " + key);
                }
            }
            manifest.import_pointers.push_back(record);
        } else {
            throw runtime_error("runtime init manifest line " + to_string(line_no) + " unsupported record kind " + tokens[0]);
        }
    }
    return manifest;
}

RuntimeInitManifest load_runtime_init_manifest(const filesystem::path& p) {
    vector<uint8_t> bytes = read_file(p);
    return parse_runtime_init_manifest_text(string(bytes.begin(), bytes.end()));
}

vector<string> validate_runtime_init_manifest(const RuntimeInitManifest& manifest, uint32_t mapped_base,
                                              uint32_t mapped_size) {
    vector<string> issues;
    if (manifest.image_path.empty()) issues.push_back("runtime init image missing path");
    if (!manifest.image_base) issues.push_back("runtime init image missing image_base");
    if (!manifest.file_hash) issues.push_back("runtime init image missing file_hash");
    if (manifest.import_pointers.empty()) issues.push_back("runtime init has no import pointers");

    set<string> seen;
    for (const auto& record : manifest.import_pointers) {
        if (!record.enabled) continue;
        string key = runtime_init_import_pointer_key(manifest, record);
        if (!seen.insert(key).second) issues.push_back("duplicate runtime init import pointer " + key);
        if (record.dll.empty()) issues.push_back("runtime init import pointer " + key + " missing dll");
        if (record.symbol.empty()) issues.push_back("runtime init import pointer " + key + " missing symbol");
        if (record.abi.empty()) issues.push_back("runtime init import pointer " + key + " missing abi");
        if (record.side_effects.empty()) issues.push_back("runtime init import pointer " + key + " missing side_effects");
        else if (!entry_side_effect_supported(record.side_effects)) {
            issues.push_back("runtime init import pointer " + key + " unsupported side_effects " + record.side_effects);
        }
        if (record.evidence.empty()) issues.push_back("runtime init import pointer " + key + " missing evidence");
        if (record.rollback.empty()) issues.push_back("runtime init import pointer " + key + " missing rollback");
        if (!record.has_iat_va && !record.has_iat_rva) {
            issues.push_back("runtime init import pointer " + key + " missing iat_va or iat_rva");
        }
        if (!record.has_shim_target_va) {
            issues.push_back("runtime init import pointer " + key + " missing shim_target_va");
        }
        if (record.has_iat_va && record.has_iat_rva && manifest.image_base &&
            record.iat_va != manifest.image_base + record.iat_rva) {
            issues.push_back("runtime init import pointer " + key + " iat va/rva mismatch");
        }
        uint32_t resolved_iat_va = record.has_iat_va ? record.iat_va :
            (manifest.image_base ? manifest.image_base + record.iat_rva : record.iat_rva);
        if (mapped_size) {
            uint64_t map_end = uint64_t(mapped_base) + uint64_t(mapped_size);
            uint64_t write_end = uint64_t(resolved_iat_va) + 4u;
            if (resolved_iat_va < mapped_base || write_end > map_end) {
                issues.push_back("runtime init import pointer " + key + " unmapped iat");
            }
        }
    }

    if (!manifest.image_path.empty()) {
        try {
            auto info = inspect_pe_info(manifest.image_path);
            if (manifest.image_base && info.image_base != manifest.image_base) {
                issues.push_back("image_base mismatch manifest=" + hx(manifest.image_base) + " pe=" + hx(info.image_base));
            }
            if (manifest.file_hash && info.fnv1a64 != manifest.file_hash) {
                issues.push_back("file_hash mismatch manifest=" + hx64(manifest.file_hash) + " pe=" + hx64(info.fnv1a64));
            }
        } catch (const exception& e) {
            issues.push_back(string("image validation failed: ") + e.what());
        }
    }
    return issues;
}

string format_runtime_init_manifest(const RuntimeInitManifest& manifest, uint32_t mapped_base,
                                    uint32_t mapped_size) {
    ostringstream o;
    o << "runtime_init_image: path=" << manifest.image_path
      << " image_base=" << hx(manifest.image_base)
      << " file_hash=" << hx64(manifest.file_hash) << "\n"
      << "runtime_init_import_pointers: " << manifest.import_pointers.size() << "\n";
    for (const auto& record : manifest.import_pointers) {
        o << "runtime_init_import_pointer:"
          << " dll=" << record.dll
          << " symbol=" << record.symbol;
        if (record.has_iat_va) o << " iat_va=" << hx(record.iat_va);
        if (record.has_iat_rva) o << " iat_rva=" << hx(record.iat_rva);
        if (record.has_shim_target_va) o << " shim_target_va=" << hx(record.shim_target_va);
        o << " abi=" << record.abi
          << " side_effects=" << record.side_effects
          << " enabled=" << (record.enabled ? "true" : "false");
        if (!record.evidence.empty()) o << " evidence=" << record.evidence;
        if (!record.rollback.empty()) o << " rollback=" << record.rollback;
        o << "\n";
    }
    auto issues = validate_runtime_init_manifest(manifest, mapped_base, mapped_size);
    o << "runtime_init_issues: " << issues.size() << "\n";
    for (const auto& issue : issues) o << "runtime_init_issue: " << issue << "\n";
    return o.str();
}

static string lower_copy(string value) {
    transform(value.begin(), value.end(), value.begin(),
              [](unsigned char c) { return static_cast<char>(tolower(c)); });
    return value;
}

static string import_symbol_key(const string& dll, const string& symbol) {
    return lower_copy(dll) + "!" + lower_copy(symbol);
}

static uint32_t resolved_iat_va(uint32_t image_base, bool has_va, uint32_t va, bool has_rva, uint32_t rva) {
    if (has_va) return va;
    if (has_rva) return image_base + rva;
    return 0;
}

ImportBindingSummary resolve_import_bindings(const PeInfo& info, const EntryImportShimManifest& entry,
                                             const RuntimeInitManifest& runtime_init) {
    ImportBindingSummary summary;
    for (const auto& issue : validate_entry_import_shim_manifest(entry)) {
        summary.diagnostics.push_back("entry import shim invalid: " + issue);
    }
    for (const auto& issue : validate_runtime_init_manifest(runtime_init, info.image_base, info.size_of_image)) {
        summary.diagnostics.push_back("runtime init invalid: " + issue);
    }

    struct PeImportFact { string key,dll,symbol; uint32_t iat_rva=0,iat_va=0; };
    vector<PeImportFact> facts;
    set<string> seen_import_names;
    for (const auto& dll : info.imports) {
        for (const auto& fn : dll.functions) {
            if (fn.by_ordinal) {
                summary.diagnostics.push_back("ordinal-only import " + dll.name + " ordinal=" +
                                              to_string(fn.ordinal) + " iat=" + hx(info.image_base + fn.iat_rva));
                continue;
            }
            string key = import_symbol_key(dll.name, fn.name);
            if (!seen_import_names.insert(key).second) {
                summary.diagnostics.push_back("duplicate import name " + dll.name + "!" + fn.name);
            }
            facts.push_back({key, dll.name, fn.name, fn.iat_rva, info.image_base + fn.iat_rva});
        }
    }

    auto find_fact = [&](const string& key, uint32_t iat_va, uint32_t iat_rva) -> const PeImportFact* {
        auto it = find_if(facts.begin(), facts.end(), [&](const PeImportFact& fact) {
            return fact.key == key && (fact.iat_va == iat_va || fact.iat_rva == iat_rva);
        });
        return it == facts.end() ? nullptr : &*it;
    };

    auto find_runtime = [&](const string& key, uint32_t iat_va, uint32_t iat_rva) -> const RuntimeInitImportPointerRecord* {
        auto it = find_if(runtime_init.import_pointers.begin(), runtime_init.import_pointers.end(),
                          [&](const RuntimeInitImportPointerRecord& record) {
            if (!record.enabled) return false;
            uint32_t record_iat_va = resolved_iat_va(runtime_init.image_base, record.has_iat_va, record.iat_va,
                                                     record.has_iat_rva, record.iat_rva);
            return import_symbol_key(record.dll, record.symbol) == key &&
                   (record_iat_va == iat_va || record.iat_rva == iat_rva);
        });
        return it == runtime_init.import_pointers.end() ? nullptr : &*it;
    };

    set<string> bound_keys;
    for (const auto& record : entry.records) {
        if (!record.enabled) continue;
        string key = import_symbol_key(record.dll, record.symbol);
        uint32_t iat_va = resolved_iat_va(info.image_base, record.has_iat_va, record.iat_va,
                                          record.has_iat_rva, record.iat_rva);
        uint32_t iat_rva = record.has_iat_rva ? record.iat_rva : (iat_va >= info.image_base ? iat_va - info.image_base : 0);
        const PeImportFact* fact = find_fact(key, iat_va, iat_rva);
        if (!fact) {
            summary.diagnostics.push_back("missing import " + record.dll + "!" + record.symbol + " iat=" + hx(iat_va));
            continue;
        }
        const auto* runtime_record = find_runtime(key, iat_va, iat_rva);
        if (!runtime_record) {
            summary.diagnostics.push_back("missing runtime init " + record.dll + "!" + record.symbol + " iat=" + hx(iat_va));
            continue;
        }
        if (record.abi != runtime_record->abi) {
            summary.diagnostics.push_back("ABI mismatch " + record.dll + "!" + record.symbol +
                                          " entry=" + record.abi + " runtime_init=" + runtime_record->abi);
            continue;
        }
        if (record.side_effects != runtime_record->side_effects) {
            summary.diagnostics.push_back("side_effect mismatch " + record.dll + "!" + record.symbol +
                                          " entry=" + record.side_effects + " runtime_init=" + runtime_record->side_effects);
            continue;
        }
        string binding_key = key + ":" + hx(fact->iat_va);
        if (!bound_keys.insert(binding_key).second) {
            summary.diagnostics.push_back("duplicate import binding " + record.dll + "!" + record.symbol + " iat=" + hx(fact->iat_va));
            continue;
        }
        ImportBindingRecord binding;
        binding.dll = fact->dll;
        binding.symbol = fact->symbol;
        binding.iat_va = fact->iat_va;
        binding.iat_rva = fact->iat_rva;
        binding.callsite_va = record.has_callsite_va ? record.callsite_va :
            (record.has_callsite_rva ? info.image_base + record.callsite_rva : 0);
        binding.callsite_rva = record.has_callsite_rva ? record.callsite_rva :
            (binding.callsite_va >= info.image_base ? binding.callsite_va - info.image_base : 0);
        binding.has_callsite = record.has_callsite_va || record.has_callsite_rva;
        binding.shim_target_va = runtime_record->shim_target_va;
        binding.has_runtime_init = true;
        binding.abi = record.abi;
        binding.side_effects = record.side_effects;
        binding.evidence = record.evidence + "+" + runtime_record->evidence;
        binding.rollback = record.rollback;
        binding.enabled = record.enabled && runtime_record->enabled;
        summary.bindings.push_back(binding);
    }

    for (const auto& record : runtime_init.import_pointers) {
        if (!record.enabled) continue;
        string key = import_symbol_key(record.dll, record.symbol);
        uint32_t iat_va = resolved_iat_va(runtime_init.image_base, record.has_iat_va, record.iat_va,
                                          record.has_iat_rva, record.iat_rva);
        uint32_t iat_rva = record.has_iat_rva ? record.iat_rva :
            (iat_va >= runtime_init.image_base ? iat_va - runtime_init.image_base : 0);
        if (!find_fact(key, iat_va, iat_rva)) {
            summary.diagnostics.push_back("runtime init import missing in PE " + record.dll + "!" + record.symbol +
                                          " iat=" + hx(iat_va));
        }
    }
    return summary;
}

string format_import_bindings(const ImportBindingSummary& summary) {
    ostringstream o;
    o << "import_bindings: " << summary.bindings.size() << "\n";
    for (const auto& binding : summary.bindings) {
        o << "import_binding:"
          << " dll=" << binding.dll
          << " symbol=" << binding.symbol
          << " iat_va=" << hx(binding.iat_va)
          << " iat_rva=" << hx(binding.iat_rva);
        if (binding.has_callsite) {
            o << " callsite_va=" << hx(binding.callsite_va)
              << " callsite_rva=" << hx(binding.callsite_rva);
        }
        o << " shim_target_va=" << hx(binding.shim_target_va)
          << " abi=" << binding.abi
          << " side_effects=" << binding.side_effects
          << " runtime_init=" << (binding.has_runtime_init ? "true" : "false")
          << " enabled=" << (binding.enabled ? "true" : "false");
        if (!binding.evidence.empty()) o << " evidence=" << binding.evidence;
        if (!binding.rollback.empty()) o << " rollback=" << binding.rollback;
        o << "\n";
    }
    o << "import_binding_diagnostics: " << summary.diagnostics.size() << "\n";
    for (const auto& diagnostic : summary.diagnostics) o << "import_binding_diagnostic: " << diagnostic << "\n";
    return o.str();
}

RuntimeStartManifest parse_runtime_start_manifest_text(const string& text) {
    RuntimeStartManifest manifest;
    istringstream input(text);
    string line;
    uint32_t line_no = 0;
    bool have_start = false;
    while (getline(input, line)) {
        ++line_no;
        auto comment = line.find('#');
        if (comment != string::npos) line = line.substr(0, comment);
        line = trim_copy(line);
        if (line.empty()) continue;
        auto tokens = split_manifest_tokens(line);
        if (tokens[0] == "runtime_start") {
            if (have_start) throw runtime_error("runtime start manifest line " + to_string(line_no) + " duplicate runtime_start");
            have_start = true;
            for (size_t i = 1; i < tokens.size(); ++i) {
                auto eq = tokens[i].find('=');
                if (eq == string::npos) throw runtime_error("runtime start manifest line " + to_string(line_no) + " token missing '='");
                string key = tokens[i].substr(0, eq);
                string value = tokens[i].substr(eq + 1);
                if (key == "entry_va") { manifest.entry_va = parse_manifest_u32(value, key); manifest.has_entry_va = true; }
                else if (key == "stack_base") manifest.stack_base = parse_manifest_u32(value, key);
                else if (key == "stack_size") manifest.stack_size = parse_manifest_u32(value, key);
                else if (key == "initial_esp") manifest.initial_esp = parse_manifest_u32(value, key);
                else if (key == "expected_abi" || key == "abi") manifest.expected_abi = value;
                else if (key == "evidence") manifest.evidence = value;
                else if (key == "rollback") manifest.rollback = value;
                else if (key == "enabled") manifest.enabled = parse_manifest_bool(value, key);
                else throw runtime_error("runtime start manifest line " + to_string(line_no) + " unknown runtime_start field " + key);
            }
        } else if (tokens[0] == "argument") {
            RuntimeStartArgumentRecord arg;
            for (size_t i = 1; i < tokens.size(); ++i) {
                auto eq = tokens[i].find('=');
                if (eq == string::npos) throw runtime_error("runtime start manifest line " + to_string(line_no) + " token missing '='");
                string key = tokens[i].substr(0, eq);
                string value = tokens[i].substr(eq + 1);
                if (key == "offset") arg.offset = parse_manifest_u32(value, key);
                else if (key == "value") arg.value = parse_manifest_u32(value, key);
                else if (key == "size") arg.size = parse_manifest_u32(value, key);
                else throw runtime_error("runtime start manifest line " + to_string(line_no) + " unknown argument field " + key);
            }
            manifest.arguments.push_back(arg);
        } else {
            throw runtime_error("runtime start manifest line " + to_string(line_no) + " unsupported record kind " + tokens[0]);
        }
    }
    return manifest;
}

RuntimeStartManifest load_runtime_start_manifest(const filesystem::path& p) {
    vector<uint8_t> bytes = read_file(p);
    return parse_runtime_start_manifest_text(string(bytes.begin(), bytes.end()));
}

vector<string> validate_runtime_start_manifest(const RuntimeStartManifest& manifest) {
    vector<string> issues;
    if (!manifest.enabled) return issues;
    if (!manifest.has_entry_va || !manifest.entry_va) issues.push_back("runtime start missing entry_va");
    if (!manifest.stack_base || !manifest.stack_size) issues.push_back("runtime start invalid stack");
    if (manifest.expected_abi != "cdecl" && manifest.expected_abi != "stdcall") {
        issues.push_back("runtime start unsupported ABI " + manifest.expected_abi);
    }
    if (manifest.evidence.empty()) issues.push_back("runtime start missing evidence");
    if (manifest.rollback.empty()) issues.push_back("runtime start missing rollback");
    uint64_t stack_end = uint64_t(manifest.stack_base) + uint64_t(manifest.stack_size);
    if (stack_end > 0xffffffffull) issues.push_back("runtime start stack overflow");
    if (manifest.initial_esp < manifest.stack_base || uint64_t(manifest.initial_esp) > stack_end) {
        issues.push_back("runtime start initial ESP outside stack");
    }
    for (const auto& arg : manifest.arguments) {
        if (arg.size != 4) issues.push_back("runtime start unsupported argument size");
        if (arg.offset % 4) issues.push_back("runtime start unaligned argument");
        uint64_t arg_va = uint64_t(manifest.initial_esp) + uint64_t(arg.offset);
        if (arg_va < manifest.stack_base || arg_va + arg.size > stack_end) {
            issues.push_back("runtime start argument write outside stack");
        }
    }
    return issues;
}

string format_runtime_start_manifest(const RuntimeStartManifest& manifest) {
    ostringstream o;
    o << "runtime_start: entry_va=" << hx(manifest.entry_va)
      << " stack_base=" << hx(manifest.stack_base)
      << " stack_size=" << manifest.stack_size
      << " initial_esp=" << hx(manifest.initial_esp)
      << " expected_abi=" << manifest.expected_abi
      << " enabled=" << (manifest.enabled ? "true" : "false");
    if (!manifest.evidence.empty()) o << " evidence=" << manifest.evidence;
    if (!manifest.rollback.empty()) o << " rollback=" << manifest.rollback;
    o << "\n";
    o << "runtime_start_arguments: " << manifest.arguments.size() << "\n";
    for (const auto& arg : manifest.arguments) {
        o << "runtime_start_argument: offset=" << arg.offset
          << " value=" << hx(arg.value)
          << " size=" << arg.size << "\n";
    }
    auto issues = validate_runtime_start_manifest(manifest);
    o << "runtime_start_issues: " << issues.size() << "\n";
    for (const auto& issue : issues) o << "runtime_start_issue: " << issue << "\n";
    return o.str();
}

CfgFunction build_cfg(const vector<uint8_t>& bytes, uint32_t base, uint32_t entry) {
    CfgFunction cfg;
    cfg.entry = entry;
    cfg.range_start = base;
    cfg.range_end = base + uint32_t(bytes.size());
    if (!in_range(entry, cfg.range_start, cfg.range_end)) {
        cfg.diagnostics.push_back("entry outside bounded range");
        return cfg;
    }

    auto decoded = decode(bytes, base);
    auto irs = lift_ir(decoded);
    map<uint32_t, IrInst> by_addr;
    for (const auto& ir : irs) by_addr[ir.address] = ir;

    set<uint32_t> leaders;
    deque<uint32_t> work;
    auto add_leader = [&](uint32_t va) {
        if (!in_range(va, cfg.range_start, cfg.range_end)) return;
        if (leaders.insert(va).second) work.push_back(va);
    };
    add_leader(entry);

    set<uint32_t> scanned;
    while (!work.empty()) {
        uint32_t pc = work.front();
        work.pop_front();
        if (!scanned.insert(pc).second) continue;
        while (in_range(pc, cfg.range_start, cfg.range_end)) {
            auto it = by_addr.find(pc);
            if (it == by_addr.end()) {
                cfg.diagnostics.push_back("decode gap at " + hx(pc));
                break;
            }
            const auto& ir = it->second;
            uint32_t next = ir_end(ir);
            if (ir.op == IrOp::Call) {
                if (ir.target) add_unique(cfg.direct_call_targets, ir.target);
            } else if (ir.op == IrOp::IndirectCall) {
                add_unique(cfg.indirect_call_sites, ir.address);
            } else if (ir.op == IrOp::Branch) {
                add_leader(ir.target);
                add_leader(next);
                break;
            } else if (ir.op == IrOp::Jump) {
                add_leader(ir.target);
                break;
            } else if (ir.op == IrOp::IndirectJump) {
                add_unique(cfg.indirect_jump_sites, ir.address);
                break;
            } else if (ir.op == IrOp::Return || ir.op == IrOp::Unsupported) {
                break;
            }
            if (next <= pc) {
                cfg.diagnostics.push_back("non-advancing decode at " + hx(pc));
                break;
            }
            pc = next;
        }
    }

    vector<uint32_t> sorted_leaders(leaders.begin(), leaders.end());
    for (uint32_t leader : sorted_leaders) {
        CfgBlock block;
        block.start = leader;
        block.end = leader;
        uint32_t pc = leader;
        while (in_range(pc, cfg.range_start, cfg.range_end)) {
            if (pc != leader && leaders.count(pc)) {
                if (!block.instructions.empty()) {
                    block.edges.push_back({CfgEdgeKind::Fallthrough, block.instructions.back().address, pc, ""});
                }
                block.end = pc;
                break;
            }
            auto it = by_addr.find(pc);
            if (it == by_addr.end()) {
                block.edges.push_back({CfgEdgeKind::Unresolved, pc, 0, "decode gap"});
                block.end = pc;
                break;
            }
            IrInst ir = it->second;
            uint32_t next = ir_end(ir);
            block.instructions.push_back(ir);
            block.end = next;

            if (ir.op == IrOp::Call) {
                string detail = in_range(ir.target, cfg.range_start, cfg.range_end) ? "" : "outside bounded range";
                block.edges.push_back({CfgEdgeKind::CallTarget, ir.address, ir.target, detail});
            } else if (ir.op == IrOp::IndirectCall) {
                block.edges.push_back({CfgEdgeKind::IndirectCall, ir.address, 0, fmt_operands(ir.operands)});
            } else if (ir.op == IrOp::Branch) {
                if (in_range(ir.target, cfg.range_start, cfg.range_end)) {
                    block.edges.push_back({CfgEdgeKind::BranchTaken, ir.address, ir.target, ir.condition});
                } else {
                    block.edges.push_back({CfgEdgeKind::Unresolved, ir.address, ir.target, "branch target outside bounded range"});
                }
                if (in_range(next, cfg.range_start, cfg.range_end)) {
                    block.edges.push_back({CfgEdgeKind::Fallthrough, ir.address, next, ""});
                }
                break;
            } else if (ir.op == IrOp::Jump) {
                if (in_range(ir.target, cfg.range_start, cfg.range_end)) {
                    block.edges.push_back({CfgEdgeKind::BranchTaken, ir.address, ir.target, "jmp"});
                } else {
                    block.edges.push_back({CfgEdgeKind::Unresolved, ir.address, ir.target, "jump target outside bounded range"});
                }
                break;
            } else if (ir.op == IrOp::IndirectJump) {
                block.edges.push_back({CfgEdgeKind::IndirectJump, ir.address, 0, fmt_operands(ir.operands)});
                break;
            } else if (ir.op == IrOp::Return) {
                block.exits = true;
                block.edges.push_back({CfgEdgeKind::Return, ir.address, 0, ""});
                break;
            } else if (ir.op == IrOp::Unsupported || !ir.ok) {
                block.has_unsupported = true;
                block.edges.push_back({CfgEdgeKind::Unresolved, ir.address, 0, ir.diagnostic.empty() ? "unsupported" : ir.diagnostic});
                break;
            }

            if (next <= pc) {
                block.edges.push_back({CfgEdgeKind::Unresolved, pc, 0, "non-advancing decode"});
                break;
            }
            pc = next;
            if (!in_range(pc, cfg.range_start, cfg.range_end)) {
                block.edges.push_back({CfgEdgeKind::Unresolved, block.instructions.back().address, pc, "fallthrough outside bounded range"});
            }
        }
        if (!block.instructions.empty()) cfg.blocks.push_back(block);
    }
    sort(cfg.direct_call_targets.begin(), cfg.direct_call_targets.end());
    sort(cfg.indirect_call_sites.begin(), cfg.indirect_call_sites.end());
    sort(cfg.indirect_jump_sites.begin(), cfg.indirect_jump_sites.end());
    return cfg;
}

string format_cfg(const CfgFunction& cfg) {
    ostringstream o;
    o << "cfg_entry: " << hx(cfg.entry) << "\n"
      << "cfg_range: " << hx(cfg.range_start) << "-" << hx(cfg.range_end) << "\n"
      << "cfg_blocks: " << cfg.blocks.size() << "\n"
      << "cfg_calls: " << cfg.direct_call_targets.size() << "\n";
    for (uint32_t target : cfg.direct_call_targets) {
        o << "cfg_call: " << hx(target) << "\n";
    }
    o << "cfg_indirect_calls: " << cfg.indirect_call_sites.size() << "\n";
    for (uint32_t site : cfg.indirect_call_sites) {
        o << "cfg_indirect_call: " << hx(site) << "\n";
    }
    o << "cfg_indirect_jumps: " << cfg.indirect_jump_sites.size() << "\n";
    for (uint32_t site : cfg.indirect_jump_sites) {
        o << "cfg_indirect_jump: " << hx(site) << "\n";
    }
    for (const auto& block : cfg.blocks) {
        o << "block: start=" << hx(block.start)
          << " end=" << hx(block.end)
          << " instructions=" << block.instructions.size()
          << " exit=" << (block.exits ? "true" : "false")
          << " unsupported=" << (block.has_unsupported ? "true" : "false") << "\n";
        for (const auto& ir : block.instructions) {
            o << "  ins: " << hx(ir.address) << " " << ir.mnemonic;
            string ops = fmt_operands(ir.operands);
            if (!ops.empty()) o << " " << ops;
            if (!ir.ok && !ir.diagnostic.empty()) o << " ; " << ir.diagnostic;
            o << "\n";
        }
        for (const auto& edge : block.edges) {
            o << "  edge: " << edge_name(edge.kind)
              << " from=" << hx(edge.from);
            if (edge.to) o << " to=" << hx(edge.to);
            if (!edge.detail.empty()) o << " detail=" << edge.detail;
            o << "\n";
        }
    }
    for (const auto& diagnostic : cfg.diagnostics) {
        o << "cfg_diagnostic: " << diagnostic << "\n";
    }
    return o.str();
}

static string label_for(uint32_t va) {
    ostringstream o;
    o << "L_" << uppercase << hex << setw(8) << setfill('0') << va;
    return o.str();
}

static string c_reg(const Operand& op) {
    if (op.kind != OperandKind::Reg) return "";
    return "ctx." + reg(op.reg, op.width);
}

static string c_reg32(uint8_t r) {
    return "ctx." + reg(r, 32);
}

static string c_read_reg_part(const Operand& op) {
    if (op.kind != OperandKind::Reg) return "0u";
    string base = c_reg32(op.reg & 3);
    if (op.width == 8) {
        if (op.reg < 4) return "(" + base + " & 0xFFu)";
        return "((" + base + " >> 8) & 0xFFu)";
    }
    if (op.width == 16) return "(" + base + " & 0xFFFFu)";
    return c_reg32(op.reg);
}

static string c_extend_reg_part(const Operand& op, bool sign_extend) {
    string raw = c_read_reg_part(op);
    if (!sign_extend) return raw;
    if (op.width == 8) return "((" + raw + " & 0x80u) ? (" + raw + " | 0xFFFFFF00u) : " + raw + ")";
    if (op.width == 16) return "((" + raw + " & 0x8000u) ? (" + raw + " | 0xFFFF0000u) : " + raw + ")";
    return raw;
}

static string c_imm(uint32_t value) {
    ostringstream o;
    o << "0x" << uppercase << hex << setw(8) << setfill('0') << value << "u";
    return o.str();
}

static string c_address(const Operand& op) {
    if (op.kind != OperandKind::Mem) return "0u";
    vector<string> parts;
    if (op.has_base) parts.push_back(c_reg(reg_op(op.base, 32)));
    if (op.has_index) {
        string index = c_reg(reg_op(op.index, 32));
        if (op.scale != 1) index = "(" + index + " * " + to_string(unsigned(op.scale)) + "u)";
        parts.push_back(index);
    }
    if (op.has_disp) parts.push_back(c_imm(uint32_t(op.disp)));
    if (parts.empty()) return "0u";
    ostringstream o;
    for (size_t i = 0; i < parts.size(); ++i) {
        if (i) o << " + ";
        o << parts[i];
    }
    return o.str();
}

static string c_read(const Operand& op) {
    switch (op.kind) {
    case OperandKind::Reg:
        return c_read_reg_part(op);
    case OperandKind::Imm:
        return c_imm(op.imm);
    case OperandKind::Rel:
        return c_imm(op.target);
    case OperandKind::Mem:
        if (op.width == 8) return "xr::runtime_read_mem8(rt, ctx, " + c_address(op) + ")";
        return "xr::runtime_read_mem32(rt, ctx, " + c_address(op) + ")";
    case OperandKind::None:
        break;
    }
    return "0u";
}

static bool can_write(const Operand& op) {
    return op.kind == OperandKind::Reg || op.kind == OperandKind::Mem;
}

static string c_write(const Operand& dst, const string& value) {
    if (dst.kind == OperandKind::Reg) {
        if (dst.width == 8) {
            string base = c_reg32(dst.reg & 3);
            if (dst.reg < 4) return base + " = (" + base + " & 0xFFFFFF00u) | (uint32_t(" + value + ") & 0xFFu);";
            return base + " = (" + base + " & 0xFFFF00FFu) | ((uint32_t(" + value + ") & 0xFFu) << 8);";
        }
        if (dst.width == 16) {
            string base = c_reg32(dst.reg);
            return base + " = (" + base + " & 0xFFFF0000u) | (uint32_t(" + value + ") & 0xFFFFu);";
        }
        return c_reg(dst) + " = uint32_t(" + value + ");";
    }
    if (dst.kind == OperandKind::Mem && dst.width == 8) return "xr::runtime_write_mem8(rt, ctx, " + c_address(dst) + ", uint8_t(" + value + "));";
    if (dst.kind == OperandKind::Mem && dst.width == 32) return "xr::runtime_write_mem32(rt, ctx, " + c_address(dst) + ", uint32_t(" + value + "));";
    return "xr::runtime_unsupported(rt, ctx, 0u);";
}

static string c_condition(const IrInst& ir) {
    if (ir.condition == "je") return "ctx.zf";
    if (ir.condition == "jne") return "!ctx.zf";
    if (ir.condition == "jb") return "ctx.cf";
    if (ir.condition == "jae") return "!ctx.cf";
    if (ir.condition == "jbe") return "ctx.cf || ctx.zf";
    if (ir.condition == "ja") return "!ctx.cf && !ctx.zf";
    if (ir.condition == "js") return "ctx.sf";
    if (ir.condition == "jns") return "!ctx.sf";
    if (ir.condition == "jp") return "ctx.pf";
    if (ir.condition == "jnp") return "!ctx.pf";
    if (ir.condition == "jo") return "ctx.of";
    if (ir.condition == "jno") return "!ctx.of";
    if (ir.condition == "jl") return "ctx.sf != ctx.of";
    if (ir.condition == "jge") return "ctx.sf == ctx.of";
    if (ir.condition == "jle") return "ctx.zf || (ctx.sf != ctx.of)";
    if (ir.condition == "jg") return "!ctx.zf && (ctx.sf == ctx.of)";
    return "unsupported_condition(ctx, rt, " + c_imm(ir.address) + ")";
}

static bool block_has_label(const CfgFunction& cfg, uint32_t va) {
    for (const auto& block : cfg.blocks) {
        if (block.start == va) return true;
    }
    return false;
}

static void emit_flag_assign(ostringstream& o, const string& expr) {
    o << "    xr::runtime_set_logic_flags(ctx, " << expr << ");\n";
}

static bool immediate_count_one(const IrInst& ir) {
    return ir.operands.size() == 2 && ir.operands[1].kind == OperandKind::Imm &&
           (ir.operands[1].imm & 0x1fu) == 1;
}

static void emit_after_hooks(ostringstream& o, const PatchManifest& manifest, uint32_t entry) {
    for (const auto* patch : patches_for(manifest, entry, PatchKind::AfterHook)) {
        o << "    xr::runtime_patch_after(rt, ctx, " << c_imm(patch->va) << ", " << c_string(patch->symbol) << ");\n";
    }
}

static string sub_name(uint32_t entry) {
    ostringstream o;
    o << "sub_" << uppercase << hex << setw(8) << setfill('0') << entry;
    return o.str();
}

static void emit_insn_c(ostringstream& o, const CfgFunction& cfg, const PatchManifest& manifest, const IrInst& ir,
                        const set<uint32_t>* pack_entries = nullptr) {
    o << "    // " << hx(ir.address) << " " << ir.mnemonic;
    string ops = fmt_operands(ir.operands);
    if (!ops.empty()) o << " " << ops;
    o << "\n";

    if (!ir.ok || ir.op == IrOp::Unsupported) {
        o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        return;
    }

    switch (ir.op) {
    case IrOp::Nop:
        o << "    (void)ctx; (void)rt;\n";
        break;
    case IrOp::Move:
        if (ir.operands.size() == 2 && can_write(ir.operands[0])) {
            o << "    " << c_write(ir.operands[0], c_read(ir.operands[1])) << "\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Movzx:
    case IrOp::Movsx:
        if (ir.width == 32 && ir.operands.size() == 2 &&
            ir.operands[0].kind == OperandKind::Reg && ir.operands[1].kind == OperandKind::Reg) {
            o << "    " << c_write(ir.operands[0], c_extend_reg_part(ir.operands[1], ir.op == IrOp::Movsx)) << "\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Lea:
        if (ir.operands.size() == 2 && ir.operands[0].kind == OperandKind::Reg) {
            o << "    " << c_write(ir.operands[0], c_address(ir.operands[1])) << "\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Xchg:
        if (ir.width == 32 && ir.operands.size() == 2 && can_write(ir.operands[0]) && can_write(ir.operands[1])) {
            o << "    { uint32_t a = " << c_read(ir.operands[0]) << "; uint32_t b = " << c_read(ir.operands[1]) << ";\n";
            o << "      " << c_write(ir.operands[0], "b") << " " << c_write(ir.operands[1], "a") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Inc:
        if (ir.width == 32 && ir.operands.size() == 1 && can_write(ir.operands[0])) {
            string a = c_read(ir.operands[0]);
            o << "    { uint32_t a = " << a << "; uint32_t r = a + 1u; bool old_cf = ctx.cf;\n";
            o << "      xr::runtime_set_add_flags(ctx, a, 1u, r); ctx.cf = old_cf; " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Dec:
        if (ir.width == 32 && ir.operands.size() == 1 && can_write(ir.operands[0])) {
            string a = c_read(ir.operands[0]);
            o << "    { uint32_t a = " << a << "; uint32_t r = a - 1u; bool old_cf = ctx.cf;\n";
            o << "      xr::runtime_set_sub_flags(ctx, a, 1u, r); ctx.cf = old_cf; " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Not:
        if (ir.width == 32 && ir.operands.size() == 1 && can_write(ir.operands[0])) {
            o << "    { uint32_t r = ~" << c_read(ir.operands[0]) << ";\n";
            o << "      " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Neg:
        if (ir.width == 32 && ir.operands.size() == 1 && can_write(ir.operands[0])) {
            string a = c_read(ir.operands[0]);
            o << "    { uint32_t a = " << a << "; uint32_t r = 0u - a;\n";
            o << "      xr::runtime_set_sub_flags(ctx, 0u, a, r); " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Add:
        if (ir.operands.size() == 2 && can_write(ir.operands[0])) {
            string a = c_read(ir.operands[0]);
            string b = c_read(ir.operands[1]);
            o << "    { uint32_t a = " << a << "; uint32_t b = " << b << "; uint32_t r = a + b;\n";
            o << "      xr::runtime_set_add_flags(ctx, a, b, r); " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Adc:
        if (ir.width == 32 && ir.operands.size() == 2 && can_write(ir.operands[0])) {
            string a = c_read(ir.operands[0]);
            string b = c_read(ir.operands[1]);
            o << "    { uint32_t a = " << a << "; uint32_t b = " << b << "; bool carry = ctx.cf; uint32_t r = a + b + (carry ? 1u : 0u);\n";
            o << "      xr::runtime_set_adc_flags(ctx, a, b, carry, r); " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Sub:
        if (ir.operands.size() == 2 && can_write(ir.operands[0])) {
            string a = c_read(ir.operands[0]);
            string b = c_read(ir.operands[1]);
            o << "    { uint32_t a = " << a << "; uint32_t b = " << b << "; uint32_t r = a - b;\n";
            o << "      xr::runtime_set_sub_flags(ctx, a, b, r); " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Sbb:
        if (ir.width == 32 && ir.operands.size() == 2 && can_write(ir.operands[0])) {
            string a = c_read(ir.operands[0]);
            string b = c_read(ir.operands[1]);
            o << "    { uint32_t a = " << a << "; uint32_t b = " << b << "; bool carry = ctx.cf; uint32_t r = a - b - (carry ? 1u : 0u);\n";
            o << "      xr::runtime_set_sbb_flags(ctx, a, b, carry, r); " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Cmp:
        if (ir.operands.size() == 2) {
            o << "    { uint32_t a = " << c_read(ir.operands[0]) << "; uint32_t b = " << c_read(ir.operands[1]) << "; xr::runtime_set_sub_flags(ctx, a, b, a - b); }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::And:
    case IrOp::Or:
    case IrOp::Xor:
        if (ir.operands.size() == 2 && can_write(ir.operands[0])) {
            string op = ir.op == IrOp::And ? " & " : ir.op == IrOp::Or ? " | " : " ^ ";
            o << "    { uint32_t r = " << c_read(ir.operands[0]) << op << c_read(ir.operands[1]) << ";\n";
            o << "      " << c_write(ir.operands[0], "r") << " ";
            emit_flag_assign(o, "r");
            o << "    }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Test:
        if (ir.operands.size() == 2) {
            emit_flag_assign(o, "(" + c_read(ir.operands[0]) + " & " + c_read(ir.operands[1]) + ")");
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Shl:
        if (ir.width == 32 && ir.operands.size() == 2 && can_write(ir.operands[0]) && immediate_count_one(ir)) {
            string a = c_read(ir.operands[0]);
            o << "    { uint32_t a = " << a << "; bool carry = (a & 0x80000000u) != 0; uint32_t r = a << 1;\n";
            o << "      xr::runtime_set_logic_flags(ctx, r); ctx.cf = carry; ctx.of = (((r & 0x80000000u) != 0) != ctx.cf); " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Shr:
        if (ir.width == 32 && ir.operands.size() == 2 && can_write(ir.operands[0]) && immediate_count_one(ir)) {
            string a = c_read(ir.operands[0]);
            o << "    { uint32_t a = " << a << "; bool carry = (a & 1u) != 0; bool old_msb = (a & 0x80000000u) != 0; uint32_t r = a >> 1;\n";
            o << "      xr::runtime_set_logic_flags(ctx, r); ctx.cf = carry; ctx.of = old_msb; " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Sar:
        if (ir.width == 32 && ir.operands.size() == 2 && can_write(ir.operands[0]) && immediate_count_one(ir)) {
            string a = c_read(ir.operands[0]);
            o << "    { uint32_t a = " << a << "; bool carry = (a & 1u) != 0; uint32_t r = uint32_t(int32_t(a) >> 1);\n";
            o << "      xr::runtime_set_logic_flags(ctx, r); ctx.cf = carry; ctx.of = false; " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Rol:
        if (ir.width == 32 && ir.operands.size() == 2 && can_write(ir.operands[0]) && immediate_count_one(ir)) {
            string a = c_read(ir.operands[0]);
            o << "    { uint32_t a = " << a << "; uint32_t r = (a << 1) | (a >> 31);\n";
            o << "      ctx.cf = (r & 1u) != 0; ctx.of = (((r & 0x80000000u) != 0) != ctx.cf); " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Ror:
        if (ir.width == 32 && ir.operands.size() == 2 && can_write(ir.operands[0]) && immediate_count_one(ir)) {
            string a = c_read(ir.operands[0]);
            o << "    { uint32_t a = " << a << "; uint32_t r = (a >> 1) | (a << 31);\n";
            o << "      ctx.cf = (r & 0x80000000u) != 0; ctx.of = (((r & 0x80000000u) != 0) != ((r & 0x40000000u) != 0)); " << c_write(ir.operands[0], "r") << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Setcc:
        if (ir.operands.size() == 1 && ir.operands[0].kind == OperandKind::Reg && ir.operands[0].width == 8) {
            o << "    " << c_write(ir.operands[0], "(" + c_condition(ir) + ") ? 1u : 0u") << "\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Cmovcc:
        if (ir.width == 32 && ir.operands.size() == 2 && ir.operands[0].kind == OperandKind::Reg) {
            o << "    if (" << c_condition(ir) << ") { " << c_write(ir.operands[0], c_read(ir.operands[1])) << " }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Jump:
        if (block_has_label(cfg, ir.target)) o << "    goto " << label_for(ir.target) << ";\n";
        else o << "    xr::runtime_unresolved_jump(rt, ctx, " << c_imm(ir.address) << ", " << c_imm(ir.target) << "); return;\n";
        break;
    case IrOp::Branch:
        if (block_has_label(cfg, ir.target)) o << "    if (" << c_condition(ir) << ") goto " << label_for(ir.target) << ";\n";
        else o << "    if (" << c_condition(ir) << ") { xr::runtime_unresolved_jump(rt, ctx, " << c_imm(ir.address) << ", " << c_imm(ir.target) << "); return; }\n";
        break;
    case IrOp::Call:
        if (!patches_for(manifest, ir.target, PatchKind::ImportShim).empty()) {
            const auto* patch = patches_for(manifest, ir.target, PatchKind::ImportShim).front();
            o << "    if (!xr::runtime_import_shim_abi(rt, ctx, " << c_imm(ir.target) << ", " << c_string(patch->symbol)
              << ", " << c_string(patch->abi) << ")) xr::runtime_direct_call(rt, ctx, " << c_imm(ir.target) << ");\n";
        } else if (pack_entries && pack_entries->count(ir.target)) {
            o << "    if (!generated_dispatch(ctx, rt, " << c_imm(ir.target) << ")) xr::runtime_direct_call(rt, ctx, " << c_imm(ir.target) << ");\n";
        } else {
            o << "    xr::runtime_direct_call(rt, ctx, " << c_imm(ir.target) << ");\n";
        }
        break;
    case IrOp::IndirectCall:
        if (ir.operands.size() == 1) {
            auto indirect_shims = patches_for(manifest, ir.address, PatchKind::IndirectImportShim);
            if (!indirect_shims.empty()) {
                const auto* patch = indirect_shims.front();
                o << "    { uint32_t target = " << c_read(ir.operands[0]) << "; if (!xr::runtime_import_pointer_shim_abi(rt, ctx, "
                  << c_imm(ir.address) << ", target, " << c_string(patch->symbol) << ", " << c_string(patch->abi)
                  << ")) xr::runtime_indirect_call(rt, ctx, " << c_imm(ir.address) << ", target); }\n";
            } else {
                o << "    xr::runtime_indirect_call(rt, ctx, " << c_imm(ir.address) << ", " << c_read(ir.operands[0]) << ");\n";
            }
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::IndirectJump:
        if (ir.operands.size() == 1) {
            o << "    xr::runtime_indirect_jump(rt, ctx, " << c_imm(ir.address) << ", " << c_read(ir.operands[0]) << "); return;\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << "); return;\n";
        }
        break;
    case IrOp::Return:
        emit_after_hooks(o, manifest, cfg.entry);
        if (!ir.operands.empty() && ir.operands[0].kind == OperandKind::Imm) {
            o << "    ctx.esp += " << c_imm(ir.operands[0].imm) << ";\n";
        }
        o << "    return;\n";
        break;
    case IrOp::Push:
        if (ir.width == 32 && ir.operands.size() == 1) {
            o << "    xr::runtime_push32(rt, ctx, " << c_read(ir.operands[0]) << ");\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Pop:
        if (ir.width == 32 && ir.operands.size() == 1 && can_write(ir.operands[0])) {
            o << "    { uint32_t v = 0; if (xr::runtime_pop32(rt, ctx, v)) { " << c_write(ir.operands[0], "v") << " } }\n";
        } else {
            o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        }
        break;
    case IrOp::Leave:
        o << "    { ctx.esp = ctx.ebp; uint32_t v = 0; if (xr::runtime_pop32(rt, ctx, v)) ctx.ebp = v; }\n";
        break;
    case IrOp::Unsupported:
        o << "    xr::runtime_unsupported(rt, ctx, " << c_imm(ir.address) << ");\n";
        break;
    }
}

static void emit_generated_preamble(ostringstream& o) {
    o << "// Auto-generated by x86recomp - DO NOT EDIT.\n"
      << "// Generated output is disposable; change metadata, lifter, or codegen instead.\n"
      << "#include <cstdint>\n"
      << "#include \"runtime.hpp\"\n\n"
      << "using xr::cpu_state;\n"
      << "static bool unsupported_condition(cpu_state& ctx, xr::runtime_context& rt, uint32_t va) { xr::runtime_unsupported(rt, ctx, va); return false; }\n\n";
}

static void emit_generated_function(ostringstream& o, const CfgFunction& cfg, const PatchManifest& manifest,
                                    const set<uint32_t>* pack_entries = nullptr) {
    o << "void " << sub_name(cfg.entry) << "(cpu_state& ctx, xr::runtime_context& rt) {\n";

    for (const auto* patch : patches_for(manifest, cfg.entry, PatchKind::Trap)) {
        o << "    xr::runtime_patch_trap(rt, ctx, " << c_imm(patch->va) << ", " << c_string(patch->symbol) << ");\n";
    }
    for (const auto* patch : patches_for(manifest, cfg.entry, PatchKind::Replace)) {
        o << "    if (xr::runtime_patch_replace(rt, ctx, " << c_imm(patch->va) << ", " << c_string(patch->symbol) << ")) return;\n";
    }
    for (const auto* patch : patches_for(manifest, cfg.entry, PatchKind::BeforeHook)) {
        o << "    xr::runtime_patch_before(rt, ctx, " << c_imm(patch->va) << ", " << c_string(patch->symbol) << ");\n";
    }
    for (const auto* patch : patches_for(manifest, cfg.entry, PatchKind::SkipOriginal)) {
        o << "    if (xr::runtime_patch_skip_original(rt, ctx, " << c_imm(patch->va) << ", " << c_string(patch->symbol) << ")) return;\n";
    }

    for (const auto& block : cfg.blocks) {
        o << label_for(block.start) << ":\n";
        for (const auto& ir : block.instructions) emit_insn_c(o, cfg, manifest, ir, pack_entries);
    }
    o << "}\n\n";
}

string emit_cfg_c(const CfgFunction& cfg, const PatchManifest& manifest) {
    auto patch_issues = validate_patch_manifest(manifest);
    if (!patch_issues.empty()) throw runtime_error("invalid patch manifest: " + patch_issues.front());

    ostringstream o;
    emit_generated_preamble(o);
    emit_generated_function(o, cfg, manifest);
    o << "int main() { cpu_state ctx; xr::runtime_context rt; xr::runtime_map_memory(rt, 0u, 0x10000u); ctx.esp = 0x10000u; sub_"
      << uppercase << hex << setw(8) << setfill('0') << cfg.entry
      << "(ctx, rt); return rt.events.empty() ? 0 : 1; }\n";
    return o.str();
}

string emit_cfg_c(const CfgFunction& cfg) {
    return emit_cfg_c(cfg, PatchManifest{});
}

string emit_cfg_c_pack(const vector<CfgFunction>& cfgs, const PatchManifest& manifest) {
    if (cfgs.empty()) throw runtime_error("generated function pack is empty");
    auto patch_issues = validate_patch_manifest(manifest);
    if (!patch_issues.empty()) throw runtime_error("invalid patch manifest: " + patch_issues.front());
    set<uint32_t> entries;
    for (const auto& cfg : cfgs) {
        if (!entries.insert(cfg.entry).second) throw runtime_error("duplicate generated function entry");
    }

    ostringstream o;
    emit_generated_preamble(o);
    o << "// debug_function_pack_count: " << dec << cfgs.size() << "\n";
    for (const auto& cfg : cfgs) {
        o << "// debug_function_map: " << sub_name(cfg.entry)
          << " entry=" << c_imm(cfg.entry)
          << " range_start=" << c_imm(cfg.range_start)
          << " range_end=" << c_imm(cfg.range_end)
          << " blocks=" << dec << cfg.blocks.size() << "\n";
        for (uint32_t target : cfg.direct_call_targets) {
            bool resolved = entries.count(target) != 0;
            o << "// debug_direct_call_map: from=" << sub_name(cfg.entry)
              << " target=" << c_imm(target)
              << " resolved=" << (resolved ? "generated" : "runtime_direct_call") << "\n";
        }
        for (uint32_t site : cfg.indirect_call_sites) {
            o << "// debug_indirect_call_map: from=" << sub_name(cfg.entry)
              << " callsite=" << c_imm(site)
              << " resolved=runtime_indirect_call\n";
        }
    }
    for (const auto& patch : manifest.records) {
        if (!patch.enabled) continue;
        o << "// debug_patch_boundary: kind=" << patch_kind_name(patch.kind)
          << " va=" << c_imm(patch.va);
        if (!patch.symbol.empty()) o << " symbol=" << patch.symbol;
        if (!patch.abi.empty()) o << " abi=" << patch.abi;
        if (!patch.dll.empty()) o << " dll=" << patch.dll;
        if (patch.iat_va) o << " iat_va=" << c_imm(patch.iat_va);
        if (patch.iat_rva) o << " iat_rva=" << c_imm(patch.iat_rva);
        if (!patch.side_effects.empty()) o << " side_effects=" << patch.side_effects;
        o << "\n";
    }
    o << "\n";
    for (const auto& cfg : cfgs) {
        o << "void " << sub_name(cfg.entry) << "(cpu_state& ctx, xr::runtime_context& rt);\n";
    }
    o << "\n";
    o << "using generated_fn = void(*)(cpu_state&, xr::runtime_context&);\n";
    o << "struct generated_function_record { uint32_t entry; generated_fn fn; const char* name; };\n";
    o << "static const generated_function_record k_generated_functions[] = {\n";
    for (const auto& cfg : cfgs) {
        o << "    {" << c_imm(cfg.entry) << ", &" << sub_name(cfg.entry) << ", \"" << sub_name(cfg.entry) << "\"},\n";
    }
    o << "};\n";
    o << "static bool generated_dispatch(cpu_state& ctx, xr::runtime_context& rt, uint32_t entry) { ";
    o << "for (const auto& record : k_generated_functions) { if (record.entry == entry) { record.fn(ctx, rt); return true; } } return false; }\n\n";
    for (const auto& cfg : cfgs) emit_generated_function(o, cfg, manifest, &entries);
    o << "int main() { xr::runtime_context rt; xr::runtime_map_memory(rt, 0u, 0x10000u);";
    for (const auto& cfg : cfgs) {
        o << " { cpu_state ctx; ctx.esp = 0x10000u; sub_"
          << uppercase << hex << setw(8) << setfill('0') << cfg.entry
          << "(ctx, rt); if (!rt.events.empty()) return 1; }";
    }
    o << " return 0; }\n";
    return o.str();
}

string format_generated_dispatch_table(const vector<CfgFunction>& cfgs) {
    if (cfgs.empty()) throw runtime_error("generated function pack is empty");
    set<uint32_t> entries;
    ostringstream o;
    o << "generated_dispatch_entries: " << cfgs.size() << "\n";
    for (const auto& cfg : cfgs) {
        if (!entries.insert(cfg.entry).second) throw runtime_error("duplicate generated function entry");
        o << "generated_dispatch_entry: entry=" << hx(cfg.entry)
          << " symbol=" << sub_name(cfg.entry)
          << " range_start=" << hx(cfg.range_start)
          << " range_end=" << hx(cfg.range_end)
          << " blocks=" << cfg.blocks.size() << "\n";
    }
    return o.str();
}

string emit_c(const vector<Ins>& is) {
    ostringstream o;
    o << "void sub_raw(cpu_state* ctx){\n";
    for (auto& i : is) {
        o << "  // " << hx(i.a) << " " << i.m << (i.o.empty() ? "" : " " + i.o) << "\n";
        if (!i.ok) o << "  unsupported(" << hx(i.a) << ");\n";
        if (i.m == "ret") o << "  return;\n";
    }
    return o.str() + "}\n";
}

static vector<PeSection> parse_sections(const vector<uint8_t>& d, size_t sec_off,
                                        uint16_t section_count) {
    need(d, sec_off, size_t(section_count) * 40, "section table");
    vector<PeSection> secs;
    secs.reserve(section_count);
    for (uint16_t i = 0; i < section_count; ++i) {
        size_t s = sec_off + size_t(i) * 40;
        PeSection ps;
        ps.name = section_name(d, s);
        ps.virtual_size = u32(d, s + 8);
        ps.virtual_address = u32(d, s + 12);
        ps.raw_size = u32(d, s + 16);
        ps.raw_ptr = u32(d, s + 20);
        ps.characteristics = u32(d, s + 36);
        if (ps.raw_size) need(d, ps.raw_ptr, ps.raw_size, "section raw data");
        secs.push_back(ps);
    }
    return secs;
}

static vector<PeImportFunction> parse_thunks(const vector<uint8_t>& d, const vector<PeSection>& secs,
                                             uint32_t thunk_rva, uint32_t iat_rva) {
    vector<PeImportFunction> functions;
    if (!thunk_rva) return functions;
    size_t thunk_off = rva_to_file(secs, thunk_rva);
    for (size_t idx = 0;; ++idx) {
        need(d, thunk_off + idx * 4, 4, "import thunk");
        uint32_t thunk = u32(d, thunk_off + idx * 4);
        if (!thunk) break;
        PeImportFunction fn;
        fn.iat_rva = iat_rva + uint32_t(idx * 4);
        if (thunk & 0x80000000u) {
            fn.by_ordinal = true;
            fn.ordinal = uint16_t(thunk & 0xffffu);
        } else {
            size_t hint_name = rva_to_file(secs, thunk);
            fn.hint = u16(d, hint_name);
            fn.name = cstr(d, hint_name + 2, "import function name");
        }
        functions.push_back(fn);
        if (functions.size() > 65536) throw runtime_error("too many import functions");
    }
    return functions;
}

static vector<PeImportDll> parse_imports(const vector<uint8_t>& d, const vector<PeSection>& secs,
                                         const PeDataDirectory& dirent) {
    vector<PeImportDll> imports;
    if (!dirent.rva) return imports;
    size_t dir = rva_to_file(secs, dirent.rva);
    if (dirent.size) need(d, dir, dirent.size, "import directory");
    for (size_t pos = dir;; pos += 20) {
        need(d, pos, 20, "import descriptor");
        uint32_t original_first_thunk = u32(d, pos);
        uint32_t time_date_stamp = u32(d, pos + 4);
        uint32_t forwarder_chain = u32(d, pos + 8);
        uint32_t name_rva = u32(d, pos + 12);
        uint32_t first_thunk = u32(d, pos + 16);
        if (!original_first_thunk && !time_date_stamp && !forwarder_chain && !name_rva && !first_thunk) break;
        PeImportDll dll;
        dll.descriptor_rva = dirent.rva + uint32_t(pos - dir);
        dll.original_first_thunk_rva = original_first_thunk;
        dll.first_thunk_rva = first_thunk;
        dll.name = cstr(d, rva_to_file(secs, name_rva), "import name");
        uint32_t thunk_rva = original_first_thunk ? original_first_thunk : first_thunk;
        dll.functions = parse_thunks(d, secs, thunk_rva, first_thunk);
        imports.push_back(dll);
        if (imports.size() > 4096) throw runtime_error("too many imports");
    }
    return imports;
}

static vector<PeDelayImportDll> parse_delay_imports(const vector<uint8_t>& d, const vector<PeSection>& secs,
                                                    const PeDataDirectory& dirent) {
    vector<PeDelayImportDll> imports;
    if (!dirent.rva) return imports;
    size_t dir = rva_to_file(secs, dirent.rva);
    if (dirent.size) need(d, dir, dirent.size, "delay import directory");
    for (size_t pos = dir;; pos += 32) {
        need(d, pos, 32, "delay import descriptor");
        uint32_t attrs = u32(d, pos);
        uint32_t name_rva = u32(d, pos + 4);
        uint32_t iat_rva = u32(d, pos + 12);
        uint32_t int_rva = u32(d, pos + 16);
        if (!attrs && !name_rva && !iat_rva && !int_rva) break;
        PeDelayImportDll dll;
        dll.descriptor_rva = dirent.rva + uint32_t(pos - dir);
        dll.iat_rva = iat_rva;
        dll.import_name_table_rva = int_rva;
        dll.name = cstr(d, rva_to_file(secs, name_rva), "delay import name");
        dll.functions = parse_thunks(d, secs, int_rva ? int_rva : iat_rva, iat_rva);
        imports.push_back(dll);
        if (imports.size() > 4096) throw runtime_error("too many delay imports");
    }
    return imports;
}

static vector<PeRelocationBlock> parse_relocations(const vector<uint8_t>& d, const vector<PeSection>& secs,
                                                   const PeDataDirectory& dirent) {
    vector<PeRelocationBlock> blocks;
    if (!dirent.rva) return blocks;
    size_t off = rva_to_file(secs, dirent.rva);
    size_t end = off + dirent.size;
    need(d, off, dirent.size, "relocation directory");
    while (off + 8 <= end) {
        uint32_t page_rva = u32(d, off);
        uint32_t block_size = u32(d, off + 4);
        if (!page_rva && !block_size) break;
        if (block_size < 8 || off + block_size > end) throw runtime_error("malformed relocation block");
        blocks.push_back({page_rva, block_size, (block_size - 8) / 2});
        off += block_size;
        if (blocks.size() > 65536) throw runtime_error("too many relocation blocks");
    }
    return blocks;
}

static PeTlsInfo parse_tls(const vector<uint8_t>& d, const vector<PeSection>& secs,
                           const PeDataDirectory& dirent) {
    PeTlsInfo tls;
    if (!dirent.rva) return tls;
    size_t off = rva_to_file(secs, dirent.rva);
    need(d, off, 24, "tls directory");
    tls.present = true;
    tls.start_raw = u32(d, off);
    tls.end_raw = u32(d, off + 4);
    tls.index_rva = u32(d, off + 8);
    tls.callbacks_rva = u32(d, off + 12);
    tls.size_zero_fill = u32(d, off + 16);
    tls.characteristics = u32(d, off + 20);
    return tls;
}

static vector<PeExport> parse_exports(const vector<uint8_t>& d, const vector<PeSection>& secs,
                                      const PeDataDirectory& dirent) {
    vector<PeExport> exports;
    if (!dirent.rva) return exports;
    size_t off = rva_to_file(secs, dirent.rva);
    need(d, off, 40, "export directory");
    uint32_t ordinal_base = u32(d, off + 16);
    uint32_t number_of_functions = u32(d, off + 20);
    uint32_t number_of_names = u32(d, off + 24);
    uint32_t address_of_functions = u32(d, off + 28);
    uint32_t address_of_names = u32(d, off + 32);
    uint32_t address_of_name_ordinals = u32(d, off + 36);
    if (!number_of_names) return exports;
    size_t funcs_off = rva_to_file(secs, address_of_functions);
    size_t names_off = rva_to_file(secs, address_of_names);
    size_t ords_off = rva_to_file(secs, address_of_name_ordinals);
    for (uint32_t i = 0; i < number_of_names; ++i) {
        uint32_t name_rva = u32(d, names_off + size_t(i) * 4);
        uint16_t ordinal_index = u16(d, ords_off + size_t(i) * 2);
        if (ordinal_index >= number_of_functions) throw runtime_error("export ordinal out of range");
        PeExport ex;
        ex.name = cstr(d, rva_to_file(secs, name_rva), "export name");
        ex.ordinal = uint16_t(ordinal_base + ordinal_index);
        ex.rva = u32(d, funcs_off + size_t(ordinal_index) * 4);
        if (rva_in_range(ex.rva, dirent.rva, dirent.size)) {
            ex.forwarder = cstr(d, rva_to_file(secs, ex.rva), "export forwarder");
        }
        exports.push_back(ex);
        if (exports.size() > 65536) throw runtime_error("too many exports");
    }
    return exports;
}

PeInfo inspect_pe_info(const filesystem::path& p) {
    vector<uint8_t> d = read_file(p);
    if (d.size() < 0x40 || d[0] != 'M' || d[1] != 'Z') throw runtime_error("not MZ");
    uint32_t pe = u32(d, 0x3c);
    need(d, pe, 0x18, "PE header");
    if (d[pe] != 'P' || d[pe + 1] != 'E' || d[pe + 2] != 0 || d[pe + 3] != 0) {
        throw runtime_error("not PE");
    }
    PeInfo info;
    info.fnv1a64 = fnv1a64(d);
    info.machine = u16(d, pe + 4);
    info.section_count = u16(d, pe + 6);
    info.timestamp = u32(d, pe + 8);
    uint16_t optional_size = u16(d, pe + 20);
    size_t opt = pe + 24;
    need(d, opt, optional_size, "optional header");
    info.optional_magic = u16(d, opt);
    if (info.optional_magic != 0x10b) throw runtime_error("unsupported optional header");
    info.linker_major = d[opt + 2];
    info.linker_minor = d[opt + 3];
    info.entrypoint_rva = u32(d, opt + 16);
    info.image_base = u32(d, opt + 28);
    info.section_alignment = u32(d, opt + 32);
    info.file_alignment = u32(d, opt + 36);
    info.size_of_image = u32(d, opt + 56);
    info.size_of_headers = u32(d, opt + 60);
    info.checksum = u32(d, opt + 64);
    info.subsystem = u16(d, opt + 68);
    info.dll_characteristics = u16(d, opt + 70);
    uint32_t directory_count = optional_size >= 96 ? u32(d, opt + 92) : 0;
    uint32_t capped_directories = min<uint32_t>(directory_count, 16);
    info.directories.resize(capped_directories);
    for (uint32_t i = 0; i < capped_directories; ++i) {
        size_t dd = opt + 96 + size_t(i) * 8;
        need(d, dd, 8, "data directory");
        info.directories[i] = {u32(d, dd), u32(d, dd + 4)};
    }
    size_t sec_off = opt + optional_size;
    info.sections = parse_sections(d, sec_off, info.section_count);
    uint32_t max_raw_end = 0;
    for (const auto& s : info.sections) {
        max_raw_end = max(max_raw_end, s.raw_ptr + s.raw_size);
        string name = s.name;
        if (name == "UPX0" || name == "UPX1" || name == ".aspack" || name == ".vmp0" || name == ".themida") {
            info.issues.push_back({"packer_section", name});
        }
        if (name == ".cms_t" || name == "stxt371" || name == "stxt2" || name == ".bind") {
            info.issues.push_back({"protection_section", name});
        }
    }
    if (d.size() > max_raw_end) info.overlay_size = uint32_t(d.size() - max_raw_end);
    if (contains_bytes(d, "AddD")) info.issues.push_back({"protection_signature", "AddD"});
    if (contains_bytes(d, "SecuROM")) info.issues.push_back({"protection_signature", "SecuROM"});
    if (contains_bytes(d, "SafeDisc")) info.issues.push_back({"protection_signature", "SafeDisc"});
    if (contains_bytes(d, "UPX!")) info.issues.push_back({"packer_signature", "UPX!"});
    if (info.directories.size() > 1) info.imports = parse_imports(d, info.sections, info.directories[1]);
    if (!info.directories.empty()) info.exports = parse_exports(d, info.sections, info.directories[0]);
    if (info.directories.size() > 5) info.relocations = parse_relocations(d, info.sections, info.directories[5]);
    if (info.directories.size() > 9) info.tls = parse_tls(d, info.sections, info.directories[9]);
    if (info.directories.size() > 13) info.delay_imports = parse_delay_imports(d, info.sections, info.directories[13]);
    return info;
}

string format_pe_summary(const PeInfo& info) {
    size_t import_function_count = 0;
    for (const auto& dll : info.imports) import_function_count += dll.functions.size();
    size_t delay_import_function_count = 0;
    for (const auto& dll : info.delay_imports) delay_import_function_count += dll.functions.size();
    uint64_t relocation_entry_count = 0;
    for (const auto& block : info.relocations) relocation_entry_count += block.entry_count;
    ostringstream o;
    o << "machine: " << hx16(info.machine) << "\n"
      << "sections: " << info.section_count << "\n"
      << "optional_magic: " << hx16(info.optional_magic) << "\n"
      << "image_base: " << hx(info.image_base) << "\n"
      << "entrypoint_rva: " << hx(info.entrypoint_rva) << "\n"
      << "entrypoint_va: " << hx(info.image_base + info.entrypoint_rva) << "\n"
      << "linker_version: " << unsigned(info.linker_major) << "." << unsigned(info.linker_minor) << "\n"
      << "timestamp: " << hx(info.timestamp) << "\n"
      << "subsystem: " << hx16(info.subsystem) << "\n"
      << "dll_characteristics: " << hx16(info.dll_characteristics) << "\n"
      << "fnv1a64: " << hx64(info.fnv1a64) << "\n"
      << "overlay_size: " << info.overlay_size << "\n"
      << "section_alignment: " << hx(info.section_alignment) << "\n"
      << "file_alignment: " << hx(info.file_alignment) << "\n"
      << "size_of_image: " << hx(info.size_of_image) << "\n"
      << "size_of_headers: " << hx(info.size_of_headers) << "\n";
    for (const auto& s : info.sections) {
        o << "section: " << s.name
          << " va=" << hx(s.virtual_address)
          << " vsize=" << hx(s.virtual_size)
          << " raw=" << hx(s.raw_ptr)
          << " raw_size=" << hx(s.raw_size)
          << " characteristics=" << hx(s.characteristics) << "\n";
    }
    PeDataDirectory import_dir = info.directories.size() > 1 ? info.directories[1] : PeDataDirectory{};
    PeDataDirectory export_dir = !info.directories.empty() ? info.directories[0] : PeDataDirectory{};
    o << "export_directory_rva: " << hx(export_dir.rva) << "\n"
      << "export_directory_size: " << hx(export_dir.size) << "\n"
      << "exports: " << info.exports.size() << "\n";
    for (const auto& ex : info.exports) {
        o << "export: ordinal=" << ex.ordinal << " rva=" << hx(ex.rva) << " name=" << ex.name;
        if (!ex.forwarder.empty()) o << " forwarder=" << ex.forwarder;
        o << "\n";
    }
    o << "import_directory_rva: " << hx(import_dir.rva) << "\n"
      << "import_directory_size: " << hx(import_dir.size) << "\n"
      << "imports: " << info.imports.size() << "\n"
      << "import_functions: " << import_function_count << "\n";
    for (const auto& dll : info.imports) {
        o << "import: " << dll.name << " functions=" << dll.functions.size()
          << " first_thunk=" << hx(dll.first_thunk_rva)
          << " original_first_thunk=" << hx(dll.original_first_thunk_rva) << "\n";
        for (const auto& fn : dll.functions) {
            o << "import_function: " << dll.name << " iat=" << hx(fn.iat_rva) << " ";
            if (fn.by_ordinal) o << "ordinal=" << fn.ordinal;
            else o << "hint=" << fn.hint << " name=" << fn.name;
            o << "\n";
        }
    }
    PeDataDirectory reloc_dir = info.directories.size() > 5 ? info.directories[5] : PeDataDirectory{};
    PeDataDirectory tls_dir = info.directories.size() > 9 ? info.directories[9] : PeDataDirectory{};
    PeDataDirectory delay_dir = info.directories.size() > 13 ? info.directories[13] : PeDataDirectory{};
    o << "relocation_directory_rva: " << hx(reloc_dir.rva) << "\n"
      << "relocation_directory_size: " << hx(reloc_dir.size) << "\n"
      << "relocation_blocks: " << info.relocations.size() << "\n"
      << "relocation_entries: " << relocation_entry_count << "\n";
    for (const auto& block : info.relocations) {
        o << "relocation_block: page_rva=" << hx(block.page_rva)
          << " entries=" << block.entry_count << "\n";
    }
    o << "tls_directory_rva: " << hx(tls_dir.rva) << "\n"
      << "tls_directory_size: " << hx(tls_dir.size) << "\n"
      << "tls_present: " << (info.tls.present ? "true" : "false") << "\n";
    if (info.tls.present) {
        o << "tls: start_raw=" << hx(info.tls.start_raw)
          << " end_raw=" << hx(info.tls.end_raw)
          << " index_rva=" << hx(info.tls.index_rva)
          << " callbacks_rva=" << hx(info.tls.callbacks_rva)
          << " zero_fill=" << hx(info.tls.size_zero_fill)
          << " characteristics=" << hx(info.tls.characteristics) << "\n";
    }
    o << "delay_import_directory_rva: " << hx(delay_dir.rva) << "\n"
      << "delay_import_directory_size: " << hx(delay_dir.size) << "\n"
      << "delay_imports: " << info.delay_imports.size() << "\n"
      << "delay_import_functions: " << delay_import_function_count << "\n";
    for (const auto& dll : info.delay_imports) {
        o << "delay_import: " << dll.name << " functions=" << dll.functions.size()
          << " iat=" << hx(dll.iat_rva)
          << " int=" << hx(dll.import_name_table_rva) << "\n";
    }
    o << "issues: " << info.issues.size() << "\n";
    for (const auto& issue : info.issues) {
        o << "issue: " << issue.code << " detail=" << issue.detail << "\n";
    }
    return o.str();
}

string format_pe_json(const PeInfo& info) {
    size_t import_function_count = 0;
    for (const auto& dll : info.imports) import_function_count += dll.functions.size();
    size_t delay_import_function_count = 0;
    for (const auto& dll : info.delay_imports) delay_import_function_count += dll.functions.size();
    uint64_t relocation_entry_count = 0;
    for (const auto& block : info.relocations) relocation_entry_count += block.entry_count;
    ostringstream o;
    o << "{\n";
    o << "  \"machine\": " << info.machine << ",\n";
    o << "  \"section_count\": " << info.section_count << ",\n";
    o << "  \"optional_magic\": " << info.optional_magic << ",\n";
    o << "  \"image_base\": " << info.image_base << ",\n";
    o << "  \"entrypoint_rva\": " << info.entrypoint_rva << ",\n";
    o << "  \"entrypoint_va\": " << info.image_base + info.entrypoint_rva << ",\n";
    o << "  \"linker_version\": \"" << unsigned(info.linker_major) << "." << unsigned(info.linker_minor) << "\",\n";
    o << "  \"timestamp\": " << info.timestamp << ",\n";
    o << "  \"subsystem\": " << info.subsystem << ",\n";
    o << "  \"dll_characteristics\": " << info.dll_characteristics << ",\n";
    o << "  \"fnv1a64\": \"" << hx64(info.fnv1a64) << "\",\n";
    o << "  \"overlay_size\": " << info.overlay_size << ",\n";
    o << "  \"size_of_image\": " << info.size_of_image << ",\n";
    o << "  \"size_of_headers\": " << info.size_of_headers << ",\n";
    o << "  \"sections\": [\n";
    for (size_t i = 0; i < info.sections.size(); ++i) {
        const auto& s = info.sections[i];
        o << "    {\"name\": \"" << json_escape(s.name) << "\", \"virtual_address\": " << s.virtual_address
          << ", \"virtual_size\": " << s.virtual_size << ", \"raw_ptr\": " << s.raw_ptr
          << ", \"raw_size\": " << s.raw_size << ", \"characteristics\": " << s.characteristics << "}"
          << (i + 1 == info.sections.size() ? "\n" : ",\n");
    }
    o << "  ],\n";
    o << "  \"exports\": [\n";
    for (size_t i = 0; i < info.exports.size(); ++i) {
        const auto& ex = info.exports[i];
        o << "    {\"name\": \"" << json_escape(ex.name) << "\", \"ordinal\": " << ex.ordinal
          << ", \"rva\": " << ex.rva << ", \"forwarder\": \"" << json_escape(ex.forwarder) << "\"}"
          << (i + 1 == info.exports.size() ? "\n" : ",\n");
    }
    o << "  ],\n";
    o << "  \"imports\": [\n";
    for (size_t i = 0; i < info.imports.size(); ++i) {
        const auto& dll = info.imports[i];
        o << "    {\"name\": \"" << json_escape(dll.name) << "\", \"first_thunk_rva\": "
          << dll.first_thunk_rva << ", \"original_first_thunk_rva\": " << dll.original_first_thunk_rva
          << ", \"functions\": [";
        for (size_t j = 0; j < dll.functions.size(); ++j) {
            const auto& fn = dll.functions[j];
            if (j) o << ", ";
            o << "{\"iat_rva\": " << fn.iat_rva << ", \"by_ordinal\": " << (fn.by_ordinal ? "true" : "false")
              << ", \"ordinal\": " << fn.ordinal << ", \"hint\": " << fn.hint
              << ", \"name\": \"" << json_escape(fn.name) << "\"}";
        }
        o << "]}" << (i + 1 == info.imports.size() ? "\n" : ",\n");
    }
    o << "  ],\n";
    o << "  \"import_function_count\": " << import_function_count << ",\n";
    o << "  \"delay_imports\": [\n";
    for (size_t i = 0; i < info.delay_imports.size(); ++i) {
        const auto& dll = info.delay_imports[i];
        o << "    {\"name\": \"" << json_escape(dll.name) << "\", \"iat_rva\": " << dll.iat_rva
          << ", \"import_name_table_rva\": " << dll.import_name_table_rva
          << ", \"function_count\": " << dll.functions.size() << "}"
          << (i + 1 == info.delay_imports.size() ? "\n" : ",\n");
    }
    o << "  ],\n";
    o << "  \"delay_import_function_count\": " << delay_import_function_count << ",\n";
    o << "  \"relocation_blocks\": " << info.relocations.size() << ",\n";
    o << "  \"relocation_entries\": " << relocation_entry_count << ",\n";
    o << "  \"tls_present\": " << (info.tls.present ? "true" : "false") << ",\n";
    o << "  \"issues\": [\n";
    for (size_t i = 0; i < info.issues.size(); ++i) {
        const auto& issue = info.issues[i];
        o << "    {\"code\": \"" << json_escape(issue.code) << "\", \"detail\": \"" << json_escape(issue.detail) << "\"}"
          << (i + 1 == info.issues.size() ? "\n" : ",\n");
    }
    o << "  ]\n";
    o << "}\n";
    return o.str();
}

string inspect_pe(const filesystem::path& p) {
    return format_pe_summary(inspect_pe_info(p));
}

static bool pe_section_readable(const PeSection& section) {
    return (section.characteristics & 0x40000000u) != 0;
}

static bool pe_section_writable(const PeSection& section) {
    return (section.characteristics & 0x80000000u) != 0;
}

static bool pe_section_executable(const PeSection& section) {
    return (section.characteristics & 0x20000000u) != 0;
}

string format_pe_image_map_summary(const PeInfo& info) {
    ostringstream o;
    o << "pe_image_map: image_base=" << hx(info.image_base)
      << " size_of_image=" << info.size_of_image << "\n"
      << "pe_image_map_sections: " << info.sections.size() << "\n";
    vector<string> issues;
    vector<pair<uint32_t, uint32_t>> ranges;
    if (!info.image_base) issues.push_back("invalid image base");
    if (!info.size_of_image) issues.push_back("invalid image size");
    for (const auto& section : info.sections) {
        uint32_t mapped_size = max(section.raw_size, section.virtual_size);
        uint64_t end_rva = uint64_t(section.virtual_address) + uint64_t(mapped_size);
        o << "pe_image_map_section: name=" << section.name
          << " va=" << hx(info.image_base + section.virtual_address)
          << " rva=" << hx(section.virtual_address)
          << " raw_size=" << section.raw_size
          << " virtual_size=" << section.virtual_size
          << " readable=" << (pe_section_readable(section) ? "true" : "false")
          << " writable=" << (pe_section_writable(section) ? "true" : "false")
          << " executable=" << (pe_section_executable(section) ? "true" : "false") << "\n";
        if (!mapped_size) issues.push_back("section " + section.name + " empty mapped size");
        if (end_rva > info.size_of_image) issues.push_back("section " + section.name + " section overflow");
        uint32_t begin = section.virtual_address;
        uint32_t end = uint32_t(min<uint64_t>(end_rva, 0xffffffffull));
        for (const auto& [other_begin, other_end] : ranges) {
            if (begin < other_end && other_begin < end) {
                issues.push_back("section " + section.name + " overlaps another section");
                break;
            }
        }
        ranges.push_back({begin, end});
    }
    o << "pe_image_map_issues: " << issues.size() << "\n";
    for (const auto& issue : issues) o << "pe_image_map_issue: " << issue << "\n";
    return o.str();
}

OpcodeHistogram unsupported_opcode_histogram(const filesystem::path& p) {
    vector<uint8_t> d = read_file(p);
    PeInfo info = inspect_pe_info(p);
    map<uint8_t, uint64_t> counts;
    OpcodeHistogram hist;
    for (const auto& s : info.sections) {
        bool executable = (s.characteristics & 0x20000000u) || (s.characteristics & 0x00000020u);
        if (!executable || !s.raw_size) continue;
        need(d, s.raw_ptr, s.raw_size, "histogram section raw data");
        vector<uint8_t> bytes(d.begin() + s.raw_ptr, d.begin() + s.raw_ptr + s.raw_size);
        auto decoded = decode(bytes, info.image_base + s.virtual_address);
        for (const auto& ins : decoded) {
            ++hist.total;
            if (ins.ok) {
                ++hist.supported;
            } else {
                ++hist.unsupported;
                if (!ins.b.empty()) ++counts[ins.b[0]];
            }
        }
    }
    for (const auto& [op, count] : counts) hist.unsupported_opcodes.push_back({op, count});
    sort(hist.unsupported_opcodes.begin(), hist.unsupported_opcodes.end(),
         [](const auto& a, const auto& b) { return a.second == b.second ? a.first < b.first : a.second > b.second; });
    return hist;
}

string format_opcode_histogram(const OpcodeHistogram& hist) {
    ostringstream o;
    o << "instructions: " << hist.total << "\n"
      << "supported: " << hist.supported << "\n"
      << "unsupported: " << hist.unsupported << "\n"
      << "unsupported_opcodes: " << hist.unsupported_opcodes.size() << "\n";
    for (const auto& [op, count] : hist.unsupported_opcodes) {
        o << "unsupported_opcode: " << hx(op) << " count=" << count << "\n";
    }
    return o.str();
}

PeSliceAnalysis analyze_pe_slice(const filesystem::path& p, uint32_t rva, uint32_t size) {
    if (!size) throw runtime_error("slice size must be nonzero");
    vector<uint8_t> d = read_file(p);
    PeInfo info = inspect_pe_info(p);
    const PeSection* section = nullptr;
    for (const auto& s : info.sections) {
        if (rva_in_section(s, rva)) {
            section = &s;
            break;
        }
    }
    if (!section) throw runtime_error("slice rva not mapped");
    uint32_t delta = rva - section->virtual_address;
    if (delta > section->raw_size || size > section->raw_size - delta) {
        throw runtime_error("slice exceeds raw section data");
    }
    size_t off = size_t(section->raw_ptr) + delta;
    need(d, off, size, "slice raw data");
    vector<uint8_t> bytes(d.begin() + off, d.begin() + off + size);

    PeSliceAnalysis analysis;
    analysis.rva = rva;
    analysis.va = info.image_base + rva;
    analysis.size = size;
    analysis.file_offset = uint32_t(off);
    analysis.section_name = section->name;

    auto decoded = decode(bytes, analysis.va);
    auto irs = lift_ir(decoded);
    map<uint8_t, uint64_t> counts;
    for (const auto& ins : decoded) {
        ++analysis.instructions;
        if (ins.ok) {
            ++analysis.supported;
        } else {
            ++analysis.unsupported;
            if (!ins.b.empty()) ++counts[ins.b[0]];
        }
    }
    for (const auto& ir : irs) {
        if (!ir.ok || ir.op == IrOp::Unsupported) ++analysis.unsupported_ir;
    }
    for (const auto& [op, count] : counts) analysis.unsupported_opcodes.push_back({op, count});
    sort(analysis.unsupported_opcodes.begin(), analysis.unsupported_opcodes.end(),
         [](const auto& a, const auto& b) { return a.second == b.second ? a.first < b.first : a.second > b.second; });

    analysis.cfg = build_cfg(bytes, analysis.va, analysis.va);
    analysis.cfg_complete = !analysis.cfg.blocks.empty() && analysis.cfg.diagnostics.empty();
    if (analysis.cfg_complete) {
        for (const auto& block : analysis.cfg.blocks) {
            if (block.has_unsupported) analysis.cfg_complete = false;
            for (const auto& edge : block.edges) {
                if (edge.kind == CfgEdgeKind::Unresolved ||
                    edge.kind == CfgEdgeKind::IndirectCall ||
                    edge.kind == CfgEdgeKind::IndirectJump) {
                    analysis.cfg_complete = false;
                }
            }
        }
    }
    analysis.generated_candidate = analysis.cfg_complete && analysis.unsupported == 0 && analysis.unsupported_ir == 0;
    return analysis;
}

string format_pe_slice_analysis(const PeSliceAnalysis& analysis) {
    ostringstream o;
    o << "slice_rva: " << hx(analysis.rva) << "\n"
      << "slice_va: " << hx(analysis.va) << "\n"
      << "slice_size: " << analysis.size << "\n"
      << "slice_file_offset: " << hx(analysis.file_offset) << "\n"
      << "slice_section: " << analysis.section_name << "\n"
      << "slice_instructions: " << analysis.instructions << "\n"
      << "slice_supported: " << analysis.supported << "\n"
      << "slice_unsupported: " << analysis.unsupported << "\n"
      << "slice_unsupported_ir: " << analysis.unsupported_ir << "\n"
      << "slice_unsupported_opcodes: " << analysis.unsupported_opcodes.size() << "\n";
    for (const auto& [op, count] : analysis.unsupported_opcodes) {
        o << "slice_unsupported_opcode: " << hx(op) << " count=" << count << "\n";
    }
    o << "slice_cfg_blocks: " << analysis.cfg.blocks.size() << "\n"
      << "slice_cfg_calls: " << analysis.cfg.direct_call_targets.size() << "\n"
      << "slice_cfg_indirect_calls: " << analysis.cfg.indirect_call_sites.size() << "\n"
      << "slice_cfg_indirect_jumps: " << analysis.cfg.indirect_jump_sites.size() << "\n"
      << "slice_cfg_complete: " << (analysis.cfg_complete ? "true" : "false") << "\n"
      << "slice_generated_candidate: " << (analysis.generated_candidate ? "true" : "false") << "\n";
    for (const auto& diagnostic : analysis.cfg.diagnostics) {
        o << "slice_cfg_diagnostic: " << diagnostic << "\n";
    }
    return o.str();
}

static string section_for_rva(const PeInfo& info, uint32_t rva);

static string function_manifest_key(const FunctionPackManifestFunction& fn, uint32_t image_base) {
    if (fn.has_rva) return "rva=" + hx(fn.rva);
    if (fn.has_va && fn.va >= image_base) return "rva=" + hx(fn.va - image_base);
    if (fn.has_va) return "va=" + hx(fn.va);
    return "unaddressed";
}

static uint32_t resolve_function_manifest_rva(const FunctionPackManifest& manifest,
                                              const FunctionPackManifestFunction& fn) {
    if (fn.has_rva) return fn.rva;
    if (!fn.has_va || fn.va < manifest.image_base) throw runtime_error("function manifest record cannot resolve rva");
    return fn.va - manifest.image_base;
}

FunctionPackManifest parse_function_pack_manifest_text(const string& text) {
    FunctionPackManifest manifest;
    istringstream input(text);
    string line;
    uint32_t line_no = 0;
    bool have_image = false;
    while (getline(input, line)) {
        ++line_no;
        auto comment = line.find('#');
        if (comment != string::npos) line = line.substr(0, comment);
        line = trim_copy(line);
        if (line.empty()) continue;
        auto tokens = split_manifest_tokens(line);
        if (tokens.empty()) continue;
        if (tokens[0] == "image") {
            if (have_image) throw runtime_error("function pack manifest line " + to_string(line_no) + " duplicate image record");
            have_image = true;
            for (size_t i = 1; i < tokens.size(); ++i) {
                auto eq = tokens[i].find('=');
                if (eq == string::npos) throw runtime_error("function pack manifest line " + to_string(line_no) + " token missing '='");
                string key = tokens[i].substr(0, eq);
                string value = tokens[i].substr(eq + 1);
                if (key == "path" || key == "pe") {
                    manifest.image_path = value;
                } else if (key == "image_base") {
                    manifest.image_base = parse_manifest_u32(value, key);
                } else if (key == "file_hash" || key == "fnv1a64") {
                    manifest.file_hash = parse_manifest_u64(value, key);
                } else {
                    throw runtime_error("function pack manifest line " + to_string(line_no) + " unknown image field " + key);
                }
            }
        } else if (tokens[0] == "function") {
            FunctionPackManifestFunction fn;
            for (size_t i = 1; i < tokens.size(); ++i) {
                auto eq = tokens[i].find('=');
                if (eq == string::npos) throw runtime_error("function pack manifest line " + to_string(line_no) + " token missing '='");
                string key = tokens[i].substr(0, eq);
                string value = tokens[i].substr(eq + 1);
                if (key == "va") {
                    fn.va = parse_manifest_u32(value, key);
                    fn.has_va = true;
                } else if (key == "rva") {
                    fn.rva = parse_manifest_u32(value, key);
                    fn.has_rva = true;
                } else if (key == "size") {
                    fn.size = parse_manifest_u32(value, key);
                } else if (key == "source") {
                    fn.source = value;
                } else if (key == "confidence") {
                    fn.confidence = value;
                } else if (key == "section") {
                    fn.section = value;
                } else if (key == "evidence") {
                    fn.evidence = value;
                } else if (key == "rollback") {
                    fn.rollback = value;
                } else if (key == "enabled") {
                    fn.enabled = parse_manifest_bool(value, key);
                } else {
                    throw runtime_error("function pack manifest line " + to_string(line_no) + " unknown function field " + key);
                }
            }
            manifest.functions.push_back(fn);
        } else {
            throw runtime_error("function pack manifest line " + to_string(line_no) + " unsupported record kind " + tokens[0]);
        }
    }
    return manifest;
}

FunctionPackManifest load_function_pack_manifest(const filesystem::path& p) {
    vector<uint8_t> bytes = read_file(p);
    return parse_function_pack_manifest_text(string(bytes.begin(), bytes.end()));
}

vector<string> validate_function_pack_manifest(const FunctionPackManifest& manifest) {
    vector<string> issues;
    if (manifest.image_path.empty()) issues.push_back("function pack image missing path");
    if (!manifest.image_base) issues.push_back("function pack image missing image_base");
    if (!manifest.file_hash) issues.push_back("function pack image missing file_hash");
    if (manifest.functions.empty()) issues.push_back("function pack has no functions");

    set<string> seen;
    for (const auto& fn : manifest.functions) {
        if (!fn.enabled) continue;
        string key = function_manifest_key(fn, manifest.image_base);
        if (!seen.insert(key).second) issues.push_back("duplicate function " + key);
        if (!fn.has_va && !fn.has_rva) issues.push_back("function " + key + " missing va or rva");
        if (fn.has_va && fn.has_rva && manifest.image_base && fn.va != manifest.image_base + fn.rva) {
            issues.push_back("function " + key + " va/rva mismatch");
        }
        if (!fn.size) issues.push_back("function " + key + " missing size");
        if (fn.source.empty()) issues.push_back("function " + key + " missing source");
        if (fn.confidence.empty()) issues.push_back("function " + key + " missing confidence");
        if (fn.section.empty()) issues.push_back("function " + key + " missing section");
        if (fn.evidence.empty()) issues.push_back("function " + key + " missing evidence");
        if (fn.rollback.empty()) issues.push_back("function " + key + " missing rollback");
    }

    if (!manifest.image_path.empty()) {
        try {
            auto info = inspect_pe_info(manifest.image_path);
            if (manifest.image_base && info.image_base != manifest.image_base) {
                issues.push_back("image_base mismatch manifest=" + hx(manifest.image_base) + " pe=" + hx(info.image_base));
            }
            if (manifest.file_hash && info.fnv1a64 != manifest.file_hash) {
                issues.push_back("file_hash mismatch manifest=" + hx64(manifest.file_hash) + " pe=" + hx64(info.fnv1a64));
            }
            for (const auto& fn : manifest.functions) {
                if (!fn.enabled || !fn.size || (!fn.has_va && !fn.has_rva)) continue;
                try {
                    uint32_t rva = resolve_function_manifest_rva(manifest, fn);
                    string section = section_for_rva(info, rva);
                    string key = "rva=" + hx(rva);
                    if (section.empty()) {
                        issues.push_back("function " + key + " slice outside section");
                        continue;
                    }
                    if (!fn.section.empty() && fn.section != section) {
                        issues.push_back("function " + key + " section mismatch manifest=" + fn.section + " pe=" + section);
                    }
                    auto slice = analyze_pe_slice(manifest.image_path, rva, fn.size);
                    if (!slice.generated_candidate) issues.push_back("function " + key + " not a generated candidate");
                } catch (const exception& e) {
                    uint32_t rva = fn.has_rva ? fn.rva : 0;
                    issues.push_back("function rva=" + hx(rva) + " validation failed: " + e.what());
                }
            }
        } catch (const exception& e) {
            issues.push_back(string("image validation failed: ") + e.what());
        }
    }
    return issues;
}

string format_function_pack_manifest(const FunctionPackManifest& manifest) {
    ostringstream o;
    o << "function_pack_image: path=" << manifest.image_path
      << " image_base=" << hx(manifest.image_base)
      << " file_hash=" << hx64(manifest.file_hash) << "\n"
      << "function_pack_functions: " << manifest.functions.size() << "\n";
    for (const auto& fn : manifest.functions) {
        o << "function_pack_function:";
        if (fn.has_va) o << " va=" << hx(fn.va);
        if (fn.has_rva) o << " rva=" << hx(fn.rva);
        o << " size=" << fn.size
          << " enabled=" << (fn.enabled ? "true" : "false");
        if (!fn.source.empty()) o << " source=" << fn.source;
        if (!fn.confidence.empty()) o << " confidence=" << fn.confidence;
        if (!fn.section.empty()) o << " section=" << fn.section;
        if (!fn.evidence.empty()) o << " evidence=" << fn.evidence;
        if (!fn.rollback.empty()) o << " rollback=" << fn.rollback;
        o << "\n";
    }
    auto issues = validate_function_pack_manifest(manifest);
    o << "function_pack_issues: " << issues.size() << "\n";
    for (const auto& issue : issues) o << "function_pack_issue: " << issue << "\n";
    return o.str();
}

vector<CfgFunction> build_function_pack_from_manifest(const FunctionPackManifest& manifest) {
    auto issues = validate_function_pack_manifest(manifest);
    if (!issues.empty()) throw runtime_error("invalid function pack manifest: " + issues.front());
    vector<CfgFunction> cfgs;
    for (const auto& fn : manifest.functions) {
        if (!fn.enabled) continue;
        auto slice = analyze_pe_slice(manifest.image_path, resolve_function_manifest_rva(manifest, fn), fn.size);
        cfgs.push_back(slice.cfg);
    }
    return cfgs;
}

string emit_cfg_c_pack_manifest(const FunctionPackManifest& manifest) {
    auto cfgs = build_function_pack_from_manifest(manifest);
    return emit_cfg_c_pack(cfgs);
}

static string ghidra_boundary_key(const GhidraFunctionBoundary& fn, uint32_t image_base) {
    if (fn.has_rva) return "rva=" + hx(fn.rva);
    if (fn.has_va && fn.va >= image_base) return "rva=" + hx(fn.va - image_base);
    if (fn.has_va) return "va=" + hx(fn.va);
    return "unaddressed";
}

static uint32_t resolve_ghidra_boundary_rva(const PeInfo& info, const GhidraFunctionBoundary& fn) {
    if (fn.has_rva) return fn.rva;
    if (!fn.has_va || fn.va < info.image_base) throw runtime_error("ghidra boundary record cannot resolve rva");
    return fn.va - info.image_base;
}

GhidraBoundaryImport parse_ghidra_boundary_import_text(const string& text) {
    GhidraBoundaryImport imported;
    istringstream input(text);
    string line;
    uint32_t line_no = 0;
    while (getline(input, line)) {
        ++line_no;
        auto comment = line.find('#');
        if (comment != string::npos) line = line.substr(0, comment);
        line = trim_copy(line);
        if (line.empty()) continue;
        auto tokens = split_manifest_tokens(line);
        if (tokens.empty()) continue;
        if (tokens[0] != "ghidra_function") {
            throw runtime_error("ghidra boundary line " + to_string(line_no) + " unsupported record kind " + tokens[0]);
        }
        GhidraFunctionBoundary fn;
        for (size_t i = 1; i < tokens.size(); ++i) {
            auto eq = tokens[i].find('=');
            if (eq == string::npos) throw runtime_error("ghidra boundary line " + to_string(line_no) + " token missing '='");
            string key = tokens[i].substr(0, eq);
            string value = tokens[i].substr(eq + 1);
            if (key == "va") {
                fn.va = parse_manifest_u32(value, key);
                fn.has_va = true;
            } else if (key == "rva") {
                fn.rva = parse_manifest_u32(value, key);
                fn.has_rva = true;
            } else if (key == "size") {
                fn.size = parse_manifest_u32(value, key);
                fn.has_size = true;
            } else if (key == "name" || key == "function") {
                fn.name = value;
            } else if (key == "source_tool" || key == "tool") {
                fn.source_tool = value;
            } else if (key == "confidence") {
                fn.confidence = value;
            } else if (key == "evidence") {
                fn.evidence = value;
            } else if (key == "verifier") {
                fn.verifier = value;
            } else if (key == "enabled") {
                fn.enabled = parse_manifest_bool(value, key);
            } else {
                throw runtime_error("ghidra boundary line " + to_string(line_no) + " unknown field " + key);
            }
        }
        imported.functions.push_back(fn);
    }
    return imported;
}

GhidraBoundaryImport load_ghidra_boundary_import(const filesystem::path& p) {
    vector<uint8_t> bytes = read_file(p);
    return parse_ghidra_boundary_import_text(string(bytes.begin(), bytes.end()));
}

vector<string> validate_ghidra_boundary_import(const GhidraBoundaryImport& imported, const PeInfo& info) {
    vector<string> issues;
    if (imported.functions.empty()) issues.push_back("ghidra boundary import has no functions");
    set<string> seen_addr, seen_name;
    for (const auto& fn : imported.functions) {
        if (!fn.enabled) continue;
        string key = ghidra_boundary_key(fn, info.image_base);
        if (!seen_addr.insert(key).second) issues.push_back("duplicate ghidra function " + key);
        if (!fn.name.empty()) {
            string name_key = fn.name;
            if (!seen_name.insert(name_key).second) issues.push_back("conflicting ghidra function name " + fn.name);
        }
        if (!fn.has_va && !fn.has_rva) issues.push_back("ghidra function " + key + " missing va or rva");
        if (fn.has_va && fn.has_rva && fn.va != info.image_base + fn.rva) {
            issues.push_back("ghidra function " + key + " va/rva mismatch");
        }
        if (fn.name.empty()) issues.push_back("ghidra function " + key + " missing name");
        if (fn.source_tool.empty()) issues.push_back("ghidra function " + key + " missing source_tool");
        if (!fn.source_tool.empty()) {
            string lower = fn.source_tool;
            transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return char(tolower(c)); });
            if (lower.find("ghidra") == string::npos) issues.push_back("ghidra function " + key + " unsupported source_tool " + fn.source_tool);
        }
        if (fn.confidence.empty()) issues.push_back("ghidra function " + key + " missing confidence");
        if (fn.evidence.empty()) issues.push_back("ghidra function " + key + " missing evidence");
        if (fn.has_size && !fn.size) issues.push_back("ghidra function " + key + " has zero size");
        if (fn.has_size && fn.verifier != "capstone_x86recomp") {
            issues.push_back("ghidra function " + key + " size lacks capstone_x86recomp verifier");
        }
        if (fn.has_va || fn.has_rva) {
            try {
                uint32_t rva = resolve_ghidra_boundary_rva(info, fn);
                string section = section_for_rva(info, rva);
                if (section.empty()) issues.push_back("ghidra function rva=" + hx(rva) + " outside section");
            } catch (const exception& e) {
                issues.push_back("ghidra function " + key + " validation failed: " + e.what());
            }
        }
    }
    return issues;
}

string format_ghidra_boundary_import(const GhidraBoundaryImport& imported, const PeInfo& info) {
    ostringstream o;
    o << "ghidra_boundary_functions: " << imported.functions.size() << "\n";
    for (const auto& fn : imported.functions) {
        o << "ghidra_boundary_function:";
        if (fn.has_va) o << " va=" << hx(fn.va);
        if (fn.has_rva) o << " rva=" << hx(fn.rva);
        if (fn.has_size) o << " size=" << fn.size;
        o << " enabled=" << (fn.enabled ? "true" : "false");
        if (!fn.name.empty()) o << " name=" << fn.name;
        if (!fn.source_tool.empty()) o << " source_tool=" << fn.source_tool;
        if (!fn.confidence.empty()) o << " confidence=" << fn.confidence;
        if (!fn.verifier.empty()) o << " verifier=" << fn.verifier;
        if (!fn.evidence.empty()) o << " evidence=" << fn.evidence;
        if (fn.has_va || fn.has_rva) {
            try {
                uint32_t rva = resolve_ghidra_boundary_rva(info, fn);
                string section = section_for_rva(info, rva);
                if (!section.empty()) o << " section=" << section;
            } catch (const exception&) {
            }
        }
        o << "\n";
    }
    auto issues = validate_ghidra_boundary_import(imported, info);
    o << "ghidra_boundary_issues: " << issues.size() << "\n";
    for (const auto& issue : issues) o << "ghidra_boundary_issue: " << issue << "\n";
    return o.str();
}

FunctionPackManifest function_pack_manifest_from_ghidra(const filesystem::path& pe_path,
                                                        const GhidraBoundaryImport& imported) {
    auto info = inspect_pe_info(pe_path);
    auto issues = validate_ghidra_boundary_import(imported, info);
    if (!issues.empty()) throw runtime_error("invalid ghidra boundary import: " + issues.front());
    FunctionPackManifest manifest;
    manifest.image_path = pe_path.string();
    manifest.image_base = info.image_base;
    manifest.file_hash = info.fnv1a64;
    for (const auto& fn : imported.functions) {
        if (!fn.enabled) continue;
        if (!fn.has_size) throw runtime_error("ghidra function " + ghidra_boundary_key(fn, info.image_base) + " missing bounded size");
        FunctionPackManifestFunction out;
        uint32_t rva = resolve_ghidra_boundary_rva(info, fn);
        out.rva = rva;
        out.va = info.image_base + rva;
        out.has_rva = true;
        out.has_va = true;
        out.size = fn.size;
        out.source = fn.source_tool;
        out.confidence = fn.confidence;
        out.section = section_for_rva(info, rva);
        out.evidence = fn.evidence + "; verifier=" + fn.verifier + "; ghidra_name=" + fn.name;
        out.rollback = "disable_ghidra_boundary_record";
        out.enabled = fn.enabled;
        manifest.functions.push_back(std::move(out));
    }
    auto pack_issues = validate_function_pack_manifest(manifest);
    if (!pack_issues.empty()) throw runtime_error("invalid ghidra function pack candidate: " + pack_issues.front());
    return manifest;
}

string emit_cfg_c_pack_ghidra(const filesystem::path& pe_path, const GhidraBoundaryImport& imported) {
    return emit_cfg_c_pack_manifest(function_pack_manifest_from_ghidra(pe_path, imported));
}

static string section_for_rva(const PeInfo& info, uint32_t rva) {
    for (const auto& section : info.sections) {
        if (rva_in_section(section, rva)) return section.name;
    }
    return "";
}

static void add_catalog_entry(FunctionCatalog& catalog, map<string, size_t>& seen, FunctionCatalogEntry entry) {
    string key = entry.kind + ":" + hx(entry.entry_va) + ":" + entry.symbol;
    auto it = seen.find(key);
    if (it != seen.end()) {
        auto& existing = catalog.entries[it->second];
        if (!entry.evidence.empty() && existing.evidence.find(entry.evidence) == string::npos) {
            if (!existing.evidence.empty()) existing.evidence += "; ";
            existing.evidence += entry.evidence;
        }
        return;
    }
    seen[key] = catalog.entries.size();
    catalog.entries.push_back(std::move(entry));
}

static void sort_catalog(FunctionCatalog& catalog) {
    sort(catalog.entries.begin(), catalog.entries.end(), [](const auto& a, const auto& b) {
        if (a.entry_va != b.entry_va) return a.entry_va < b.entry_va;
        if (a.kind != b.kind) return a.kind < b.kind;
        return a.symbol < b.symbol;
    });
}

FunctionCatalog build_function_catalog(const PeInfo& info) {
    FunctionCatalog catalog;
    map<string, size_t> seen;
    if (info.entrypoint_rva) {
        add_catalog_entry(catalog, seen, {
            info.image_base + info.entrypoint_rva,
            info.entrypoint_rva,
            "pe_entrypoint",
            "high",
            section_for_rva(info, info.entrypoint_rva),
            "entrypoint",
            "PE optional header AddressOfEntryPoint",
            ""
        });
    }
    for (const auto& ex : info.exports) {
        add_catalog_entry(catalog, seen, {
            info.image_base + ex.rva,
            ex.rva,
            "pe_export",
            ex.forwarder.empty() ? "high" : "medium",
            section_for_rva(info, ex.rva),
            ex.forwarder.empty() ? "export" : "forwarded_export",
            ex.forwarder.empty() ? "PE export address table" : "PE export forwarder",
            ex.name
        });
    }
    for (const auto& dll : info.imports) {
        for (const auto& fn : dll.functions) {
            string symbol = dll.name + "!";
            symbol += fn.by_ordinal ? ("#" + to_string(fn.ordinal)) : fn.name;
            add_catalog_entry(catalog, seen, {
                info.image_base + fn.iat_rva,
                fn.iat_rva,
                "pe_import",
                "high",
                section_for_rva(info, fn.iat_rva),
                "import_iat",
                "PE import descriptor/IAT",
                symbol
            });
        }
    }
    for (const auto& dll : info.delay_imports) {
        for (const auto& fn : dll.functions) {
            string symbol = dll.name + "!";
            symbol += fn.by_ordinal ? ("#" + to_string(fn.ordinal)) : fn.name;
            add_catalog_entry(catalog, seen, {
                info.image_base + fn.iat_rva,
                fn.iat_rva,
                "pe_delay_import",
                "high",
                section_for_rva(info, fn.iat_rva),
                "delay_import_iat",
                "PE delay import descriptor/IAT",
                symbol
            });
        }
    }
    sort_catalog(catalog);
    return catalog;
}

FunctionCatalog build_function_catalog(const PeInfo& info, const GhidraBoundaryImport& imported) {
    FunctionCatalog catalog = build_function_catalog(info);
    map<string, size_t> seen;
    for (size_t i = 0; i < catalog.entries.size(); ++i) {
        const auto& entry = catalog.entries[i];
        seen[entry.kind + ":" + hx(entry.entry_va) + ":" + entry.symbol] = i;
    }
    for (const auto& fn : imported.functions) {
        if (!fn.enabled || (!fn.has_va && !fn.has_rva)) continue;
        uint32_t rva = 0;
        try {
            rva = resolve_ghidra_boundary_rva(info, fn);
        } catch (const exception&) {
            continue;
        }
        string evidence = fn.evidence;
        if (fn.has_size) {
            if (!evidence.empty()) evidence += "; ";
            evidence += "size=" + to_string(fn.size);
        }
        if (!fn.verifier.empty()) {
            if (!evidence.empty()) evidence += "; ";
            evidence += "verifier=" + fn.verifier;
        }
        add_catalog_entry(catalog, seen, {
            info.image_base + rva,
            rva,
            fn.source_tool.empty() ? "ghidra" : fn.source_tool,
            fn.confidence,
            section_for_rva(info, rva),
            "ghidra_function_boundary",
            evidence,
            fn.name
        });
    }
    sort_catalog(catalog);
    return catalog;
}

FunctionCatalog build_function_catalog(const PeInfo& info, const CfgFunction& cfg, const PatchManifest& manifest) {
    FunctionCatalog catalog = build_function_catalog(info);
    map<string, size_t> seen;
    for (size_t i = 0; i < catalog.entries.size(); ++i) {
        const auto& entry = catalog.entries[i];
        seen[entry.kind + ":" + hx(entry.entry_va) + ":" + entry.symbol] = i;
    }
    auto add_va = [&](uint32_t va, string source, string confidence, string kind, string evidence, string symbol = "") {
        uint32_t rva = va >= info.image_base ? va - info.image_base : va;
        add_catalog_entry(catalog, seen, {
            va,
            rva,
            std::move(source),
            std::move(confidence),
            section_for_rva(info, rva),
            std::move(kind),
            std::move(evidence),
            std::move(symbol)
        });
    };
    if (cfg.entry) {
        add_va(cfg.entry, "cfg_entry", "medium", "bounded_cfg_entry", "caller-provided bounded CFG entry");
    }
    for (uint32_t target : cfg.direct_call_targets) {
        add_va(target, "cfg_direct_call", "medium", "direct_call_target", "bounded CFG direct call target");
    }
    for (uint32_t site : cfg.indirect_call_sites) {
        add_va(site, "cfg_indirect_callsite", "medium", "indirect_callsite", "bounded CFG indirect callsite");
    }
    for (const auto& patch : manifest.records) {
        if (!patch.enabled) continue;
        string kind = "manifest_patch";
        if (patch.kind == PatchKind::ImportShim) kind = "manifest_import_shim";
        if (patch.kind == PatchKind::IndirectImportShim) kind = "manifest_import_pointer_callsite";
        add_va(patch.va, "manifest", "high", kind, patch.evidence, patch.symbol);
    }
    sort_catalog(catalog);
    return catalog;
}

string format_function_catalog(const FunctionCatalog& catalog) {
    ostringstream o;
    o << "function_catalog_entries: " << catalog.entries.size() << "\n";
    for (const auto& entry : catalog.entries) {
        o << "function_catalog_entry: va=" << hx(entry.entry_va)
          << " rva=" << hx(entry.entry_rva)
          << " kind=" << entry.kind
          << " source=" << entry.source
          << " confidence=" << entry.confidence;
        if (!entry.section.empty()) o << " section=" << entry.section;
        if (!entry.symbol.empty()) o << " symbol=" << entry.symbol;
        if (!entry.evidence.empty()) o << " evidence=" << entry.evidence;
        o << "\n";
    }
    return o.str();
}
}
