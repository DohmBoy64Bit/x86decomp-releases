import os
import shutil
import subprocess
import sys
from pathlib import Path


def put16(buf, off, value):
    buf[off:off + 2] = int(value).to_bytes(2, "little")


def put32(buf, off, value):
    buf[off:off + 4] = int(value).to_bytes(4, "little")


def put_ascii(buf, off, text):
    data = text.encode("ascii")
    buf[off:off + len(data)] = data


def make_pe():
    buf = bytearray(0x600)
    buf[0:2] = b"MZ"
    put32(buf, 0x3C, 0x80)
    buf[0x80:0x84] = b"PE\0\0"
    put16(buf, 0x84, 0x14C)
    put16(buf, 0x86, 1)
    put32(buf, 0x88, 0x18000000)
    put16(buf, 0x94, 0xE0)
    opt = 0x98
    put16(buf, opt, 0x10B)
    buf[opt + 2] = 7
    buf[opt + 3] = 10
    put32(buf, opt + 16, 0x1000)
    put32(buf, opt + 28, 0x400000)
    put32(buf, opt + 32, 0x1000)
    put32(buf, opt + 36, 0x200)
    put32(buf, opt + 56, 0x2000)
    put32(buf, opt + 60, 0x200)
    put16(buf, opt + 68, 2)
    put16(buf, opt + 70, 0x8100)
    put32(buf, opt + 92, 16)
    section = opt + 0xE0
    put_ascii(buf, section, ".text")
    put32(buf, section + 8, 0x200)
    put32(buf, section + 12, 0x1000)
    put32(buf, section + 16, 0x200)
    put32(buf, section + 20, 0x200)
    put32(buf, section + 36, 0x60000020)
    buf[0x200:0x202] = bytes.fromhex("90 C3")
    buf[0x210:0x217] = bytes.fromhex("B8 2A 00 00 00 40 C3")
    buf[0x220:0x226] = bytes.fromhex("87 D8 0F B6 C3 C3")
    return bytes(buf)


def run(args, **kwargs):
    result = subprocess.run(args, text=True, capture_output=True, **kwargs)
    if result.returncode != 0:
        raise RuntimeError(
            f"command failed ({result.returncode}): {' '.join(map(str, args))}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def main():
    if len(sys.argv) != 5:
        print("usage: compile_generated_pack_ghidra.py <generator> <work_dir> <runtime_src> <runtime_include_dir>", file=sys.stderr)
        return 2
    generator = Path(sys.argv[1])
    work_dir = Path(sys.argv[2])
    runtime_src = Path(sys.argv[3])
    runtime_include_dir = Path(sys.argv[4])

    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True)

    pe_path = work_dir / "synthetic_ghidra.exe"
    pe_path.write_bytes(make_pe())
    ghidra_path = work_dir / "synthetic_ghidra.boundaries"
    ghidra_path.write_text(
        "\n".join([
            "ghidra_function va=0x00401000 rva=0x00001000 size=2 name=FUN_00401000 source_tool=ghidra_mcp confidence=high evidence=synthetic_ghidra_boundary verifier=capstone_x86recomp enabled=true",
            "ghidra_function va=0x00401010 rva=0x00001010 size=7 name=FUN_00401010 source_tool=ghidra_mcp confidence=high evidence=synthetic_ghidra_boundary verifier=capstone_x86recomp enabled=true",
            "ghidra_function va=0x00401020 rva=0x00001020 size=6 name=FUN_00401020 source_tool=ghidra_mcp confidence=high evidence=synthetic_ghidra_boundary verifier=capstone_x86recomp enabled=true",
            "",
        ]),
        encoding="utf-8",
    )

    summary = run([generator, "format-ghidra-boundaries", pe_path, ghidra_path]).stdout
    if "ghidra_boundary_issues: 0" not in summary:
        raise RuntimeError(summary)
    catalog = run([generator, "function-catalog-ghidra", pe_path, ghidra_path]).stdout
    if "kind=ghidra_function_boundary" not in catalog:
        raise RuntimeError(catalog)

    generated_cpp = work_dir / "generated_pack.cpp"
    generated_cpp.write_text(run([generator, "emit-cfg-c-pack-ghidra", pe_path, ghidra_path]).stdout, encoding="utf-8")
    generated_text = generated_cpp.read_text(encoding="utf-8")
    for required in [
        "debug_function_pack_count: 3",
        "debug_function_map: sub_00401000",
        "debug_function_map: sub_00401010",
        "debug_function_map: sub_00401020",
    ]:
        if required not in generated_text:
            raise RuntimeError(f"generated pack missing {required}")

    runtime_src_cmake = runtime_src.as_posix()
    runtime_include_dir_cmake = runtime_include_dir.as_posix()
    (work_dir / "CMakeLists.txt").write_text(
        "\n".join([
            "cmake_minimum_required(VERSION 3.20)",
            "project(generated_pack_ghidra_compile LANGUAGES CXX)",
            "set(CMAKE_CXX_STANDARD 20)",
            f'add_executable(generated_pack_ghidra generated_pack.cpp "{runtime_src_cmake}")',
            f'target_include_directories(generated_pack_ghidra PRIVATE "{runtime_include_dir_cmake}")',
            "",
        ]),
        encoding="utf-8",
    )
    build_dir = work_dir / "build"
    run(["cmake", "-S", work_dir, "-B", build_dir])
    run(["cmake", "--build", build_dir, "--config", "Debug"])
    exe = build_dir / "generated_pack_ghidra"
    if os.name == "nt":
        exe = build_dir / "Debug" / "generated_pack_ghidra.exe"
    run([exe])
    return 0


if __name__ == "__main__":
    sys.exit(main())
