if(NOT DEFINED GENERATOR)
  message(FATAL_ERROR "GENERATOR is required")
endif()
if(NOT DEFINED WORK_DIR)
  message(FATAL_ERROR "WORK_DIR is required")
endif()
if(NOT DEFINED RUNTIME_SRC)
  message(FATAL_ERROR "RUNTIME_SRC is required")
endif()
if(NOT DEFINED RUNTIME_INCLUDE_DIR)
  message(FATAL_ERROR "RUNTIME_INCLUDE_DIR is required")
endif()

file(REMOVE_RECURSE "${WORK_DIR}")
file(MAKE_DIRECTORY "${WORK_DIR}")

set(MANIFEST_FILE "${WORK_DIR}/entry_import_shims.manifest")
file(WRITE "${MANIFEST_FILE}"
"entry_import_shim dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x10 callsite_va=0x00401000 abi=stdcall side_effects=version_info_write evidence=synthetic_generated_pack_harness rollback=drop_record enabled=true\n")

set(GENERATED_CPP "${WORK_DIR}/generated_pack.cpp")
execute_process(
  COMMAND "${GENERATOR}" emit-cfg-c-pack-entry-import-raw "${MANIFEST_FILE}" "FF 15 10 00 00 00 C3"
  OUTPUT_FILE "${GENERATED_CPP}"
  RESULT_VARIABLE gen_result
  ERROR_VARIABLE gen_error
)
if(NOT gen_result EQUAL 0)
  message(FATAL_ERROR "generator failed: ${gen_error}")
endif()

file(READ "${GENERATED_CPP}" generated_text)
foreach(required
  "debug_patch_boundary: kind=indirect_import_shim"
  "dll=KERNEL32.dll"
  "iat_va=0x00000010u"
  "side_effects=version_info_write"
  "runtime_import_pointer_shim_abi")
  if(NOT generated_text MATCHES "${required}")
    message(FATAL_ERROR "generated pack missing ${required}")
  endif()
endforeach()

set(HARNESS_CPP "${WORK_DIR}/entry_import_harness.cpp")
file(WRITE "${HARNESS_CPP}"
"#include <cstdint>\n"
"#include <string>\n"
"#define main generated_pack_main\n"
"#include \"generated_pack.cpp\"\n"
"#undef main\n"
"\n"
"static bool get_version_ex_a(xr::runtime_context& rt, xr::cpu_state& ctx, uint32_t, const char* symbol) {\n"
"    if (std::string(symbol) != \"KERNEL32.dll!GetVersionExA\") {\n"
"        xr::runtime_unsupported_side_effect(rt, ctx, 0, symbol);\n"
"        return false;\n"
"    }\n"
"    uint32_t out_va = 0;\n"
"    if (!xr::runtime_read32(rt, ctx.esp + 4, out_va)) return false;\n"
"    uint32_t size = 0;\n"
"    if (!xr::runtime_read32(rt, out_va, size)) return false;\n"
"    if (size < 20) {\n"
"        xr::runtime_unsupported_side_effect(rt, ctx, out_va, symbol);\n"
"        return false;\n"
"    }\n"
"    if (!xr::runtime_write32(rt, out_va + 4, 5)) return false;\n"
"    if (!xr::runtime_write32(rt, out_va + 8, 1)) return false;\n"
"    if (!xr::runtime_write32(rt, out_va + 12, 2600)) return false;\n"
"    if (!xr::runtime_write32(rt, out_va + 16, 2)) return false;\n"
"    ctx.eax = 1;\n"
"    return true;\n"
"}\n"
"\n"
"int main() {\n"
"    xr::runtime_context rt;\n"
"    xr::cpu_state ctx;\n"
"    xr::runtime_map_memory(rt, 0u, 0x10000u);\n"
"    ctx.esp = 0x8000u;\n"
"    constexpr uint32_t shim_target = 0x5100u;\n"
"    constexpr uint32_t version_info = 0x9000u;\n"
"    xr::runtime_write32(rt, ctx.esp + 4, version_info);\n"
"    xr::runtime_write32(rt, version_info, 20u);\n"
"    if (!xr::runtime_bind_import_pointer_shim_abi(rt, 0x10u, shim_target, \"KERNEL32.dll!GetVersionExA\", \"stdcall\", get_version_ex_a)) return 1;\n"
"    sub_00401000(ctx, rt);\n"
"    uint32_t major = 0;\n"
"    xr::runtime_read32(rt, version_info + 4, major);\n"
"    return rt.events.empty() && ctx.eax == 1u && major == 5u ? 0 : 1;\n"
"}\n")

file(WRITE "${WORK_DIR}/CMakeLists.txt"
"cmake_minimum_required(VERSION 3.20)\n"
"project(entry_import_shim_pack LANGUAGES CXX)\n"
"set(CMAKE_CXX_STANDARD 20)\n"
"add_executable(entry_import_shim_pack entry_import_harness.cpp \"${RUNTIME_SRC}\")\n"
"target_include_directories(entry_import_shim_pack PRIVATE \"${RUNTIME_INCLUDE_DIR}\" \"${WORK_DIR}\")\n")

execute_process(
  COMMAND "${CMAKE_COMMAND}" -S "${WORK_DIR}" -B "${WORK_DIR}/build"
  RESULT_VARIABLE configure_result
)
if(NOT configure_result EQUAL 0)
  message(FATAL_ERROR "entry import shim pack configure failed")
endif()

execute_process(
  COMMAND "${CMAKE_COMMAND}" --build "${WORK_DIR}/build" --config Debug
  RESULT_VARIABLE build_result
)
if(NOT build_result EQUAL 0)
  message(FATAL_ERROR "entry import shim pack build failed")
endif()

set(GENERATED_EXE "${WORK_DIR}/build/entry_import_shim_pack")
if(WIN32)
  set(GENERATED_EXE "${WORK_DIR}/build/Debug/entry_import_shim_pack.exe")
endif()
execute_process(
  COMMAND "${GENERATED_EXE}"
  RESULT_VARIABLE run_result
)
if(NOT run_result EQUAL 0)
  message(FATAL_ERROR "entry import shim pack runtime smoke failed")
endif()
