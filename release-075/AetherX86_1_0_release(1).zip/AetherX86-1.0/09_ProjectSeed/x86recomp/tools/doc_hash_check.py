#!/usr/bin/env python3
"""Deterministic documentation and release-integrity manifest generator.

The manifest covers mandatory project records plus release-relevant source,
configuration, tests, tools, target manifests, and text evidence. It excludes
self-referential hash manifests, generated build trees, VCS metadata, and binary
artifacts so it can be regenerated repeatedly without drift.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

INCLUDE_SUFFIXES = {
    ".c",
    ".cc",
    ".cmake",
    ".cpp",
    ".h",
    ".hpp",
    ".json",
    ".md",
    ".patchmanifest",
    ".py",
    ".txt",
    ".yaml",
    ".yml",
}
INCLUDE_NAMES = {
    ".gitignore",
    "CMakeLists.txt",
}
EXCLUDE_DIRS = {
    ".git",
    ".pytest_cache",
    "__pycache__",
    "_build",
    "build",
}
EXCLUDE_NAMES = {
    "DOC_HASHES.sha256",
    "doc_hash_final_1_0.sha256",
    "doc_hash_phase28.sha256",
    "doc_hash_phase29.sha256",
    "doc_hash_phase30.sha256",
    "doc_hash_phase31.sha256",
    "doc_hash_phase32.sha256",
}
EXCLUDE_SUFFIXES = {
    ".a",
    ".exe",
    ".lib",
    ".o",
    ".obj",
    ".pdb",
    ".so",
    ".zip",
}


def is_included(rel: Path, path: Path) -> bool:
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    if path.name in EXCLUDE_NAMES or path.name.endswith(".tmp"):
        return False
    suffix = path.suffix.lower()
    if suffix in EXCLUDE_SUFFIXES:
        return False
    return suffix in INCLUDE_SUFFIXES or path.name in INCLUDE_NAMES


def iter_integrity_files(root: Path):
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if is_included(rel, path):
            yield rel, path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--output", default="-")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    lines = [f"{sha256(path)}  {rel.as_posix()}" for rel, path in iter_integrity_files(root)]
    text = "\n".join(lines) + "\n"
    if args.output == "-":
        print(text, end="")
    else:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
