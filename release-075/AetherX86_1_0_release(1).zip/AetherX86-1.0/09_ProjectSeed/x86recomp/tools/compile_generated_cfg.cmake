if(NOT DEFINED GENERATOR)
  message(FATAL_ERROR "GENERATOR is required")
endif()
if(NOT DEFINED WORK_DIR)
  message(FATAL_ERROR "WORK_DIR is required")
endif()
if(NOT DEFINED HEX_BYTES)
  message(FATAL_ERROR "HEX_BYTES is required")
endif()
if(NOT DEFINED RUNTIME_SRC)
  message(FATAL_ERROR "RUNTIME_SRC is required")
endif()
if(NOT DEFINED RUNTIME_INCLUDE_DIR)
  message(FATAL_ERROR "RUNTIME_INCLUDE_DIR is required")
endif()

file(REMOVE_RECURSE "${WORK_DIR}")
file(MAKE_DIRECTORY "${WORK_DIR}")

set(GENERATOR_COMMAND emit-cfg-c-raw)
if(DEFINED PATCHED AND PATCHED)
  set(GENERATOR_COMMAND emit-cfg-c-patched-raw)
endif()
if(DEFINED INDIRECT_IMPORT_SHIM AND INDIRECT_IMPORT_SHIM)
  set(GENERATOR_COMMAND emit-cfg-c-indirect-import-raw)
endif()
if(DEFINED MANIFEST_FILE)
  set(GENERATOR_COMMAND emit-cfg-c-manifest-raw)
endif()

set(GENERATED_CPP "${WORK_DIR}/generated_cfg.cpp")
execute_process(
  COMMAND "${GENERATOR}" "${GENERATOR_COMMAND}" "${HEX_BYTES}" "${MANIFEST_FILE}"
  OUTPUT_FILE "${GENERATED_CPP}"
  RESULT_VARIABLE gen_result
  ERROR_VARIABLE gen_error
)
if(NOT gen_result EQUAL 0)
  message(FATAL_ERROR "generator failed: ${gen_error}")
endif()

file(WRITE "${WORK_DIR}/CMakeLists.txt"
"cmake_minimum_required(VERSION 3.20)\n"
"project(generated_cfg_compile LANGUAGES CXX)\n"
"set(CMAKE_CXX_STANDARD 20)\n"
"add_executable(generated_cfg generated_cfg.cpp \"${RUNTIME_SRC}\")\n"
"target_include_directories(generated_cfg PRIVATE \"${RUNTIME_INCLUDE_DIR}\")\n")

execute_process(
  COMMAND "${CMAKE_COMMAND}" -S "${WORK_DIR}" -B "${WORK_DIR}/build"
  RESULT_VARIABLE configure_result
)
if(NOT configure_result EQUAL 0)
  message(FATAL_ERROR "generated cfg configure failed")
endif()

execute_process(
  COMMAND "${CMAKE_COMMAND}" --build "${WORK_DIR}/build" --config Debug
  RESULT_VARIABLE build_result
)
if(NOT build_result EQUAL 0)
  message(FATAL_ERROR "generated cfg build failed")
endif()

if(DEFINED RUN_GENERATED AND RUN_GENERATED)
  set(GENERATED_EXE "${WORK_DIR}/build/generated_cfg")
  if(WIN32)
    set(GENERATED_EXE "${WORK_DIR}/build/Debug/generated_cfg.exe")
  endif()
  execute_process(
    COMMAND "${GENERATED_EXE}"
    RESULT_VARIABLE run_result
  )
  if(NOT run_result EQUAL 0)
    message(FATAL_ERROR "generated cfg runtime smoke failed")
  endif()
endif()
