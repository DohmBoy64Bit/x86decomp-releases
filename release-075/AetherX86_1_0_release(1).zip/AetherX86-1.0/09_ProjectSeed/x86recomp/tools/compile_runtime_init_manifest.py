import os
import shutil
import subprocess
import sys
from pathlib import Path


def put16(buf, off, value):
    buf[off:off + 2] = int(value).to_bytes(2, "little")


def put32(buf, off, value):
    buf[off:off + 4] = int(value).to_bytes(4, "little")


def put_ascii(buf, off, text):
    data = text.encode("ascii")
    buf[off:off + len(data)] = data


def fnv1a64(data):
    value = 14695981039346656037
    for byte in data:
        value ^= byte
        value = (value * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return value


def make_pe():
    buf = bytearray(0x800)
    buf[0:2] = b"MZ"
    put32(buf, 0x3C, 0x80)
    buf[0x80:0x84] = b"PE\0\0"
    put16(buf, 0x84, 0x14C)
    put16(buf, 0x86, 2)
    put32(buf, 0x88, 0x18000000)
    put16(buf, 0x94, 0xE0)
    opt = 0x98
    put16(buf, opt, 0x10B)
    buf[opt + 2] = 7
    buf[opt + 3] = 10
    put32(buf, opt + 16, 0x1000)
    put32(buf, opt + 28, 0x400000)
    put32(buf, opt + 32, 0x1000)
    put32(buf, opt + 36, 0x200)
    put32(buf, opt + 56, 0x3000)
    put32(buf, opt + 60, 0x200)
    put16(buf, opt + 68, 2)
    put16(buf, opt + 70, 0x8100)
    put32(buf, opt + 92, 16)
    put32(buf, opt + 104, 0x2000)
    put32(buf, opt + 108, 0x28)
    section = opt + 0xE0
    put_ascii(buf, section, ".text")
    put32(buf, section + 8, 0x200)
    put32(buf, section + 12, 0x1000)
    put32(buf, section + 16, 0x200)
    put32(buf, section + 20, 0x200)
    put32(buf, section + 36, 0x60000020)
    idata = section + 40
    put_ascii(buf, idata, ".idata")
    put32(buf, idata + 8, 0x200)
    put32(buf, idata + 12, 0x2000)
    put32(buf, idata + 16, 0x200)
    put32(buf, idata + 20, 0x400)
    put32(buf, idata + 36, 0xC0000040)
    buf[0x200:0x207] = bytes.fromhex("FF 15 70 20 40 00 C3")
    put32(buf, 0x400, 0x2060)
    put32(buf, 0x40C, 0x2050)
    put32(buf, 0x410, 0x2070)
    put_ascii(buf, 0x450, "KERNEL32.dll")
    put32(buf, 0x460, 0x2080)
    put32(buf, 0x464, 0)
    put32(buf, 0x470, 0x2080)
    put32(buf, 0x474, 0)
    put16(buf, 0x480, 0)
    put_ascii(buf, 0x482, "GetVersionExA")
    return bytes(buf)


def run(args, **kwargs):
    result = subprocess.run(args, text=True, capture_output=True, **kwargs)
    if result.returncode != 0:
        raise RuntimeError(
            f"command failed ({result.returncode}): {' '.join(map(str, args))}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def main():
    if len(sys.argv) != 5:
        print("usage: compile_runtime_init_manifest.py <generator> <work_dir> <runtime_src> <runtime_include_dir>", file=sys.stderr)
        return 2
    generator = Path(sys.argv[1])
    work_dir = Path(sys.argv[2])
    runtime_src = Path(sys.argv[3])
    runtime_include_dir = Path(sys.argv[4])

    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True)

    pe_path = work_dir / "synthetic_runtime_init.exe"
    pe_data = make_pe()
    pe_path.write_bytes(pe_data)
    file_hash = fnv1a64(pe_data)

    runtime_init_path = work_dir / "synthetic_runtime.runtimeinit"
    runtime_init_path.write_text(
        "\n".join([
            f'image path="{pe_path}" image_base=0x00400000 file_hash=0x{file_hash:016X}',
            "runtime_init_import_pointer dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x00402070 iat_rva=0x00002070 "
            "shim_target_va=0x00510000 abi=stdcall side_effects=version_info_write "
            "evidence=synthetic_runtime_init_manifest rollback=drop_record enabled=true",
            "",
        ]),
        encoding="utf-8",
    )
    summary = run([generator, "format-runtime-init", runtime_init_path, "0x00400000", "0x00020000"]).stdout
    if "runtime_init_issues: 0" not in summary:
        raise RuntimeError(summary)

    entry_manifest_path = work_dir / "synthetic_entry_import.manifest"
    entry_manifest_path.write_text(
        "entry_import_shim dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x00402070 iat_rva=0x00002070 "
        "callsite_va=0x00401000 callsite_rva=0x00001000 abi=stdcall side_effects=version_info_write "
        "evidence=synthetic_runtime_init_manifest rollback=drop_record enabled=true\n",
        encoding="utf-8",
    )
    bindings = run([generator, "format-import-bindings", pe_path, entry_manifest_path, runtime_init_path]).stdout
    if "import_bindings: 1" not in bindings or "import_binding_diagnostics: 0" not in bindings:
        raise RuntimeError(bindings)

    generated_cpp = work_dir / "generated_pack.cpp"
    generated_cpp.write_text(
        run([generator, "emit-cfg-c-pack-entry-import-raw", entry_manifest_path, "FF 15 70 20 40 00 C3"]).stdout,
        encoding="utf-8",
    )
    generated_text = generated_cpp.read_text(encoding="utf-8")
    for required in [
        "debug_patch_boundary: kind=indirect_import_shim",
        "iat_va=0x00402070u",
        "KERNEL32.dll!GetVersionExA",
        "runtime_import_pointer_shim_abi",
    ]:
        if required not in generated_text:
            raise RuntimeError(f"generated pack missing {required}")

    runtime_src_cmake = runtime_src.as_posix()
    runtime_include_dir_cmake = runtime_include_dir.as_posix()
    (work_dir / "runtime_init_harness.cpp").write_text(
        "\n".join([
            "#include <cstdint>",
            "#include <string>",
            "#define main generated_pack_main",
            "#include \"generated_pack.cpp\"",
            "#undef main",
            "",
            "static bool get_version_ex_a(xr::runtime_context& rt, xr::cpu_state& ctx, uint32_t, const char* symbol) {",
            "    if (std::string(symbol) != \"KERNEL32.dll!GetVersionExA\") {",
            "        xr::runtime_unsupported_side_effect(rt, ctx, 0, symbol);",
            "        return false;",
            "    }",
            "    uint32_t out_va = 0;",
            "    if (!xr::runtime_read32(rt, ctx.esp + 4, out_va)) return false;",
            "    uint32_t size = 0;",
            "    if (!xr::runtime_read32(rt, out_va, size)) return false;",
            "    if (size < 20) return false;",
            "    if (!xr::runtime_write32(rt, out_va + 4, 5)) return false;",
            "    if (!xr::runtime_write32(rt, out_va + 8, 1)) return false;",
            "    if (!xr::runtime_write32(rt, out_va + 12, 2600)) return false;",
            "    if (!xr::runtime_write32(rt, out_va + 16, 2)) return false;",
            "    ctx.eax = 1;",
            "    return true;",
            "}",
            "",
            "int main() {",
            "    xr::runtime_context rt;",
            "    xr::cpu_state ctx;",
            "    xr::runtime_map_memory(rt, 0x00400000u, 0x00020000u);",
            "    ctx.esp = 0x00418000u;",
            "    constexpr uint32_t version_info = 0x00419000u;",
            "    xr::runtime_write32(rt, ctx.esp + 4, version_info);",
            "    xr::runtime_write32(rt, version_info, 20u);",
            "    xr::runtime_import_pointer_init init;",
            "    init.iat_va = 0x00402070u;",
            "    init.shim_target = 0x00510000u;",
            "    init.symbol = \"KERNEL32.dll!GetVersionExA\";",
            "    init.abi = \"stdcall\";",
            "    init.callback = get_version_ex_a;",
            "    if (!xr::runtime_apply_import_pointer_init(rt, init)) return 1;",
            "    sub_00401000(ctx, rt);",
            "    uint32_t major = 0;",
            "    xr::runtime_read32(rt, version_info + 4, major);",
            "    return rt.events.empty() && ctx.eax == 1u && major == 5u ? 0 : 1;",
            "}",
            "",
        ]),
        encoding="utf-8",
    )
    (work_dir / "CMakeLists.txt").write_text(
        "\n".join([
            "cmake_minimum_required(VERSION 3.20)",
            "project(runtime_init_manifest_compile LANGUAGES CXX)",
            "set(CMAKE_CXX_STANDARD 20)",
            f'add_executable(runtime_init_manifest runtime_init_harness.cpp "{runtime_src_cmake}")',
            f'target_include_directories(runtime_init_manifest PRIVATE "{runtime_include_dir_cmake}" "{work_dir.as_posix()}")',
            "",
        ]),
        encoding="utf-8",
    )
    build_dir = work_dir / "build"
    run(["cmake", "-S", work_dir, "-B", build_dir])
    run(["cmake", "--build", build_dir, "--config", "Debug"])
    exe = build_dir / "runtime_init_manifest"
    if os.name == "nt":
        exe = build_dir / "Debug" / "runtime_init_manifest.exe"
    run([exe])
    return 0


if __name__ == "__main__":
    sys.exit(main())
