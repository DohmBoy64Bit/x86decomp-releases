#!/usr/bin/env python3
"""Compare x86recomp raw decode output against Capstone for supported fixtures."""

from __future__ import annotations

import re
import subprocess
import sys
from dataclasses import dataclass

try:
    from capstone import Cs, CS_ARCH_X86, CS_MODE_32
except ImportError:
    print("SKIP: Python capstone module is not installed")
    sys.exit(77)


@dataclass(frozen=True)
class Fixture:
    name: str
    hex_bytes: str
    base: int = 0x00401000


FIXTURES = [
    Fixture("nop", "90"),
    Fixture("push-ebp", "55"),
    Fixture("push-eax", "50"),
    Fixture("push-esi", "56"),
    Fixture("push-imm32", "68 78 56 34 12"),
    Fixture("push-imm8", "6A 7F"),
    Fixture("pop-ebp", "5D"),
    Fixture("pop-eax", "58"),
    Fixture("pop-esi", "5E"),
    Fixture("inc-eax", "40"),
    Fixture("dec-eax", "48"),
    Fixture("not-eax", "F7 D0"),
    Fixture("neg-eax", "F7 D8"),
    Fixture("group5-inc-mem", "FF 00"),
    Fixture("group5-dec-mem", "FF 08"),
    Fixture("mov-reg-reg", "8B EC"),
    Fixture("mov-imm32", "B8 2A 00 00 00"),
    Fixture("mov-imm16-prefix", "66 B8 34 12"),
    Fixture("mov-r8-r8", "8A C3"),
    Fixture("mov-moffs-to-eax", "A1 78 56 34 12"),
    Fixture("mov-eax-to-moffs", "A3 78 56 34 12"),
    Fixture("mov-modrm-reg", "89 D8"),
    Fixture("mov-modrm-disp8", "8B 45 FC"),
    Fixture("mov-sib-disp32", "8B 84 88 78 56 34 12"),
    Fixture("lea-sib-no-base", "8D 04 8D 00 10 00 00"),
    Fixture("xchg-rm-r", "87 D8"),
    Fixture("movzx-r32-r8", "0F B6 C3"),
    Fixture("movsx-r32-r16", "0F BF C3"),
    Fixture("add-rm-r", "01 D8"),
    Fixture("add-r-rm", "03 45 FC"),
    Fixture("adc-rm-r", "11 D8"),
    Fixture("adc-rm-imm8", "83 D0 01"),
    Fixture("or-rm-r", "09 D8"),
    Fixture("and-r-rm", "23 45 FC"),
    Fixture("sub-rm-r", "29 D8"),
    Fixture("sbb-rm-r", "19 D8"),
    Fixture("sbb-rm-imm8", "83 D8 01"),
    Fixture("xor-r-rm", "33 C0"),
    Fixture("cmp-rm-r", "39 D8"),
    Fixture("test-rm-r", "85 C0"),
    Fixture("group1-add-imm32", "81 C0 78 56 34 12"),
    Fixture("group1-sub-imm8", "83 E8 01"),
    Fixture("group1-cmp-mem-imm8", "83 7D FC 01"),
    Fixture("group11-mov-mem-imm32", "C7 01 78 56 34 12"),
    Fixture("shl-rm-1", "D1 E0"),
    Fixture("shr-rm-1", "D1 E8"),
    Fixture("sar-rm-1", "D1 F8"),
    Fixture("rol-rm-1", "D1 C0"),
    Fixture("ror-rm-1", "D1 C8"),
    Fixture("shl-rm-imm8", "C1 E0 02"),
    Fixture("shl-rm-cl", "D3 E0"),
    Fixture("sete-rm8", "0F 94 C0"),
    Fixture("cmovne-r-rm", "0F 45 C3"),
    Fixture("group5-call-mem", "FF 15 78 56 34 12"),
    Fixture("group5-push-mem", "FF 35 78 56 34 12"),
    Fixture("group5-jmp-mem", "FF 25 78 56 34 12"),
    Fixture("call-rel32", "E8 01 00 00 00"),
    Fixture("jmp-rel32", "E9 01 00 00 00"),
    Fixture("jmp-rel8", "EB FE"),
    Fixture("jcc-rel8", "74 05"),
    Fixture("jcc-rel32", "0F 85 78 56 34 12"),
]


def parse_x86recomp_line(line: str) -> tuple[int, str, str]:
    match = re.fullmatch(r"0x([0-9A-Fa-f]+):\s+([a-z0-9]+)(?:\s+(.*))?", line.strip())
    if not match:
        raise ValueError(f"could not parse x86recomp line: {line!r}")
    return int(match.group(1), 16), match.group(2), match.group(3) or ""


def split_operands(op_str: str) -> list[str]:
    if not op_str:
        return []
    parts: list[str] = []
    depth = 0
    start = 0
    for idx, ch in enumerate(op_str):
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
        elif ch == "," and depth == 0:
            parts.append(op_str[start:idx].strip())
            start = idx + 1
    parts.append(op_str[start:].strip())
    return parts


def normalize_hex(text: str) -> str:
    def repl(match: re.Match[str]) -> str:
        return f"0x{int(match.group(0), 16):x}"

    return re.sub(r"0x[0-9a-fA-F]+", repl, text)


def normalize_operand(op: str) -> str:
    op = op.lower().strip()
    if re.fullmatch(r"\d+", op):
        op = f"0x{int(op):x}"
    for prefix in ("qword ptr ", "dword ptr ", "word ptr ", "byte ptr "):
        op = op.replace(prefix, "")
    op = normalize_hex(op)
    op = re.sub(
        r"(?<=\s[+-]\s)(\d+)\b",
        lambda match: f"0x{int(match.group(1)):x}",
        op,
    )
    op = re.sub(
        r"(?<=, )(\d+)\b",
        lambda match: f"0x{int(match.group(1)):x}",
        op,
    )
    op = re.sub(r"\s+", " ", op)
    return op


def normalize_operands(op_str: str) -> list[str]:
    return [normalize_operand(part) for part in split_operands(op_str)]


def run_x86recomp(exe: str, fixture: Fixture) -> tuple[int, str, str]:
    proc = subprocess.run(
        [exe, "lift-raw", fixture.hex_bytes],
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"x86recomp failed for {fixture.name}: {proc.stderr.strip()}")
    lines = [line for line in proc.stdout.splitlines() if line.strip()]
    if len(lines) != 1:
        raise AssertionError(f"{fixture.name}: expected one decoded line, got {len(lines)}")
    return parse_x86recomp_line(lines[0])


def run_capstone(md: Cs, fixture: Fixture) -> tuple[int, int, str, str]:
    code = bytes.fromhex(fixture.hex_bytes)
    insns = list(md.disasm(code, fixture.base))
    if len(insns) != 1:
        raise AssertionError(f"{fixture.name}: Capstone decoded {len(insns)} instructions")
    insn = insns[0]
    if insn.size != len(code):
        raise AssertionError(f"{fixture.name}: Capstone size {insn.size} != fixture size {len(code)}")
    return insn.address, insn.size, insn.mnemonic, insn.op_str


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: capstone_decode_verify.py <x86recomp_exe>", file=sys.stderr)
        return 2

    md = Cs(CS_ARCH_X86, CS_MODE_32)
    exe = sys.argv[1]
    failures: list[str] = []
    for fixture in FIXTURES:
        try:
            xr_addr, xr_mnemonic, xr_ops = run_x86recomp(exe, fixture)
            cs_addr, _cs_size, cs_mnemonic, cs_ops = run_capstone(md, fixture)
            if xr_addr != cs_addr:
                failures.append(f"{fixture.name}: address {xr_addr:#x} != {cs_addr:#x}")
            if xr_mnemonic != cs_mnemonic:
                failures.append(f"{fixture.name}: mnemonic {xr_mnemonic!r} != {cs_mnemonic!r}")
            if normalize_operands(xr_ops) != normalize_operands(cs_ops):
                failures.append(
                    f"{fixture.name}: operands {normalize_operands(xr_ops)!r} != "
                    f"{normalize_operands(cs_ops)!r}"
                )
        except Exception as exc:
            failures.append(f"{fixture.name}: {exc}")

    if failures:
        print("Capstone decode verification failed:")
        for failure in failures:
            print(f"  - {failure}")
        return 1

    print(f"Capstone {sys.modules['capstone'].__version__} verified {len(FIXTURES)} decode fixtures in x86 32-bit mode")
    return 0


if __name__ == "__main__":
    sys.exit(main())
