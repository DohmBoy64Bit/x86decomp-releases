import os
import shutil
import subprocess
import sys
from pathlib import Path


def put16(buf, off, value):
    buf[off:off + 2] = int(value).to_bytes(2, "little")


def put32(buf, off, value):
    buf[off:off + 4] = int(value).to_bytes(4, "little")


def put_ascii(buf, off, text):
    data = text.encode("ascii")
    buf[off:off + len(data)] = data


def fnv1a64(data):
    value = 14695981039346656037
    for byte in data:
        value ^= byte
        value = (value * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return value


def make_pe():
    buf = bytearray(0x3400)
    buf[0:2] = b"MZ"
    put32(buf, 0x3C, 0x80)
    buf[0x80:0x84] = b"PE\0\0"
    put16(buf, 0x84, 0x14C)
    put16(buf, 0x86, 2)
    put32(buf, 0x88, 0x18000000)
    put16(buf, 0x94, 0xE0)
    opt = 0x98
    put16(buf, opt, 0x10B)
    buf[opt + 2] = 7
    buf[opt + 3] = 10
    put32(buf, opt + 16, 0x1000)
    put32(buf, opt + 28, 0x400000)
    put32(buf, opt + 32, 0x1000)
    put32(buf, opt + 36, 0x200)
    put32(buf, opt + 56, 0x6000)
    put32(buf, opt + 60, 0x200)
    put16(buf, opt + 68, 2)
    put16(buf, opt + 70, 0x8100)
    put32(buf, opt + 92, 16)
    put32(buf, opt + 104, 0x3000)
    put32(buf, opt + 108, 0x28)
    section = opt + 0xE0
    put_ascii(buf, section, ".text")
    put32(buf, section + 8, 0x2000)
    put32(buf, section + 12, 0x1000)
    put32(buf, section + 16, 0x2000)
    put32(buf, section + 20, 0x200)
    put32(buf, section + 36, 0x60000020)
    idata = section + 40
    put_ascii(buf, idata, ".idata")
    put32(buf, idata + 8, 0x1000)
    put32(buf, idata + 12, 0x3000)
    put32(buf, idata + 16, 0x1000)
    put32(buf, idata + 20, 0x2200)
    put32(buf, idata + 36, 0xC0000040)
    buf[0x200:0x206] = bytes.fromhex("E8 FB 0F 00 00 C3")
    buf[0x1200:0x1207] = bytes.fromhex("FF 15 70 30 40 00 C3")

    put32(buf, 0x2200, 0x3060)
    put32(buf, 0x220C, 0x3050)
    put32(buf, 0x2210, 0x3070)
    put_ascii(buf, 0x2250, "KERNEL32.dll")
    put32(buf, 0x2260, 0x3080)
    put32(buf, 0x2264, 0)
    put32(buf, 0x2270, 0x3080)
    put32(buf, 0x2274, 0)
    put16(buf, 0x2280, 0)
    put_ascii(buf, 0x2282, "GetVersionExA")
    return bytes(buf)


def run(args, **kwargs):
    result = subprocess.run(args, text=True, capture_output=True, **kwargs)
    if result.returncode != 0:
        raise RuntimeError(
            f"command failed ({result.returncode}): {' '.join(map(str, args))}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def main():
    if len(sys.argv) != 5:
        print("usage: compile_integrated_bringup_pack.py <generator> <work_dir> <runtime_src> <runtime_include_dir>",
              file=sys.stderr)
        return 2
    generator = Path(sys.argv[1])
    work_dir = Path(sys.argv[2])
    runtime_src = Path(sys.argv[3])
    runtime_include_dir = Path(sys.argv[4])

    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True)

    pe_path = work_dir / "synthetic_bringup.exe"
    pe_data = make_pe()
    pe_path.write_bytes(pe_data)
    file_hash = fnv1a64(pe_data)

    entry_manifest_path = work_dir / "synthetic_entry_import.manifest"
    entry_manifest_path.write_text(
        "entry_import_shim dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x00403070 iat_rva=0x00003070 "
        "callsite_va=0x00402000 callsite_rva=0x00002000 abi=stdcall side_effects=version_info_write "
        "evidence=synthetic_integrated_bringup rollback=drop_record enabled=true\n",
        encoding="utf-8",
    )

    runtime_init_path = work_dir / "synthetic_bringup.runtimeinit"
    runtime_init_path.write_text(
        "\n".join([
            f'image path="{pe_path}" image_base=0x00400000 file_hash=0x{file_hash:016X}',
            "runtime_init_import_pointer dll=KERNEL32.dll symbol=GetVersionExA iat_va=0x00403070 iat_rva=0x00003070 "
            "shim_target_va=0x00510000 abi=stdcall side_effects=version_info_write "
            "evidence=synthetic_integrated_bringup rollback=drop_record enabled=true",
            "",
        ]),
        encoding="utf-8",
    )

    runtime_start_path = work_dir / "synthetic_bringup.runtime_start"
    runtime_start_path.write_text(
        "\n".join([
            "runtime_start entry_va=0x00401000 stack_base=0x00405000 stack_size=0x800 "
            "initial_esp=0x00405200 expected_abi=cdecl evidence=synthetic_integrated_bringup "
            "rollback=drop_record enabled=true",
            "argument offset=4 value=0x00405400 size=4",
            "",
        ]),
        encoding="utf-8",
    )

    image_map = run([generator, "format-pe-image-map", pe_path]).stdout
    runtime_init = run([generator, "format-runtime-init", runtime_init_path, "0x00400000", "0x00006000"]).stdout
    import_bindings = run([generator, "format-import-bindings", pe_path, entry_manifest_path, runtime_init_path]).stdout
    runtime_start = run([generator, "format-runtime-start", runtime_start_path]).stdout
    for text, required in [
        (image_map, "pe_image_map_issues: 0"),
        (runtime_init, "runtime_init_issues: 0"),
        (import_bindings, "import_bindings: 1"),
        (import_bindings, "import_binding_diagnostics: 0"),
        (runtime_start, "runtime_start_issues: 0"),
    ]:
        if required not in text:
            raise RuntimeError(text)

    generated_cpp = work_dir / "generated_pack.cpp"
    generated_cpp.write_text(
        run([
            generator,
            "emit-cfg-c-pack-entry-import-raw",
            entry_manifest_path,
            "E8 FB 0F 00 00 C3",
            "FF 15 70 30 40 00 C3",
        ]).stdout,
        encoding="utf-8",
    )
    generated_text = generated_cpp.read_text(encoding="utf-8")
    for required in [
        "debug_function_pack_count: 2",
        "debug_function_map: sub_00401000",
        "debug_function_map: sub_00402000",
        "debug_direct_call_map: from=sub_00401000 target=0x00402000u resolved=generated",
        "debug_indirect_call_map: from=sub_00402000 callsite=0x00402000u resolved=runtime_indirect_call",
        "debug_patch_boundary: kind=indirect_import_shim",
        "iat_va=0x00403070u",
        "runtime_import_pointer_shim_abi",
    ]:
        if required not in generated_text:
            raise RuntimeError(f"generated pack missing {required}")

    (work_dir / "integrated_debug_map.txt").write_text(
        "\n".join([
            "[image]",
            image_map.strip(),
            "[runtime_init]",
            runtime_init.strip(),
            "[import_bindings]",
            import_bindings.strip(),
            "[runtime_start]",
            runtime_start.strip(),
            "[generated_maps]",
            "\n".join(line for line in generated_text.splitlines() if "debug_" in line),
            "",
        ]),
        encoding="utf-8",
    )

    runtime_src_cmake = runtime_src.as_posix()
    runtime_include_dir_cmake = runtime_include_dir.as_posix()
    (work_dir / "integrated_harness.cpp").write_text(
        "\n".join([
            "#include <cstdint>",
            "#include <string>",
            "#include <vector>",
            "#define main generated_pack_main",
            "#include \"generated_pack.cpp\"",
            "#undef main",
            "",
            "static bool get_version_ex_a(xr::runtime_context& rt, xr::cpu_state& ctx, uint32_t, const char* symbol) {",
            "    if (std::string(symbol) != \"KERNEL32.dll!GetVersionExA\") {",
            "        xr::runtime_unsupported_side_effect(rt, ctx, 0, symbol);",
            "        return false;",
            "    }",
            "    uint32_t out_va = 0;",
            "    if (!xr::runtime_read32(rt, ctx.esp + 4, out_va)) return false;",
            "    uint32_t size = 0;",
            "    if (!xr::runtime_read32(rt, out_va, size)) return false;",
            "    if (size < 20) return false;",
            "    if (!xr::runtime_write32(rt, out_va + 4, 5)) return false;",
            "    if (!xr::runtime_write32(rt, out_va + 8, 1)) return false;",
            "    if (!xr::runtime_write32(rt, out_va + 12, 2600)) return false;",
            "    if (!xr::runtime_write32(rt, out_va + 16, 2)) return false;",
            "    ctx.eax = 1;",
            "    return true;",
            "}",
            "",
            "int main() {",
            "    xr::runtime_context rt;",
            "    std::vector<xr::runtime_image_section> sections;",
            "    xr::runtime_image_section text;",
            "    text.va = 0x00401000u;",
            "    text.rva = 0x00001000u;",
            "    text.raw_size = 0x2000u;",
            "    text.virtual_size = 0x2000u;",
            "    text.readable = true;",
            "    text.executable = true;",
            "    text.name = \".text\";",
            "    text.raw_data.assign(text.raw_size, 0);",
            "    xr::runtime_image_section idata;",
            "    idata.va = 0x00403000u;",
            "    idata.rva = 0x00003000u;",
            "    idata.raw_size = 0x1000u;",
            "    idata.virtual_size = 0x1000u;",
            "    idata.readable = true;",
            "    idata.writable = true;",
            "    idata.name = \".idata\";",
            "    idata.raw_data.assign(idata.raw_size, 0);",
            "    sections.push_back(text);",
            "    sections.push_back(idata);",
            "    auto image = xr::runtime_map_image(rt, 0x00400000u, 0x00006000u, sections);",
            "    if (!image.ok) return 1;",
            "    xr::runtime_import_pointer_init init;",
            "    init.iat_va = 0x00403070u;",
            "    init.shim_target = 0x00510000u;",
            "    init.symbol = \"KERNEL32.dll!GetVersionExA\";",
            "    init.abi = \"stdcall\";",
            "    init.callback = get_version_ex_a;",
            "    if (!xr::runtime_apply_import_pointer_init(rt, init)) return 2;",
            "    xr::runtime_start_config start;",
            "    start.entry_va = 0x00401000u;",
            "    start.stack_base = 0x00405000u;",
            "    start.stack_size = 0x00000800u;",
            "    start.initial_esp = 0x00405200u;",
            "    start.abi = \"cdecl\";",
            "    start.arguments.push_back({4u, 0x00405400u, 4u});",
            "    xr::cpu_state ctx;",
            "    auto prepared = xr::runtime_prepare_start(rt, ctx, start);",
            "    if (!prepared.ok) return 3;",
            "    if (!xr::runtime_write32(rt, 0x00405400u, 20u)) return 4;",
            "    sub_00401000(ctx, rt);",
            "    uint32_t iat_value = 0;",
            "    uint32_t major = 0;",
            "    if (!xr::runtime_read32(rt, 0x00403070u, iat_value)) return 5;",
            "    if (!xr::runtime_read32(rt, 0x00405404u, major)) return 6;",
            "    return rt.events.empty() && iat_value == 0x00510000u && ctx.eax == 1u && major == 5u ? 0 : 7;",
            "}",
            "",
        ]),
        encoding="utf-8",
    )
    (work_dir / "CMakeLists.txt").write_text(
        "\n".join([
            "cmake_minimum_required(VERSION 3.20)",
            "project(integrated_synthetic_bringup_pack LANGUAGES CXX)",
            "set(CMAKE_CXX_STANDARD 20)",
            f'add_executable(integrated_synthetic_bringup integrated_harness.cpp "{runtime_src_cmake}")',
            f'target_include_directories(integrated_synthetic_bringup PRIVATE "{runtime_include_dir_cmake}" "{work_dir.as_posix()}")',
            "",
        ]),
        encoding="utf-8",
    )
    build_dir = work_dir / "build"
    run(["cmake", "-S", work_dir, "-B", build_dir])
    run(["cmake", "--build", build_dir, "--config", "Debug"])
    exe = build_dir / "integrated_synthetic_bringup"
    if os.name == "nt":
        exe = build_dir / "Debug" / "integrated_synthetic_bringup.exe"
    run([exe])
    return 0


if __name__ == "__main__":
    sys.exit(main())
