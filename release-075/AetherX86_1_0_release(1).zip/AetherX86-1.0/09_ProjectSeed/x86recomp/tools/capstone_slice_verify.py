#!/usr/bin/env python3
"""Verify or compare x86recomp PE-slice analysis against Capstone."""

from __future__ import annotations

import struct
import subprocess
import sys
import tempfile
from pathlib import Path

try:
    from capstone import Cs, CS_ARCH_X86, CS_MODE_32
except ImportError:
    print("SKIP: Python capstone module is not installed")
    sys.exit(77)


SLICE_RVA = 0x1000
SLICE_VA = 0x401000
SLICE_BYTES = bytes.fromhex("83 F8 02 74 02 90 C3 B8 01 00 00 00 C3")


def put16(buf: bytearray, off: int, value: int) -> None:
    struct.pack_into("<H", buf, off, value)


def put32(buf: bytearray, off: int, value: int) -> None:
    struct.pack_into("<I", buf, off, value)


def make_synthetic_pe(path: Path) -> None:
    buf = bytearray(0x400)
    buf[0:2] = b"MZ"
    put32(buf, 0x3C, 0x80)
    buf[0x80:0x84] = b"PE\0\0"
    put16(buf, 0x84, 0x14C)
    put16(buf, 0x86, 1)
    put16(buf, 0x94, 0xE0)
    opt = 0x98
    put16(buf, opt, 0x10B)
    buf[opt + 2] = 7
    buf[opt + 3] = 10
    put32(buf, opt + 16, SLICE_RVA)
    put32(buf, opt + 28, 0x400000)
    put32(buf, opt + 32, 0x1000)
    put32(buf, opt + 36, 0x200)
    put32(buf, opt + 56, 0x2000)
    put32(buf, opt + 60, 0x200)
    put16(buf, opt + 68, 2)
    put32(buf, opt + 92, 16)
    sec = opt + 0xE0
    buf[sec:sec + 5] = b".text"
    put32(buf, sec + 8, 0x100)
    put32(buf, sec + 12, SLICE_RVA)
    put32(buf, sec + 16, 0x200)
    put32(buf, sec + 20, 0x200)
    put32(buf, sec + 36, 0x60000020)
    buf[0x200:0x200 + len(SLICE_BYTES)] = SLICE_BYTES
    path.write_bytes(buf)


def parse_summary(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip()
    return out


def u16(data: bytes, off: int) -> int:
    return struct.unpack_from("<H", data, off)[0]


def u32(data: bytes, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def pe_slice_bytes(path: Path, rva: int, size: int) -> tuple[int, bytes]:
    data = path.read_bytes()
    if data[:2] != b"MZ":
        raise ValueError("not MZ")
    pe = u32(data, 0x3C)
    if data[pe:pe + 4] != b"PE\0\0":
        raise ValueError("not PE")
    section_count = u16(data, pe + 6)
    optional_size = u16(data, pe + 20)
    opt = pe + 24
    if u16(data, opt) != 0x10B:
        raise ValueError("unsupported optional header")
    image_base = u32(data, opt + 28)
    sec_off = opt + optional_size
    for idx in range(section_count):
        off = sec_off + idx * 40
        virtual_size = u32(data, off + 8)
        virtual_address = u32(data, off + 12)
        raw_size = u32(data, off + 16)
        raw_ptr = u32(data, off + 20)
        span = max(virtual_size, raw_size)
        if span and virtual_address <= rva < virtual_address + span:
            delta = rva - virtual_address
            if delta + size > raw_size:
                raise ValueError("slice exceeds raw section")
            file_off = raw_ptr + delta
            return image_base + rva, data[file_off:file_off + size]
    raise ValueError("slice rva not mapped")


def run_slice(exe: str, path: Path, rva: int, size: int) -> dict[str, str]:
    proc = subprocess.run(
        [exe, "analyze-pe-slice", str(path), hex(rva), str(size)],
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip())
    return parse_summary(proc.stdout)


def compare_slice(exe: str, path: Path, rva: int, size: int, strict: bool) -> int:
    summary = run_slice(exe, path, rva, size)
    base, code = pe_slice_bytes(path, rva, size)

    md = Cs(CS_ARCH_X86, CS_MODE_32)
    capstone_count = len(list(md.disasm(code, base)))
    x86_count = int(summary.get("slice_instructions", "-1"))
    failures: list[str] = []
    if x86_count != capstone_count:
        failures.append(f"slice instruction count != Capstone count {capstone_count}")
    if strict and summary.get("slice_rva") != "0x00001000":
        failures.append(f"unexpected slice_rva {summary.get('slice_rva')!r}")
    if strict and summary.get("slice_section") != ".text":
        failures.append(f"unexpected section {summary.get('slice_section')!r}")
    if strict and summary.get("slice_generated_candidate") != "true":
        failures.append("supported fixture was not marked as generated candidate")

    if failures:
        if not strict:
            print(
                "Capstone slice comparison recorded: "
                f"x86recomp_instructions={x86_count} capstone_instructions={capstone_count} "
                f"count_match=false generated_candidate={summary.get('slice_generated_candidate')}"
            )
            return 0
        print("Capstone slice verification failed:")
        for failure in failures:
            print(f"  - {failure}")
        return 1

    print(
        f"Capstone {sys.modules['capstone'].__version__} verified PE slice analysis in x86 32-bit mode: "
        f"x86recomp_instructions={x86_count} capstone_instructions={capstone_count} count_match=true "
        f"generated_candidate={summary.get('slice_generated_candidate')}"
    )
    return 0


def main() -> int:
    if len(sys.argv) not in (2, 5):
        print("usage: capstone_slice_verify.py <x86recomp_exe> [<pe> <rva> <size>]", file=sys.stderr)
        return 2

    exe = sys.argv[1]
    if len(sys.argv) == 5:
        return compare_slice(exe, Path(sys.argv[2]), int(sys.argv[3], 0), int(sys.argv[4], 0), strict=False)

    with tempfile.TemporaryDirectory(prefix="x86recomp-slice-") as tmp:
        pe_path = Path(tmp) / "slice_fixture.exe"
        make_synthetic_pe(pe_path)
        return compare_slice(exe, pe_path, SLICE_RVA, len(SLICE_BYTES), strict=True)


if __name__ == "__main__":
    sys.exit(main())
