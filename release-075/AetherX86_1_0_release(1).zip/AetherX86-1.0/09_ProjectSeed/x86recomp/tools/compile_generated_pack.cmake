if(NOT DEFINED GENERATOR)
  message(FATAL_ERROR "GENERATOR is required")
endif()
if(NOT DEFINED WORK_DIR)
  message(FATAL_ERROR "WORK_DIR is required")
endif()
if(NOT DEFINED RUNTIME_SRC)
  message(FATAL_ERROR "RUNTIME_SRC is required")
endif()
if(NOT DEFINED RUNTIME_INCLUDE_DIR)
  message(FATAL_ERROR "RUNTIME_INCLUDE_DIR is required")
endif()
if(NOT DEFINED HEX_BYTES_1 OR NOT DEFINED HEX_BYTES_2 OR NOT DEFINED HEX_BYTES_3)
  message(FATAL_ERROR "HEX_BYTES_1, HEX_BYTES_2, and HEX_BYTES_3 are required")
endif()

file(REMOVE_RECURSE "${WORK_DIR}")
file(MAKE_DIRECTORY "${WORK_DIR}")

set(GENERATED_CPP "${WORK_DIR}/generated_pack.cpp")
execute_process(
  COMMAND "${GENERATOR}" emit-cfg-c-pack-raw "${HEX_BYTES_1}" "${HEX_BYTES_2}" "${HEX_BYTES_3}"
  OUTPUT_FILE "${GENERATED_CPP}"
  RESULT_VARIABLE gen_result
  ERROR_VARIABLE gen_error
)
if(NOT gen_result EQUAL 0)
  message(FATAL_ERROR "generator failed: ${gen_error}")
endif()

file(READ "${GENERATED_CPP}" generated_text)
foreach(required
  "debug_function_pack_count: 3"
  "debug_function_map: sub_00401000"
  "debug_function_map: sub_00402000"
  "debug_function_map: sub_00403000")
  if(NOT generated_text MATCHES "${required}")
    message(FATAL_ERROR "generated pack missing ${required}")
  endif()
endforeach()
if(DEFINED EXPECT_DIRECT_CALL AND EXPECT_DIRECT_CALL)
  if(NOT generated_text MATCHES "debug_direct_call_map: from=sub_00401000 target=0x00402000u resolved=generated")
    message(FATAL_ERROR "generated pack missing resolved direct-call debug map")
  endif()
  if(NOT generated_text MATCHES "sub_00402000\\(ctx, rt\\);")
    message(FATAL_ERROR "generated pack missing generated direct-call dispatch")
  endif()
endif()

file(WRITE "${WORK_DIR}/CMakeLists.txt"
"cmake_minimum_required(VERSION 3.20)\n"
"project(generated_pack_compile LANGUAGES CXX)\n"
"set(CMAKE_CXX_STANDARD 20)\n"
"add_executable(generated_pack generated_pack.cpp \"${RUNTIME_SRC}\")\n"
"target_include_directories(generated_pack PRIVATE \"${RUNTIME_INCLUDE_DIR}\")\n")

execute_process(
  COMMAND "${CMAKE_COMMAND}" -S "${WORK_DIR}" -B "${WORK_DIR}/build"
  RESULT_VARIABLE configure_result
)
if(NOT configure_result EQUAL 0)
  message(FATAL_ERROR "generated pack configure failed")
endif()

execute_process(
  COMMAND "${CMAKE_COMMAND}" --build "${WORK_DIR}/build" --config Debug
  RESULT_VARIABLE build_result
)
if(NOT build_result EQUAL 0)
  message(FATAL_ERROR "generated pack build failed")
endif()

set(GENERATED_EXE "${WORK_DIR}/build/generated_pack")
if(WIN32)
  set(GENERATED_EXE "${WORK_DIR}/build/Debug/generated_pack.exe")
endif()
execute_process(
  COMMAND "${GENERATED_EXE}"
  RESULT_VARIABLE run_result
)
if(NOT run_result EQUAL 0)
  message(FATAL_ERROR "generated pack runtime smoke failed")
endif()
