import os
import shutil
import subprocess
import sys
from pathlib import Path


def run(args, **kwargs):
    result = subprocess.run(args, text=True, capture_output=True, **kwargs)
    if result.returncode != 0:
        raise RuntimeError(
            f"command failed ({result.returncode}): {' '.join(map(str, args))}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def main():
    if len(sys.argv) != 5:
        print("usage: compile_runtime_start_manifest.py <generator> <work_dir> <runtime_src> <runtime_include_dir>",
              file=sys.stderr)
        return 2
    generator = Path(sys.argv[1])
    work_dir = Path(sys.argv[2])
    runtime_src = Path(sys.argv[3])
    runtime_include_dir = Path(sys.argv[4])

    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True)

    manifest_path = work_dir / "synthetic_runtime.runtime_start"
    manifest_path.write_text(
        "\n".join([
            "runtime_start entry_va=0x00401000 stack_base=0x00010000 stack_size=0x1000 "
            "initial_esp=0x00010800 expected_abi=cdecl evidence=synthetic_runtime_start_manifest "
            "rollback=drop_record enabled=true",
            "argument offset=4 value=0x12345678 size=4",
            "",
        ]),
        encoding="utf-8",
    )

    summary = run([generator, "format-runtime-start", manifest_path]).stdout
    if "runtime_start_issues: 0" not in summary:
        raise RuntimeError(summary)

    generated_cpp = work_dir / "generated_pack.cpp"
    generated_cpp.write_text(run([generator, "emit-cfg-c-pack-raw", "8B 44 24 04 C3"]).stdout,
                             encoding="utf-8")
    generated_text = generated_cpp.read_text(encoding="utf-8")
    for required in [
        "debug_function_pack_count: 1",
        "debug_function_map: sub_00401000",
        "runtime_read_mem32",
    ]:
        if required not in generated_text:
            raise RuntimeError(f"generated pack missing {required}")

    runtime_src_cmake = runtime_src.as_posix()
    runtime_include_dir_cmake = runtime_include_dir.as_posix()
    (work_dir / "runtime_start_harness.cpp").write_text(
        "\n".join([
            "#include <cstdint>",
            "#define main generated_pack_main",
            "#include \"generated_pack.cpp\"",
            "#undef main",
            "",
            "int main() {",
            "    xr::runtime_context rt;",
            "    xr::cpu_state ctx;",
            "    xr::runtime_start_config start;",
            "    start.entry_va = 0x00401000u;",
            "    start.stack_base = 0x00010000u;",
            "    start.stack_size = 0x00001000u;",
            "    start.initial_esp = 0x00010800u;",
            "    start.abi = \"cdecl\";",
            "    start.arguments.push_back({4u, 0x12345678u, 4u});",
            "    auto prepared = xr::runtime_prepare_start(rt, ctx, start);",
            "    if (!prepared.ok) return 1;",
            "    sub_00401000(ctx, rt);",
            "    return rt.events.empty() && ctx.esp == 0x00010800u && ctx.eax == 0x12345678u ? 0 : 1;",
            "}",
            "",
        ]),
        encoding="utf-8",
    )
    (work_dir / "CMakeLists.txt").write_text(
        "\n".join([
            "cmake_minimum_required(VERSION 3.20)",
            "project(runtime_start_manifest_compile LANGUAGES CXX)",
            "set(CMAKE_CXX_STANDARD 20)",
            f'add_executable(runtime_start_manifest runtime_start_harness.cpp "{runtime_src_cmake}")',
            f'target_include_directories(runtime_start_manifest PRIVATE "{runtime_include_dir_cmake}" "{work_dir.as_posix()}")',
            "",
        ]),
        encoding="utf-8",
    )
    build_dir = work_dir / "build"
    run(["cmake", "-S", work_dir, "-B", build_dir])
    run(["cmake", "--build", build_dir, "--config", "Debug"])
    exe = build_dir / "runtime_start_manifest"
    if os.name == "nt":
        exe = build_dir / "Debug" / "runtime_start_manifest.exe"
    run([exe])
    return 0


if __name__ == "__main__":
    sys.exit(main())
