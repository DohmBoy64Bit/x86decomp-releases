import tempfile
import unittest
from pathlib import Path

from n64recomp_kit.splat import create_splat_config
from n64recomp_kit.cli import main


class SplatTests(unittest.TestCase):
    def test_create_splat_config(self):
        rom = Path(__file__).parent / "fixtures" / "minimal.z64"
        with tempfile.TemporaryDirectory() as td:
            padded = Path(td) / "game.z64"
            padded.write_bytes(rom.read_bytes() + b"\0" * 0x1000)
            cfg = Path(td) / "decomp" / "splat.yaml"
            report = create_splat_config(
                cfg,
                rom_path=padded,
                basename="fixture",
                code_start=0x1000,
                vram=0x80000400,
            )
            text = cfg.read_text()
            self.assertEqual(report.basename, "fixture")
            self.assertIn("platform: n64", text)
            self.assertIn("splat.yaml", report.config)
            self.assertIn("- [0x1000, asm, boot]", text)
            self.assertTrue((Path(td) / "decomp" / "asm").is_dir())

    def test_splat_init_cli(self):
        rom = Path(__file__).parent / "fixtures" / "minimal.z64"
        with tempfile.TemporaryDirectory() as td:
            padded = Path(td) / "game.z64"
            padded.write_bytes(rom.read_bytes() + b"\0" * 0x1000)
            cfg = Path(td) / "splat.yaml"
            rc = main([
                "splat-init",
                "--config", str(cfg),
                "--rom", str(padded),
                "--basename", "fixture",
            ])
            self.assertEqual(rc, 0)
            self.assertTrue(cfg.is_file())


if __name__ == "__main__":
    unittest.main()
