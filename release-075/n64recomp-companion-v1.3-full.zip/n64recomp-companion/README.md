# n64recomp-companion

Windows-first companion toolkit for N64Recomp workflows: Podman build environment, PowerShell bootstrap scripts, Splat integration, open MIPS toolchain checks, CDB trace evidence helpers, ROM/ELF triage, workspace phase detection, N64Recomp config validation, batch codegen runs, RT64/RmlUi runtime starter generation, and reproducible JSON reports.

This repository does not include Nintendo ROMs, proprietary game assets, private SDK material, or a finished runtime for any commercial game. N64Recomp code generation is only one layer of a native PC port. A practical port also needs verified metadata, runtime glue, overlays, DMA, saves, input, audio, renderer integration, and platform-specific debugging.

## What is included

```text
n64recomp-companion/
├── Containerfile                       # Podman image with N64Recomp, Splat, and GNU MIPS tools
├── pyproject.toml                      # installable Python CLI package
├── n64recomp_kit/                      # stdlib-only Python implementation
├── tools/                              # direct script entry points
├── scripts/                            # PowerShell-first and shell automation
├── templates/                          # generated Windows RT64/RmlUi starter project
├── docs/                               # Windows, Podman, Splat, runtime starter, workflow, and config docs
├── tests/                              # unit tests and binary fixtures
└── .github/workflows/ci.yml            # package test workflow
```

## Windows fast start

Open PowerShell in the repository root.

```powershell
python -m pip install -e .
python -m n64recomp_kit doctor --root .
python -m n64recomp_kit workspace-status --root .
```

Install local Python decomp tools:

```powershell
.\scripts\Bootstrap-DecompTools.ps1
. .\.deps\decomp-tools\env.ps1
python -m n64recomp_kit doctor --root .
```

Build upstream N64Recomp natively from an x64 Developer PowerShell:

```powershell
.\scripts\Bootstrap-N64Recomp-Windows.ps1 -Prefix .deps\N64Recomp -Ref main
python -m n64recomp_kit doctor --n64recomp .\.deps\N64Recomp\build\N64Recomp.exe --root .
```

Use Podman instead of installing Linux MIPS tools locally:

```powershell
.\scripts\Initialize-PodmanMachine.ps1
.\scripts\Build-PodmanImage.ps1
.\scripts\Enter-PodmanShell.ps1 -WorkDir .
```

Inside the Podman container, the project is mounted at `/work`; `N64Recomp`, Splat, `uv`, and GNU big-endian MIPS tools are on `PATH`.

## Phase-aware workflow

Start every real project by recording state and classifying the workspace:

```powershell
python -m n64recomp_kit init-state --root .
python -m n64recomp_kit workspace-status --root .
```

The detector looks for `baserom.z64`, Splat YAML, `asm/`, `configure.py`, `*.recomp.toml`, `RecompiledFuncs/`, `external/N64Recomp`, `external/N64ModernRuntime`, `docs/function_ledger.md`, and `tools/*cdb*.ps1`. It reports a Track A matching-decomp phase or Track B N64Recomp phase with gaps and one concrete next step.

## ROM and Splat workflow

Inspect a legally obtained ROM image:

```powershell
python -m n64recomp_kit rom-info C:\N64\Project\baserom.n64
```

Normalize byte order when needed:

```powershell
python -m n64recomp_kit convert-rom C:\N64\Project\baserom.v64 C:\N64\Project\baserom.z64 --overwrite
```

Generate and run a conservative Splat starting config:

```powershell
python -m n64recomp_kit splat-init --config decomp\splat.yaml --rom baserom.z64 --basename game_us --overwrite
python -m n64recomp_kit splat-run decomp\splat.yaml --report build\splat-report.json
```

Splat-generated `asm/` is an artifact. Do not fix BSS, segment, or split errors by hand-editing generated assembly; fix YAML/symbol metadata and re-split.

## First matching build support

For a first assembly-only matching attempt after Splat has generated `asm/`, emit a minimal `configure.py`:

```powershell
python -m n64recomp_kit emit-matching-configure --root . --game game_us
python -m n64recomp_kit matching-build --root . --clean --build --report build\matching-build.json
```

The generated build expects `asm/`, `baserom.z64`, and a linker script named after the game slug, such as `game_us.ld`. Tool paths are controlled by `AS`, `LD`, and `OBJCOPY` environment variables.

## MIPS toolchain checks

Check for open MIPS tools on `PATH`:

```powershell
python -m n64recomp_kit toolchain-info
python -m n64recomp_kit mips-smoke --prefix mips-linux-gnu- --output-dir build\mips-smoke
```

On Windows, the Podman container is the most repeatable path for GNU MIPS tools. Native Windows matching builds can also use project-specific MSYS2 or cross-toolchain paths if they are already installed and exposed on `PATH`.

## N64Recomp codegen workflow

Inspect the ELF built by a matching disassembly/decompilation project:

```powershell
python -m n64recomp_kit elf-info build\game.elf
```

Create a concrete N64Recomp TOML config using real paths:

```powershell
python -m n64recomp_kit init --config game.recomp.toml --entrypoint 0x80000400 --elf build\game.elf --output-func-path RecompiledFuncs --overwrite
python -m n64recomp_kit check-config game.recomp.toml
```

Run N64Recomp with a JSON report:

```powershell
python -m n64recomp_kit run game.recomp.toml --n64recomp .\.deps\N64Recomp\build\N64Recomp.exe --clean-output --report build\recomp-report.json
python -m n64recomp_kit summarize-output RecompiledFuncs
```

Do not treat generated `RecompiledFuncs/` as the primary edit target. Fix TOML, symbols, overlay metadata, or host runtime glue first.


## RT64, RmlUi, LunaSVG, and FreeType runtime starter

Generate a named Windows CMake project that opens a basic SDL2 game window, links RT64 when enabled, and includes launcher/menu RML assets backed by RmlUi, LunaSVG, and FreeType dependency wiring:

```powershell
python -m n64recomp_kit new-runtime-project --output .\runtime\MyGame --name "My Game" --overwrite
cd .\runtime\MyGame
.\scripts\Configure-Windows.ps1
.\scripts\Build-Windows.ps1
.\scripts\Run-Windows.ps1
```

The generated starter includes `CMakeLists.txt`, `CMakePresets.json`, a `Makefile`, `vcpkg.json`, Windows PowerShell configure/build/run scripts, `src/main.cpp`, RT64/RmlUi status glue, and menu assets under `assets/ui`. It does not include ROMs, proprietary assets, or game-specific runtime glue. Add N64Recomp output and N64ModernRuntime integration after the ELF/codegen path is real.

## Windows CDB evidence helpers

Find `cdb.exe` and project wrapper scripts:

```powershell
python -m n64recomp_kit cdb-info --root .
```

After running a project-specific CDB wrapper, archive the result:

```powershell
python -m n64recomp_kit cdb-evidence --output logs\traces\overlay_dispatch.cdb.md --wrapper tools\run_game_cdb.ps1 --target build\GameRecompiled.exe --result HIT --breakpoint GameRecompiled!overlay_dispatch --summary "Breakpoint hit before first overlay call."
```

CDB proves host-process behavior. Guest VRAM/RDRAM facts still need static evidence from ROM/ELF/symbols or a guest debugger bridge.

## Batch runs

Create a batch manifest with real config files:

```toml
[[project]]
name = "game-us"
config = "game.us.recomp.toml"

[[project]]
name = "game-jp"
config = "game.jp.recomp.toml"
```

Validate or run the batch:

```powershell
python -m n64recomp_kit batch batch.toml --mode check --report build\batch-check.json
python -m n64recomp_kit batch batch.toml --mode run --n64recomp .\.deps\N64Recomp\build\N64Recomp.exe --report build\batch-run.json
```

## Direct scripts

| Script | Purpose |
|---|---|
| `tools/n64_rom_info.py` | Inspect N64 ROM byte order, header fields, bootcode hash, and checksum header words. |
| `tools/n64_rom_convert.py` | Convert `.n64` or `.v64` byte order to big-endian `.z64`. |
| `tools/n64_elf_info.py` | Inspect ELF class, endian mode, architecture, entry point, and executable sections. |
| `tools/n64_workspace_status.py` | Detect Track A/B phase, project gaps, state file, and CDB wrappers. |
| `tools/n64_new_runtime_project.py` | Generate a Windows CMake starter with RT64, RmlUi, LunaSVG, and FreeType wiring. |
| `tools/n64_init_state.py` | Write `N64_PROJECT_STATE.md`. |
| `tools/n64_init_ledger.py` | Write `docs/function_ledger.md`. |
| `tools/n64_emit_matching_configure.py` | Generate a conservative assembly-only `configure.py`. |
| `tools/n64_matching_build.py` | Run the generated matching build and write a JSON report. |
| `tools/n64recomp_config_check.py` | Validate N64Recomp TOML config paths and value constraints. |
| `tools/n64recomp_run.py` | Run N64Recomp with validation and JSON reporting. |
| `tools/n64recomp_batch.py` | Batch-check or batch-run several configs. |
| `tools/n64_splat_init.py` | Generate a conservative Splat YAML starting point. |
| `tools/n64_splat_run.py` | Run Splat and write a JSON report. |
| `tools/mips_toolchain_info.py` | Discover open MIPS cross toolchains on `PATH`. |
| `tools/mips_smoke_test.py` | Assemble and link a tiny big-endian MIPS ELF. |
| `tools/n64_cdb_info.py` | Locate CDB and project CDB wrappers. |
| `tools/n64_cdb_evidence.py` | Archive CDB trace conclusions in a repeatable evidence note. |

## Verification status

The Python implementation uses only the standard library. The package is tested locally with unit tests and binary fixtures. Current upstream facts are documented in [`docs/verified-facts.md`](docs/verified-facts.md), and Windows/Podman details are documented in [`docs/windows-setup.md`](docs/windows-setup.md) and [`docs/podman.md`](docs/podman.md).

## Legal notes

Use this toolkit only with game files you are legally allowed to inspect or transform. Do not commit ROMs, game assets, generated proprietary code, private SDK material, local ROM paths, or private debug traces.

## License

MIT. See [`LICENSE`](LICENSE).
