import json
import tempfile
import unittest
from pathlib import Path

from n64recomp_kit.cli import main
from n64recomp_kit.local_llm import emit_local_llm_workflow, local_llm_doctor, _openai_tools_from_mcp


class LocalLlmWorkflowTests(unittest.TestCase):
    def test_emit_workflow_files(self):
        with tempfile.TemporaryDirectory() as td:
            report = emit_local_llm_workflow(td, mupen_root="C:/Mupen64MCP", overwrite=True)
            files = {Path(p).name for p in report.files}
            self.assertIn("Start-Mupen64McpDaemon.ps1", files)
            self.assertIn("Start-LMStudioServer.ps1", files)
            self.assertIn("Start-LlamaCppServer.ps1", files)
            self.assertIn("Invoke-LocalLlmMcpPrompt.ps1", files)
            cfg = Path(td) / "configs" / "local-llm" / "mcp-client-config.json"
            data = json.loads(cfg.read_text(encoding="utf-8"))
            args = data["mcpServers"]["n64-debug-mcp"]["args"]
            self.assertIn("C:/Mupen64MCP/mcp/python", args)
            ps = (Path(td) / "scripts" / "Start-Mupen64McpDaemon.ps1").read_text(encoding="utf-8")
            self.assertIn("mupen64plus-video-rice.dll", ps)
            self.assertIn("mupen64plus-rsp-hle.dll", ps)
            self.assertIn("PATH ORDER CRITICAL", ps)

    def test_cli_emit_and_doctor(self):
        with tempfile.TemporaryDirectory() as td:
            self.assertEqual(main(["emit-local-llm-workflow", "--root", td, "--mupen-root", "C:/Mupen64MCP", "--overwrite"]), 0)
            self.assertEqual(main(["local-llm-doctor", "--root", td, "--timeout", "1"]), 0)

    def test_doctor_mupen_layout(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for rel in [
                "native/n64_debug_daemon/build/n64-debug-daemon.exe",
                "mcp/python",
                "build/mupen64plus/lib/mupen64plus.dll",
                "native/n64_debug_daemon/build/mupen64plus-input-inject.dll",
                "plugins/mupen64plus-video-rice.dll",
                "plugins/mupen64plus-rsp-hle.dll",
            ]:
                p = root / rel
                p.parent.mkdir(parents=True, exist_ok=True)
                if p.suffix:
                    p.write_bytes(b"x")
                else:
                    p.mkdir(exist_ok=True)
            data = local_llm_doctor(root=".", mupen_root=root, timeout=1)
            self.assertTrue(data["mupen64mcp"]["ready_for_headless_debug"])
            self.assertTrue(data["mupen64mcp"]["ready_for_frame_capture"])

    def test_openai_tools_from_mcp(self):
        tools = _openai_tools_from_mcp([
            {"name": "n64_get_pc", "description": "read pc", "inputSchema": {"type": "object", "properties": {}}}
        ])
        self.assertEqual(tools[0]["function"]["name"], "n64_get_pc")
        self.assertEqual(tools[0]["function"]["parameters"]["type"], "object")


if __name__ == "__main__":
    unittest.main()
