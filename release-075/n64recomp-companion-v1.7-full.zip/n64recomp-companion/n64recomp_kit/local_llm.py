from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable, Sequence

from .util import write_json


@dataclass
class LocalLlmWorkflowReport:
    root: str
    files: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


DEFAULT_MCP_SERVER_NAME = "n64-debug-mcp"
DEFAULT_LMSTUDIO_BASE_URL = "http://127.0.0.1:1234/v1"
DEFAULT_LLAMA_CPP_BASE_URL = "http://127.0.0.1:8080/v1"


def _ps_quote(text: str) -> str:
    return "'" + text.replace("'", "''") + "'"


def _write(path: Path, text: str, *, overwrite: bool) -> str:
    if path.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite existing file: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.replace("\n", "\r\n") if path.suffix.lower() == ".ps1" else text, encoding="utf-8")
    return str(path)


def _mcp_client_config(mupen_root: str, server_name: str = DEFAULT_MCP_SERVER_NAME) -> dict[str, Any]:
    return {
        "mcpServers": {
            server_name: {
                "command": "uv",
                "args": ["--directory", str(Path(mupen_root) / "mcp" / "python"), "run", "n64-debug-mcp"],
            }
        }
    }


def emit_local_llm_workflow(
    root: str | Path = ".",
    *,
    mupen_root: str = "D:/Mupen64MCP",
    overwrite: bool = False,
) -> LocalLlmWorkflowReport:
    """Write Windows-first helper scripts for Mupen64MCP plus local OpenAI-compatible LLM servers."""
    root_path = Path(root)
    files: list[str] = []
    scripts = root_path / "scripts"
    configs = root_path / "configs" / "local-llm"
    prompts = root_path / "prompts"
    docs = root_path / "docs"

    files.append(_write(scripts / "Start-Mupen64McpDaemon.ps1", START_DAEMON_PS1, overwrite=overwrite))
    files.append(_write(scripts / "Start-Mupen64McpServer.ps1", START_MCP_SERVER_PS1, overwrite=overwrite))
    files.append(_write(scripts / "Start-LMStudioServer.ps1", START_LMSTUDIO_PS1, overwrite=overwrite))
    files.append(_write(scripts / "Start-LlamaCppServer.ps1", START_LLAMA_CPP_PS1, overwrite=overwrite))
    files.append(_write(scripts / "Invoke-LocalLlmMcpPrompt.ps1", INVOKE_LOCAL_LLM_MCP_PS1, overwrite=overwrite))
    files.append(_write(scripts / "Test-LocalLlmMcpWorkflow.ps1", TEST_LOCAL_LLM_MCP_PS1, overwrite=overwrite))

    client_config = _mcp_client_config(mupen_root)
    client_path = configs / "mcp-client-config.json"
    if client_path.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite existing file: {client_path}")
    write_json(client_path, client_config)
    files.append(str(client_path))

    local_agent_config = {
        "lmstudio": {"base_url": DEFAULT_LMSTUDIO_BASE_URL, "api_key": "lm-studio"},
        "llama_cpp_python": {"base_url": DEFAULT_LLAMA_CPP_BASE_URL, "api_key": "local"},
        "mcp": {
            "server_name": DEFAULT_MCP_SERVER_NAME,
            "command": "uv",
            "args": ["--directory", str(Path(mupen_root) / "mcp" / "python"), "run", "n64-debug-mcp"],
        },
        "daemon": {
            "port": 9876,
            "rendered_capture": {
                "gfx": "plugins/mupen64plus-video-rice.dll",
                "rsp": "plugins/mupen64plus-rsp-hle.dll",
                "audio": "dummy",
            },
            "headless_debug": {"gfx": "dummy", "rsp": "dummy", "audio": "dummy"},
        },
    }
    agent_path = configs / "local-agent.json"
    if agent_path.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite existing file: {agent_path}")
    write_json(agent_path, local_agent_config)
    files.append(str(agent_path))

    files.append(_write(prompts / "n64-mcp-analysis.md", MCP_ANALYSIS_PROMPT, overwrite=overwrite))
    files.append(_write(docs / "local-llm-mcp.md", LOCAL_LLM_DOC, overwrite=overwrite))
    return LocalLlmWorkflowReport(root=str(root_path), files=files)


def probe_openai_compatible(base_url: str, *, api_key: str = "local", timeout: int = 5) -> dict[str, Any]:
    base = base_url.rstrip("/")
    request = urllib.request.Request(
        base + "/models",
        headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"},
        method="GET",
    )
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read().decode("utf-8", errors="replace")
            try:
                payload = json.loads(body)
            except json.JSONDecodeError:
                payload = {"raw": body[:1000]}
            models = payload.get("data", []) if isinstance(payload, dict) else []
            return {
                "base_url": base_url,
                "available": True,
                "status": response.status,
                "seconds": round(time.perf_counter() - started, 3),
                "model_count": len(models) if isinstance(models, list) else 0,
                "models": [m.get("id") for m in models if isinstance(m, dict) and m.get("id")][:20],
            }
    except (OSError, urllib.error.URLError, urllib.error.HTTPError) as exc:
        return {
            "base_url": base_url,
            "available": False,
            "seconds": round(time.perf_counter() - started, 3),
            "error": str(exc),
        }


def local_llm_doctor(
    *,
    root: str | Path = ".",
    mupen_root: str | Path | None = None,
    lmstudio_base_url: str = DEFAULT_LMSTUDIO_BASE_URL,
    llama_cpp_base_url: str = DEFAULT_LLAMA_CPP_BASE_URL,
    api_key: str = "local",
    timeout: int = 3,
) -> dict[str, Any]:
    project_root = Path(root)
    mupen = Path(mupen_root) if mupen_root else None
    scripts = [
        project_root / "scripts" / "Start-Mupen64McpDaemon.ps1",
        project_root / "scripts" / "Start-Mupen64McpServer.ps1",
        project_root / "scripts" / "Invoke-LocalLlmMcpPrompt.ps1",
    ]
    mupen_layout: dict[str, Any] = {"root": str(mupen) if mupen else None, "checked": mupen is not None}
    if mupen:
        expected = {
            "daemon": mupen / "native" / "n64_debug_daemon" / "build" / "n64-debug-daemon.exe",
            "mcp_python": mupen / "mcp" / "python",
            "core": mupen / "build" / "mupen64plus" / "lib" / "mupen64plus.dll",
            "input": mupen / "native" / "n64_debug_daemon" / "build" / "mupen64plus-input-inject.dll",
            "rice": mupen / "plugins" / "mupen64plus-video-rice.dll",
            "rsp_hle": mupen / "plugins" / "mupen64plus-rsp-hle.dll",
        }
        mupen_layout["paths"] = {name: {"path": str(path), "exists": path.exists()} for name, path in expected.items()}
        mupen_layout["ready_for_headless_debug"] = all(mupen_layout["paths"][key]["exists"] for key in ["daemon", "mcp_python", "core", "input"])
        mupen_layout["ready_for_frame_capture"] = mupen_layout["ready_for_headless_debug"] and all(mupen_layout["paths"][key]["exists"] for key in ["rice", "rsp_hle"])
    return {
        "tools": {
            "uv": shutil.which("uv"),
            "lms": shutil.which("lms"),
            "llama-server": shutil.which("llama-server"),
            "python": sys.executable,
        },
        "workflow_scripts": [{"path": str(path), "exists": path.exists()} for path in scripts],
        "mupen64mcp": mupen_layout,
        "lmstudio": probe_openai_compatible(lmstudio_base_url, api_key=api_key, timeout=timeout),
        "llama_cpp": probe_openai_compatible(llama_cpp_base_url, api_key=api_key, timeout=timeout),
    }


def format_local_llm_doctor(data: dict[str, Any]) -> str:
    lines = ["Local LLM / Mupen64MCP workflow"]
    lines.append("Tools:")
    for name, path in data["tools"].items():
        lines.append(f"  {name:<13} {path or 'not found'}")
    lines.append("Workflow scripts:")
    for script in data["workflow_scripts"]:
        lines.append(f"  {'yes' if script['exists'] else 'no '} {script['path']}")
    mupen = data["mupen64mcp"]
    if mupen.get("checked"):
        lines.append(f"Mupen64MCP root: {mupen['root']}")
        for name, entry in mupen.get("paths", {}).items():
            lines.append(f"  {name:<12} {'yes' if entry['exists'] else 'no '} {entry['path']}")
        lines.append(f"Headless debug ready : {'yes' if mupen.get('ready_for_headless_debug') else 'no'}")
        lines.append(f"Frame capture ready  : {'yes' if mupen.get('ready_for_frame_capture') else 'no'}")
    else:
        lines.append("Mupen64MCP root: not checked")
    for key in ["lmstudio", "llama_cpp"]:
        probe = data[key]
        label = "LM Studio" if key == "lmstudio" else "llama.cpp"
        lines.append(f"{label:<10}: {'available' if probe.get('available') else 'not reachable'} at {probe.get('base_url')}")
        if probe.get("models"):
            lines.append("  models: " + ", ".join(probe["models"]))
        elif probe.get("error"):
            lines.append("  " + probe["error"])
    return "\n".join(lines)


class McpStdioClient:
    """Small stdio MCP client for local tool bridges."""

    def __init__(self, command: Sequence[str], *, cwd: str | Path | None = None, timeout: int = 30):
        self.command = list(command)
        self.cwd = str(cwd) if cwd is not None else None
        self.timeout = timeout
        self.proc: subprocess.Popen[str] | None = None
        self._next_id = 1

    def __enter__(self) -> "McpStdioClient":
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def start(self) -> None:
        if self.proc is not None:
            return
        self.proc = subprocess.Popen(
            self.command,
            cwd=self.cwd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        self.request(
            "initialize",
            {
                "protocolVersion": "2025-06-18",
                "capabilities": {},
                "clientInfo": {"name": "n64recomp-kit-local-llm", "version": "1.7.0"},
            },
        )
        self.notify("notifications/initialized", {})

    def close(self) -> None:
        if self.proc is None:
            return
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        self.proc = None

    def _send(self, payload: dict[str, Any]) -> None:
        if self.proc is None or self.proc.stdin is None:
            raise RuntimeError("MCP process is not running")
        self.proc.stdin.write(json.dumps(payload, separators=(",", ":")) + "\n")
        self.proc.stdin.flush()

    def _read_message(self) -> dict[str, Any]:
        if self.proc is None or self.proc.stdout is None:
            raise RuntimeError("MCP process is not running")
        deadline = time.time() + self.timeout
        while time.time() < deadline:
            line = self.proc.stdout.readline()
            if line:
                text = line.strip()
                if not text:
                    continue
                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    continue
            if self.proc.poll() is not None:
                stderr = self.proc.stderr.read() if self.proc.stderr else ""
                raise RuntimeError(f"MCP process exited with {self.proc.returncode}: {stderr}")
            time.sleep(0.02)
        raise TimeoutError("timed out waiting for MCP response")

    def request(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        req_id = self._next_id
        self._next_id += 1
        payload: dict[str, Any] = {"jsonrpc": "2.0", "id": req_id, "method": method}
        if params is not None:
            payload["params"] = params
        self._send(payload)
        while True:
            message = self._read_message()
            if message.get("id") != req_id:
                continue
            if "error" in message:
                raise RuntimeError(f"MCP {method} failed: {message['error']}")
            result = message.get("result", {})
            return result if isinstance(result, dict) else {"result": result}

    def notify(self, method: str, params: dict[str, Any] | None = None) -> None:
        payload: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        self._send(payload)

    def list_tools(self) -> list[dict[str, Any]]:
        result = self.request("tools/list")
        tools = result.get("tools", [])
        return tools if isinstance(tools, list) else []

    def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        return self.request("tools/call", {"name": name, "arguments": arguments})


def _openai_tools_from_mcp(tools: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    converted = []
    for tool in tools:
        name = tool.get("name")
        if not isinstance(name, str) or not name:
            continue
        schema = tool.get("inputSchema") if isinstance(tool.get("inputSchema"), dict) else {"type": "object", "properties": {}}
        converted.append(
            {
                "type": "function",
                "function": {
                    "name": name,
                    "description": str(tool.get("description") or f"Call the MCP tool {name}"),
                    "parameters": schema,
                },
            }
        )
    return converted


def _chat_completion(
    *,
    base_url: str,
    api_key: str,
    model: str,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
    temperature: float,
    timeout: int,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"model": model, "messages": messages, "temperature": temperature}
    if tools:
        payload["tools"] = tools
        payload["tool_choice"] = "auto"
    req = urllib.request.Request(
        base_url.rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8", errors="replace"))


def _tool_result_text(result: dict[str, Any]) -> str:
    content = result.get("content")
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict):
                if item.get("type") == "text" and isinstance(item.get("text"), str):
                    parts.append(item["text"])
                else:
                    parts.append(json.dumps(item, sort_keys=True))
            else:
                parts.append(str(item))
        return "\n".join(parts)
    return json.dumps(result, indent=2, sort_keys=True)


def local_llm_ask(
    *,
    prompt: str,
    model: str,
    base_url: str,
    api_key: str = "local",
    mcp_command: Sequence[str] | None = None,
    system: str | None = None,
    max_tool_rounds: int = 8,
    temperature: float = 0.2,
    timeout: int = 120,
) -> dict[str, Any]:
    messages: list[dict[str, Any]] = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    if not mcp_command:
        response = _chat_completion(base_url=base_url, api_key=api_key, model=model, messages=messages, tools=None, temperature=temperature, timeout=timeout)
        message = response.get("choices", [{}])[0].get("message", {})
        return {"ok": True, "tool_rounds": 0, "answer": message.get("content", ""), "raw": response}

    transcript: list[dict[str, Any]] = []
    with McpStdioClient(mcp_command, timeout=timeout) as mcp:
        mcp_tools = mcp.list_tools()
        openai_tools = _openai_tools_from_mcp(mcp_tools)
        for round_index in range(max_tool_rounds + 1):
            response = _chat_completion(base_url=base_url, api_key=api_key, model=model, messages=messages, tools=openai_tools, temperature=temperature, timeout=timeout)
            message = response.get("choices", [{}])[0].get("message", {})
            tool_calls = message.get("tool_calls") or []
            if not tool_calls:
                return {
                    "ok": True,
                    "tool_rounds": round_index,
                    "answer": message.get("content", ""),
                    "available_mcp_tools": [tool.get("name") for tool in mcp_tools if tool.get("name")],
                    "transcript": transcript,
                }
            messages.append(message)
            for call in tool_calls:
                function = call.get("function", {}) if isinstance(call, dict) else {}
                name = function.get("name")
                raw_args = function.get("arguments") or "{}"
                try:
                    args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                except json.JSONDecodeError:
                    args = {}
                if not isinstance(name, str) or not isinstance(args, dict):
                    result = {"isError": True, "content": [{"type": "text", "text": "Invalid tool call payload"}]}
                else:
                    result = mcp.call_tool(name, args)
                transcript.append({"tool": name, "arguments": args, "result": result})
                messages.append({"role": "tool", "tool_call_id": call.get("id"), "content": _tool_result_text(result)})
    return {"ok": False, "tool_rounds": max_tool_rounds, "answer": "tool round limit reached", "transcript": transcript}


START_DAEMON_PS1 = r'''<#
Starts the Mupen64MCP native daemon on Windows.
Real Rice + RSP-HLE plugins are selected in Rendered mode so framebuffer tools can capture pixels.
Dummy graphics remains available for CPU/debug sessions where a black framebuffer is acceptable.
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$MupenRoot,
  [Parameter(Mandatory=$true)][string]$Rom,
  [ValidateSet('Rendered','Headless')][string]$Mode = 'Rendered',
  [int]$Port = 9876,
  [switch]$AllowWriteMemory,
  [string]$DaemonExe,
  [string]$Core,
  [string]$DataDir,
  [string]$ConfigDir,
  [string]$Gfx,
  [string]$Rsp,
  [string]$Audio = 'dummy',
  [string]$InputPlugin,
  [string]$Msys2Bin = 'C:\msys64\mingw64\bin',
  [string]$WinLibsBin = '',
  [switch]$NoStopExisting
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $MupenRoot).Path
if (-not $DaemonExe) { $DaemonExe = Join-Path $root 'native\n64_debug_daemon\build\n64-debug-daemon.exe' }
if (-not $Core) { $Core = Join-Path $root 'build\mupen64plus\lib\mupen64plus.dll' }
if (-not $DataDir) { $DataDir = Join-Path $root 'build\mupen64plus\share' }
if (-not $ConfigDir) { $ConfigDir = Join-Path $root 'build\mupen64plus\config' }
if (-not $InputPlugin) { $InputPlugin = Join-Path $root 'native\n64_debug_daemon\build\mupen64plus-input-inject.dll' }
if (-not $Gfx) {
  if ($Mode -eq 'Rendered') { $Gfx = Join-Path $root 'plugins\mupen64plus-video-rice.dll' } else { $Gfx = 'dummy' }
}
if (-not $Rsp) {
  if ($Mode -eq 'Rendered') { $Rsp = Join-Path $root 'plugins\mupen64plus-rsp-hle.dll' } else { $Rsp = 'dummy' }
}

$required = @($DaemonExe, $Core, $Rom, $DataDir, $ConfigDir, $InputPlugin)
if ($Gfx -ne 'dummy') { $required += $Gfx }
if ($Rsp -ne 'dummy') { $required += $Rsp }
foreach ($path in $required) {
  if (-not (Test-Path -LiteralPath $path)) { throw "Required path not found: $path" }
}

# PATH ORDER CRITICAL for this workflow: MSYS2 -> WinLibs -> Mupen64Plus core lib -> existing system PATH.
$pathParts = @()
if ($Msys2Bin -and (Test-Path -LiteralPath $Msys2Bin)) { $pathParts += $Msys2Bin }
if ($WinLibsBin -and (Test-Path -LiteralPath $WinLibsBin)) { $pathParts += $WinLibsBin }
$pathParts += (Split-Path -Parent $Core)
$env:Path = (($pathParts + @($env:Path)) -join ';')

if (-not $NoStopExisting) {
  Get-Process 'n64-debug-daemon' -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep -Seconds 1
}

$argsList = @(
  '--core', $Core,
  '--rom', $Rom,
  '--datadir', $DataDir,
  '--configdir', $ConfigDir,
  '--gfx', $Gfx,
  '--rsp', $Rsp,
  '--audio', $Audio,
  '--input', $InputPlugin,
  '--port', [string]$Port
)
if ($AllowWriteMemory) { $argsList += '--allow-write-memory' }

Write-Host "Starting n64-debug-daemon on port $Port"
Write-Host "Mode: $Mode"
if ($Mode -eq 'Rendered') {
  Write-Host 'Rendered mode uses real Rice video and RSP-HLE plugins so framebuffer capture can return pixels.'
}
Start-Process -FilePath $DaemonExe -ArgumentList $argsList -NoNewWindow
Write-Host 'Daemon launch requested.'
Write-Host 'For games that need START on boot, call the MCP tool n64_set_controller with buttons="START" and sticky=true before resume.'
'''

START_MCP_SERVER_PS1 = r'''<#
Starts the Python Mupen64MCP server from the repository checkout.
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$MupenRoot,
  [switch]$UseInstalledCommand
)
$ErrorActionPreference = 'Stop'
$mcpPython = Join-Path (Resolve-Path -LiteralPath $MupenRoot).Path 'mcp\python'
if (-not (Test-Path -LiteralPath $mcpPython)) { throw "Mupen64MCP Python server directory not found: $mcpPython" }
if ($UseInstalledCommand) {
  $cmd = Get-Command 'n64-debug-mcp' -ErrorAction Stop
  & $cmd.Source
  exit $LASTEXITCODE
}
$uv = Get-Command 'uv' -ErrorAction SilentlyContinue
if ($uv) {
  & $uv.Source --directory $mcpPython run n64-debug-mcp
  exit $LASTEXITCODE
}
Push-Location $mcpPython
try {
  python -m pip install -e .
  n64-debug-mcp
  exit $LASTEXITCODE
}
finally { Pop-Location }
'''

START_LMSTUDIO_PS1 = r'''<#
Starts or verifies the LM Studio local API server.
LM Studio can also be started from the app Developer tab.
#>
[CmdletBinding()]
param(
  [string]$BaseUrl = 'http://127.0.0.1:1234/v1',
  [switch]$StartWithLmsCli,
  [switch]$VerifyOnly
)
$ErrorActionPreference = 'Stop'
if ($StartWithLmsCli -and -not $VerifyOnly) {
  $lms = Get-Command 'lms' -ErrorAction SilentlyContinue
  if (-not $lms) { throw 'LM Studio CLI `lms` was not found on PATH. Start the server from the LM Studio Developer tab or install/enable the CLI.' }
  & $lms.Source server start
}
$modelsUrl = ($BaseUrl.TrimEnd('/')) + '/models'
try {
  $models = Invoke-RestMethod -Uri $modelsUrl -Headers @{ Authorization = 'Bearer lm-studio' } -TimeoutSec 5
  Write-Host "LM Studio API reachable at $BaseUrl"
  if ($models.data) { $models.data | Select-Object -First 20 id | Format-Table -AutoSize }
}
catch {
  throw "LM Studio API not reachable at $BaseUrl. Start it from the Developer tab, or run this script with -StartWithLmsCli if lms is installed. $($_.Exception.Message)"
}
'''

START_LLAMA_CPP_PS1 = r'''<#
Starts a local OpenAI-compatible llama.cpp server using either llama-cpp-python or llama-server.
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Model,
  [ValidateSet('llama-cpp-python','llama-server')][string]$Mode = 'llama-cpp-python',
  [string]$HostAddress = '127.0.0.1',
  [int]$Port = 8080,
  [int]$ContextSize = 8192,
  [string]$ServerExe,
  [switch]$NoNewWindow
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $Model)) { throw "Model file not found: $Model" }
if ($Mode -eq 'llama-cpp-python') {
  $python = Get-Command 'python' -ErrorAction Stop
  $argsList = @('-m','llama_cpp.server','--model',$Model,'--host',$HostAddress,'--port',[string]$Port,'--n_ctx',[string]$ContextSize)
  Write-Host "Starting llama-cpp-python server at http://$HostAddress`:$Port/v1"
  Start-Process -FilePath $python.Source -ArgumentList $argsList -NoNewWindow:$NoNewWindow
} else {
  if (-not $ServerExe) {
    $cmd = Get-Command 'llama-server' -ErrorAction SilentlyContinue
    if (-not $cmd) { throw 'llama-server was not found on PATH. Pass -ServerExe or use -Mode llama-cpp-python.' }
    $ServerExe = $cmd.Source
  }
  $argsList = @('--model',$Model,'--host',$HostAddress,'--port',[string]$Port,'--ctx-size',[string]$ContextSize)
  Write-Host "Starting llama-server at http://$HostAddress`:$Port/v1"
  Start-Process -FilePath $ServerExe -ArgumentList $argsList -NoNewWindow:$NoNewWindow
}
'''

INVOKE_LOCAL_LLM_MCP_PS1 = r'''<#
Runs one local LLM prompt through n64recomp-kit. When -MupenRoot is supplied, the command also exposes Mupen64MCP tools to the model.
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Prompt,
  [Parameter(Mandatory=$true)][string]$Model,
  [ValidateSet('LMStudio','LlamaCpp')][string]$Provider = 'LMStudio',
  [string]$BaseUrl,
  [string]$ApiKey = 'local',
  [string]$MupenRoot,
  [int]$MaxToolRounds = 8
)
$ErrorActionPreference = 'Stop'
if (-not $BaseUrl) {
  if ($Provider -eq 'LMStudio') { $BaseUrl = 'http://127.0.0.1:1234/v1'; $ApiKey = 'lm-studio' }
  else { $BaseUrl = 'http://127.0.0.1:8080/v1' }
}
$argsList = @('local-llm-ask','--prompt',$Prompt,'--model',$Model,'--base-url',$BaseUrl,'--api-key',$ApiKey,'--max-tool-rounds',[string]$MaxToolRounds)
if ($MupenRoot) {
  $mcpPython = Join-Path (Resolve-Path -LiteralPath $MupenRoot).Path 'mcp\python'
  $argsList += @('--mcp-command','uv','--mcp-arg','--directory','--mcp-arg',$mcpPython,'--mcp-arg','run','--mcp-arg','n64-debug-mcp')
}
python -m n64recomp_kit @argsList
exit $LASTEXITCODE
'''

TEST_LOCAL_LLM_MCP_PS1 = r'''<#
Checks script presence, optional Mupen64MCP paths, and local OpenAI-compatible API endpoints.
#>
[CmdletBinding()]
param(
  [string]$MupenRoot,
  [string]$LMStudioBaseUrl = 'http://127.0.0.1:1234/v1',
  [string]$LlamaCppBaseUrl = 'http://127.0.0.1:8080/v1'
)
$ErrorActionPreference = 'Stop'
$argsList = @('local-llm-doctor','--lmstudio-base-url',$LMStudioBaseUrl,'--llama-cpp-base-url',$LlamaCppBaseUrl)
if ($MupenRoot) { $argsList += @('--mupen-root',$MupenRoot) }
python -m n64recomp_kit @argsList
exit $LASTEXITCODE
'''

MCP_ANALYSIS_PROMPT = """# N64 MCP analysis prompt

You are assisting a Windows-first N64Recomp workflow. Use Mupen64MCP tools conservatively and report every address, register value, breakpoint, and memory range you used as evidence.

Recommended first steps:

1. Check daemon status with `n64_get_status`.
2. If the game is sitting at boot or attract mode, set START before resuming with `n64_set_controller` using `buttons` set to `START` and `sticky` set to true.
3. Capture CPU state with `n64_get_pc` and `n64_get_registers`.
4. Use breakpoints, traces, RDRAM reads, PI DMA capture, and framebuffer capture to connect runtime behavior back to Splat/N64Recomp symbols.
5. Do not write memory unless the session explicitly allows it and the change is recorded.

When framebuffer evidence is needed, the daemon should use real Rice video and RSP-HLE plugins. Dummy graphics is acceptable for CPU/debugging, but it can return a black framebuffer.
"""

LOCAL_LLM_DOC = r"""# Local LLM + Mupen64MCP workflow

This workflow connects three local pieces:

- Mupen64MCP for runtime N64 debugging through Mupen64Plus.
- A local OpenAI-compatible model server from LM Studio or llama.cpp.
- `n64recomp-kit local-llm-ask`, a small bridge that can expose MCP tools to a local model using OpenAI-style tool calls.

## Generate scripts

```powershell
python -m n64recomp_kit emit-local-llm-workflow --root . --mupen-root C:\dev\Mupen64MCP --overwrite
```

## Start Mupen64MCP daemon

Rendered mode uses Rice video plus RSP-HLE for framebuffer capture:

```powershell
.\scripts\Start-Mupen64McpDaemon.ps1 -MupenRoot C:\dev\Mupen64MCP -Rom C:\roms\game.z64 -Mode Rendered -AllowWriteMemory
```

Headless mode keeps CPU/debugging tools available and uses dummy graphics:

```powershell
.\scripts\Start-Mupen64McpDaemon.ps1 -MupenRoot C:\dev\Mupen64MCP -Rom C:\roms\game.z64 -Mode Headless
```

The script prepends PATH in this order for the daemon process: MSYS2 MINGW64, optional WinLibs, Mupen64Plus core library directory, then the existing system PATH.

## Start the MCP server

```powershell
.\scripts\Start-Mupen64McpServer.ps1 -MupenRoot C:\dev\Mupen64MCP
```

The generated `configs/local-llm/mcp-client-config.json` can also be copied into MCP-capable clients.

## Use LM Studio

Start the LM Studio API server from the Developer tab, or use the CLI if `lms` is installed:

```powershell
.\scripts\Start-LMStudioServer.ps1 -StartWithLmsCli
```

Then run a prompt:

```powershell
$ModelId = (Invoke-RestMethod http://127.0.0.1:1234/v1/models).data[0].id
.\scripts\Invoke-LocalLlmMcpPrompt.ps1 -Provider LMStudio -Model $ModelId -MupenRoot C:\dev\Mupen64MCP -Prompt "Check status, press START if needed, then capture PC and registers."
```

## Use llama.cpp

With llama-cpp-python:

```powershell
python -m pip install "llama-cpp-python[server]"
.\scripts\Start-LlamaCppServer.ps1 -Mode llama-cpp-python -Model C:\models\model.gguf
```

With llama-server:

```powershell
.\scripts\Start-LlamaCppServer.ps1 -Mode llama-server -ServerExe C:\tools\llama-server.exe -Model C:\models\model.gguf
```

Then run a prompt:

```powershell
$ModelId = (Invoke-RestMethod http://127.0.0.1:8080/v1/models).data[0].id
.\scripts\Invoke-LocalLlmMcpPrompt.ps1 -Provider LlamaCpp -Model $ModelId -MupenRoot C:\dev\Mupen64MCP -Prompt "Read the current PC and export a short trace summary."
```

## Diagnostics

```powershell
.\scripts\Test-LocalLlmMcpWorkflow.ps1 -MupenRoot C:\dev\Mupen64MCP
python -m n64recomp_kit local-llm-doctor --mupen-root C:\dev\Mupen64MCP --json
```

## MCP operational notes

- `n64_start_daemon` and `n64_stop_daemon` are MCP lifecycle tools; the PowerShell daemon script is a direct alternative for users who want explicit paths.
- Use real Rice video and RSP-HLE plugins when framebuffer capture matters.
- Dummy graphics can be useful for debugger-only work, but framebuffer capture can be black.
- To skip boot or attract mode, call `n64_set_controller` with START sticky before resuming.
- Keep ROM paths outside the repo and never commit copyrighted ROMs.
"""
