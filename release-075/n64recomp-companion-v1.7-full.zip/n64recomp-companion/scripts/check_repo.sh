#!/usr/bin/env bash
set -euo pipefail
python3 -m unittest discover -s tests -v
python3 -m n64recomp_kit doctor --json >/dev/null || true
python3 -m n64recomp_kit workspace-status --root . >/dev/null
python3 -m n64recomp_kit check-config tests/fixtures/valid_elf_config.toml >/dev/null
python3 -m n64recomp_kit elf-info tests/fixtures/minimal_mips_be.elf >/dev/null
python3 -m n64recomp_kit rom-info tests/fixtures/minimal.z64 >/dev/null
python3 -m n64recomp_kit emit-matching-configure --root build/check-matching --game check_game --overwrite >/dev/null
python3 -m n64recomp_kit emit-elf-build --root build/check-elf --overwrite >/dev/null
python3 -m n64recomp_kit cdb-info --root . --json >/dev/null || true
python3 -m n64recomp_kit new-runtime-project --output build/check-runtime --name CheckRuntime --overwrite --json >/dev/null
python3 -m n64recomp_kit emit-local-llm-workflow --root build/check-local-llm --mupen-root C:/Mupen64MCP --overwrite >/dev/null
python3 -m n64recomp_kit local-llm-doctor --root build/check-local-llm --timeout 1 --json >/dev/null || true
