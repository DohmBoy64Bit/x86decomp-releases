<#
Runs one local LLM prompt through n64recomp-kit. When -MupenRoot is supplied, the command also exposes Mupen64MCP tools to the model.
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Prompt,
  [Parameter(Mandatory=$true)][string]$Model,
  [ValidateSet('LMStudio','LlamaCpp')][string]$Provider = 'LMStudio',
  [string]$BaseUrl,
  [string]$ApiKey = 'local',
  [string]$MupenRoot,
  [int]$MaxToolRounds = 8
)
$ErrorActionPreference = 'Stop'
if (-not $BaseUrl) {
  if ($Provider -eq 'LMStudio') { $BaseUrl = 'http://127.0.0.1:1234/v1'; $ApiKey = 'lm-studio' }
  else { $BaseUrl = 'http://127.0.0.1:8080/v1' }
}
$argsList = @('local-llm-ask','--prompt',$Prompt,'--model',$Model,'--base-url',$BaseUrl,'--api-key',$ApiKey,'--max-tool-rounds',[string]$MaxToolRounds)
if ($MupenRoot) {
  $mcpPython = Join-Path (Resolve-Path -LiteralPath $MupenRoot).Path 'mcp\python'
  $argsList += @('--mcp-command','uv','--mcp-arg','--directory','--mcp-arg',$mcpPython,'--mcp-arg','run','--mcp-arg','n64-debug-mcp')
}
python -m n64recomp_kit @argsList
exit $LASTEXITCODE
