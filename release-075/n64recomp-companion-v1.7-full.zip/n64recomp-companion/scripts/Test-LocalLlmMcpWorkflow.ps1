<#
Checks script presence, optional Mupen64MCP paths, and local OpenAI-compatible API endpoints.
#>
[CmdletBinding()]
param(
  [string]$MupenRoot,
  [string]$LMStudioBaseUrl = 'http://127.0.0.1:1234/v1',
  [string]$LlamaCppBaseUrl = 'http://127.0.0.1:8080/v1'
)
$ErrorActionPreference = 'Stop'
$argsList = @('local-llm-doctor','--lmstudio-base-url',$LMStudioBaseUrl,'--llama-cpp-base-url',$LlamaCppBaseUrl)
if ($MupenRoot) { $argsList += @('--mupen-root',$MupenRoot) }
python -m n64recomp_kit @argsList
exit $LASTEXITCODE
