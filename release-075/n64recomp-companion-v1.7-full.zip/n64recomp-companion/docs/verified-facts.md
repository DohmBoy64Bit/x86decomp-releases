# Verified facts used by this package

Checked on 2026-07-10.

## N64Recomp

- Upstream N64Recomp describes itself as a tool that statically recompiles N64 games into native executables.
- Upstream build instructions require CMake 3.20 or newer, a C++20-capable compiler, and recursive submodules.
- N64Recomp code generation is not a complete port runtime by itself. A project still needs host runtime integration.

Source: https://github.com/N64Recomp/N64Recomp

## N64ModernRuntime

- N64ModernRuntime is the runtime layer used by traditional ports and recompilations of N64 games.
- Its two core libraries are `ultramodern` and `librecomp`.

Source: https://github.com/N64Recomp/N64ModernRuntime

## Splat

- The active binary splitting tool package is `splat64`.
- The documented install line is `python3 -m pip install -U splat64[mips]`.
- The `mips` optional dependency group is required for N64, PSX, PS2, and PSP platforms.

Source: https://github.com/ethteck/splat

## Podman on Windows

- Podman runs on Windows with a native CLI plus a Podman-managed Linux guest machine.
- `podman machine init` initializes the Linux virtual machine.
- `podman machine start` starts that virtual machine.

Sources: https://podman.io/docs/installation, https://docs.podman.io/en/latest/markdown/podman-machine-init.1.html, https://docs.podman.io/en/stable/markdown/podman-machine-start.1.html

## Windows debugging

- Microsoft Debugging Tools for Windows can be installed from the Windows SDK, WDK, or as a standalone SDK feature selection.
- CDB is the Microsoft Console Debugger and is one of the command-line debuggers in Debugging Tools for Windows.

Source: https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/debugger-download-tools

## MSYS2 and uv

- MSYS2 provides native Windows builds for tools including GCC, CPython, and CMake, using the Pacman package manager.
- uv supports Windows installation through its standalone installer and WinGet.

Sources: https://www.msys2.org/, https://docs.astral.sh/uv/getting-started/installation/

## RT64/RmlUi runtime starter facts

- RT64 describes itself as an N64 graphics renderer for emulators and native ports, and its repository states that it is public to provide a working implementation to native ports that wish to use RT64 as their renderer. Source: https://github.com/rt64/rt64
- RT64's README lists CMake 3.20 or above, a C++17 compiler, Windows 10 or 11 SDK on Windows, and recursive submodules as build requirements. Source: https://github.com/rt64/rt64
- N64ModernRuntime says `ultramodern` expects the user to provide and register a graphics renderer and recommends RT64. Source: https://github.com/N64Recomp/N64ModernRuntime
- RmlUi's CMake project defines the `RMLUI_SVG_PLUGIN` option and `RMLUI_FONT_ENGINE` cache variable; its docs state that FreeType is required for Windows builds and that LunaSVG is used by the SVG plugin. Sources: https://mikke89.github.io/RmlUiDoc/pages/cpp_manual/building_with_cmake.html and https://mikke89.github.io/RmlUiDoc/pages/cpp_manual/svg.html
- LunaSVG defines the CMake alias target `lunasvg::lunasvg`. Source: https://github.com/sammycage/lunasvg

## ELF generation handoff

- N64Recomp's README says the recompiler accepts symbols and metadata alongside the binary and that its TOML config specifies input and output file paths.
- The same README notes a future custom metadata format is planned to operate without an ELF, so the current practical path still treats ELF metadata as central.
- Splat's documented package is a binary splitting tool for decompilation and modding workflows, with N64 support through the `mips` extra.
- GNU-style MIPS binutils provide the assembler/linker/readelf path used by the companion's open-toolchain ELF builder; proprietary compiler binaries are not distributed here.

Sources: https://github.com/N64Recomp/N64Recomp, https://pypi.org/project/splat64/

## Local LLM and Mupen64MCP workflow

- Mupen64MCP describes itself as an N64 ROM debugging MCP server backed by Mupen64Plus.
- Its README lists Windows, CMake, Python, MSYS2 MINGW64, and Mupen64Plus debugger builds as expected workflow pieces.
- The documented daemon options include core, ROM, gfx, audio, input, rsp, data directory, config directory, port, and write-memory enablement.
- The README lists MCP tools including daemon lifecycle, emulation, CPU, memory, breakpoints, tracing, input, framebuffer, assets, PI DMA, and RSP/SP categories.
- The README notes Rice video plus RSP-HLE for real rendering/framebuffer capture; dummy graphics remains useful for debugger-focused sessions.
- LM Studio documents a local API server that can be started from the Developer tab or with `lms server start`, and documents OpenAI-compatible endpoints under `/v1`.
- llama.cpp's server README documents OpenAI API-compatible chat, responses, and embeddings routes.
- llama-cpp-python documents an OpenAI-compatible server installed with `pip install llama-cpp-python[server]` and run with `python3 -m llama_cpp.server --model <model_path>`.

Sources: https://github.com/DohmBoy64Bit/Mupen64MCP, https://lmstudio.ai/docs/developer/core/server, https://lmstudio.ai/docs/developer/openai-compat, https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md, https://llama-cpp-python.readthedocs.io/en/latest/server/
