# Local LLM + Mupen64MCP workflow

This workflow connects three local pieces:

- Mupen64MCP for runtime N64 debugging through Mupen64Plus.
- A local OpenAI-compatible model server from LM Studio or llama.cpp.
- `n64recomp-kit local-llm-ask`, a small bridge that can expose MCP tools to a local model using OpenAI-style tool calls.

## Generate scripts

```powershell
python -m n64recomp_kit emit-local-llm-workflow --root . --mupen-root C:\dev\Mupen64MCP --overwrite
```

## Start Mupen64MCP daemon

Rendered mode uses Rice video plus RSP-HLE for framebuffer capture:

```powershell
.\scripts\Start-Mupen64McpDaemon.ps1 -MupenRoot C:\dev\Mupen64MCP -Rom C:\roms\game.z64 -Mode Rendered -AllowWriteMemory
```

Headless mode keeps CPU/debugging tools available and uses dummy graphics:

```powershell
.\scripts\Start-Mupen64McpDaemon.ps1 -MupenRoot C:\dev\Mupen64MCP -Rom C:\roms\game.z64 -Mode Headless
```

The script prepends PATH in this order for the daemon process: MSYS2 MINGW64, optional WinLibs, Mupen64Plus core library directory, then the existing system PATH.

## Start the MCP server

```powershell
.\scripts\Start-Mupen64McpServer.ps1 -MupenRoot C:\dev\Mupen64MCP
```

The generated `configs/local-llm/mcp-client-config.json` can also be copied into MCP-capable clients.

## Use LM Studio

Start the LM Studio API server from the Developer tab, or use the CLI if `lms` is installed:

```powershell
.\scripts\Start-LMStudioServer.ps1 -StartWithLmsCli
```

Then run a prompt:

```powershell
$ModelId = (Invoke-RestMethod http://127.0.0.1:1234/v1/models).data[0].id
.\scripts\Invoke-LocalLlmMcpPrompt.ps1 -Provider LMStudio -Model $ModelId -MupenRoot C:\dev\Mupen64MCP -Prompt "Check status, press START if needed, then capture PC and registers."
```

## Use llama.cpp

With llama-cpp-python:

```powershell
python -m pip install "llama-cpp-python[server]"
.\scripts\Start-LlamaCppServer.ps1 -Mode llama-cpp-python -Model C:\models\model.gguf
```

With llama-server:

```powershell
.\scripts\Start-LlamaCppServer.ps1 -Mode llama-server -ServerExe C:\tools\llama-server.exe -Model C:\models\model.gguf
```

Then run a prompt:

```powershell
$ModelId = (Invoke-RestMethod http://127.0.0.1:8080/v1/models).data[0].id
.\scripts\Invoke-LocalLlmMcpPrompt.ps1 -Provider LlamaCpp -Model $ModelId -MupenRoot C:\dev\Mupen64MCP -Prompt "Read the current PC and export a short trace summary."
```

## Diagnostics

```powershell
.\scripts\Test-LocalLlmMcpWorkflow.ps1 -MupenRoot C:\dev\Mupen64MCP
python -m n64recomp_kit local-llm-doctor --mupen-root C:\dev\Mupen64MCP --json
```

## MCP operational notes

- `n64_start_daemon` and `n64_stop_daemon` are MCP lifecycle tools; the PowerShell daemon script is a direct alternative for users who want explicit paths.
- Use real Rice video and RSP-HLE plugins when framebuffer capture matters.
- Dummy graphics can be useful for debugger-only work, but framebuffer capture can be black.
- To skip boot or attract mode, call `n64_set_controller` with START sticky before resuming.
- Keep ROM paths outside the repo and never commit copyrighted ROMs.
