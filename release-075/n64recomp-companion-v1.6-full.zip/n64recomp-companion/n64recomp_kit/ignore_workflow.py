from __future__ import annotations

import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

from .audit import read_names_file, sort_names
from .recomp import run_recomp
from .util import write_json

UNSUPPORTED_MNEMONICS = frozenset({"trunc.l.d", "trunc.l.s"})
GLABEL_RE = re.compile(r"^\s*(?:glabel|\.globl)\s+([A-Za-z_.$][\w.$]*)")
LABEL_RE = re.compile(r"^\s*([A-Za-z_.$][\w.$]*):\s*(?:#.*)?$")
ENDLABEL_RE = re.compile(r"^\s*endlabel\b")
COP0_RE = re.compile(r"\b(mfc0|mtc0)\s+\$[a-z0-9]+,\s*\$(\d+)", re.IGNORECASE)
JAL_LOW_RE = re.compile(r"\bjal\s+(func_800[0-9A-Fa-f]+)\b", re.IGNORECASE)
FUNC_RE = re.compile(r"\b(func_[0-9A-Fa-f]{6,8})\b")


@dataclass
class UnsupportedScan:
    ok: bool
    asm_dir: str
    genuine_ignored: list[str]
    low_func_callers: list[str]
    files_scanned: int
    outputs: dict[str, str]

    def to_dict(self) -> dict:
        return asdict(self)


def scan_asm_file(path: Path) -> tuple[set[str], set[str]]:
    unsupported: set[str] = set()
    low_callers: set[str] = set()
    current: str | None = None
    pending_global: str | None = None
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        m = GLABEL_RE.match(line)
        if m:
            pending_global = m.group(1)
            if line.startswith("glabel"):
                current = pending_global
            continue
        m = LABEL_RE.match(line)
        if m:
            label = m.group(1)
            if label.startswith("func_") or label == pending_global:
                current = label
            continue
        if ENDLABEL_RE.match(line):
            current = None
            continue
        if current is None:
            continue
        lower = line.lower()
        if any(mnem in lower for mnem in UNSUPPORTED_MNEMONICS):
            unsupported.add(current)
        cop0 = COP0_RE.search(line)
        if cop0 and cop0.group(2) != "12":
            unsupported.add(current)
        if JAL_LOW_RE.search(line):
            low_callers.add(current)
    return unsupported, low_callers


def scan_unsupported(*, asm_dir: str | Path, out_dir: str | Path = "symbols/recomp") -> UnsupportedScan:
    asm = Path(asm_dir)
    if not asm.is_dir():
        raise FileNotFoundError(f"asm dir missing: {asm}")
    unsupported: set[str] = set()
    callers: set[str] = set()
    files = 0
    for path in sorted(list(asm.rglob("*.s")) + list(asm.rglob("*.S"))):
        files += 1
        u, c = scan_asm_file(path)
        unsupported |= u
        callers |= c
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    genuine = sort_names(unsupported)
    low = sort_names(callers - unsupported)
    paths = {
        "ignored_genuine": str(out / "ignored-genuine.txt"),
        "low_func_callers": str(out / "func-800-callers.txt"),
        "legacy_union": str(out / "ignored-funcs.txt"),
    }
    Path(paths["ignored_genuine"]).write_text("# Genuinely unsupported instruction functions for [patches].ignored.\n" + "\n".join(genuine) + ("\n" if genuine else ""), encoding="utf-8")
    Path(paths["low_func_callers"]).write_text("# Functions that call func_800* symbols; review mirror/manual function setup before ignoring.\n" + "\n".join(low) + ("\n" if low else ""), encoding="utf-8")
    union = sort_names(genuine + low)
    Path(paths["legacy_union"]).write_text("# Legacy union of genuine ignores and low-memory callers.\n" + "\n".join(union) + ("\n" if union else ""), encoding="utf-8")
    return UnsupportedScan(True, str(asm), genuine, low, files, paths)


def _format_ignored_block(names: list[str]) -> str:
    if not names:
        return "ignored = []"
    body = "\n".join(f'    "{name}",' for name in names)
    return f"ignored = [\n{body}\n]"


def sync_ignored_toml(*, config: str | Path, ignored_files: Iterable[str | Path], output: str | Path | None = None, dry_run: bool = False) -> dict:
    cfg = Path(config)
    text = cfg.read_text(encoding="utf-8")
    names: list[str] = []
    for file in ignored_files:
        names.extend(read_names_file(file))
    sorted_names = sort_names(names)
    block = _format_ignored_block(sorted_names)
    pattern = re.compile(r"ignored\s*=\s*\[(?:.|\n)*?\]", re.MULTILINE)
    if pattern.search(text):
        new_text = pattern.sub(block, text, count=1)
    elif re.search(r"^\s*\[patches\]\s*$", text, re.MULTILINE):
        new_text = re.sub(r"(^\s*\[patches\]\s*$)", r"\1\n" + block, text, count=1, flags=re.MULTILINE)
    else:
        new_text = text.rstrip() + "\n\n[patches]\n" + block + "\n"
    out = Path(output) if output else cfg
    changed = new_text != text or out != cfg
    if not dry_run:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(new_text, encoding="utf-8")
    return {"ok": True, "dry_run": dry_run, "config": str(cfg), "output": str(out), "ignored_count": len(sorted_names), "changed": changed, "ignored": sorted_names}


def extract_failed_function(text: str) -> str | None:
    patterns = [
        r"(?:function|symbol|func)[:= ]+(func_[0-9A-Fa-f]{6,8})",
        r"\b(func_[0-9A-Fa-f]{6,8})\b",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1)
    return None


def recomp_smoke(*, config: str | Path, n64recomp: str | None = None, max_iterations: int = 5, ignored_file: str | Path | None = None, clean_output: bool = False, timeout: int | None = None, allow_missing_paths: bool = False, dry_run: bool = False, report_path: str | Path | None = None) -> dict:
    ignored_path = Path(ignored_file) if ignored_file else Path(config).parent / "ignored-extra.txt"
    discovered: list[str] = []
    iterations: list[dict] = []
    for index in range(max_iterations):
        if dry_run:
            iterations.append({"iteration": index + 1, "status": "dry_run", "config": str(config)})
            break
        report = run_recomp(config, n64recomp=n64recomp, clean_output=clean_output, timeout=timeout, allow_missing_paths=allow_missing_paths)
        entry = {"iteration": index + 1, "status": report.get("status"), "n64recomp": report.get("n64recomp")}
        cmd = report.get("command") or {}
        output = (cmd.get("stdout") or "") + "\n" + (cmd.get("stderr") or "")
        failed = extract_failed_function(output)
        if failed:
            discovered.append(failed)
            entry["failed_function"] = failed
            existing = read_names_file(ignored_path)
            ignored_path.parent.mkdir(parents=True, exist_ok=True)
            ignored_path.write_text("\n".join(sort_names(existing + [failed])) + "\n", encoding="utf-8")
        iterations.append(entry)
        if report.get("status") == "ok" or not failed:
            break
    final = {"ok": iterations[-1]["status"] in {"ok", "dry_run"} if iterations else False, "config": str(config), "ignored_file": str(ignored_path), "discovered": sort_names(discovered), "iterations": iterations, "started_at_unix": int(time.time())}
    if report_path:
        write_json(report_path, final)
    return final
