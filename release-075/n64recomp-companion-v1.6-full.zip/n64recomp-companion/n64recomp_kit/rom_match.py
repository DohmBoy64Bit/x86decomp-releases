from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Iterable

from .util import read_bytes, write_json

MAP_LINE_RE = re.compile(r"^\s*(?:0x)?([0-9A-Fa-f]{1,16})\s+(?:0x)?([0-9A-Fa-f]{1,16})\s+(.+?)\s*$")


def first_mismatch(a: bytes, b: bytes, limit: int | None = None) -> int | None:
    n = min(len(a), len(b), limit if limit is not None else max(len(a), len(b)))
    for i in range(n):
        if a[i] != b[i]:
            return i
    if limit is None and len(a) != len(b):
        return n
    return None


def rom_match_check(*, expected: str | Path, actual: str | Path, start: int = 0, size: int | None = None, report: str | Path | None = None) -> dict:
    exp = read_bytes(expected)
    act = read_bytes(actual)
    exp_slice = exp[start : start + size if size is not None else None]
    act_slice = act[start : start + size if size is not None else None]
    mismatch = first_mismatch(exp_slice, act_slice)
    ok = mismatch is None and len(exp_slice) == len(act_slice)
    data = {
        "ok": ok,
        "expected": str(expected),
        "actual": str(actual),
        "start": start,
        "size": size if size is not None else len(exp_slice),
        "expected_size": len(exp_slice),
        "actual_size": len(act_slice),
        "first_mismatch": None if mismatch is None else {"relative": mismatch, "absolute": start + mismatch, "expected_byte": exp_slice[mismatch], "actual_byte": act_slice[mismatch]},
    }
    if report:
        write_json(report, data)
    return data


def _load_manifest(path: str | Path) -> list[dict]:
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = data.get("sections", [])
    if not isinstance(data, list):
        raise ValueError("section manifest must be a JSON list or an object with a sections list")
    return data


def rom_match_sections(*, manifest: str | Path, report: str | Path | None = None) -> dict:
    sections = _load_manifest(manifest)
    results = []
    ok = True
    for sec in sections:
        name = sec.get("name") or f"section_{len(results)}"
        expected = Path(sec["expected"])
        actual = Path(sec["actual"])
        exp_off = int(sec.get("expected_offset", sec.get("offset", 0)), 0) if isinstance(sec.get("expected_offset", sec.get("offset", 0)), str) else int(sec.get("expected_offset", sec.get("offset", 0)))
        act_off = int(sec.get("actual_offset", sec.get("offset", 0)), 0) if isinstance(sec.get("actual_offset", sec.get("offset", 0)), str) else int(sec.get("actual_offset", sec.get("offset", 0)))
        size_val = sec.get("size")
        size = int(size_val, 0) if isinstance(size_val, str) else int(size_val)
        exp = read_bytes(expected)[exp_off : exp_off + size]
        act = read_bytes(actual)[act_off : act_off + size]
        mismatch = first_mismatch(exp, act)
        sec_ok = mismatch is None and len(exp) == len(act) == size
        ok = ok and sec_ok
        results.append({"name": name, "ok": sec_ok, "expected": str(expected), "actual": str(actual), "expected_offset": exp_off, "actual_offset": act_off, "size": size, "first_mismatch": None if mismatch is None else {"relative": mismatch, "expected_byte": exp[mismatch], "actual_byte": act[mismatch]}})
    data = {"ok": ok, "manifest": str(manifest), "section_count": len(results), "sections": results}
    if report:
        write_json(report, data)
    return data


def parse_simple_map(path: str | Path) -> list[dict]:
    rows = []
    for raw in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        m = MAP_LINE_RE.match(line)
        if not m:
            continue
        try:
            offset = int(m.group(1), 16)
            size = int(m.group(2), 16)
        except ValueError:
            continue
        source = m.group(3).strip()
        rows.append({"offset": offset, "size": size, "source": source})
    return rows


def rom_build_from_map(*, map_file: str | Path, output: str | Path, fill: int = 0, root: str | Path = ".", size: int | None = None, dry_run: bool = False, report: str | Path | None = None) -> dict:
    root_p = Path(root)
    rows = parse_simple_map(map_file)
    total = size if size is not None else max((r["offset"] + r["size"] for r in rows), default=0)
    image = bytearray([fill & 0xFF]) * total
    copied = []
    for row in rows:
        src = Path(row["source"])
        if not src.is_absolute():
            src = root_p / src
        if not src.is_file():
            copied.append({**row, "ok": False, "error": f"missing source: {src}"})
            continue
        data = src.read_bytes()[: row["size"]]
        if len(data) < row["size"]:
            data += bytes([fill & 0xFF]) * (row["size"] - len(data))
        if row["offset"] + row["size"] > len(image):
            image.extend(bytes([fill & 0xFF]) * (row["offset"] + row["size"] - len(image)))
        image[row["offset"] : row["offset"] + row["size"]] = data
        copied.append({**row, "source": str(src), "ok": True})
    ok = all(r.get("ok") for r in copied)
    if not dry_run:
        out = Path(output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(bytes(image))
    data = {"ok": ok, "dry_run": dry_run, "map_file": str(map_file), "output": str(output), "size": len(image), "copied": copied}
    if report:
        write_json(report, data)
    return data
