from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

from .audit import sort_names
from .elf_build import build_elf_from_splat, load_elf_build_paths
from .util import run_command, write_json

LABEL_RE = re.compile(r"^\s*(?:glabel\s+|\.globl\s+)?([A-Za-z_.$][\w.$]*):?\s*$")
WORD_FUNC_RE = re.compile(r"(\.word\s+)(func_[0-9A-Fa-f]{6,8})\b", re.IGNORECASE)
JUMP_LABEL_RE = re.compile(r"\b(j|jal|beq|bne|beql|bnel|blez|bgtz|bltz|bgez)\s+([A-Za-z_.$][\w.$]*)", re.IGNORECASE)


def _iter_asm_files(asm_dir: str | Path) -> list[Path]:
    root = Path(asm_dir)
    if root.is_file():
        return [root]
    if not root.is_dir():
        raise FileNotFoundError(f"asm path not found: {root}")
    return sorted(list(root.rglob("*.s")) + list(root.rglob("*.S")))


def patch_data_asm(*, asm_dir: str | Path, symbols: Iterable[str] = (), dry_run: bool = False, report: str | Path | None = None) -> dict:
    """Comment-mark .word func_* references as data-pointer references for review.

    This does not invent new addresses. It only annotates data-like word references that
    often become unresolved link symbols in early Splat output.
    """
    wanted = set(symbols)
    changed_files = []
    replacements = []
    for path in _iter_asm_files(asm_dir):
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        out = []
        changed = False
        for idx, line in enumerate(lines, 1):
            m = WORD_FUNC_RE.search(line)
            if m and (not wanted or m.group(2) in wanted) and "n64recomp-kit:data-pointer" not in line:
                new_line = line + "  # n64recomp-kit:data-pointer-review"
                replacements.append({"path": str(path), "line": idx, "symbol": m.group(2), "before": line, "after": new_line})
                out.append(new_line)
                changed = True
            else:
                out.append(line)
        if changed:
            changed_files.append(str(path))
            if not dry_run:
                path.write_text("\n".join(out) + "\n", encoding="utf-8")
    data = {"ok": True, "dry_run": dry_run, "changed_files": changed_files, "replacement_count": len(replacements), "replacements": replacements}
    if report:
        write_json(report, data)
    return data


def patch_tail_asm(*, asm_dir: str | Path, prefix: str = "tail_", dry_run: bool = False, report: str | Path | None = None) -> dict:
    """Rename duplicate local labels across tail asm files to stable file-scoped labels.

    This is intentionally conservative: it only rewrites duplicate labels that appear
    in more than one asm file and matching branch/jump operands in that same file.
    """
    files = _iter_asm_files(asm_dir)
    labels_by_file: dict[Path, set[str]] = {}
    global_counts: dict[str, int] = {}
    for path in files:
        labels: set[str] = set()
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            m = re.match(r"^\s*([A-Za-z_.$][\w.$]*):", raw)
            if not m:
                continue
            label = m.group(1)
            if label.startswith(("func_", "D_", "glabel")):
                continue
            labels.add(label)
            global_counts[label] = global_counts.get(label, 0) + 1
        labels_by_file[path] = labels
    duplicates = {label for label, count in global_counts.items() if count > 1}
    changes = []
    for path in files:
        labels = labels_by_file.get(path, set()) & duplicates
        if not labels:
            continue
        stem = re.sub(r"\W+", "_", path.stem)
        mapping = {label: f"{prefix}{stem}_{label.lstrip('.')}" for label in labels}
        text = path.read_text(encoding="utf-8", errors="replace")
        new = text
        for old, new_name in mapping.items():
            new = re.sub(rf"(^\s*){re.escape(old)}:", rf"\1{new_name}:", new, flags=re.MULTILINE)
            new = re.sub(rf"\b{re.escape(old)}\b", new_name, new)
        if new != text:
            changes.append({"path": str(path), "renamed": mapping})
            if not dry_run:
                path.write_text(new, encoding="utf-8")
    data = {"ok": True, "dry_run": dry_run, "duplicate_labels": sort_names(duplicates), "changed_files": len(changes), "changes": changes}
    if report:
        write_json(report, data)
    return data


def load_tail_split_hints(path: str | Path) -> list[int]:
    p = Path(path)
    hints: list[int] = []
    if not p.is_file():
        return hints
    for raw in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.split("#", 1)[0].strip()
        if line:
            hints.append(int(line, 0))
    return sorted(set(hints))


def suggest_tail_split_hints(*, asm_dir: str | Path, min_gap: int = 0x4000, output: str | Path | None = None) -> dict:
    starts = []
    for path in _iter_asm_files(asm_dir):
        m = re.search(r"([0-9A-Fa-f]{5,8})", path.stem)
        if m:
            starts.append(int(m.group(1), 16))
    starts = sorted(set(starts))
    hints = []
    previous = None
    for start in starts:
        if previous is None or start - previous >= min_gap:
            hints.append(start)
        previous = start
    if output:
        out = Path(output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("\n".join(f"0x{x:X}" for x in hints) + ("\n" if hints else ""), encoding="utf-8")
    return {"ok": True, "asm_dir": str(asm_dir), "hint_count": len(hints), "hints": [f"0x{x:X}" for x in hints], "output": str(output) if output else None}


def apply_tail_split_hints(*, yaml_path: str | Path, hints_file: str | Path, segment_name: str = "tail", dry_run: bool = False, report: str | Path | None = None) -> dict:
    y = Path(yaml_path)
    text = y.read_text(encoding="utf-8")
    hints = load_tail_split_hints(hints_file)
    added = []
    insert_lines = []
    for hint in hints:
        hex_hint = f"0x{hint:X}"
        if hex_hint.lower() not in text.lower():
            added.append(hex_hint)
            insert_lines.append(f"      - [{hex_hint}, asm, {segment_name}_{hint:X}]")
    if not insert_lines:
        data = {"ok": True, "dry_run": dry_run, "yaml": str(y), "added": []}
        if report:
            write_json(report, data)
        return data
    lines = text.splitlines()
    out_lines = []
    in_segment = False
    inserted = False
    for line in lines:
        out_lines.append(line)
        if re.match(rf"\s*-\s*name:\s*{re.escape(segment_name)}\s*$", line):
            in_segment = True
        elif in_segment and re.match(r"\s*subsegments:\s*$", line):
            out_lines.extend(insert_lines)
            inserted = True
            in_segment = False
    if not inserted:
        raise ValueError(f"could not find subsegments block for segment {segment_name!r}")
    new_text = "\n".join(out_lines) + "\n"
    if not dry_run:
        y.write_text(new_text, encoding="utf-8")
    data = {"ok": True, "dry_run": dry_run, "yaml": str(y), "hints_file": str(hints_file), "added": added}
    if report:
        write_json(report, data)
    return data


def mips_link_preflight(*, config: str | Path, root: str | Path = ".", prefix: str | None = None, profile: str = "asm-only", timeout: int | None = None, dry_run: bool = True, report: str | Path | None = None) -> dict:
    paths = load_elf_build_paths(config, root_path=root)
    build = build_elf_from_splat(config, root_path=root, prefix=prefix, profile=profile, dry_run=dry_run, timeout=timeout)
    data = {"ok": build.ok, "dry_run": dry_run, "paths": paths.to_dict(), "build": build.to_dict()}
    if report:
        write_json(report, data)
    return data


def recompiled_c_sanitize(*, path: str | Path, dry_run: bool = False, report: str | Path | None = None) -> dict:
    """Apply conservative host-C cleanup annotations to generated files.

    Current implementation only normalizes CRLF and strips trailing NUL bytes from C/C++
    files. It deliberately avoids semantic rewrites unless future project-specific
    evidence is supplied.
    """
    root = Path(path)
    files = [root] if root.is_file() else [p for p in root.rglob("*") if p.suffix.lower() in {".c", ".cc", ".cpp", ".h", ".hpp"}]
    changed = []
    for f in files:
        raw = f.read_bytes()
        new = raw.replace(b"\x00", b"")
        if new != raw:
            changed.append(str(f))
            if not dry_run:
                f.write_bytes(new)
    data = {"ok": True, "dry_run": dry_run, "files_scanned": len(files), "changed_files": changed}
    if report:
        write_json(report, data)
    return data
