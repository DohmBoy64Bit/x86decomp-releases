#!/usr/bin/env bash
set -euo pipefail
IMAGE="n64recomp-companion:latest"
N64RECOMP_REF="main"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --image) IMAGE="$2"; shift 2 ;;
    --ref) N64RECOMP_REF="$2"; shift 2 ;;
    -h|--help) echo "Usage: scripts/build_docker_image.sh [--image NAME] [--ref GIT_REF]"; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
docker build --build-arg N64RECOMP_REF="$N64RECOMP_REF" -t "$IMAGE" .
