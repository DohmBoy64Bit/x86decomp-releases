#!/usr/bin/env bash
set -euo pipefail
python3 -m unittest discover -s tests -v
python3 -m n64recomp_kit doctor --json >/dev/null || true
python3 -m n64recomp_kit check-config tests/fixtures/valid_elf_config.toml >/dev/null
python3 -m n64recomp_kit elf-info tests/fixtures/minimal_mips_be.elf >/dev/null
python3 -m n64recomp_kit rom-info tests/fixtures/minimal.z64 >/dev/null
