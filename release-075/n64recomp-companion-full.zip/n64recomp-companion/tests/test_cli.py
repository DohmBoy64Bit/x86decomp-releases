import unittest

from n64recomp_kit.cli import main


class CliTests(unittest.TestCase):
    def test_check_config_cli(self):
        rc = main(["check-config", "tests/fixtures/valid_elf_config.toml"])
        self.assertEqual(rc, 0)

    def test_elf_info_cli(self):
        rc = main(["elf-info", "tests/fixtures/minimal_mips_be.elf"])
        self.assertEqual(rc, 0)


if __name__ == "__main__":
    unittest.main()
