"""Companion utilities for N64Recomp workflows."""

__all__ = ["__version__"]
__version__ = "1.0.0"
