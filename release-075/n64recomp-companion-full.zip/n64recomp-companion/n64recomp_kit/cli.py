from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .batch import run_batch
from .config import create_config, format_validation, validate_config
from .doctor import doctor, format_doctor
from .elf import format_elf_info, inspect_elf
from .recomp import format_summary, run_recomp, summarize_output
from .rom import convert_to_z64, format_rom_info, inspect_rom
from .util import parse_int, print_json, write_json


def _add_json(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true", help="print machine-readable JSON")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="n64recomp-kit", description="Companion tools for N64Recomp workflows")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("doctor", help="check local tool availability")
    p.add_argument("--n64recomp", help="path to N64Recomp binary")
    _add_json(p)

    p = sub.add_parser("rom-info", help="inspect an N64 ROM header")
    p.add_argument("rom")
    _add_json(p)

    p = sub.add_parser("convert-rom", help="convert .n64/.v64 byte order to .z64")
    p.add_argument("input")
    p.add_argument("output")
    p.add_argument("--overwrite", action="store_true")
    _add_json(p)

    p = sub.add_parser("elf-info", help="inspect an ELF32 file")
    p.add_argument("elf")
    _add_json(p)

    p = sub.add_parser("init", help="write a concrete N64Recomp TOML config")
    p.add_argument("--config", required=True, help="output TOML path")
    p.add_argument("--entrypoint", help="entrypoint integer, decimal or 0x hex")
    p.add_argument("--elf", help="ELF input path")
    p.add_argument("--rom", help="ROM input path for symbol-file mode")
    p.add_argument("--symbols", help="N64Recomp symbols TOML path for symbol-file mode")
    p.add_argument("--output-func-path", default="RecompiledFuncs")
    p.add_argument("--relocatable-sections-path")
    p.add_argument("--single-file-output", action="store_true")
    p.add_argument("--functions-per-output-file", type=int, default=50)
    p.add_argument("--recomp-include", default='#include "recomp.h"')
    p.add_argument("--overwrite", action="store_true")

    p = sub.add_parser("check-config", help="validate an N64Recomp TOML config")
    p.add_argument("config")
    p.add_argument("--allow-missing-paths", action="store_true")
    _add_json(p)

    p = sub.add_parser("run", help="validate and run N64Recomp")
    p.add_argument("config")
    p.add_argument("--n64recomp", help="path to N64Recomp binary")
    p.add_argument("--clean-output", action="store_true")
    p.add_argument("--timeout", type=int)
    p.add_argument("--allow-missing-paths", action="store_true")
    p.add_argument("--report", default="recomp-report.json")
    _add_json(p)

    p = sub.add_parser("summarize-output", help="summarize generated recompilation output")
    p.add_argument("path")
    p.add_argument("--largest", type=int, default=10)
    _add_json(p)

    p = sub.add_parser("batch", help="batch-check or batch-run several configs")
    p.add_argument("manifest")
    p.add_argument("--mode", choices=["check", "run"], default="check")
    p.add_argument("--n64recomp", help="path to N64Recomp binary")
    p.add_argument("--clean-output", action="store_true")
    p.add_argument("--timeout", type=int)
    p.add_argument("--allow-missing-paths", action="store_true")
    p.add_argument("--report", default="batch-report.json")
    _add_json(p)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            data = doctor(n64recomp=args.n64recomp)
            print_json(data) if args.json else print(format_doctor(data))
            return 0 if data["n64recomp"]["available"] else 2
        if args.command == "rom-info":
            info = inspect_rom(args.rom)
            print_json(info.to_dict()) if args.json else print(format_rom_info(info))
            return 0
        if args.command == "convert-rom":
            data = convert_to_z64(args.input, args.output, overwrite=args.overwrite)
            print_json(data) if args.json else print(f"Wrote {data['output']} ({data['source_byte_order']} -> z64-big-endian)")
            return 0
        if args.command == "elf-info":
            info = inspect_elf(args.elf)
            print_json(info.to_dict()) if args.json else print(format_elf_info(info))
            return 0
        if args.command == "init":
            entrypoint = parse_int(args.entrypoint) if args.entrypoint else None
            out = create_config(
                args.config,
                entrypoint=entrypoint,
                elf_path=args.elf,
                rom_path=args.rom,
                symbols_file_path=args.symbols,
                output_func_path=args.output_func_path,
                relocatable_sections_path=args.relocatable_sections_path,
                single_file_output=args.single_file_output,
                functions_per_output_file=args.functions_per_output_file,
                recomp_include=args.recomp_include,
                overwrite=args.overwrite,
            )
            print(f"Wrote {out}")
            return 0
        if args.command == "check-config":
            result = validate_config(args.config, allow_missing_paths=args.allow_missing_paths)
            print_json(result.to_dict()) if args.json else print(format_validation(result))
            return 0 if result.ok else 1
        if args.command == "run":
            report = run_recomp(
                args.config,
                n64recomp=args.n64recomp,
                clean_output=args.clean_output,
                timeout=args.timeout,
                allow_missing_paths=args.allow_missing_paths,
            )
            write_json(args.report, report)
            if args.json:
                print_json(report)
            else:
                print(f"Status: {report['status']}")
                print(f"Report: {args.report}")
                if "output_summary" in report:
                    print(format_summary(summarize_output(report["output_summary"]["path"])))
            return 0 if report.get("status") == "ok" else 1
        if args.command == "summarize-output":
            summary = summarize_output(args.path, largest=args.largest)
            print_json(summary.to_dict()) if args.json else print(format_summary(summary))
            return 0 if summary.exists else 1
        if args.command == "batch":
            report = run_batch(
                args.manifest,
                mode=args.mode,
                n64recomp=args.n64recomp,
                clean_output=args.clean_output,
                timeout=args.timeout,
                allow_missing_paths=args.allow_missing_paths,
            )
            write_json(args.report, report)
            if args.json:
                print_json(report)
            else:
                print(f"Projects: {report['project_count']}")
                print(f"Failures: {report['failed_count']}")
                print(f"Report: {args.report}")
            return 0 if report["ok"] else 1
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
