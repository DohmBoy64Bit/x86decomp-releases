from __future__ import annotations

import platform
import shutil
from pathlib import Path

from .recomp import find_n64recomp
from .util import python_version, run_command


def _tool_status(name: str, version_args: list[str] | None = None) -> dict:
    path = shutil.which(name)
    result = {"name": name, "path": path, "available": path is not None}
    if path and version_args:
        cmd = [path] + version_args
        res = run_command(cmd, timeout=10)
        text = (res.stdout or res.stderr).splitlines()
        result["version_probe"] = text[0] if text else ""
        result["version_returncode"] = res.returncode
    return result


def doctor(*, n64recomp: str | None = None) -> dict:
    binary = find_n64recomp(n64recomp)
    tools = [
        _tool_status("git", ["--version"]),
        _tool_status("cmake", ["--version"]),
        _tool_status("ninja", ["--version"]),
        _tool_status("clang", ["--version"]),
        _tool_status("clang++", ["--version"]),
        _tool_status("cc", ["--version"]),
        _tool_status("c++", ["--version"]),
    ]
    return {
        "python": python_version(),
        "platform": platform.platform(),
        "n64recomp": {"path": binary, "available": binary is not None},
        "tools": tools,
        "ok_for_local_bootstrap": all(next(t for t in tools if t["name"] == name)["available"] for name in ("git", "cmake"))
        and (next(t for t in tools if t["name"] == "ninja")["available"] or True),
    }


def format_doctor(data: dict) -> str:
    lines = [
        f"Python   : {data['python']}",
        f"Platform : {data['platform']}",
        f"N64Recomp: {data['n64recomp']['path'] or 'not found'}",
        "Tools:",
    ]
    for tool in data["tools"]:
        label = "yes" if tool["available"] else "no"
        line = f"  {tool['name']:<8} {label:<3} {tool['path'] or ''}"
        if tool.get("version_probe"):
            line += f"  {tool['version_probe']}"
        lines.append(line)
    return "\n".join(lines)
