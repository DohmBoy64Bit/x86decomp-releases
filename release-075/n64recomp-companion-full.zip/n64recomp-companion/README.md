# n64recomp-companion

A complete companion toolkit for [N64Recomp](https://github.com/N64Recomp/N64Recomp): build automation, Docker environment, config validation, ROM/ELF triage, batch recompilation runs, and reproducible output reports.

This repository does **not** include Nintendo ROMs, proprietary game assets, or a finished runtime for any commercial game. N64Recomp generates C/C++ recompilation output from an N64 binary plus metadata; a playable native PC port still needs a runtime and project-specific integration work. The toolkit here focuses on making that real workflow repeatable and less error-prone.

## What is included

```text
n64recomp-companion/
├── Dockerfile                         # Linux container that builds N64Recomp from source
├── pyproject.toml                     # installable Python CLI package
├── n64recomp_kit/                     # stdlib-only Python implementation
├── tools/                             # direct script entry points
├── scripts/                           # shell automation for bootstrap/build/run
├── docs/                              # verified workflow and config reference
├── tests/                             # unit tests and valid fixtures
└── .github/workflows/ci.yml           # package test workflow
```

## Fast start

```bash
python3 -m pip install -e .
n64recomp-kit doctor
```

Build N64Recomp on Linux or macOS:

```bash
./scripts/bootstrap_n64recomp.sh --prefix "$PWD/.deps/N64Recomp" --jobs 8
export PATH="$PWD/.deps/N64Recomp/build:$PATH"
n64recomp-kit doctor --n64recomp "$PWD/.deps/N64Recomp/build/N64Recomp"
```

Use Docker instead of installing toolchains locally:

```bash
./scripts/build_docker_image.sh
./scripts/docker_shell.sh "$PWD"
```

Inside the container, your repository is mounted at `/work` and the built N64Recomp binary is available as `/opt/n64recomp/build/N64Recomp`.

## Common workflow

1. Inspect your legally obtained ROM image:

   ```bash
   n64recomp-kit rom-info path/to/game.z64
   ```

2. Normalize byte order if the file is `.n64` or `.v64`:

   ```bash
   n64recomp-kit convert-rom path/to/game.v64 build/game.z64
   ```

3. Inspect the ELF you built from a matching disassembly or decompilation project:

   ```bash
   n64recomp-kit elf-info path/to/game.elf
   ```

4. Create a concrete N64Recomp TOML config using real paths:

   ```bash
   n64recomp-kit init \
     --config project.toml \
     --entrypoint 0x80000400 \
     --elf path/to/game.elf \
     --output-func-path RecompiledFuncs
   ```

   Or, for symbol-file mode:

   ```bash
   n64recomp-kit init \
     --config project.toml \
     --entrypoint 0x80000400 \
     --rom build/game.z64 \
     --symbols path/to/symbols.toml \
     --output-func-path RecompiledFuncs
   ```

5. Validate the config before running upstream code generation:

   ```bash
   n64recomp-kit check-config project.toml
   ```

6. Run N64Recomp and write a machine-readable report:

   ```bash
   n64recomp-kit run project.toml \
     --n64recomp "$PWD/.deps/N64Recomp/build/N64Recomp" \
     --clean-output \
     --report build/recomp-report.json
   ```

7. Summarize generated output:

   ```bash
   n64recomp-kit summarize-output RecompiledFuncs
   ```

## Batch runs

Create a batch manifest using real config files:

```toml
[[project]]
name = "game-us"
config = "project.us.toml"

[[project]]
name = "game-jp"
config = "project.jp.toml"
```

Run validation only:

```bash
n64recomp-kit batch batch.toml --mode check --report build/batch-check.json
```

Run code generation for every config:

```bash
n64recomp-kit batch batch.toml \
  --mode run \
  --n64recomp "$PWD/.deps/N64Recomp/build/N64Recomp" \
  --report build/batch-run.json
```

## Direct scripts

The `tools/` directory exposes the same CLI modules as standalone commands:

| Script | Purpose |
|---|---|
| `tools/n64_rom_info.py` | Inspect N64 ROM byte order, header fields, CIC-style bootcode hash, and checksum header words. |
| `tools/n64_rom_convert.py` | Convert `.n64` or `.v64` byte order to big-endian `.z64`. |
| `tools/n64_elf_info.py` | Inspect ELF class, endian mode, architecture, entry point, and executable sections. |
| `tools/n64recomp_config_check.py` | Validate N64Recomp TOML config paths and value constraints. |
| `tools/n64recomp_run.py` | Run N64Recomp with validation and JSON reporting. |
| `tools/n64recomp_batch.py` | Batch-check or batch-run several configs. |

## Verification status

The implementation is self-contained and uses only Python standard-library modules. The facts embedded in the docs were cross-checked against upstream N64Recomp README/CMake/config parser, N64ModernRuntime README, and the repository release page as of 2026-07-09. See [`docs/verified-facts.md`](docs/verified-facts.md).

## Legal and safety notes

Use this toolkit only with game files you are legally allowed to inspect or transform. Do not commit ROMs, game assets, generated proprietary code, or private SDK material. This repository intentionally ignores those file types in `.gitignore`.

## License

MIT. See [`LICENSE`](LICENSE).
