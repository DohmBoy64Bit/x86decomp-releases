# N64Recomp workflow with this companion

## 1. Build upstream N64Recomp

Local build:

```bash
./scripts/bootstrap_n64recomp.sh --prefix "$PWD/.deps/N64Recomp" --jobs 8
```

Container build:

```bash
./scripts/build_docker_image.sh
./scripts/docker_shell.sh "$PWD"
```

The Docker image builds upstream N64Recomp from source and puts `N64Recomp` on `PATH`.

## 2. Confirm your inputs

N64Recomp needs executable code plus metadata. In practice that means one of these paths:

- ELF mode: a matching ELF from a disassembly or decompilation project.
- Symbol-file mode: a ROM plus a N64Recomp-compatible symbols TOML.

This toolkit validates paths and TOML structure. It does not generate accurate symbols from a bare ROM.

## 3. Normalize ROM byte order

Run:

```bash
n64recomp-kit rom-info game.z64
```

If the byte order is not `z64-big-endian`, convert it:

```bash
n64recomp-kit convert-rom game.v64 build/game.z64
```

## 4. Inspect the ELF

Run:

```bash
n64recomp-kit elf-info game.elf
```

A normal N64 target ELF is usually ELF32, big-endian, and MIPS. The inspector reports those fields and the executable sections so you can catch mismatched files before running code generation.

## 5. Create a config

ELF mode:

```bash
n64recomp-kit init \
  --config project.toml \
  --entrypoint 0x80000400 \
  --elf game.elf \
  --output-func-path RecompiledFuncs
```

Symbol-file mode:

```bash
n64recomp-kit init \
  --config project.toml \
  --entrypoint 0x80000400 \
  --rom build/game.z64 \
  --symbols symbols.toml \
  --output-func-path RecompiledFuncs
```

## 6. Validate and run

```bash
n64recomp-kit check-config project.toml
n64recomp-kit run project.toml --n64recomp .deps/N64Recomp/build/N64Recomp --clean-output
```

A JSON report is written to `recomp-report.json` by default. It contains validation diagnostics, the exact command, exit code, stdout/stderr, elapsed time, and output file summary.

## 7. Integrate runtime

Generated code must be integrated with a runtime that implements macros, RDRAM state, libultra behavior, graphics/audio/controller callbacks, storage, overlays, and game-specific patches. N64ModernRuntime is the upstream runtime project designed for this ecosystem; commercial-game projects still need title-specific work.
