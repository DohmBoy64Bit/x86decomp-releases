# Legal and scope notes

This repository contains only original automation and documentation. It does not contain Nintendo code, ROMs, extracted assets, generated game code, private SDKs, or keys.

Recommended hygiene:

- Keep ROMs and extracted assets outside the Git repository or covered by `.gitignore`.
- Commit only source code, scripts, documentation, and metadata that you have the right to publish.
- Store generated N64Recomp output privately unless you have confirmed it is legal to distribute.
- Treat each game's runtime integration as title-specific engineering work.

What this toolkit can do:

- Build upstream N64Recomp in a repeatable environment.
- Validate configs before invoking the recompiler.
- Inspect ROM and ELF inputs for obvious mismatch problems.
- Run batch code-generation experiments and produce JSON reports.

What this toolkit cannot honestly do by itself:

- Create accurate function symbols from an arbitrary commercial ROM.
- Replace a game-specific decompilation/disassembly project.
- Provide a finished graphics/audio/input runtime for every game.
- Make copyrighted game files redistributable.
