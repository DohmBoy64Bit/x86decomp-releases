# Verified facts used by this toolkit

Checked on 2026-07-09 against public upstream project pages and raw source files.

## N64Recomp scope

The upstream README describes N64: Recompiled as a tool that statically recompiles N64 binaries into C code that can be compiled for any platform. It also says the output is expected to be used with a runtime that supplies required functionality and macro implementations.

Practical implication: this companion does not promise a complete playable PC port from a ROM alone. It automates the reproducible portions around N64Recomp and reports clearly when project-specific integration remains.

## Build requirements

The upstream README states that N64Recomp builds with CMake 3.20 or newer and a C++20-capable compiler. The upstream `CMakeLists.txt` sets `CMAKE_CXX_STANDARD 20` and defines the `N64Recomp`, `RSPRecomp`, `RecompModTool`, `OfflineModRecomp`, `RecompModMerger`, and `LiveRecomp` targets.

## Submodules

The upstream `.gitmodules` lists these submodules:

- `lib/rabbitizer` from `https://github.com/Decompollaborate/rabbitizer`
- `lib/ELFIO` from `https://github.com/serge1/ELFIO`
- `lib/fmt` from `https://github.com/fmtlib/fmt`
- `lib/tomlplusplus` from `https://github.com/marzer/tomlplusplus`
- `lib/sljit` from `https://github.com/zherczeg/sljit`

The bootstrap and Docker scripts clone with `--recurse-submodules` and run `git submodule update --init --recursive` because upstream requires recursive submodules.

## Config behavior

The upstream README says the recompiler is configured by a TOML file passed as the first argument. The upstream config parser confirms these concrete fields are read from `[input]`: `entrypoint`, `elf_path`, `symbols_file_path`, `rom_file_path`, `output_func_path`, `relocatable_sections_path`, `uses_mips3_float_mode`, `bss_section_suffix`, `single_file_output`, `use_absolute_symbols`, `manual_funcs`, `function_sizes`, `output_binary_path`, `unpaired_lo16_warnings`, `use_mdebug`, `mdebug_file_mappings`, `recomp_include`, `functions_per_output_file`, `trace_mode`, `func_reference_syms_file`, `data_reference_syms_files`, `allow_exports`, and `strict_patch_mode`.

The same parser confirms `[patches]` supports `stubs`, `ignored`, `renamed`, `instruction`, and `hook` entries. It checks instruction patch VRAM alignment and function size divisibility by 4; this toolkit mirrors those checks.

## Metadata input limitation

The upstream README says the current required metadata path is an ELF file and that the easiest way to get one is a disassembly or decompilation project. The current config parser also supports symbol TOML plus ROM fields. This toolkit supports validating and generating configs for both modes without claiming that it can automatically invent missing symbols.

## N64ModernRuntime role

N64ModernRuntime describes itself as a modern runtime for traditional ports and N64Recomp recompilations. Its README says it contains `ultramodern` and `librecomp`; `ultramodern` implements core libultra functionality, while `librecomp` bridges generated N64Recomp code with ultramodern and provides remaining libultra functionality such as overlay handling and save media support.
