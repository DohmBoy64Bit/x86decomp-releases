# Docker usage

Build the image:

```bash
./scripts/build_docker_image.sh
```

Pin an upstream N64Recomp ref:

```bash
./scripts/build_docker_image.sh --ref main --image n64recomp-companion:main
```

Open a shell with the current repository mounted at `/work`:

```bash
./scripts/docker_shell.sh "$PWD"
```

Run commands inside the container:

```bash
n64recomp-kit doctor
N64Recomp path/to/project.toml
n64recomp-kit run path/to/project.toml --n64recomp /usr/local/bin/N64Recomp
```

The Dockerfile intentionally builds N64Recomp during image creation instead of vendoring upstream source. That keeps this repository small and preserves upstream licensing and submodule boundaries.
