# AI Guardrails — Binding Ruleset

These rules govern all AI-assisted work on Cosmic Ascension Online. They are not
suggestions. Violating a MUST rule invalidates the work; it must be redone.

## G1. Truthfulness — no hallucination

- G1.1 MUST NOT state an API signature, config option, CLI flag, library behavior,
  version capability, file path, or project fact without verifying it in this
  session: by reading the actual file, fetching the current official docs, or
  executing code that proves it.
- G1.2 MUST cite the verification in the work product (file path read, doc URL and
  version fetched, or command output) when the claim is non-obvious.
- G1.3 MUST say "unverified" and stop rather than guess. A wrong guess presented
  confidently is the worst possible output.
- G1.4 MUST treat its own prior outputs as unverified claims — earlier messages in
  a session are not sources.
- G1.5 MUST re-verify anything version-sensitive at the start of each phase, even
  if verified in a previous phase (dependencies may have been updated).

## G2. Completeness — no TODOs, no placeholders

- G2.1 MUST NOT commit code containing TODO, FIXME, XXX, HACK, WIP, TBD,
  "placeholder", "not implemented", "coming soon", `throw new Error("stub")`,
  empty function bodies standing in for behavior, lorem ipsum, or dummy values
  meant to be replaced later. `scripts/check-no-placeholders.mjs` enforces this.
- G2.2 MUST NOT commit commented-out code.
- G2.3 If a task is too large to finish completely, MUST split it into smaller
  tasks that are each individually complete, tested, and documented — never commit
  the large task half-done.
- G2.4 Docstrings MUST be meaningful: they explain purpose, behavior, inputs,
  outputs, side effects, and error conditions in real sentences. A docstring that
  merely restates the symbol name (e.g. "Gets the user" on `getUser`) counts as a
  placeholder and fails review.
- G2.5 Test bodies MUST assert real behavior. An empty test, a test with no
  assertions, or `expect(true).toBe(true)` counts as a placeholder.

## G3. Phase discipline

- G3.1 MUST perform the Phase Start Ritual in `AGENTS.md` before any work in a new
  phase: re-read all rules docs, the phase document, and the previous phase's exit
  gate; fetch current official docs for the phase's technologies; run `npm run
  verify` clean; record the charter confirmation.
- G3.2 MUST perform the shorter Session Start Ritual every session.
- G3.3 MUST NOT begin a phase whose entry gate is not fully satisfied, and MUST NOT
  declare a phase complete while any exit-gate item is unchecked.
- G3.4 MUST implement only what the current phase document lists. Ideas outside the
  phase go to the Backlog or the phase document's Open Questions — never into code.

## G4. Current documentation — always read the latest docs

- G4.1 MUST fetch the current official documentation (URLs in
  `docs/rules/TECH-STACK.md`) for any library, framework, or platform feature
  before first use in a phase, and record it in the phase's Docs Consulted table
  with version and date.
- G4.2 MUST check the installed version (`package.json` / lockfile) and read the
  docs for THAT version, noting any breaking changes since the last consultation.
- G4.3 MUST NOT copy code patterns from memory of older library versions when the
  current docs show a different API.

## G5. Testing — 100% coverage (details in TESTING-STANDARDS.md)

- G5.1 Every workspace enforces 100% line, branch, function, and statement coverage
  via Vitest thresholds. The build fails below 100%.
- G5.2 Coverage exceptions (`/* v8 ignore */` and config `exclude`) are forbidden
  except for the narrow cases whitelisted in TESTING-STANDARDS.md §4, each with a
  written justification comment.
- G5.3 Tests are written with or before the code they cover, in the same commit.

## G6. Documentation — 100% coverage with hash verification (details in DOCUMENTATION-STANDARDS.md)

- G6.1 Every source directory is mapped to a system documentation file in
  `docs/.doc-sync.json`. Unmapped source files fail the build.
- G6.2 When code changes, its mapped documentation MUST be genuinely updated in the
  same commit, then `node scripts/check-doc-sync.mjs --update` re-records both
  hashes. Running `--update` without actually revising the documentation is a
  falsified record and is forbidden.
- G6.3 Every exported and internal symbol carries a meaningful TSDoc docstring
  (G2.4). ESLint and TypeDoc validation enforce presence; review enforces meaning.

## G7. Game integrity

- G7.1 The server is authoritative over combat, inventory, currency, items, trades,
  movement, and progression. The client MUST never compute an outcome that matters.
- G7.2 All client input is validated against shared zod schemas server-side.
- G7.3 High-value transactions (trades, marketplace, rare drops) are audit-logged.
- G7.4 Randomness in combat creates variation, never the primary mechanic, per the
  design document.

## G8. Original IP

- G8.1 All names, races, techniques, transformations, artifacts, characters, and
  lore use the project's own glossary (Resonance, Ascension Index, Ascendant Forms,
  Disciplines, Breakthroughs, the Shattered Meridian, Axiom Shards, Vaeloryn, the
  First Fracture). MUST NOT reproduce characters, terminology, storylines, or
  distinctive elements of any existing franchise.

## G9. Honesty about progress

- G9.1 Status reports MUST distinguish done (all gates green) from in-progress from
  not started. "Done" claimed for gated work that has not passed its gates is a
  guardrail violation.
- G9.2 When something failed, report the failure and its evidence first, before any
  proposed fix.
