# Original IP Glossary — Canonical Terminology

All game code, content, documentation, and UI text uses these terms and only
these terms (guardrail G8). New lore terms are added here first, then used.

| Term | Meaning |
|------|---------|
| Resonance | The universe's primary life-energy force, present in beings, planets, stars, and artifacts. |
| Resonance Reserve | A character's pool of energy available for techniques and transformations. |
| Resonance Signature | The detectable presence a character emits; sensed by trained fighters. |
| Suppression | Deliberately hiding or lowering a Resonance Signature. |
| Ascension Index | A rough estimate of a fighter's developed potential; never reveals skill, gear, or condition. |
| Ascendant Form | A transformation or advanced physical state; a major milestone with tradeoffs. |
| Discipline | A combat path (class): Vanguard, Resonant Adept, Void Strider, Aegis Warden, Arsenal Savant, Wildbound. |
| Technique | An individual combat move with cost, speed, range, accuracy, impact, guard damage, cooldown, type, status, counter. |
| Breakthrough | A major progression milestone in a character's development. |
| Overcharge | Temporarily pushing beyond safe limits. |
| Fracture | Physical or spiritual strain caused by excessive power use. |
| Vitality | Physical health resource in combat. |
| Guard | Defensive stability and resistance to interruption in combat. |
| The Shattered Meridian | The region of space where the game takes place. |
| The First Fracture | The cataclysm that destroyed the gateway-building civilization. |
| Axiom Shards | Nine ancient artifacts tied to cosmic principles (life, memory, distance, matter, time, conflict, restoration, identity, possibility). |
| Vaeloryn, the Eon Wyrm | The celestial being summoned by the assembled Shards. |
| World Decree | The single bounded wish Vaeloryn can grant. |

Terms from existing franchises are forbidden everywhere, including code
identifiers, test fixtures, and sample content.
