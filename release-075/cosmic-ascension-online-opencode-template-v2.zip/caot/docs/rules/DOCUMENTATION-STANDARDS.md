# Documentation Standards — 100% Coverage, Hash-Verified

## 1. Three layers of documentation, all mandatory

1. Docstrings (TSDoc) on every symbol — enforced by ESLint + TypeDoc validation.
2. System documentation in `docs/systems/` — one living document per source
   directory, hash-bound via `docs/.doc-sync.json`.
3. Phase records in `docs/phases/` — charter confirmations, Docs Consulted tables,
   Decisions logs, Open Questions.

## 2. Docstring coverage (100%)

Every module, class, interface, type alias, enum, function, and method — exported
or internal — carries a TSDoc comment. Enforcement:
- ESLint `jsdoc/require-jsdoc` (contexts include non-exported declarations),
  `jsdoc/require-description`, `jsdoc/require-param-description`,
  `jsdoc/require-returns-description`, `jsdoc/require-throws` where applicable, and
  `tsdoc/syntax` for valid TSDoc. Config: `config-templates/eslint.config.mjs`.
- `npx typedoc --validation` fails on any undocumented exported symbol.
- `scripts/check-no-placeholders.mjs` rejects empty or trivially short docstrings.

A meaningful docstring states: what the symbol is for, what it does (including side
effects), what each parameter means beyond its type, what is returned, and how it
fails. Example of a FAILING docstring: "Handles combat." Example of a PASSING one:
"Resolves one combat round: validates both queued actions against the shared
schemas, orders them by technique speed with Guard-stagger overrides, applies
costs, damage, and status effects atomically, and returns the ordered event log.
Throws CombatStateError if either combatant is not in an active encounter."

## 3. System documentation with hash verification

`docs/.doc-sync.json` maps source globs to system docs and records a SHA-256 hash
of the mapped sources and of the doc, taken the last time the doc was updated.

Workflow when changing code in a mapped directory:
1. Make the code change.
2. Update the mapped `docs/systems/<name>.md` so it accurately describes the new
   behavior — architecture, data flow, invariants, message formats, decisions.
3. Run `node scripts/check-doc-sync.mjs --update` to re-record both hashes.
4. Commit code + doc + manifest together.

The checker (`node scripts/check-doc-sync.mjs`) fails when:
- a mapped source set's current hash differs from the recorded hash (code drifted
  ahead of docs, or `--update` wasn't run after a doc revision);
- a doc's hash differs from its recorded hash (doc changed without re-recording);
- any file matching `requireMapping` globs is not covered by at least one mapping
  (undocumented source — 100% documentation coverage violated);
- a mapped doc file does not exist or is empty.

Running `--update` without genuinely revising the documentation is falsification
(guardrail G6.2). Reviews spot-check diffs: a code change with an `--update`-only
manifest change and no meaningful doc diff is rejected.

## 4. What a system doc must contain

Purpose and scope; responsibilities and non-responsibilities; data model; public
interface (routes/messages/functions); invariants and validation rules; failure
modes; interaction with other systems; and a short changelog line per substantive
update. Write prose, not bullet fragments; a future contributor should understand
the system from the doc alone.

## 5. Phase records

Each phase document accumulates: Charter Confirmation (goals restated at phase
start), Docs Consulted (external doc URL, version, date, notes), Decisions (what
was decided, why, alternatives rejected), Open Questions (blockers for the owner),
and the living exit-gate checklist. These are append-mostly and never deleted.
