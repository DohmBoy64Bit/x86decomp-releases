# Tech Stack — Choices, Version Policy, and Official Documentation Sources

## 1. Stack

| Layer | Technology | Role |
|-------|-----------|------|
| Language | TypeScript (strict mode) everywhere | One language across server, client, shared, tools |
| Runtime | Node.js (current LTS) | Server and tooling |
| HTTP server | Fastify | Auth, REST endpoints, static serving |
| Realtime | `ws` (WebSocket) | Authoritative game gateway |
| Validation | zod | Shared client/server message and content schemas |
| Database | PostgreSQL | Accounts, characters, world, economy, audit logs |
| DB access | Typed query layer chosen in Phase 0 (evaluate Drizzle vs Kysely against current docs) | Migrations + typed queries |
| Cache/pubsub | Redis | Sessions, presence, rate limits, cross-node pub/sub |
| Client | React + Vite | Responsive PWA game interface |
| Client state | Chosen in Phase 0 against current docs (evaluate Zustand vs Redux Toolkit) | UI and game-state stores |
| Testing | Vitest + V8 coverage, fast-check, Testcontainers, Playwright (Phase 8+) | 100% coverage enforcement |
| Docs tooling | TypeDoc, ESLint jsdoc/tsdoc plugins | Docstring enforcement & API reference |
| AI coding agent | OpenCode | Project instructions, guarded permissions, and repeatable phase workflows |
| CI | GitHub Actions | Hard gates on every push/PR |

Exact versions are pinned in the root `package.json` during Phase 0 and upgraded
deliberately (dedicated commits, docs re-consulted, full verify run) — never
implicitly.

## 2. Latest-docs rule (guardrail G4)

Before first use of any technology in a phase, fetch its CURRENT official docs and
record version + date in the phase's Docs Consulted table. Official sources:

| Technology | Official documentation |
|------------|------------------------|
| Node.js | https://nodejs.org/docs/latest/api/ |
| TypeScript | https://www.typescriptlang.org/docs/ |
| Fastify | https://fastify.dev/docs/latest/ |
| ws | https://github.com/websockets/ws (README + docs folder) |
| zod | https://zod.dev |
| PostgreSQL | https://www.postgresql.org/docs/current/ |
| Drizzle ORM | https://orm.drizzle.team/docs/overview |
| Kysely | https://kysely.dev/docs/intro |
| Redis | https://redis.io/docs/latest/ |
| React | https://react.dev/reference/react |
| Vite | https://vite.dev/guide/ |
| Zustand | https://zustand.docs.pmnd.rs |
| Redux Toolkit | https://redux-toolkit.js.org |
| Vitest | https://vitest.dev/guide/ |
| fast-check | https://fast-check.dev |
| Testcontainers (Node) | https://node.testcontainers.org |
| Playwright | https://playwright.dev/docs/intro |
| TypeDoc | https://typedoc.org |
| ESLint | https://eslint.org/docs/latest/ |
| eslint-plugin-jsdoc | https://github.com/gajus/eslint-plugin-jsdoc |
| OpenCode | https://opencode.ai/docs |
| GitHub Actions | https://docs.github.com/en/actions |
| PWA (web app manifest, service workers) | https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps |
| WCAG accessibility | https://www.w3.org/WAI/WCAG22/quickref/ |

If a fetched doc contradicts anything written in this repository, the fetched doc
wins; update the repository doc in the same commit (doc-sync will require it).

## 3. Version upgrade procedure

1. Read the release notes/changelog for the target version from the official source.
2. Note breaking changes in the phase's Docs Consulted table.
3. Upgrade in an isolated commit; run `npm run verify`; fix fallout completely.
4. Update any system docs describing affected behavior (doc-sync enforced).
