# Testing Standards — 100% Coverage Policy

## 1. Policy

All workspaces (`server`, `client`, `shared`, `tools`) enforce 100% line, branch,
function, and statement coverage with Vitest + V8 coverage. Thresholds live in each
workspace's `vitest.config.ts` (template in `config-templates/vitest.config.ts`) and
fail the run when any metric drops below 100. CI runs coverage on every push; the
pre-commit hook runs it on changed workspaces.

## 2. What kinds of tests

- Unit tests: every function/class in isolation, including all error branches.
- Integration tests: HTTP routes and WebSocket message flows against a real
  Postgres/Redis via Testcontainers (from Phase 1), exercising the full stack.
- Simulation tests: combat engine and economy invariants driven by seeded RNG and
  property-based cases (fast-check) — e.g. "Guard never goes negative", "a trade
  never creates or destroys currency", "no technique sequence produces NaN stats".
- Contract tests: every zod message schema has round-trip and rejection tests.
- E2E smoke (from Phase 8): Playwright flows for register → create character →
  move → fight → equip on desktop and mobile viewports.

## 3. Rules

- T1 Tests accompany code in the same commit. No "tests later".
- T2 Every bug fix first adds a failing test that reproduces the bug.
- T3 No assertion-free or tautological tests (guardrail G2.5).
- T4 Tests are deterministic: seeded RNG, fake timers, no network beyond
  Testcontainers, no ordering dependence. A flaky test is a failing test.
- T5 Test names describe behavior ("rejects trade when either party lacks the
  item"), not implementation ("calls tradeService").
- T6 Coverage of generated files or third-party code is achieved by excluding
  generation targets from source, not by ignore-comments in engine code.

## 4. Permitted coverage exclusions (exhaustive whitelist)

Only these may use `/* v8 ignore */` or config `exclude`, and each inline ignore
carries a one-line justification comment:
1. `*.config.ts` files and the `scripts/` folder of each workspace.
2. Type-only files (pure `interface`/`type` declarations emit no runtime code).
3. Process-level entry bootstrap (`main.ts` process wiring) — its logic must be
   extracted into tested functions so the bootstrap is only calls.
4. Exhaustiveness guards proven unreachable by the type system (`assertNever`).
Anything else requires a written exception in the phase document's Decisions log,
approved by the project owner.

## 5. Commands

- `npm run test` — all workspaces, coverage enforced.
- `npm run test -w server` — one workspace.
- `npm run verify` — build + lint + typecheck + tests + placeholder scan + doc-sync.
