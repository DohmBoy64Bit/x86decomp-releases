# Cosmic Ascension Online

### A Text-Based Open-World Light MMORPG

**Tagline:** *Train beyond your limits. Explore the stars. Shape a living universe.*

## Project Overview

**Cosmic Ascension Online** is a browser-based, text-driven open-world light MMORPG set within an original science-fantasy universe of martial artists, alien civilizations, ancient cosmic powers, and world-threatening conflicts.

The game draws inspiration from the fantasy of high-powered martial-arts anime: intense training, energy-based combat, rivalries, transformations, tournaments, destructive techniques, unusual alien races, and warriors who gradually rise from local fighters to universe-shaping legends. However, it will not reproduce the characters, terminology, storyline, locations, transformations, artifacts, or visual identity of any existing franchise.

Instead, **Cosmic Ascension Online** will have its own races, planets, characters, factions, mythology, combat terminology, transformation systems, and long-running narrative.

The game will combine the descriptive depth and social interaction of a traditional MUD with an accessible graphical interface. Most actions and encounters will be presented through atmospheric text, combat logs, dialogue, and commands, while maps, character portraits, ability icons, equipment displays, status effects, and environmental artwork provide visual context.

It will run directly within modern web browsers and be fully usable on desktop computers, tablets, and mobile phones. The interface should feel more like a lightweight online game than a traditional command-line terminal, while still supporting optional typed commands for experienced MUD players.

---

# The Core Player Fantasy

Players begin as relatively unknown fighters entering a vast universe filled with dangerous creatures, rival warriors, unexplored planets, secret masters, ancient ruins, and growing cosmic threats.

Through exploration, training, quests, combat, tournaments, relationships, and major story decisions, players develop their characters into increasingly powerful beings. Their journey may take them from defending a small settlement to fighting in interplanetary wars, challenging legendary champions, unlocking forbidden techniques, discovering hidden transformations, and influencing events that affect the entire game world.

The intended progression fantasy is not simply:

> Higher number defeats lower number.

Power matters, but victory should also depend on preparation, ability selection, timing, positioning, resource management, status effects, counters, equipment choices, and knowledge of the opponent.

A stronger character should have an advantage without becoming automatically unbeatable.

---

# Original World and Terminology

The universe of **Cosmic Ascension Online** is connected by an invisible cosmic force known as **Resonance**.

Resonance exists within living beings, planets, stars, and certain ancient artifacts. Trained fighters learn to sense, control, suppress, and project it. Resonance powers physical enhancements, ranged techniques, defensive barriers, healing abilities, transformations, and unusual supernatural disciplines.

A character’s overall combat potential is represented by an **Ascension Index**. This replaces the traditional concept of a power level. The Ascension Index provides a rough estimate of a fighter’s developed potential, but it does not reveal their strategy, equipment, hidden abilities, current condition, or actual combat skill.

Other potential terms include:

* **Resonance** — the universe’s primary life-energy system.
* **Ascension Index** — an estimate of a character’s overall developed power.
* **Resonance Reserve** — the energy available for techniques.
* **Ascendant Forms** — transformations and advanced physical states.
* **Disciplines** — classes or primary combat paths.
* **Techniques** — individual combat moves and abilities.
* **Breakthroughs** — major progression milestones.
* **Resonance Signature** — the detectable presence of a character.
* **Suppression** — hiding or lowering a Resonance Signature.
* **Overcharge** — temporarily pushing beyond safe limits.
* **Fracture** — physical or spiritual strain caused by excessive power use.

These names can be adjusted during worldbuilding, but the game should consistently use its own terminology.

---

# The Setting

The game takes place across a region of space known as **the Shattered Meridian**.

Long ago, the Meridian was connected by an advanced civilization that could manipulate Resonance on a planetary scale. That civilization disappeared during an event remembered as **the First Fracture**, leaving behind sealed gateways, ruined cities, altered species, dangerous machines, and fragments of knowledge that modern civilizations do not fully understand.

Today, the Meridian contains independent planets, warrior cultures, trade coalitions, religious orders, criminal empires, research factions, nomadic fleets, and isolated worlds that have never encountered life beyond their own skies.

A growing disturbance is now spreading through the ancient gateway network. Creatures are mutating, lost structures are awakening, and powerful individuals are beginning to experience unusual Breakthroughs. Key story characters believe these events are connected to the First Fracture and to an intelligence that may still exist beyond the known universe.

The main storyline will unfold through chapters, world events, faction conflicts, dungeons, and permanent changes to locations.

---

# Playable Races

Every playable race will have:

* A unique homeworld.
* A detailed history and culture.
* Distinctive physical or spiritual traits.
* At least two positive racial modifiers.
* At least one meaningful negative modifier.
* Exclusive dialogue and story interactions.
* Access to certain racial techniques.
* Restrictions on some techniques, equipment, or Ascendant Forms.
* One or more possible racial progression paths.

Racial traits should create different playstyles rather than establishing a single objectively superior race.

For example, one race might regenerate quickly and possess a large Resonance Reserve but suffer reduced equipment compatibility. Another may excel at weapon combat and tactical analysis but be completely unable to transform. A physically powerful species may have difficulty controlling complex techniques, while a fragile energy-based species may possess exceptional control but struggle in prolonged melee combat.

Some races will access several transformations. Others may have one highly specialized evolution, a temporary awakened state, equipment-based advancement, biological adaptation, or no transformation ability at all.

Characters without transformations must remain competitive through exclusive techniques, superior equipment interaction, permanent upgrades, tactical flexibility, or specialized class combinations.

---

# Classes and Combat Disciplines

Classes will be called **Disciplines**. A Discipline represents how a character has learned to fight rather than determining their species or personality.

Possible launch Disciplines could include:

* **Vanguard** — close-range martial combat, counters, grapples, and defensive pressure.
* **Resonant Adept** — energy projection, barriers, mobility, and battlefield control.
* **Void Strider** — speed, misdirection, stealth, debuffs, and precision attacks.
* **Aegis Warden** — protection, healing, interception, and group support.
* **Arsenal Savant** — weapons, armor systems, gadgets, traps, and tactical preparation.
* **Wildbound** — survival, creature knowledge, environmental abilities, and adaptive fighting.

Each Discipline should have several possible builds rather than one fixed sequence of upgrades.

A player’s available moveset will be influenced by:

* Race.
* Discipline.
* Equipped weapon.
* Equipped armor.
* Training history.
* Transformation state.
* Mentors encountered.
* Faction reputation.
* Story decisions.
* Techniques discovered through exploration.
* Techniques learned from other players or rare manuals.

Players should be able to save multiple technique loadouts, but only a limited number of techniques may be prepared for a battle. This creates meaningful choices without forcing players to manage hundreds of buttons.

---

# Tactical Combat

Combat will use a readable tactical system designed around decisions rather than pure randomness.

Each technique will have a small number of understandable properties:

* Resonance cost.
* Speed.
* Range.
* Accuracy.
* Impact.
* Guard damage.
* Cooldown or recovery time.
* Technique type.
* Possible status effect.
* Counter or weakness.

Combatants will manage three primary resources:

1. **Vitality** — physical health.
2. **Resonance** — energy used for techniques and transformations.
3. **Guard** — defensive stability and resistance to interruption.

Combat can also include temporary conditions such as staggered, exposed, silenced, grounded, bleeding, disoriented, restrained, or overcharged.

Players will make choices involving:

* Attacking.
* Guarding.
* Evading.
* Charging Resonance.
* Changing stance.
* Closing or creating distance.
* Interrupting an opponent.
* Using an item.
* Transforming.
* Suppressing or revealing their power.
* Preparing a counter.
* Interacting with the environment.

Powerful attacks should usually create a warning, charge period, resource commitment, positioning requirement, or recovery window. This gives opponents an opportunity to react instead of simply receiving unavoidable damage.

Statistics influence combat effectiveness, but tactics determine how that effectiveness is used. Randomness may create variation, but it should never be the primary combat mechanic.

For mobile accessibility, players should be able to select actions using buttons, quick slots, or optional typed commands. A short command queue can allow players to prepare their next action without requiring extremely fast typing.

---

# Transformations and Ascendant Forms

Transformations will be called **Ascendant Forms**.

They should be major character milestones rather than ordinary equipment upgrades. Unlocking one may require a racial storyline, dangerous training, a rare mentor, emotional development, a dungeon objective, a hidden location, or a difficult personal trial.

Ascendant Forms may provide:

* New techniques.
* Altered combat properties.
* Temporary stat changes.
* Different strengths and weaknesses.
* New visual portraits or effects.
* Increased Resonance consumption.
* Physical or mental strain.
* Story consequences.
* Changes in how NPCs react to the character.

Transformations will not always be direct upgrades. One form may increase speed while reducing defense. Another may produce enormous damage but rapidly drain Resonance. Advanced players should need to decide when a form is appropriate instead of remaining transformed permanently.

---

# Exploration and World Structure

The universe will contain multiple planets and large regions, each divided into interconnected locations or rooms.

Every planet should have its own:

* Biomes.
* Settlements.
* Factions.
* Wildlife.
* Intelligent species.
* Resources.
* Shops.
* Dungeons.
* Weather or environmental conditions.
* Regional storylines.
* Local events.
* Hidden locations.
* Transportation systems.
* Combat encounters.
* Cultural identity.

Players will travel through directional movement, clickable exits, or map selection. Location descriptions should change according to time, weather, active events, completed quests, nearby creatures, and major world conditions.

The graphical map will show:

* The current location.
* Discovered paths.
* Nearby landmarks.
* Party members.
* Known NPCs.
* Event areas.
* Dungeon progress.
* Environmental hazards.
* Points of interest.

Undiscovered regions should remain hidden until explored, purchased from a cartographer, learned from another player, or revealed through a quest.

Some creatures will move between locations, hunt other creatures, defend territories, flee from stronger threats, or appear under specific environmental conditions. This will make the world feel active rather than presenting enemies as static menu entries.

---

# Dungeons

Dungeons will be structured adventures with a defined final objective, usually ending in a boss encounter.

A dungeon may include:

* Branching routes.
* Environmental hazards.
* Puzzles.
* Patrols.
* Resource-management decisions.
* Optional encounters.
* Hidden rooms.
* Lore discoveries.
* Mini-bosses.
* Group mechanics.
* Multiple possible endings.
* A final boss battle.

The detailed dungeon map should show explored rooms, the party’s position, unlocked doors, discovered hazards, and known objectives.

Bosses must use recognizable patterns, changing phases, special counters, environmental mechanics, and unique fighting styles. Their difficulty should come from learning and coordination rather than inflated health alone.

Dungeons may support solo, party, and challenge versions. Challenge versions can introduce altered mechanics, restricted equipment, time objectives, or leaderboard scoring without requiring entirely separate content.

---

# The Axiom Shards

Scattered across the Shattered Meridian are nine ancient artifacts known as the **Axiom Shards**.

Each Shard is associated with a cosmic principle such as life, memory, distance, matter, time, conflict, restoration, identity, or possibility. Their locations change as part of the persistent world, and finding them may involve exploration, investigation, PvE encounters, negotiation, faction politics, player trading, or competitive conflict.

When all nine are assembled under the correct conditions, they summon **Vaeloryn, the Eon Wyrm**, an ancient celestial being capable of issuing a single **World Decree**.

A World Decree functions as the game’s wish system. Wishes must follow defined rules and cannot grant unlimited administrative power, permanently destroy other players, duplicate the rarest items without restriction, or bypass the game’s progression structure.

Possible wishes might include:

* Restoring a destroyed location.
* Reviving an important NPC.
* Changing a character’s race or origin.
* Unlocking a rare training path.
* Creating a temporary global event.
* Recovering a lost artifact.
* Removing a severe transformation penalty.
* Opening a previously inaccessible world.
* Granting a limited reward to the player’s faction or party.

The Axiom Shard system should generate server-wide stories. Their collection, theft, exchange, protection, and use may involve multiple players and factions.

---

# Story and World Events

The world will contain both authored story events and procedural regional events.

**Story events** advance the main narrative and may permanently affect characters, factions, settlements, and planets.

**Dynamic events** can appear according to location, time, population, previous outcomes, or world conditions. Examples include:

* Creature migrations.
* Bandit attacks.
* Invasions.
* Natural disasters.
* Escaped prisoners.
* Traveling merchants.
* Distress signals.
* Crashed vessels.
* Hunting targets.
* Faction disputes.
* Rare-resource discoveries.
* Public boss encounters.
* Axiom Shard sightings.
* Tournament announcements.
* NPC kidnappings.
* Outbreaks of Resonance corruption.

Events should have success and failure outcomes. Ignored attacks may damage a settlement, close a shop, change local prices, displace NPCs, or allow an enemy faction to gain territory.

Major events can unfold through several connected stages, encouraging players to cooperate without requiring them to formally join the same party.

---

# Key Story Characters

The universe will contain recurring named characters with their own motivations, relationships, histories, and combat abilities.

These characters may act as:

* Mentors.
* Rivals.
* Faction leaders.
* Merchants.
* Researchers.
* Tournament champions.
* Criminals.
* Explorers.
* Antagonists.
* Temporary allies.
* Hidden bosses.

Key characters should continue acting even when players are not directly interacting with them. Their loyalties and circumstances may change according to world events and player decisions.

Players should not replace the important characters in the story, but they should be capable of influencing their survival, beliefs, alliances, and eventual outcomes.

---

# Quests and Progression

Progression will come from more than combat experience.

Players can advance through:

* Main story chapters.
* Regional quests.
* Race-specific storylines.
* Discipline training.
* Exploration discoveries.
* Dungeon completion.
* Tournament victories.
* Faction reputation.
* Crafting and gathering.
* Fishing.
* Creature research.
* Technique mastery.
* Mentorship.
* World-event participation.
* Achievements and collections.
* Social or political accomplishments.

Quest solutions may involve fighting, negotiation, investigation, exploration, item collection, puzzles, escorting NPCs, or choosing between factions.

A quest journal will track objectives, previous dialogue, major choices, discovered lore, and relevant map information.

---

# Economy, Items and Trading

The game will contain both NPC commerce and a player-driven economy.

Players will be able to:

* Buy and sell goods at shops.
* Trade directly with other players through a confirmation window.
* Send items through an in-game mail system.
* List goods on a regional or universal marketplace.
* Exchange crafting materials.
* Commission crafted equipment.
* Repair and improve gear.
* Sell captured resources and discoveries.

The economy will require both currency sources and currency sinks.

Sources may include quests, creature bounties, tournament prizes, selling resources, and completing events.

Sinks may include repairs, transportation, crafting fees, marketplace fees, training, cosmetic services, housing, equipment modification, and certain transformation-related costs.

High-value transactions should be logged to reduce fraud and allow support staff to investigate exploits.

---

# Equipment

Characters may equip armor, weapons, accessories, consumables, and utility items.

## Armor

Armor will affect more than a single defense number. Different sets may influence:

* Physical protection.
* Energy resistance.
* Guard strength.
* Mobility.
* Resonance regeneration.
* Environmental resistance.
* Technique compatibility.
* Status resistance.

Heavy armor may protect a character but reduce speed or Resonance efficiency. Lighter equipment may improve movement while providing less protection.

## Weapons

Weapons should enable different tactical options rather than simply adding damage.

Possible weapon families include:

* Unarmed amplifiers.
* Blades.
* Polearms.
* Staves.
* Heavy weapons.
* Resonance firearms.
* Energy-channeling devices.
* Shields.
* Thrown weapons.
* Technological tools.

Some races or Disciplines may be unable to use certain weapon types, while others receive exclusive techniques from them.

Equipment should support upgrading and customization without producing endless tiers of disposable loot.

---

# Crafting, Gathering and Fishing

Players can gather resources from different biomes and use them in a lightweight crafting system.

Potential professions include:

* Armorsmithing.
* Weaponsmithing.
* Resonance engineering.
* Medicine.
* Cooking.
* Artifact research.
* Survival crafting.

Fishing will be a dedicated gathering activity with planet-specific species, weather conditions, bait, equipment, rare catches, collections, cooking ingredients, quests, and occasional unusual encounters.

Fishing should offer relaxing progression and social interaction without becoming mandatory for combat advancement.

---

# Tournaments and Competitive Play

Players and administrators will be able to create structured tournaments.

Tournament options may include:

* One-versus-one.
* Team battles.
* Elimination brackets.
* Round-robin competitions.
* Race-restricted events.
* No-transformation matches.
* Standardized-equipment matches.
* Power-band divisions.
* Open-power exhibitions.
* Discipline-specific contests.
* Seasonal championships.

Official tournaments should have spectator support, commentary logs, rankings, match history, prizes, and anti-exploit rules.

Standardized and power-banded formats will allow tactical competition without requiring every participant to possess endgame equipment.

Open-world PvP should be restricted to designated areas, faction conflicts, consensual challenges, special events, or opt-in rules. New players should not be vulnerable to unrestricted attacks.

---

# Social Systems

The game will include:

* Global, local, party, private, faction, guild, trade, and help chat.
* Friends and ignore lists.
* Guilds or clans.
* Parties and raid groups.
* Player profiles.
* Mail.
* Emotes and role-playing commands.
* Looking-for-group tools.
* Mentorship between experienced and new players.
* Player reporting and blocking.
* Moderation logs.
* Trade confirmations.
* Custom chat filters.

Guilds may unlock shared storage, guild missions, rankings, tournament teams, social spaces, and long-term group objectives without providing overwhelming combat advantages.

---

# Additional Features

To support long-term play, the game should also include:

* A guided interactive tutorial.
* A searchable help and command system.
* A lore codex.
* Character biographies.
* Achievements and collections.
* Daily and weekly objectives that do not punish players for missing days.
* Faction reputation.
* Titles and cosmetic rewards.
* Character respecialization.
* Technique testing or training rooms.
* Combat replays and readable battle logs.
* Party matchmaking.
* Guild and friend activity feeds.
* Seasonal story chapters.
* Server announcements.
* Player feedback and bug-reporting tools.
* Administrative event controls.
* Content-management tools for adding quests, NPCs, items, and locations.
* Accessibility settings.
* Account recovery and security controls.
* Anti-botting and anti-exploit monitoring.

---

# Platform and Interface

**Cosmic Ascension Online** should be developed as a responsive web application that works across desktop and mobile browsers.

The interface may contain:

* A central narrative and combat panel.
* A collapsible map.
* Character and target status panels.
* Ability quick slots.
* Chat tabs.
* An inventory and equipment window.
* Quest tracking.
* NPC portraits.
* Location artwork.
* Animated technique effects.
* Optional command input.
* Customizable font size.
* High-contrast and reduced-motion modes.
* Screen-reader-friendly text.
* Keyboard navigation.
* Mobile touch controls.

The application may also function as an installable progressive web app, allowing players to launch it from their device in a similar manner to a native application.

The server must remain authoritative over combat, inventory, currency, item generation, trades, movement, and progression. The browser should display and request actions but never determine important outcomes by itself.

---

# Recommended Launch Scope

The complete vision is large, so the initial playable release should focus on a strong foundation.

A realistic first version could include:

* Account registration and login.
* Character creation.
* Four to six playable races.
* Four to six Disciplines.
* One main planet.
* Several settlements and biomes.
* A main story chapter.
* Regional and random events.
* Tactical PvE combat.
* Limited consensual PvP.
* One tournament format.
* Three or four dungeons.
* NPCs, shops, items, armor, and weapons.
* Inventory and equipment.
* Direct player trading.
* Basic crafting and fishing.
* Parties, guilds, chat, friends, blocking, and reporting.
* A detailed regional and dungeon map.
* One early Ascendant Form for applicable races.
* An introductory Axiom Shard storyline.

Additional planets, advanced transformations, universal markets, large-scale faction wars, world-changing wishes, raids, housing, and complex political systems can be introduced after the core game is stable.

---

# Design Principles

**Originality First**
The game should capture the excitement of cosmic martial-arts progression while maintaining original terminology, stories, races, artwork, characters, artifacts, and transformations.

**Tactical, Not Tedious**
Combat should contain meaningful counters and decisions without requiring players to memorize hundreds of commands.

**Power With Counterplay**
Character progression must matter, but greater power should not guarantee victory in every situation.

**A Living World**
NPCs, creatures, factions, prices, and locations should respond to events and player actions.

**Accessible by Default**
The game should be fully playable with mouse, touchscreen, keyboard, or assistive technology.

**Social Without Dependency**
Players should benefit from cooperation without being prevented from enjoying solo activities.

**Expandable Systems**
New worlds, races, quests, techniques, transformations, and events should be addable without redesigning the core game.

## Final Summary

**Cosmic Ascension Online** is a text-based open-world light MMORPG combining martial-arts progression, science-fantasy exploration, tactical combat, MUD-style social interaction, and a persistent evolving universe.

Players create warriors from original alien races, choose combat Disciplines, discover techniques, equip weapons and armor, explore distinct planets, enter tournaments, complete dungeons, participate in world events, trade with one another, and unlock race-specific Ascendant Forms.

At the center of the universe are the nine Axiom Shards and Vaeloryn, the Eon Wyrm—a powerful celestial being capable of granting a limited World Decree. Their existence connects exploration, competition, politics, and the central narrative while providing a long-term objective capable of producing memorable server-wide stories.

The result should feel familiar to fans of cosmic martial-arts anime while standing entirely within its own recognizable world.
