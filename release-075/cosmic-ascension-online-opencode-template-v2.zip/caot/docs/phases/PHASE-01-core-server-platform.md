# Phase 1 — Core Server Platform

## Goal
Accounts, authentication, sessions, persistence, and the authoritative realtime
message protocol. After this phase a player can register, log in, hold a stable
authenticated WebSocket session, disconnect, and reconnect without corruption.

## Non-goals
No characters, no world, no gameplay. Protocol carries only auth/session/system
messages plus a versioned envelope ready for future message types.

## Required Reading
Rules docs; Phase 0 exit gate; design document (`docs/DESIGN.md`) §Platform and Interface (server
authority); `docs/systems/` produced in Phase 0.

## Entry gate
Phase 0 exit gate fully green.

## Deliverables
1. PostgreSQL schema + migrations for accounts and sessions; typed query layer.
2. Registration and login (Argon2id password hashing per current OWASP guidance —
   fetch and record it), email uniqueness, rate limiting via Redis.
3. Session management: token issue/refresh/revoke; account recovery flow design
   recorded in Decisions (implementation may land in Phase 9 hardening if owner
   agrees — record the call).
4. WebSocket gateway v1: authenticated connect, heartbeat, graceful resume,
   ordered delivery guarantees documented; every message zod-validated both sides
   from `shared/`.
5. Structured logging, error taxonomy, and audit-log table (used later for trades).
6. Message protocol document `docs/systems/protocol.md` — the single source of
   truth for envelope format, versioning, and error codes.
7. Integration tests via Testcontainers covering every route and message type,
   including failure and abuse paths (bad tokens, replay, malformed payloads).

## Exit gate
- [ ] Register → login → connect → heartbeat → resume → logout works end to end.
- [ ] Malformed/hostile inputs are rejected with tested error codes; nothing crashes.
- [ ] All Phase 0 gates still green (`npm run verify`).
- [ ] `docs/systems/` covers auth, sessions, gateway, protocol; doc-sync green.
- [ ] Docs Consulted includes current OWASP password storage guidance and the DB
      layer's current migration docs.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
