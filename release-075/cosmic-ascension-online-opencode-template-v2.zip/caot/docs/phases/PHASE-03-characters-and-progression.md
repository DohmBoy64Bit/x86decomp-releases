# Phase 3 — Characters & Progression Base

## Goal
Character creation and the progression backbone: four launch races, four launch
Disciplines, core stats, Resonance mechanics (Reserve, Signature, Suppression),
the Ascension Index, training activities, and Breakthrough milestones.

## Non-goals
No combat resolution yet (stats exist; fights do not). No Ascendant Forms (Phase
5). Remaining launch races/Disciplines beyond four each may land in Phase 5
content work if the owner prefers — record in Decisions.

## Required Reading
Rules docs; Phase 2 exit gate; design document (`docs/DESIGN.md`) §Original World and Terminology,
§Playable Races, §Classes and Combat Disciplines, §Quests and Progression.

## Entry gate
Phase 2 exit gate fully green.

## Deliverables
1. Race design records: four original races authored in `content/` with
   homeworld, culture, two+ positive and one+ meaningful negative modifier,
   racial techniques list, restrictions, and progression path — per the design
   document's race requirements. Names from the project glossary only.
2. Discipline design records: Vanguard, Resonant Adept, Void Strider, Aegis
   Warden authored with multiple build directions.
3. Character engine: creation flow (race, Discipline, name validation,
   appearance text), persistent character state, stat model, Resonance Reserve,
   Resonance Signature with Suppression, Ascension Index derivation (estimate,
   not exact power — per design), Breakthrough milestone framework.
4. Training gameplay: at least three repeatable training activities that raise
   stats/technique mastery with diminishing returns and meaningful choice.
5. Technique framework: technique definitions in content files (cost, speed,
   range, accuracy, impact, guard damage, cooldown, type, status, counter)
   validated by schema; loadout system with limited prepared slots.
6. Client: character creation screens, character status panel, training UI.
7. System docs: `characters.md`, `progression.md`, `techniques.md`, `races.md`,
   `disciplines.md`.

## Exit gate
- [ ] Create each race/Discipline combination; all modifiers demonstrably apply
      (asserted by tests, not by inspection).
- [ ] Train stats, hit a Breakthrough, see Ascension Index change; Suppression
      hides Signature from other sessions (protocol-tested).
- [ ] Technique loadouts save/swap with slot limits enforced server-side.
- [ ] Racial balance rule holds: no race strictly dominates another across the
      stat/mechanic matrix (property test comparing modifier sets).
- [ ] All prior gates green; doc-sync green; Docs Consulted updated.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
