# Phase 4 — Tactical Combat

## Goal
The readable tactical combat system: Vitality/Resonance/Guard, technique
execution, status conditions, stances, distance, interrupts, counters, charging,
and PvE encounters against creatures in the world — decisions over randomness.

## Non-goals
No PvP (Phase 7). No transformations in combat (Phase 5 wires Ascendant Forms
in). No dungeon bosses (Phase 5).

## Required Reading
Rules docs; Phase 3 exit gate; design document (`docs/DESIGN.md`) §Tactical Combat, §Exploration
(creature behavior), §Design Principles (Power With Counterplay).

## Entry gate
Phase 3 exit gate fully green.

## Deliverables
1. Combat engine: encounter lifecycle, action selection (attack, guard, evade,
   charge Resonance, change stance, close/create distance, interrupt, item,
   suppress/reveal, prepare counter), resolution ordering by technique speed,
   the three resources, Guard break/stagger, recovery windows for heavy attacks.
2. Status conditions: staggered, exposed, silenced, grounded, bleeding,
   disoriented, restrained, overcharged — each with tested application,
   duration, stacking, and cleanse rules.
3. Deterministic core: seeded RNG injected; identical seeds + inputs produce
   identical outcomes (the foundation of combat tests and future replays).
4. Creature system: creature definitions in content files with behavior profiles
   (aggressive, territorial, fleeing, pack), roaming between rooms, spawn rules
   by biome/time/weather.
5. Combat log: readable, atmospheric text events streamed over the protocol;
   short command queue so mobile players can pre-select the next action.
6. Client: combat panel with action buttons, quick slots, target status, log.
7. Balance harness in `tools/`: scripted AI-vs-AI simulations across matchups
   producing win-rate and duration reports, run on demand (not in CI).
8. System docs: `combat-engine.md`, `status-effects.md`, `creatures.md`.

## Exit gate
- [ ] Full PvE fight end to end from the world (encounter → actions → victory/
      defeat/flee → persistence of results).
- [ ] Property tests: resources never negative/NaN; no action sequence deadlocks
      an encounter; heavy attacks always expose a reaction window.
- [ ] The "higher number auto-wins" failure is disproven: harness shows a lower-
      Index build with counters beating a higher-Index naive build in a designed
      scenario test.
- [ ] Combat is fully playable by buttons alone and by typed commands alone.
- [ ] All prior gates green; doc-sync green; Docs Consulted updated.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
