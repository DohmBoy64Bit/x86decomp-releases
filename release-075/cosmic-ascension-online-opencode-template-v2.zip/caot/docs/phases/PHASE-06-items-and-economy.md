# Phase 6 — Items & Economy

## Goal
The material game: inventory, equipment with tactical properties, shops and
currency with sources and sinks, direct player trading with confirmations and
audit logs, basic crafting professions, and fishing.

## Non-goals
No universal/regional marketplace, no mail-attached items beyond design notes,
no housing (all post-launch; record in BACKLOG).

## Required Reading
Rules docs; Phase 5 exit gate; design document (`docs/DESIGN.md`) §Economy, Items and Trading,
§Equipment, §Crafting, Gathering and Fishing.

## Entry gate
Phase 5 exit gate fully green.

## Deliverables
1. Inventory engine: server-authoritative items, stacking, weight/slot rules,
   equip slots (armor, weapon, accessories, consumables, utility).
2. Equipment with tactical properties per design (protection, energy resistance,
   Guard strength, mobility, Resonance regeneration, technique compatibility,
   status resistance); heavy/light tradeoffs wired into the combat engine; race/
   Discipline restrictions and exclusive weapon techniques.
3. Weapon families for launch: at minimum unarmed amplifiers, blades, polearms,
   Resonance firearms, shields — each enabling distinct combat options.
4. Currency + NPC shops: sources (quests, bounties, events) and sinks (repairs,
   crafting fees, training, transport) with an economy invariant test suite —
   currency is never created or destroyed except by whitelisted sources/sinks.
5. Direct trading: two-party confirmation window, atomic server-side exchange,
   full audit logging of high-value transactions.
6. Crafting: at least armorsmithing, weaponsmithing, medicine, cooking; gathering
   nodes by biome; upgrade/repair without endless disposable-loot tiers.
7. Fishing: planet-specific species, weather/bait/equipment conditions, rare
   catches, collections, cooking ingredients, and one fishing quest line.
8. Client: inventory/equipment window, shop UI, trade window, crafting and
   fishing interfaces.
9. System docs: `items.md`, `equipment.md`, `economy.md`, `trading.md`,
   `crafting.md`, `fishing.md`.

## Exit gate
- [ ] Property tests prove: trades are atomic under concurrency (no dupes/loss);
      economy invariant holds across simulated weeks of activity.
- [ ] Equipment measurably changes combat behavior per its properties (tests).
- [ ] A player can earn, buy, equip, upgrade, trade, craft, and fish end to end.
- [ ] Audit log records every high-value transaction with actor/context.
- [ ] All prior gates green; doc-sync green; Docs Consulted updated.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
