# Phase 2 — World & Movement

## Goal
A living, describable world: the room graph, the starting region of the main
planet, movement, atmospheric descriptions that react to time and weather, and
the map data feed for the client's map panel.

## Non-goals
No combat, no NPC dialogue trees, no quests. Creatures may appear in room
descriptions as ambience only if data-driven and tested.

## Required Reading
Rules docs; Phase 1 exit gate; design document (`docs/DESIGN.md`) §The Setting, §Exploration and
World Structure; `docs/systems/protocol.md`.

## Entry gate
Phase 1 exit gate fully green.

## Deliverables
1. Content pipeline: rooms/regions/exits defined as schema-validated files in
   `content/` (zod schemas in `shared/`); a `tools/` validator that rejects broken
   exits, orphan rooms, and missing descriptions — run inside `npm run verify`.
2. World engine: room graph, directional movement, look command, exit discovery,
   per-room occupancy, movement messages over the gateway.
3. Time-of-day and weather systems; description composition that varies by both.
4. The starting region of the main planet authored: at minimum one settlement,
   two biomes, 40+ rooms with real descriptive text (original IP glossary only).
5. Map data protocol: discovered-rooms fog-of-war state per character
   (persisted), landmarks, points of interest.
6. Client: narrative panel rendering room text and movement, clickable exits,
   optional typed commands (`north`, `look`), collapsible map panel fed by map
   data.
7. System docs: `world-engine.md`, `content-pipeline.md`, `map.md`.

## Exit gate
- [ ] A logged-in session can walk the entire authored region by buttons and by
      typed commands; descriptions change with time and weather.
- [ ] Fog-of-war persists across reconnects; undiscovered rooms never leak to the
      client (verified by protocol tests).
- [ ] Content validator catches every seeded defect in a test fixture set.
- [ ] All prior gates green; doc-sync green; Docs Consulted updated.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
