# Phase 9 — Hardening & Launch

## Goal
Make the game safe to operate in public: load and soak testing, anti-exploit and
anti-bot monitoring, account security, backups and recovery, admin/live-ops
tooling, closed beta, and the public launch of the Recommended Launch Scope.

## Non-goals
No new features. Only fixes, hardening, tooling, and content corrections found
in beta.

## Required Reading
Rules docs; Phase 8 exit gate; design document (`docs/DESIGN.md`) §Additional Features (admin
controls, anti-botting, account security), §Recommended Launch Scope.

## Entry gate
Phase 8 exit gate fully green.

## Deliverables
1. Load/soak testing: scripted bot population exercising movement, combat, chat,
   trading; connection targets set by owner and recorded; soak run of 72+ hours
   with zero leaks/crashes; performance budgets documented.
2. Security hardening: dependency audit, rate limits reviewed on every endpoint
   and message type, session fixation/replay tests, account recovery flow
   completed (from Phase 1 decision), optional TOTP 2FA.
3. Anti-exploit/anti-bot: server-side sanity monitors (impossible action rates,
   currency anomalies, teleport detection), automated flagging into moderation
   queue, economy anomaly reports from audit logs.
4. Operations: automated backups with tested restore, migration rollback drill,
   structured metrics + alerting, deployment runbook `docs/systems/operations.md`,
   admin panel (player lookup, item/currency adjustments with audit trail, event
   controls, server announcements, feedback/bug-report intake).
5. Closed beta: invite flow, feedback and bug-report tools in client, triage
   process; all critical/major findings fixed under the standard gates.
6. Launch checklist executed: content freeze, final full verify, tagged release,
   monitoring watch, rollback plan rehearsed.

## Exit gate
- [ ] Soak and load targets met with evidence attached to this document.
- [ ] Restore-from-backup drill and migration rollback drill both succeeded.
- [ ] Beta exit criteria met: zero known critical defects, owner sign-off.
- [ ] All gates green on the release tag; doc-sync green; API reference builds.
- [ ] Public launch completed; first-week operations review written up here.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
