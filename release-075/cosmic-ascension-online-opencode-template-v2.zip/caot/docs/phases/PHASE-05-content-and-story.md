# Phase 5 — Content & Story Systems

## Goal
The narrative game: NPCs with dialogue, quests and the journal, dynamic regional
events, three dungeons with bosses, main story chapter one, the introductory
Axiom Shard storyline, and the first Ascendant Form for applicable races.

## Non-goals
No economy systems (Phase 6) beyond quest item rewards. No additional planets.
World Decree wishes remain post-launch; only the introductory Shard arc ships.

## Required Reading
Rules docs; Phase 4 exit gate; design document (`docs/DESIGN.md`) §Story and World Events, §Key
Story Characters, §Dungeons, §The Axiom Shards, §Transformations.

## Entry gate
Phase 4 exit gate fully green.

## Deliverables
1. NPC system: named characters with schedules, dispositions, and reactive
   dialogue trees (content-driven); recurring key characters (mentor, rival,
   faction leader, antagonist) authored with original identities.
2. Quest engine: objectives (fight, talk, explore, collect, escort, choose),
   branches, consequences, journal with dialogue history and choice records.
3. Dynamic events: data-driven regional events (creature migration, bandit
   attack, distress signal, merchant arrival) with success/failure world
   consequences (prices, NPC displacement, closed shops).
4. Dungeon framework + three authored dungeons: branching routes, hazards, a
   puzzle each, patrols, hidden rooms, mini-boss, final boss with phases and
   learnable patterns; solo and party difficulty; dungeon map with explored
   rooms/party positions.
5. Main story chapter one and the introductory Axiom Shard arc (rumor →
   investigation → contested recovery), establishing the First Fracture mystery.
6. Ascendant Form v1: unlock trial per applicable race, transformation state in
   combat with real tradeoffs (drain, strain/Fracture risk), NPC reaction hooks.
7. Remaining launch content to target: fifth/sixth race and Discipline if
   Phase 3 shipped four (owner decision recorded).
8. System docs: `npcs.md`, `quests.md`, `events.md`, `dungeons.md`, `story.md`,
   `ascendant-forms.md`. Create `docs/BACKLOG.md` for post-launch ideas.

## Exit gate
- [ ] Chapter one playable start to finish including one dungeon and the Shard
      arc; choices produce different recorded outcomes (tested branches).
- [ ] Each boss defeated by pattern play, not stat excess: scripted harness
      proves an at-level tactical bot wins and a naive bot loses.
- [ ] Ascendant Form unlock trial completable; transformed combat tradeoffs
      verified by tests; staying transformed permanently is demonstrably bad.
- [ ] Dynamic events fire, succeed, fail, and visibly change the region.
- [ ] All prior gates green; doc-sync green; Docs Consulted updated.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
