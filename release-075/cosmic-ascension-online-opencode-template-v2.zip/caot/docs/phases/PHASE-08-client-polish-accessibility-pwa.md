# Phase 8 — Client Polish, Accessibility & PWA

## Goal
Turn the functional client into the launch interface: responsive layout across
desktop/tablet/phone, quick slots and touch controls, portraits and location
artwork slots, accessibility modes, the installable PWA shell, the guided
tutorial, and the searchable help system and lore codex.

## Non-goals
No new gameplay systems. Content additions limited to tutorial, help text, and
codex entries.

## Required Reading
Rules docs; Phase 7 exit gate; design document (`docs/DESIGN.md`) §Platform and Interface,
§Additional Features (tutorial, help, codex, accessibility).

## Entry gate
Phase 7 exit gate fully green.

## Deliverables
1. Responsive layout system: central narrative/combat panel, collapsible map,
   status panels, chat tabs, quest tracker — usable at phone, tablet, desktop
   widths; mobile touch controls and the combat command queue polished.
2. Visual identity: NPC portrait slots, location artwork slots, ability icons,
   status effect indicators, technique effect text animation (reduced-motion
   aware). Asset pipeline documented; commissioned/generated art tracked in
   content files.
3. Accessibility: customizable font size, high-contrast mode, reduced-motion
   mode, screen-reader-friendly semantics (live regions for narrative/combat
   log), full keyboard navigation. Audit against current WCAG 2.2 AA (fetch and
   record the quickref; run automated axe checks in E2E).
4. PWA: web app manifest, service worker for shell caching and safe update flow
   (never stale game data), install prompts on supported platforms.
5. Guided interactive tutorial covering movement, training, combat, loadouts,
   equipment, and party basics; skippable and re-entrant.
6. Searchable help + command reference generated from the actual command
   registry (never hand-duplicated); lore codex fed by discovered content.
7. Playwright E2E suite: the §2 smoke flows on desktop and mobile viewports,
   including axe accessibility assertions, wired into CI.
8. System docs: `client-architecture.md`, `accessibility.md`, `pwa.md`.

## Exit gate
- [ ] Full core loop (create → explore → quest → fight → equip → party) completed
      on a real phone browser and desktop, by touch and by keyboard alone.
- [ ] Automated axe checks pass; manual screen-reader pass recorded in Decisions.
- [ ] App installs as a PWA and relaunches into a valid session flow.
- [ ] Tutorial completion rate instrumented; help search returns every command.
- [ ] All prior gates green; doc-sync green; Docs Consulted updated.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
