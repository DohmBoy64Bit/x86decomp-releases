# Phase 0 — Foundation & Enforcement

## Goal
Stand up the monorepo and make every quality gate real and failing-by-default
BEFORE any game code exists. Prove the entire pipeline with a walking skeleton:
a served page and a WebSocket echo that pass all gates at 100%.

## Non-goals
No game mechanics, no world content, no database schema beyond what the skeleton
needs. Resist all temptation to start "just a little" combat code.

## Required Reading (Phase Start Ritual step 5)
`AGENTS.md`; all four docs in `docs/rules/`; `docs/PROJECT_PLAN.md` §3, §6, §7.

## Entry gate
Template copied into a fresh git repository; project owner has approved
`docs/PROJECT_PLAN.md`.

## Deliverables
1. npm-workspaces monorepo: `server/`, `client/`, `shared/`, `content/`, `tools/`,
   root `package.json` with pinned versions chosen after consulting current docs
   (record in Docs Consulted). Decide DB layer (Drizzle vs Kysely) and client
   state library (Zustand vs Redux Toolkit); record both in Decisions.
2. TypeScript strict configs; ESLint flat config from
   `config-templates/eslint.config.mjs` with jsdoc/tsdoc rules active.
3. Vitest with 100/100/100/100 thresholds from `config-templates/vitest.config.ts`
   in every workspace.
4. `scripts/check-no-placeholders.mjs` and `scripts/check-doc-sync.mjs` wired into
   `npm run verify`; initial `docs/.doc-sync.json` mapping the skeleton sources to
   their first system docs in `docs/systems/`.
5. Husky pre-commit hook from `config-templates/.husky/pre-commit`; CI from
   `.github/workflows/ci.yml` green on the default branch.
6. Walking skeleton: Fastify serves the client shell; client opens a WebSocket;
   server echoes a zod-validated message; all of it fully tested and documented.
7. Local dev environment: docker compose for Postgres + Redis; `npm run dev`
   boots server + client with live reload.
8. `docs/systems/` started with docs for the skeleton (server bootstrap, gateway
   echo, client shell, shared schemas).

## Exit gate (all must be checked with evidence linked)
- [ ] `npm run verify` passes on a clean clone with zero warnings.
- [ ] Deliberately breaking each gate (a TODO comment, an uncovered line, an
      undocumented export, a code edit without doc update) fails the pre-commit
      hook AND CI — one demonstration commit per gate, then reverted.
- [ ] Walking skeleton runs end to end via `npm run dev`.
- [ ] CI green on default branch; branch protection requires the verify job.
- [ ] Docs Consulted table filled for every pinned dependency.
- [ ] Charter Confirmation, Decisions, Open Questions sections maintained.

## Charter Confirmation
(Write the phase goals in your own words at phase start, per AGENTS.md ritual step 7.)

## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|

## Decisions
(Append: decision, rationale, alternatives rejected.)

## Open Questions
(Append blockers for the project owner. Empty means none.)
