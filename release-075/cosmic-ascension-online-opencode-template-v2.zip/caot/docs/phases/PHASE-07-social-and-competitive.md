# Phase 7 — Social & Competitive

## Goal
The multiplayer game: chat channels, friends/ignore, parties, guilds, mail
(messages), consensual PvP, one full tournament format with spectators, and the
moderation/reporting backbone.

## Non-goals
No raids, no guild halls, no seasonal championships, no open-world faction wars
(post-launch). Mail carries text only unless owner approves attachments.

## Required Reading
Rules docs; Phase 6 exit gate; design document (`docs/DESIGN.md`) §Tournaments and Competitive
Play, §Social Systems, §Additional Features (moderation items).

## Entry gate
Phase 6 exit gate fully green.

## Deliverables
1. Chat: global, local (room), party, private, guild, trade, help channels;
   custom filters; rate limits; profanity/abuse filter hooks.
2. Social graph: friends, ignore/block (block silences all channels and blocks
   trade/challenge), player profiles, looking-for-group listing.
3. Parties: invite/leave/kick, shared combat encounters, party frames in UI,
   party position on maps (world + dungeon).
4. Guilds: create/join/rank/leave, guild chat, shared storage with permission
   tiers and audit logging, no combat-power advantages per design.
5. PvP: consensual challenge flow, designated arena areas, full combat engine
   reuse; new players never attackable without opt-in (enforced + tested).
6. Tournament system (one format: 1v1 single elimination): creation by admins,
   registration, brackets, scheduling, spectator text stream, match history,
   rankings, prizes, anti-exploit rules (no outside healing, standardized
   consumables toggle).
7. Moderation: report player/content flow, moderation action log, mute/kick/ban
   tooling, trade confirmations already audited in Phase 6 surfaced to staff.
8. System docs: `chat.md`, `social.md`, `guilds.md`, `pvp.md`, `tournaments.md`,
   `moderation.md`.

## Exit gate
- [ ] Two real concurrent sessions: befriend, party, clear a dungeon together,
      duel, and complete a 4+ entrant tournament with a spectator watching.
- [ ] Block/ignore verified effective across every channel and interaction type.
- [ ] Abuse paths tested: chat flood, challenge spam, tournament no-shows,
      report spam — all rate-limited or handled without crashes.
- [ ] All prior gates green; doc-sync green; Docs Consulted updated.

## Charter Confirmation
## Docs Consulted
| Technology | Version | Official URL | Date | Notes |
|---|---|---|---|---|
## Decisions
## Open Questions
