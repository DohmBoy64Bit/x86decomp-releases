# Cosmic Ascension Online — Master Project Plan

Version 1.0 — 2026-07-10
Status: Approved for Phase 0

## 1. Vision

Cosmic Ascension Online is a browser-based, text-driven, open-world light MMORPG set
in an original science-fantasy universe: the Shattered Meridian. Players grow from
unknown fighters into universe-shaping warriors through training, tactical combat,
exploration, quests, tournaments, dungeons, and a persistent evolving story centered
on the nine Axiom Shards and Vaeloryn, the Eon Wyrm. The interface blends MUD-style
atmospheric text with a lightweight graphical UI (maps, portraits, quick slots) and
runs as a responsive, installable PWA on desktop and mobile. Full design reference:
the full design document stored at `docs/DESIGN.md`.

## 2. Target of this plan: the Recommended Launch Scope

The phases below build directly toward the design document's launch scope:
account registration and login; character creation; four to six playable races; four
to six Disciplines; one main planet with several settlements and biomes; a main story
chapter; regional and random events; tactical PvE combat; limited consensual PvP; one
tournament format; three or four dungeons; NPCs, shops, items, armor, weapons;
inventory and equipment; direct player trading; basic crafting and fishing; parties,
guilds, chat, friends, blocking, reporting; detailed regional and dungeon maps; one
early Ascendant Form for applicable races; and an introductory Axiom Shard storyline.
Everything beyond that (additional planets, universal markets, raids, housing, World
Decrees) is post-launch and out of scope for these phases.

## 3. Architecture summary

- Monorepo (npm workspaces): `server/`, `client/`, `shared/`, `content/`, `tools/`.
- Server: Node.js LTS + TypeScript, Fastify for HTTP, native WebSocket gateway
  (`ws`) for real-time play. The server is authoritative over all game state.
- Persistence: PostgreSQL (accounts, characters, inventory, economy, world state)
  via a typed query layer; Redis for sessions, presence, pub/sub, and rate limiting.
- Client: React + TypeScript + Vite, responsive, PWA-installable, WCAG-conscious.
- Shared: zod schemas defining every client-server message; both sides validate.
- Content: game data (races, techniques, items, rooms, quests, NPCs) as versioned,
  schema-validated JSON/YAML — no game data hardcoded in engine code.
- Exact versions are pinned in Phase 0 after consulting current official docs, per
  `docs/rules/TECH-STACK.md`.

## 4. Development method

Work proceeds in strictly gated phases. Each phase has a document in `docs/phases/`
with goals, deliverables, entry gate, exit gate, and a checklist. A phase may not
begin until the previous phase's exit gate is fully green, and every phase begins
with the Phase Start Ritual in `AGENTS.md` (rules refresh + latest-docs fetch).
Every commit on every phase passes the same hard gates: build, lint, typecheck,
100% test coverage, 100% docstring coverage, placeholder scan, and doc-hash sync.
Each phase ends in a vertically playable state: the game runs end to end with
whatever features exist so far.

## 5. Phase overview

| Phase | Name | Delivers | Playable result |
|-------|------|----------|-----------------|
| 0 | Foundation & Enforcement | Monorepo, CI, all quality gates live, walking skeleton | "Hello Meridian" page served, echo over WebSocket, all gates green |
| 1 | Core Server Platform | Accounts, auth, sessions, persistence, realtime gateway, message protocol | Register, log in, stay connected, reconnect safely |
| 2 | World & Movement | Room graph, one starting region, movement, descriptions, look/map data, time & weather | Walk around a described world with a live map panel |
| 3 | Characters & Progression Base | Character creation, 4 races, 4 Disciplines, stats, Resonance, Ascension Index, breakthroughs | Create an original alien warrior and train stats |
| 4 | Tactical Combat | Vitality/Resonance/Guard, techniques, statuses, turn engine, PvE encounters, combat log | Fight wandering creatures with real tactics |
| 5 | Content & Story Systems | NPCs, dialogue, quests, journal, dynamic events, 3 dungeons + bosses, story chapter 1, Axiom Shard intro, first Ascendant Form | Play the opening story arc and clear dungeons |
| 6 | Items & Economy | Inventory, equipment, armor/weapons, shops, currency, direct trading, crafting, fishing | Gear up, trade, craft, fish |
| 7 | Social & Competitive | Chat systems, friends/ignore, parties, guilds, mail, consensual PvP, one tournament format, moderation & reporting | Group up, duel, run a bracket tournament |
| 8 | Client Polish, Accessibility & PWA | Full responsive UI pass, quick slots, portraits, accessibility modes, offline-shell PWA, tutorial, help/codex | The launch-quality interface on phone and desktop |
| 9 | Hardening & Launch | Load/soak testing, anti-exploit and anti-bot monitoring, economy audit logs, backups, admin tools, closed beta, launch | Public launch of the Recommended Launch Scope |

Estimated durations are deliberately omitted: phases end when their exit gates pass,
not when a date arrives.

## 6. Cross-phase quality gates (identical for every phase)

1. `npm run build` — all workspaces compile with zero TypeScript errors (strict mode).
2. `npm run lint` — ESLint with jsdoc/tsdoc rules, zero warnings tolerated.
3. `npm run test` — Vitest, all tests pass, coverage thresholds 100/100/100/100.
4. `node scripts/check-no-placeholders.mjs` — zero TODO/FIXME/placeholder/stub markers.
5. `node scripts/check-doc-sync.mjs` — every source directory's documentation hash
   is current, and no source file is unmapped.
6. `npx typedoc --validation` (from Phase 1 on) — API reference builds with zero
   undocumented-symbol warnings.
Aggregated as `npm run verify`, run in pre-commit hooks and CI.

## 7. Documentation system

Living docs are written per system under `docs/systems/` (created in Phase 1 as code
appears). `docs/.doc-sync.json` maps each source directory to its system doc and
records content hashes of both sides. The checker fails CI when code drifts ahead of
its documentation. Additionally, every phase document accumulates a "Docs Consulted"
table (external docs, versions, dates) and a "Decisions" log, so the reasoning trail
never has to be reconstructed from memory.

## 8. Risks and mitigations

- Scope creep from the full vision: mitigated by the launch-scope boundary in §2 and
  per-phase non-goals sections; anything else goes to `docs/BACKLOG.md`, not code.
- Realtime scale: mitigated by soak tests in Phase 9 and stateless-where-possible
  gateway design in Phase 1.
- Content bottleneck: mitigated by schema-driven content files (Phase 2 onward) so
  writing rooms/quests/NPCs never requires engine changes.
- AI-generated regressions or fabrications: mitigated by the hard gates in §6 and
  the guardrails in `docs/rules/AI-GUARDRAILS.md`.
- IP contamination from inspirational sources: mitigated by the Original IP rule in
  `AGENTS.md`; all names come from the project's own glossary.

## 9. Post-launch backlog (explicitly out of scope now)

Additional planets and biomes; advanced Ascendant Forms; universal marketplace;
large-scale faction wars; raids; player housing; World Decree wish events; seasonal
championships; guild social spaces; combat replays; political systems. Tracked in
`docs/BACKLOG.md` once created in Phase 5.
