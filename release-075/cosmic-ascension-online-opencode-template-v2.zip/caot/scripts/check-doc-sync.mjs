#!/usr/bin/env node
/**
 * Documentation-sync gate for Cosmic Ascension Online.
 *
 * Reads `docs/.doc-sync.json`, which maps each documentation file to the source
 * globs it documents and records SHA-256 hashes of both sides taken the last
 * time the documentation was updated. The check fails when either side has
 * drifted from its recorded hash, when a mapped doc is missing or empty, or
 * when any source file matched by `requireMapping` is not covered by at least
 * one mapping (100% documentation coverage).
 *
 * Usage:
 *   node scripts/check-doc-sync.mjs            verify (exit 1 on any drift)
 *   node scripts/check-doc-sync.mjs --update   re-record hashes after genuinely
 *                                              updating the documentation
 *
 * Zero dependencies; runs on Node 18+.
 */
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, existsSync, statSync, readdirSync } from "node:fs";
import { join, relative, sep } from "node:path";
import process from "node:process";

const ROOT = process.cwd();
const MANIFEST_PATH = join(ROOT, "docs", ".doc-sync.json");
const UPDATE = process.argv.includes("--update");

/**
 * Converts a glob pattern into an anchored regular expression. Supports `**`
 * (any depth including none), `*` (any characters within one path segment),
 * and `?` (one character within a segment). All other characters are literal.
 * @param {string} glob - The glob pattern, using `/` as the separator.
 * @returns {RegExp} Anchored regex matching relative POSIX-style paths.
 */
function globToRegex(glob) {
  let re = "";
  let i = 0;
  while (i < glob.length) {
    const c = glob[i];
    if (c === "*") {
      if (glob[i + 1] === "*") {
        // `**/` or trailing `**` — match any depth, including none.
        if (glob[i + 2] === "/") { re += "(?:[^/]+/)*"; i += 3; }
        else { re += ".*"; i += 2; }
      } else { re += "[^/]*"; i += 1; }
    } else if (c === "?") { re += "[^/]"; i += 1; }
    else { re += c.replace(/[.+^${}()|[\]\\]/g, "\\$&"); i += 1; }
  }
  return new RegExp(`^${re}$`);
}

/**
 * Recursively lists every file under the repository root, returning paths
 * relative to the root with `/` separators. Skips directories that never
 * contain hash-relevant sources.
 * @returns {string[]} Sorted relative file paths.
 */
function listAllFiles() {
  const skip = new Set([".git", "node_modules", "dist", "build", "coverage", ".husky"]);
  const out = [];
  /** @param {string} dir - Absolute directory to walk. */
  function walk(dir) {
    for (const entry of readdirSync(dir)) {
      const abs = join(dir, entry);
      const st = statSync(abs);
      if (st.isDirectory()) {
        if (!skip.has(entry)) walk(abs);
      } else {
        out.push(relative(ROOT, abs).split(sep).join("/"));
      }
    }
  }
  walk(ROOT);
  return out.sort();
}

/**
 * Computes a stable SHA-256 hash over a set of files: each file contributes
 * its relative path and its content, so renames and edits both change the hash.
 * @param {string[]} files - Sorted relative file paths.
 * @returns {string} Hex digest, or the literal string "empty" when no files match.
 */
function hashFiles(files) {
  if (files.length === 0) return "empty";
  const h = createHash("sha256");
  for (const f of files) {
    h.update(f);
    h.update("\0");
    h.update(readFileSync(join(ROOT, f)));
  }
  return h.digest("hex");
}

if (!existsSync(MANIFEST_PATH)) {
  console.error(`doc-sync: manifest not found at ${relative(ROOT, MANIFEST_PATH)}`);
  process.exit(1);
}

/** @type {{requireMapping: string[], exclude: string[], mappings: {doc: string, sources: string[], sourcesHash?: string, docHash?: string}[]}} */
const manifest = JSON.parse(readFileSync(MANIFEST_PATH, "utf8"));
const allFiles = listAllFiles();
const errors = [];

// 1. Per-mapping drift checks.
for (const m of manifest.mappings) {
  const docAbs = join(ROOT, m.doc);
  if (!existsSync(docAbs)) { errors.push(`Missing doc file: ${m.doc}`); continue; }
  const docContent = readFileSync(docAbs, "utf8");
  if (docContent.trim().length < 200) {
    errors.push(`Doc too short to be meaningful (<200 chars): ${m.doc}`);
    continue;
  }
  const regs = m.sources.map(globToRegex);
  const srcFiles = allFiles.filter((f) => regs.some((r) => r.test(f)));
  const srcHash = hashFiles(srcFiles);
  const docHash = createHash("sha256").update(docContent).digest("hex");

  if (UPDATE) {
    m.sourcesHash = srcHash;
    m.docHash = docHash;
    continue;
  }
  if (m.sourcesHash !== srcHash) {
    errors.push(
      `STALE DOCS: sources for "${m.doc}" changed but hashes were not re-recorded.\n` +
      `  -> Update ${m.doc} to reflect the code change, then run: node scripts/check-doc-sync.mjs --update`
    );
  } else if (m.docHash !== docHash) {
    errors.push(
      `UNRECORDED DOC EDIT: "${m.doc}" changed without re-recording.\n` +
      `  -> Run: node scripts/check-doc-sync.mjs --update`
    );
  }
}

// 2. 100% documentation coverage: every required source file must be mapped.
const requireRegs = (manifest.requireMapping ?? []).map(globToRegex);
const excludeRegs = (manifest.exclude ?? []).map(globToRegex);
const mappedRegs = manifest.mappings.flatMap((m) => m.sources.map(globToRegex));
for (const f of allFiles) {
  if (!requireRegs.some((r) => r.test(f))) continue;
  if (excludeRegs.some((r) => r.test(f))) continue;
  if (!mappedRegs.some((r) => r.test(f))) {
    errors.push(`UNDOCUMENTED SOURCE: ${f} matches requireMapping but no doc mapping covers it.`);
  }
}

if (UPDATE) {
  writeFileSync(MANIFEST_PATH, JSON.stringify(manifest, null, 2) + "\n");
  console.log(`doc-sync: hashes re-recorded for ${manifest.mappings.length} mapping(s).`);
  if (errors.length) { console.error(errors.join("\n")); process.exit(1); }
  process.exit(0);
}

if (errors.length) {
  console.error("doc-sync: FAILED\n" + errors.join("\n"));
  process.exit(1);
}
console.log(`doc-sync: OK (${manifest.mappings.length} mapping(s) verified, coverage complete).`);
