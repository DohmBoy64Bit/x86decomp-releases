#!/usr/bin/env node
/**
 * Placeholder gate for Cosmic Ascension Online (guardrail G2).
 *
 * Scans tracked source and documentation files for forbidden markers: TODO,
 * FIXME, XXX, HACK, WIP, TBD, placeholder text, "not implemented" stubs,
 * lorem ipsum, and empty or trivially short docstrings. Exits 1 with a file:line
 * report when anything is found.
 *
 * Usage: node scripts/check-no-placeholders.mjs
 * Zero dependencies; runs on Node 18+.
 */
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative, sep, extname } from "node:path";
import process from "node:process";

const ROOT = process.cwd();
const SCAN_EXTENSIONS = new Set([".ts", ".tsx", ".mts", ".cts", ".mjs", ".cjs", ".js", ".jsx", ".md", ".json", ".yml", ".yaml", ".sql", ".html", ".css"]);
const SKIP_DIRS = new Set([".git", "node_modules", "dist", "build", "coverage", ".husky"]);
// Governance documents legitimately NAME the forbidden markers while defining
// the policy; they are exempt. Code, content, and system docs are never exempt.
const ALLOWLIST = new Set([
  "scripts/check-no-placeholders.mjs",
  "AGENTS.md",
  "README.md",
  "docs/PROJECT_PLAN.md",
  ".github/workflows/ci.yml",
]);
const ALLOWLIST_PREFIXES = ["docs/rules/", "docs/phases/", "config-templates/"];

/** Marker patterns and human-readable reasons. */
const PATTERNS = [
  { re: /\b(TODO|FIXME|XXX|HACK)\b/, reason: "forbidden task marker" },
  { re: /\b(WIP|TBD)\b/, reason: "work-in-progress marker" },
  { re: /\bplace\s?holder\b/i, reason: "placeholder text" },
  { re: /\bnot\s+implemented\b/i, reason: "unimplemented stub" },
  { re: /\bcoming\s+soon\b/i, reason: "deferred-content marker" },
  { re: /\blorem\s+ipsum\b/i, reason: "dummy filler text" },
  { re: /throw\s+new\s+Error\(\s*["'`]\s*(stub|unimplemented)/i, reason: "stub throw" },
  { re: /\/\*\*\s*\*\//, reason: "empty docstring" },
];

/**
 * Recursively collects scannable files relative to the repository root.
 * @returns {string[]} Relative POSIX-style paths of files to scan.
 */
function collect() {
  const out = [];
  /** @param {string} dir - Absolute directory to walk. */
  function walk(dir) {
    for (const entry of readdirSync(dir)) {
      const abs = join(dir, entry);
      const st = statSync(abs);
      if (st.isDirectory()) { if (!SKIP_DIRS.has(entry)) walk(abs); continue; }
      const rel = relative(ROOT, abs).split(sep).join("/");
      const exempt = ALLOWLIST.has(rel) || ALLOWLIST_PREFIXES.some((p) => rel.startsWith(p));
      if (SCAN_EXTENSIONS.has(extname(entry)) && !exempt) out.push(rel);
    }
  }
  walk(ROOT);
  return out.sort();
}

/**
 * Detects docstrings whose visible text is too short to be meaningful
 * (guardrail G2.4). A block comment starting with slash-star-star whose
 * stripped text is under 20 characters is treated as a placeholder docstring.
 * @param {string} content - Full file content.
 * @returns {number[]} 1-based line numbers of offending docstrings.
 */
function shortDocstrings(content) {
  const hits = [];
  const re = /(?:^|\n)[ \t]*\/\*\*([\s\S]*?)\*\//g;
  let m;
  while ((m = re.exec(content)) !== null) {
    const text = m[1].replace(/^\s*\*?/gm, "").replace(/@\w+/g, "").replace(/\s+/g, " ").trim();
    if (text.length > 0 && text.length < 20) {
      hits.push(content.slice(0, m.index).split("\n").length);
    }
  }
  return hits;
}

const findings = [];
for (const rel of collect()) {
  const content = readFileSync(join(ROOT, rel), "utf8");
  const lines = content.split("\n");
  lines.forEach((line, idx) => {
    for (const { re, reason } of PATTERNS) {
      if (re.test(line)) findings.push(`${rel}:${idx + 1}  ${reason}  | ${line.trim().slice(0, 100)}`);
    }
  });
  if ([".ts", ".tsx", ".mts", ".mjs", ".js", ".jsx"].includes(extname(rel))) {
    for (const ln of shortDocstrings(content)) {
      findings.push(`${rel}:${ln}  docstring under 20 chars (guardrail G2.4)`);
    }
  }
}

if (findings.length) {
  console.error(`placeholder-check: FAILED (${findings.length} finding(s))\n` + findings.join("\n"));
  process.exit(1);
}
console.log("placeholder-check: OK (no TODOs, placeholders, stubs, or empty docstrings).");
