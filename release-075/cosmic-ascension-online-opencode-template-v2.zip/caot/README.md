# Cosmic Ascension Online — OpenCode Project Template

A text-based open-world light MMORPG. This repository template contains the complete
development plan, OpenCode instructions, phase gates, and enforcement tooling for
building the game.

## What is in this template

| Path | Purpose |
|------|---------|
| `AGENTS.md` | OpenCode's project instruction entry point, loaded automatically from the repository root. |
| `opencode.json` | Provider-neutral project config that loads the binding rule files, disables sharing, restricts destructive shell actions, and ignores generated directories. |
| `.opencode/commands/` | Project commands for `/phase-start`, `/session-start`, and `/verify`. |
| `docs/PROJECT_PLAN.md` | Master plan: vision, architecture, all phases, and milestones. |
| `docs/phases/` | One document per phase with goals, deliverables, entry gates, exit gates, and evidence sections. |
| `docs/rules/AI-GUARDRAILS.md` | Binding rules for all AI-assisted work. |
| `docs/rules/TESTING-STANDARDS.md` | 100% test coverage policy and configuration. |
| `docs/rules/DOCUMENTATION-STANDARDS.md` | 100% documentation and docstring coverage policy. |
| `docs/rules/TECH-STACK.md` | Stack policy and official documentation URLs that must be re-read each phase. |
| `docs/.doc-sync.json` | Hash manifest binding source directories to their documentation files. |
| `scripts/check-doc-sync.mjs` | Fails when code changed but its mapped documentation did not. |
| `scripts/check-no-placeholders.mjs` | Fails on deferred markers, filler text, stubbed code, or empty docstrings. |
| `config-templates/` | Ready-to-copy Vitest, ESLint, TypeDoc, and Husky configurations with all gates enabled. |
| `.github/workflows/ci.yml` | CI pipeline enforcing every gate on every push and pull request. |

## Start with OpenCode

1. Install and configure OpenCode using the current official documentation at
   <https://opencode.ai/docs>. Provider credentials and model preferences belong in
   the developer's global OpenCode configuration, not this repository.
2. Copy the template into a new Git repository and open a terminal at its root.
3. Run `opencode`. OpenCode automatically loads `AGENTS.md`, merges `opencode.json`
   with the developer's global config, and discovers the commands in
   `.opencode/commands/`.
4. Run `/phase-start 0` to begin `docs/phases/PHASE-00-foundation.md` through the
   mandatory gated workflow. In later sessions, run `/session-start` before new
   implementation work.
5. Use OpenCode's Plan agent for investigation and planning, then switch to Build
   after the plan and entry gates are verified.

The template already contains a curated `AGENTS.md`, so `/init` is not required.
OpenCode can update an existing `AGENTS.md`, but review that diff carefully before
keeping it so the binding rituals and guardrails are not weakened.

## OpenCode safety defaults

The checked-in config is intentionally provider-neutral. It disables conversation
sharing, denies access outside the repository, protects environment files, asks
before unlisted shell commands, allows common read-only Git and verification
commands, and explicitly denies destructive cleanup and force-push commands.
OpenCode's `--auto` mode should not be used unless the project owner explicitly
approves it for that session.

## Non-negotiable principles

The full ruleset lives in `docs/rules/AI-GUARDRAILS.md`. Nothing is asserted without
a verified source, nothing is committed with deferred markers or incomplete stubs,
every line of code is tested, every module is documented, and documentation
freshness is verified by hash rather than trust.
