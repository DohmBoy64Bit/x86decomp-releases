---
description: Run and diagnose the complete project verification suite
agent: build
---

Run `npm run verify` and report the result of every configured gate. When a gate
fails, show the earliest actionable failure and trace it to the relevant project
rule or phase requirement. Make only complete, tested, documented fixes; then rerun
the full suite and report the final evidence.
