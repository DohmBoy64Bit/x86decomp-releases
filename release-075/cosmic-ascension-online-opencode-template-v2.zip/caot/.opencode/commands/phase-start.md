---
description: Run the mandatory start ritual for a project phase
agent: build
---

Begin phase $ARGUMENTS by following the Phase Start Ritual in `AGENTS.md` in its
exact order. Read every required project document, confirm the previous phase exit
gate, consult the current official technology documentation, record the Docs
Consulted evidence, run `npm run verify`, and update the Phase Charter Confirmation.

Do not implement phase deliverables until every entry condition and ritual step has
passed. When a gate fails or a fact cannot be verified, record the blocker in the
phase document and report it instead of guessing or bypassing the gate.
