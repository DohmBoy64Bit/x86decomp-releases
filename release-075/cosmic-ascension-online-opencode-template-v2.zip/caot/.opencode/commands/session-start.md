---
description: Run the mandatory start ritual for the current session
agent: build
---

Follow the Session Start Ritual in `AGENTS.md`. Identify the current phase from the
phase documents and checklist state, re-read the binding guardrails, and run
`npm run verify` before beginning new work.

Report any pre-existing failure with its evidence first. Fix it before unrelated
implementation work, and do not claim the session is ready while a gate is red.
