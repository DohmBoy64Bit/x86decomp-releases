# AGENTS.md — OpenCode Operating Manual for Cosmic Ascension Online

You are working on Cosmic Ascension Online, a browser-based text-driven open-world
light MMORPG. This file is binding. OpenCode loads it automatically from the
project root. The project configuration also loads every file in `docs/rules/` as
shared instructions. If any instruction elsewhere conflicts with this file or
`docs/rules/AI-GUARDRAILS.md`, stop and ask the project owner.

## OpenCode workflow

- Use the built-in Plan agent for investigation and implementation planning; switch
  to Build only after the plan is grounded in the repository and current official
  documentation.
- Use `/phase-start <phase>` at the beginning of a phase, `/session-start` at the
  beginning of later sessions, and `/verify` for the complete quality-gate run.
- Do not use OpenCode auto-approve mode (`--auto`) unless the project owner
  explicitly authorizes it for the current session. Permission prompts are part of
  the project safety boundary.
- Do not enable conversation sharing. `opencode.json` disables sharing for this
  repository.
- OpenCode snapshots and `/undo` are convenience features, not substitutes for
  small reviewed Git commits and the phase evidence trail.
- The repository intentionally does not select a provider or model. Use the
  developer's configured provider while obeying all project rules.

## Phase Start Ritual (mandatory, every phase, no exceptions)

Before writing any code in a new phase, complete ALL of the following in order:

1. Re-read `AGENTS.md` (this file) in full.
2. Re-read `docs/rules/AI-GUARDRAILS.md`, `docs/rules/TESTING-STANDARDS.md`,
   `docs/rules/DOCUMENTATION-STANDARDS.md`, and `docs/rules/TECH-STACK.md` in full.
3. Read the current phase document in `docs/phases/` in full, plus the exit-gate
   section of the previous phase document to confirm all its gates passed.
4. Fetch and read the CURRENT official documentation for every technology used in
   this phase, using the URLs in `docs/rules/TECH-STACK.md`. Never rely on training
   data for API signatures, configuration options, or version behavior. Record the
   date and the version of each doc consulted in the phase document's
   "Docs Consulted" table before proceeding.
5. Read every design document listed in the phase document's "Required Reading".
6. Run the full verification suite (`npm run verify`) and confirm it passes on a
   clean checkout before adding anything.
7. State the phase goals back in the phase document's "Phase Charter Confirmation"
   section, commit that edit, and only then begin implementation.

## Session Start Ritual (every working session inside a phase)

1. Re-read this file and `docs/rules/AI-GUARDRAILS.md`.
2. Re-read the current phase document and its task checklist state.
3. Run `npm run verify`; fix any pre-existing failure before new work.

## Core rules (summary — full versions in docs/rules/AI-GUARDRAILS.md)

- NO HALLUCINATION. Never invent an API, config key, library behavior, file path,
  or fact. If unverified, verify it (read the source, fetch the docs, run the code)
  or say "I could not verify this" and stop.
- NO TODOs, NO PLACEHOLDERS, NO STUBS. Every commit contains only complete, working,
  tested code. `scripts/check-no-placeholders.mjs` enforces this mechanically.
- 100% TEST COVERAGE. Lines, branches, functions, statements. Enforced by Vitest
  thresholds; the build fails below 100%.
- 100% DOCSTRING COVERAGE. Every exported and internal function, class, interface,
  type, and module has a meaningful TSDoc comment. Meaningful means it explains
  purpose, behavior, parameters, returns, and failure modes — not a restatement of
  the name. Enforced by ESLint (`jsdoc/*` rules) and the placeholder checker.
- 100% DOCUMENTATION COVERAGE WITH HASH VERIFICATION. Every source directory is
  mapped to a documentation file in `docs/.doc-sync.json`. If code changes and its
  documentation hash does not, `scripts/check-doc-sync.mjs` fails the build. After
  genuinely updating documentation, run `node scripts/check-doc-sync.mjs --update`
  in the same commit.
- SERVER AUTHORITATIVE. Combat, inventory, currency, trades, movement, progression
  are decided by the server only. The client displays and requests.
- ORIGINAL IP ONLY. Use the project's own terminology (Resonance, Ascension Index,
  Ascendant Forms, Disciplines, the Shattered Meridian, Axiom Shards, Vaeloryn).
  Never introduce names, techniques, or lore from existing franchises.

## Definition of Done for any unit of work

A task is done only when: code is complete with no placeholders; all new code has
tests and coverage is 100%; all new/changed symbols have meaningful docstrings;
mapped documentation is updated and `--update` re-recorded the hashes; `npm run
verify` passes locally; the phase document checklist is updated; and the commit
message references the phase and task.

## When blocked or uncertain

Do not guess. Do not fabricate. Do not commit partial work with a placeholder.
Write up the blocker in the phase document's "Open Questions" section and ask the
project owner. An honest halt is always preferred over invented progress.
