/**
 * Vitest configuration template enforcing the project's 100% coverage policy
 * (docs/rules/TESTING-STANDARDS.md). Copy into each workspace during Phase 0
 * and adjust only the `include` globs; thresholds must never be lowered.
 */
import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["src/**/*.test.ts", "src/**/*.test.tsx"],
    coverage: {
      provider: "v8",
      all: true,
      include: ["src/**"],
      exclude: [
        "src/**/*.test.*",
        "src/**/*.d.ts",
        "src/main.ts"
      ],
      thresholds: {
        lines: 100,
        functions: 100,
        branches: 100,
        statements: 100
      },
      reporter: ["text", "html", "lcov"]
    }
  }
});
