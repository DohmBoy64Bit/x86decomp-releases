/**
 * ESLint flat-config template enforcing docstring coverage (guardrail G6.3)
 * and the no-placeholder policy (guardrail G2). Copy to the repository root in
 * Phase 0. Verify plugin option names against the current eslint-plugin-jsdoc
 * documentation (docs/rules/TECH-STACK.md) before first use.
 */
import jsdoc from "eslint-plugin-jsdoc";
import tsdoc from "eslint-plugin-tsdoc";
import tseslint from "typescript-eslint";

export default tseslint.config(
  ...tseslint.configs.strictTypeChecked,
  {
    files: ["**/src/**/*.{ts,tsx}"],
    plugins: { jsdoc, tsdoc },
    rules: {
      "tsdoc/syntax": "error",
      "jsdoc/require-jsdoc": ["error", {
        publicOnly: false,
        require: {
          ClassDeclaration: true,
          ClassExpression: true,
          FunctionDeclaration: true,
          FunctionExpression: true,
          MethodDefinition: true,
          ArrowFunctionExpression: true
        },
        contexts: [
          "TSInterfaceDeclaration",
          "TSTypeAliasDeclaration",
          "TSEnumDeclaration",
          "TSPropertySignature",
          "PropertyDefinition"
        ]
      }],
      "jsdoc/require-description": ["error", { descriptionStyle: "body" }],
      "jsdoc/require-param": "error",
      "jsdoc/require-param-description": "error",
      "jsdoc/require-returns": "error",
      "jsdoc/require-returns-description": "error",
      "jsdoc/require-throws": "error",
      "no-warning-comments": ["error", {
        terms: ["todo", "fixme", "xxx", "hack", "wip", "tbd"],
        location: "anywhere"
      }],
      "no-empty-function": "error"
    }
  }
);
