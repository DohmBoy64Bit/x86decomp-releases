---
name: x86decomp-evidence-engineer
description: Evidence-first operating skill for native Windows x86/x86-64 matching and functional decompilation using Ghidra, independent decoding, compiler experiments, PE-to-COFF comparison, bounded runtime/symbolic validation, and auditable project memory.
version: 2.0.0
license: Apache-2.0
compatibility: Python 3.11+, Ghidra 12.1 baseline, native PE32 i386 and PE32+ AMD64 targets
metadata:
  package: x86decomp-toolkit
  package_version: 0.2.0
  modes:
    - matching
    - functional
  default_policy: evidence-first
  mutation_policy: read-only-unless-approved
  target_execution_policy: isolated-only
  claim_gate: three-independent-source
  status: production-template
  architectures:
    - x86
    - x86_64
  formats:
    - PE32
    - PE32+
    - COFF-i386
    - COFF-AMD64
tags:
  - reverse-engineering
  - decompilation
  - x86
  - x86-64
  - pe32
  - pe32-plus
  - coff
  - ghidra
  - evidence
  - reproducibility
---

# x86decomp evidence engineer

## Mission

Operate `x86decomp-toolkit` as an evidence-governed decompilation system with two
independent per-function modes:

1. **Matching decompilation** attempts to reproduce the target instruction stream,
   modeled relocations, exact bytes, patched image, or complete relink.
2. **Functional decompilation** produces maintainable source and validates explicitly
   selected behavior through ABI checks, bounded concrete execution, bounded symbolic
   comparison, runtime coverage, and integration tests.

The mission is not to invent missing source history. The mission is to create a
reproducible project in which observations, inferences, candidates, and verified
properties are separated and every state transition has machine-readable evidence.

## Absolute truth boundary

Compilation can destroy or merge information. Never claim automatic recovery of:

- original comments;
- original local or private symbol names;
- original macros or formatting;
- exact source-file boundaries;
- original templates or inline organization;
- exact compiler flags without evidence;
- semantic equivalence for all inputs from finite testing;
- universal correctness from three-source review.

No tool, model, analyst, or validator may cross this boundary by wording. When a
property cannot be measured, report `unknown` and identify the smallest experiment
that could reduce the uncertainty.

## Supported baseline

The package implements bounded workflows for:

- native Windows PE32/i386;
- native Windows PE32+/AMD64;
- COFF i386 and AMD64 relocatable objects;
- unpacked user-mode code;
- one or more discontiguous function body ranges;
- C, C++, assembly, binary, object, and executable candidates;
- Ghidra static-analysis artifacts;
- Capstone independent instruction decoding;
- compiler and linker processes declared by explicit profiles/manifests;
- Unicorn bounded concrete execution;
- built-in Capstone/Z3 bounded symbolic comparison;
- optional angr bounded comparison;
- DynamoRIO drcov coverage collection;
- evidence-gated Ghidra MCP reads and approved mutations.

Packed, virtualized, encrypted, anti-analysis, managed CLR, kernel-mode, self-modifying,
or unknown-code host-execution cases are not treated as normal supported inputs. Keep
such inputs as evidence and mark the relevant operation `unsupported_scope`, `blocked`,
or `unknown`.

## Non-negotiable anti-hallucination rules

1. Never describe decompiler output as original source.
2. Never describe a plausible name as an original name.
3. Never promote a Ghidra type, signature, or class inference directly to fact.
4. Never use AI output as evidence for its own proposal.
5. Never treat absence of a static reference as proof that runtime access is impossible.
6. Never call raw byte similarity semantic equivalence.
7. Never call relocation-masked equality raw byte equality.
8. Never call finite differential tests universal proof.
9. Never call a bounded symbolic result universal proof.
10. Never say the three-source gate guarantees truth.
11. Never hide parser bounds errors, tool failures, unsupported instructions, solver
    timeouts, missing dependencies, contradictions, or incomplete observations.
12. Never fabricate a success-shaped response for an unsupported subsystem.
13. Never silently weaken a requested verification property.
14. Never execute an unknown target on the host.
15. Never redistribute proprietary compiler binaries.
16. Never accept an MCP mutation merely because the server returned success.
17. Never flatten a discontiguous function into one fabricated body interval.
18. Never compare a complete object file directly with function bytes and call it a
    function match.
19. Never infer a complete ABI from a single return instruction or call site.
20. Never promote a status unless its exact required report exists and passes.

## Required vocabulary

Use these words consistently:

- **Observed** — directly present in captured bytes, a sealed file, a tool result, or a
  runtime trace.
- **Derived** — deterministically calculated from observed inputs by a named algorithm.
- **Proposed** — a working interpretation or candidate awaiting independent checks.
- **Corroborated** — supported by multiple records but below the formal claim gate.
- **Verified** — passed the project verification gate for one precisely worded claim.
- **Rejected** — contradicted or falsified for the stated artifact and scope.
- **Unknown** — insufficient evidence or validator coverage.
- **Blocked** — cannot progress until a named prerequisite is satisfied.
- **Bounded** — valid only within explicitly declared inputs, paths, memory model,
  instruction subset, timeout, or environment.

Avoid “fully recovered,” “basically exact,” “probably original,” and “confirmed” unless
an exact verification property immediately follows.

## Separation of concerns

### Immutable evidence layer

Owns original binaries, function bytes, compiler outputs, PDBs, runtime traces,
external documents, hashes, and imported reports. Evidence is copied into project
storage, content-addressed, path-confined, and never edited in place.

### PE/COFF ingestion layer

Owns bounded parsing of image and object formats. It records what exists in the file;
it does not infer source intent.

### Static-analysis layer

Owns Ghidra functions, symbols, types, references, raw/high P-code, decompiler C, token
trees, instruction records, and analyst annotations. Static analysis is revisable.

### Independent-decoder layer

Owns Capstone decode, normalized operands, direct branch targets, CFG edges, and
cross-check reports. It does not own source types or equivalence claims.

### Analysis database

Owns cross-function entities, references, ABI observations, type constraints,
conflicts, accepted constraints, and provenance. No model or MCP server is canonical.

### Candidate-source layer

Owns staged C, C++, assembly, headers, compiler profiles, linker manifests, and hybrid
build trees. Candidate source is an implementation attempt, not historical evidence.

### Matching-verification layer

Owns compiler reports, COFF symbol extraction, PE-to-COFF comparison, normalized
instruction/CFG comparison, exact-byte checks, image patch reports, and relink reports.

### Functional-verification layer

Owns ABI reports, Unicorn differential reports, Z3/angr bounded reports, DynamoRIO
coverage, and integration-test reports.

### Governance layer

Owns evidence claims, contradiction records, MCP approvals, work-queue validators,
function state transitions, and append-only project memory.

### Agent layer

May propose names, types, C/C++ source, experiments, and tests. Agent output remains
`proposed` until an independent evidence or validator path accepts the exact property.

## Mandatory startup procedure

Before analysis or mutation:

1. Read `project.json`.
2. Run `x86decomp verify-project <project>`.
3. Run `x86decomp memory-verify <project>`.
4. Read `memory/PROJECT_MEMORY.md`.
5. Read the affected function's `workflow.json`.
6. Verify imported function artifacts with `x86decomp artifact-verify`.
7. Identify stable IDs and exact body ranges.
8. State the requested outcome as one measurable property.
9. Choose `matching`, `functional`, or both.
10. Select the smallest validator capable of measuring that property.

Do not mutate source, Ghidra, workflow state, or claims while integrity checks fail.

## Stable identity contract

- Function IDs: `pe-rva:XXXXXXXX`.
- Directory IDs: `pe-rva_XXXXXXXX`.
- RVAs are unsigned and image-relative.
- Address ranges are half-open: `[start, end)`.
- Function body ranges are sorted and non-overlapping.
- A body may have multiple discontiguous ranges.
- Ghidra virtual addresses are display/provenance data, not cross-build identity.
- File offsets are never substituted for RVAs without an explicit conversion record.
- x86-64 addresses must not be truncated to 32 bits.

## Independent two-mode workflow

Every function owns independent mode state. A function can pass one mode and remain
unknown in the other.

### Source stages

```text
original_bytes
  -> generated_assembly
  -> decompiler_candidate
  -> human_candidate
  -> accepted_source
```

A source-stage change does not automatically promote either mode.

### Matching states

```text
not_started
  -> decompiled
  -> compiles
  -> abi_compatible
  -> instruction_similar
  -> byte_matched
  -> image_integrated
  -> full_relink_validated
```

`blocked` is an explicit side state.

Definitions:

- `decompiled`: a candidate representation exists.
- `compiles`: a named compiler profile emitted the expected artifact and report.
- `abi_compatible`: the declared ABI checks passed for the scoped properties.
- `instruction_similar`: a versioned normalizer compared decoded instructions/CFG and
  met the recorded threshold or classification.
- `byte_matched`: all target bytes in scope are raw-byte equal. Do not use for a masked
  or normalized match.
- `image_integrated`: a hash-gated patch was written into a copy and the resulting PE
  passed integrity checks.
- `full_relink_validated`: the declared linker produced an image and its selected image
  acceptance checks passed.

### Functional states

```text
not_started
  -> decompiled
  -> compiles
  -> abi_compatible
  -> differentially_validated
  -> symbolically_bounded
  -> integration_validated
```

`blocked` is an explicit side state.

Definitions:

- `differentially_validated`: target and candidate produced equal declared observations
  for every concrete harness case in the report.
- `symbolically_bounded`: a declared symbolic model found no counterexample within its
  supported instruction subset and configured path/step/solver bounds.
- `integration_validated`: named application-level scenarios passed in the declared
  environment.

### State transition rules

- Transitions are monotonic by default.
- Regression requires `--allow-regression` and a memory event explaining why.
- Every promotion includes a report kind and report path.
- A report for one mode cannot automatically promote the other.
- `blocked` must include a concrete blocker.
- Reanalysis that invalidates a prerequisite requires downstream review or regression.

Commands:

```bash
x86decomp workflow-init PROJECT pe-rva:00012340 \
  --mode matching --mode functional

x86decomp workflow-show PROJECT pe-rva:00012340

x86decomp workflow-update PROJECT pe-rva:00012340 \
  --source-stage human_candidate \
  --matching-status compiles \
  --candidate src/staging/pe-rva_00012340.c \
  --compiler-profile msvc-x86-vc6 \
  --report-kind compile \
  --report-path reports/compile/pe-rva_00012340.json
```

## Triple fact-check claim protocol

A claim may become `verified` only if every check passes.

### Check A — count

At least three evidence records support the exact same narrowly worded claim.

### Check B — independence

At least three independent failure domains must be present. Different files or scripts
that consume one upstream analysis are not automatically independent.

Examples of potentially independent groups:

- raw binary/manual format decoding;
- Ghidra analysis;
- Capstone/Zydis independent decoding;
- compiler output;
- authenticated same-build PDB;
- isolated runtime trace;
- authoritative format or ABI documentation.

### Check C — diversity

At least two evidence kinds are required. Three static-analysis outputs alone are not
sufficient.

### Check D — integrity

Every file-backed evidence hash must still match.

### Check E — contradiction resolution

No unresolved contradiction may remain attached. More supporting records do not cancel
contradictory evidence.

### Check F — scope precision

Only verify the property actually measured.

Good:

- `pe-rva:00012340 performs callee stack cleanup of 8 bytes on observed returns`.
- `candidate section bytes equal target range 0 under compiler profile X`.

Bad:

- `the function is definitely original __stdcall source`.
- `the whole function is matched` when relocations or secondary ranges were excluded.

Commands:

```bash
x86decomp evidence-add PROJECT --kind binary --source target-range \
  --summary "Observed ret 8 at all decoded returns" --file range.bin
x86decomp claim-create PROJECT --statement "...narrow claim..."
x86decomp claim-attach PROJECT CLAIM_ID EVIDENCE_ID
x86decomp claim-contradict PROJECT CLAIM_ID EVIDENCE_ID
x86decomp claim-verify PROJECT CLAIM_ID
```

## PE ingestion workflow

1. Parse with `x86decomp inspect-pe`.
2. Confirm architecture and image kind.
3. Seal the binary during `x86decomp init`.
4. Inspect sections and executable permissions.
5. Record imports, delay imports, exports, resources, base relocations, debug/CodeView,
   TLS callbacks, load configuration, and x64 runtime functions where present.
6. Treat malformed/bounds-invalid data as parser failure, not absent metadata.
7. Never execute the image during ingestion.

```bash
x86decomp inspect-pe program.exe
x86decomp init program.exe projects/program
```

## Ghidra export workflow

Use Ghidra as the primary static analyzer but not as ground truth.

```bash
x86decomp ghidra-export \
  program.exe \
  projects/program/analysis/ghidra \
  program \
  projects/program/analysis/exports \
  --scripts-dir ghidra_scripts \
  --overwrite
```

Expected project exports:

```text
program.json
sections.json
functions.jsonl
symbols.jsonl
types.jsonl
metrics.json
```

Expected per-function exports:

```text
function.json
ranges/*.bin
instructions.jsonl
listing.asm
references.jsonl
decompiler.c
decompiler-tree.jsonl
high-pcode.jsonl
high-pcode.txt
raw-pcode.jsonl
context.h
```

Rules:

- `decompiler.c` is proposed source structure.
- `decompiler-tree.jsonl` preserves token/address structure but remains analysis output.
- raw P-code is instruction semantics from Ghidra's language model.
- high P-code is transformed decompiler IR and may change with analysis/types.
- exact range bytes remain the matching anchor.
- import artifacts before trusting them:

```bash
x86decomp artifact-import PROJECT FUNCTION_ARTIFACT_DIR
x86decomp artifact-verify PROJECT pe-rva:00012340
```

## Independent decoder and cross-check workflow

Use Capstone for independent instruction boundaries and normalized operands:

```bash
x86decomp disassemble function.bin --base 0x401000 --architecture x86
x86decomp crosscheck-ghidra instructions.jsonl function.bin \
  --base 0x401000 --architecture x86 \
  --report reports/crosscheck.json
```

If Ghidra and Capstone disagree:

1. stop promotion;
2. preserve both outputs;
3. inspect architecture/mode/base address;
4. inspect overlapping code/data or wrong function bounds;
5. resolve before trusting CFG or source generation.

## Analysis database and type constraints

Ingest structured artifacts into SQLite:

```bash
x86decomp db-ingest analysis.sqlite artifact-dir --image-base 0x400000
```

Query only parameterized SQL for untrusted values:

```bash
x86decomp db-query analysis.sqlite \
  'SELECT * FROM entities WHERE stable_id = ?' \
  --parameters-json '["pe-rva:00012340"]'
```

Add type/ABI constraints with provenance:

```bash
x86decomp db-constraint-add analysis.sqlite \
  pe-rva:00012340 calling_convention __stdcall ghidra-analysis \
  --evidence-id ev-123 --confidence 0.65

x86decomp db-constraint-conflicts analysis.sqlite \
  pe-rva:00012340 calling_convention

x86decomp db-constraint-accept analysis.sqlite CONSTRAINT_ID
```

Acceptance rules:

- width, signedness, pointer-ness, pointee type, constness, aggregate layout, field
  offsets, parameter storage, and return storage are separate properties;
- conflict checks precede acceptance;
- accepted means accepted by project policy, not historically original;
- AI confidence is a ranking signal, never probability of truth.

## Compiler laboratory

Compiler profiles must declare executable, arguments, output kind, environment, and
version metadata. The runner:

- avoids shell interpolation;
- hashes executable/source/output;
- removes stale output;
- uses isolated work directories;
- applies timeouts;
- records stdout/stderr;
- optionally caches results by full experiment identity.

```bash
x86decomp compile profile.json candidate.c candidate.obj \
  --cache build/cache \
  --report reports/compile.json
```

For bounded flag exploration:

```bash
x86decomp compiler-lab lab.json --report reports/compiler-lab.json
```

Experiment rules:

1. vary one causal dimension at a time when interpreting results;
2. retain failures when they constrain future work;
3. never infer the original compiler from one matching function alone;
4. do not redistribute proprietary historical compilers;
5. register user-owned toolchains by executable hashes:

```bash
x86decomp toolchain-register toolchains.json vc6 msvc 12.00 \
  --executable cl=/opt/vc6/bin/cl.exe \
  --executable link=/opt/vc6/bin/link.exe
x86decomp toolchain-verify toolchains.json vc6
```

## Executable-aware matching workflow

The central comparison is a linked PE range versus one COFF symbol, not full-file
bytes.

```bash
x86decomp diff-function \
  program.exe 0x12340 0x90 candidate.obj FunctionName \
  --report reports/matching/FunctionName.json
```

The engine:

1. maps RVA to PE bytes;
2. parses i386/AMD64 COFF;
3. resolves symbol extent;
4. extracts symbol bytes;
5. models candidate relocations;
6. compares raw bytes;
7. compares relocation-normalized bytes;
8. decodes normalized instructions;
9. compares CFG edges;
10. emits a scoped classification.

Never collapse these classifications:

- `byte_matched` — raw equality;
- `relocation_normalized_match` — equality after modeled address-dependent fields are
  excluded or normalized;
- `instruction_similar` — normalized instruction/CFG relationship only;
- `mismatch` — no stronger classification passed.

For synthetic objects where reconstructed relocations are supplied explicitly:

```bash
x86decomp coff-synthesize target.bin TargetFunction target.obj \
  --architecture x86 --relocations relocations.json
```

Synthetic COFF output does not prove recovered original object boundaries or link-time
metadata.

## ABI validation

```bash
x86decomp abi-check function.bin abi-contract.json \
  --base 0x401000 --report reports/abi.json
```

For x86 model explicitly:

- `__cdecl`;
- `__stdcall`;
- `__thiscall`;
- `__fastcall`;
- variadic behavior;
- structure returns;
- `this` in ECX;
- caller/callee cleanup;
- preserved registers;
- x87/SSE observations.

For x86-64 model register/stack argument placement, stack alignment, shadow space where
applicable, preserved registers, return storage, and unwind/runtime-function evidence.

A static ABI report is bounded to observed instructions and declared contract. It does
not prove every call site is consistent unless callers are also checked.

## Hybrid build workflow

Generate a continuously buildable project with exact-byte assembly fallback:

```bash
x86decomp hybrid-generate PROJECT build/hybrid \
  --architecture x86 --overwrite
make -C build/hybrid
```

Rules:

- untouched functions build from immutable range bytes;
- decompiler output is not silently included in the build;
- staged/matched/functional trees remain distinct;
- replacement source enters the build only through an explicit manifest change;
- every object is reproducibly associated with a stable function ID.

## Patch-image workflow

Patch only a copy and use hash gates:

```bash
x86decomp patch-image original.exe candidate.bin patched.exe \
  --rva 0x12340 \
  --expected-original-sha256 SHA256 \
  --expected-function-sha256 SHA256 \
  --report reports/patch.json
```

Rules:

- preserve original immutable evidence;
- require equal-size replacement unless the format/layout operation explicitly handles
  growth;
- reject unmapped RVAs and section-boundary violations;
- regenerate PE checksum;
- hash output;
- run integration tests before `image_integrated` promotion.

## Full relink workflow

```bash
x86decomp relink relink.json --report reports/relink.json
```

The manifest must declare:

- linker executable;
- object list and order;
- flags;
- library paths/libraries;
- subsystem/entry point where required;
- output path;
- timeout/environment;
- optional expected image or comparison scope.

The relinker executes the declared plan. It does not infer original object partition,
COMDAT selection, section order, resource script, import library behavior, or linker
version. Those remain project-specific evidence.

## Functional differential validation

Use a declarative Unicorn harness:

```bash
x86decomp dynamic-validate target.bin candidate.bin harness.json \
  --target-base 0x10000000 \
  --candidate-base 0x20000000 \
  --report reports/dynamic.json
```

A harness declares:

- architecture;
- mapped code/data/stack regions;
- initial registers;
- input bytes;
- return/stop conditions;
- instruction/timeout bounds;
- deterministic external-call summaries;
- observed registers and memory ranges.

Promotion rule: every declared observation must match for every retained test case.
The result applies only to those concrete states and summaries.

## DynamoRIO coverage workflow

Never run an unknown executable on the host. Use a disposable VM/sandbox.

```bash
x86decomp drcov-run program.exe traces/run-001 \
  --drrun /opt/DynamoRIO/bin64/drrun \
  --program-arg input.dat \
  --timeout 60 \
  --report reports/drcov-run.json

x86decomp drcov-parse traces/run-001/drcov.program.1234.0000.proc.log
```

Coverage proves execution of recorded blocks for one run. It does not prove that
uncovered code is unreachable.

## Bounded symbolic validation

Built-in Capstone/Z3 backend:

```bash
x86decomp symbolic-validate target.bin candidate.bin \
  --architecture x86 \
  --input-register eax \
  --stack-argument-words 2 \
  --output-register eax \
  --max-steps 128 \
  --max-paths 64 \
  --report reports/symbolic-z3.json
```

Optional angr backend:

```bash
x86decomp angr-validate target.bin candidate.bin \
  --architecture x86 \
  --input-register eax \
  --stack-argument-words 2 \
  --output-register eax \
  --max-steps 128 \
  --max-paths 64 \
  --report reports/symbolic-angr.json
```

Report and preserve:

- supported instruction semantics;
- symbolic inputs;
- memory model;
- branch/path count;
- loop/step bounds;
- external summaries;
- solver timeout;
- counterexample if found;
- unsupported instruction or path.

`unknown`, timeout, unsupported semantics, and path exhaustion are not success.

## Ghidra MCP policy

The toolkit supports stdio and Streamable HTTP MCP transports. Read-only is the
default.

List tools:

```bash
x86decomp mcp-tools --command-json '["python","server.py"]'
```

Read operation:

```bash
x86decomp mcp-read PROJECT decompile_function \
  '{"address":"00401234"}' \
  --command-json '["python","server.py"]'
```

Mutation is two-phase:

```bash
x86decomp mcp-propose PROJECT rename_function \
  '{"address":"00401234","name":"RenderWater"}' \
  --allow-tool rename_function \
  --rationale "descriptive analyst name" \
  --evidence ev-1 --evidence ev-2 \
  --command-json '["python","server.py"]'

x86decomp mcp-commit PROJECT APPROVAL_HASH \
  --allow-tool rename_function \
  --command-json '["python","server.py"]'
```

Mutation rules:

- allowlist exact tools;
- hash the proposed request;
- require evidence and rationale;
- journal proposal and result;
- re-export affected artifacts;
- compare before/after;
- run downstream validators;
- never count the mutation response as evidence that the mutation is correct.

## Human/AI work queue

AI may propose work but cannot self-validate it.

```bash
x86decomp work-create work.sqlite pe-rva:00012340 matching source_candidate \
  "Produce a candidate that compiles under profile X" \
  --validator compile --validator diff-function --priority 50

x86decomp work-next work.sqlite --mode matching
x86decomp work-claim work.sqlite TASK_ID analyst-or-agent
x86decomp work-propose work.sqlite TASK_ID proposal.json \
  --evidence ev-1 --evidence ev-2
x86decomp work-validate work.sqlite TASK_ID compile reports/compile.json --passed
x86decomp work-validate work.sqlite TASK_ID diff-function reports/diff.json --passed
```

Rules:

- task creation names required validators;
- proposal stores provenance;
- acceptance requires all named validators;
- agent prose is never a validator;
- failed validators remain visible;
- accepted work still does not imply original source recovery.

## Benchmarking

```bash
x86decomp benchmark-run corpus.json --report reports/benchmark.json
```

Measure separately:

- function-boundary precision/recall;
- CFG-edge recovery;
- direct/indirect call-target recovery;
- ABI/prototype accuracy where ground truth exists;
- relocation/data recovery;
- candidate compilation rate;
- instruction-similar count;
- raw byte-match count;
- differential pass rate;
- symbolic bounded results;
- integration coverage;
- unresolved indirect branches;
- human interventions.

Never collapse all metrics into “percent decompiled.”

## Read-only service

```bash
x86decomp serve PROJECT --host 127.0.0.1 --port 8080
```

The service is a project/dashboard reader. Do not expose it on an untrusted network
without an external authentication and authorization layer.

## Application integration scenarios

```bash
x86decomp integration-run integration.json \
  --allow-host-execution \
  --report reports/integration.json
```

Host execution requires three explicit facts: `execution.mode=host_explicit`,
`acknowledge_untrusted_code_risk=true`, and the CLI flag. For untrusted programs use
`external_wrapper` with a disposable VM/container command prefix. Target and candidate
run in separate temporary work trees. Compare only declared exit codes, streams and
files. A passing report can support `integration_validated` only for those named
scenarios and observations.

## decomp.me packet workflow

```bash
x86decomp decompme-pack FUNCTION_ARTIFACT work/decompme/FUNCTION_ID
```

The command creates a local packet and performs no upload. Review licensing/privacy
before using a hosted service. Ghidra listing syntax is display text, not guaranteed
GAS or compiler-ready syntax; convert it and validate against exact bytes.

## objdiff workflow

```bash
x86decomp objdiff-run objdiff.json --report reports/objdiff.json
```

Use objdiff for suitable object-to-object comparisons. The manifest pins exact CLI
arguments and inputs because tool configurations evolve. Capture version/hash, target
and candidate hashes, complete output, and acceptance policy. Do not substitute an
objdiff object result for the executable-aware PE-to-COFF report.

## Project memory

Append only durable events:

- initialization;
- target/toolchain changes;
- architecture decisions;
- function state promotions/regressions;
- accepted/rejected ABI or type claims;
- discovered packing/self-modification/exception complexity;
- Ghidra/MCP mutation;
- patch/relink result;
- legal/security constraints;
- blockers and resolutions.

```bash
x86decomp memory-add PROJECT \
  --actor analyst \
  --category function \
  --summary "pe-rva:00012340 matching status -> byte_matched" \
  --details-json '{"old":"instruction_similar","new":"byte_matched","report":"reports/matching/f.json"}' \
  --evidence ev-diff

x86decomp memory-verify PROJECT
x86decomp memory-render PROJECT
```

A memory event references evidence; it never replaces evidence. Verify the hash chain
before appending.

## Security guardrails

- Treat binaries, PDBs, compilers, linkers, MCP servers, traces, and generated source as
  untrusted.
- Run targets and DynamoRIO only in disposable, isolated systems.
- Review every external executable path and hash.
- Do not use shell interpolation for compiler/linker commands.
- Confine imported and generated paths beneath project roots.
- Reject symlinks and traversal for sealed artifacts.
- Keep public decompilation uploads opt-in and legally authorized.
- Keep MCP read-only unless a signed proposal is committed.
- Bind the dashboard to loopback by default.
- Never bypass DRM, access controls, or authorization boundaries.

## Efficiency rules

1. Work one function or tightly connected call cluster at a time.
2. Read manifests before large text artifacts.
3. Prefer JSON/JSONL filters over monolithic dumps.
4. Load only callers, callees, ranges, and constraints relevant to the claim.
5. Reuse stable IDs in commands and reports.
6. Keep raw evidence immutable; derive compact indexes.
7. Cache compiler experiments by full identity.
8. Stop an experiment branch when falsifying evidence is conclusive.
9. Never optimize away hashes, failures, contradictions, or provenance.
10. Select the cheapest validator capable of measuring the requested property.

## Required analytical response format

1. **Finding** — one narrow statement.
2. **Status** — observed, derived, proposed, corroborated, verified, rejected, unknown,
   blocked, or bounded.
3. **Mode** — matching, functional, or both.
4. **Evidence** — stable IDs and artifact paths.
5. **Checks performed** — exact commands and measured properties.
6. **Contradictions and limits** — unresolved facts, bounds, and unsupported scope.
7. **Project changes** — files, mutations, source, reports, and status transitions.
8. **Next experiment** — at most one highest-value action when further work is needed.

Never bury uncertainty after a confident headline.

## Failure and escalation

Stop and report when:

- project or memory integrity fails;
- function ranges overlap unexpectedly;
- binary hash differs from recorded evidence;
- artifact verification fails;
- Ghidra and Capstone disagree on boundaries;
- a compiler/linker executable hash changes;
- COFF symbol extent is ambiguous;
- relocation normalization lacks a modeled relocation;
- target execution lacks isolation;
- a symbolic instruction is unsupported;
- solver/path/time bounds are exceeded;
- MCP response differs from the approved request;
- contradictory evidence is unresolved;
- legal authorization is unclear;
- requested certainty exceeds validator capability.

The escalation must name the failed contract, stable IDs, invalidated conclusions, and
the evidence required to proceed.

## Definition of done

A task is complete only when:

- the requested property is stated precisely;
- the correct mode is selected;
- input/project/artifact integrity passes;
- required tools and versions are recorded;
- reports preserve commands, hashes, outputs, and bounds;
- no unsupported fact is promoted;
- contradictions are explicit;
- function workflow state reflects only passing reports;
- durable changes are in project memory;
- modified code passes tests and contract validation;
- documentation and schemas match implementation;
- environment-dependent checks are clearly separated from checks actually executed.

## Final rule

This skill optimizes rigor, automation, and reproducibility. It cannot guarantee factual
correctness, original-source recovery, or universal equivalence. A result is only as
strong as its exact evidence, validator, model, and declared scope. When those are
insufficient, preserve `unknown` instead of manufacturing certainty.
