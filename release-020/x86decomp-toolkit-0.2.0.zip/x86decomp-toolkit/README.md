# x86decomp-toolkit

An evidence-governed, end-to-end orchestration toolkit for incremental native Windows
x86 and x86-64 decompilation.

The toolkit has two independent per-function workflows:

1. **Matching decompilation** — compile candidate C/C++ or assembly and determine
   whether it reproduces the target instructions, normalized references, exact bytes,
   patched image, or a manifest-driven relink.
2. **Functional decompilation** — produce maintainable source and validate explicitly
   selected behavior using bounded ABI analysis, Unicorn differential execution,
   built-in Z3 symbolic comparison, optional angr comparison, DynamoRIO coverage, and
   integration tests.

These modes are deliberately independent. A function can be byte-matched without a
runtime test, or behaviorally validated without reproducing the original instruction
stream.

## Truth boundary

This package does **not** claim to recover information that compilation removed. It
cannot guarantee original comments, identifiers, macros, templates, source-file
boundaries, compiler flags, or universal semantic equivalence. Every verifier reports
only the exact property it measured. Three-source review is a governance gate, not an
infallibility guarantee.

## Implemented architecture

| Component | Implementation |
|---|---|
| Immutable input and evidence | SHA-256 sealed project input, copied evidence, path confinement |
| PE ingestion | PE32/i386 and PE32+/AMD64, sections, imports, delay imports, exports, resources, relocations, debug/CodeView, TLS, load config, x64 runtime functions |
| Ghidra analysis | Headless project export, exact discontiguous ranges, C, token tree, raw/high P-code, instructions, references, types, symbols, queries |
| Independent decode | Capstone x86/x64 decode, normalized operands/branches/CFG and Ghidra cross-check |
| Analysis database | SQLite entities, references, ABI records, type constraints, conflicts and provenance |
| Matching engine | COFF parser, symbol extraction, relocation masking, PE-function↔COFF comparison, synthetic COFF generation, manifest-driven objdiff CLI adapter |
| Compiler laboratory | Hash-pinned profiles, isolated work directories, cache, flag matrices, user-owned toolchain registry |
| Hybrid project | Buildable exact-byte assembly fallback plus staging/matched/functional source trees |
| Image integration | Hash-gated PE patching and checksum regeneration |
| Full relink | Real manifest-driven linker invocation with object/tool/output provenance and optional image comparison |
| ABI validation | Explicit x86 conventions, x64 model, stack cleanup, register-use and x87/SSE observations |
| Dynamic validation | Unicorn bounded function harnesses and deterministic external-call summaries |
| Runtime coverage | DynamoRIO drcov execution and normalized text-log parsing |
| Integration scenarios | Explicit-consent target/candidate process execution with exit/stdout/stderr/file observations and external-wrapper isolation support |
| Symbolic validation | Built-in Capstone/Z3 bounded engine and optional angr comparative backend |
| Ghidra MCP | Stdio and Streamable HTTP clients, read-only default, hash-approved mutation journal |
| Work orchestration | Validator-gated human/AI task queue; AI output is never evidence by itself |
| Benchmarking | Byte, PE↔COFF, dynamic, symbolic, boundary/CFG/call-target metrics and human-intervention counts |
| Service/UI | Optional FastAPI JSON endpoints and read-only project dashboard |
| Project memory | Append-only hash-chained decision and status ledger |

## Supported baseline

The implemented parsers support:

- native Windows PE32, `IMAGE_FILE_MACHINE_I386`;
- native Windows PE32+, `IMAGE_FILE_MACHINE_AMD64`;
- unpacked user-mode code where static function artifacts can be obtained;
- function-sized C, C++, or assembly candidates;
- COFF i386 and AMD64 relocatable objects.

Packed, virtualized, encrypted, self-modifying, kernel-mode, managed CLR, or
anti-analysis targets are not silently accepted as ordinary inputs. A project may
still retain such a binary as evidence, but the relevant validator must report the
unsupported scope.

## Install

Core only:

```bash
python -m pip install .
```

All dependency-light validators and service:

```bash
python -m pip install '.[disassembly,dynamic,symbolic,service]'
```

Optional angr backend:

```bash
python -m pip install '.[angr]'
```

External tools such as Ghidra, DynamoRIO, historical MSVC, `lld-link`, and `objdiff`
remain user-installed. Proprietary compiler binaries are never redistributed.

## Create and verify a project

```bash
x86decomp init program.exe projects/program
x86decomp verify-project projects/program
x86decomp memory-verify projects/program
```

Project creation selects both modes by default and creates the analysis database,
work queue, evidence store, function store, source stages, reports, build caches, and
memory ledger.

## Export Ghidra analysis

```bash
export GHIDRA_HOME=/opt/ghidra
x86decomp ghidra-export \
  program.exe \
  projects/program/analysis/ghidra \
  program \
  projects/program/analysis/exports \
  --scripts-dir ./ghidra_scripts \
  --overwrite
```

Each function artifact includes:

```text
function.json
ranges/*.bin
instructions.jsonl
listing.asm
references.jsonl
decompiler.c
decompiler-tree.jsonl
high-pcode.jsonl
high-pcode.txt
raw-pcode.jsonl
context.h
```

Ghidra output is analysis evidence, not ground truth. Cross-check it independently:

```bash
x86decomp crosscheck-ghidra \
  instructions.jsonl ranges/00.bin \
  --base 0x401000 --architecture x86 \
  --report reports/crosscheck.json
```

## Initialize and advance both function modes

```bash
x86decomp workflow-init projects/program pe-rva:00001000 \
  --mode matching --mode functional

x86decomp workflow-update projects/program pe-rva:00001000 \
  --source-stage decompiler_candidate \
  --matching-status decompiled \
  --functional-status decompiled
```

Matching and functional states are independent and monotonic unless an explicit,
audited regression is requested.

### Matching states

```text
not_started -> decompiled -> compiles -> abi_compatible
            -> instruction_similar -> byte_matched
            -> image_integrated -> full_relink_validated
```

### Functional states

```text
not_started -> decompiled -> compiles -> abi_compatible
            -> differentially_validated
            -> symbolically_bounded
            -> integration_validated
```

`blocked` is an explicit side state for either mode.

## Matching workflow

Compile a candidate with a reproducible profile:

```bash
x86decomp compile \
  examples/compiler-profiles/gcc-i686-object.json \
  examples/sample_source/add.c \
  build/add.o \
  --cache build/cache \
  --report build/add.compile.json
```

Search compiler flags with a bounded matrix:

```bash
x86decomp compiler-lab \
  examples/labs/gcc-optimization-matrix.json \
  --report reports/compiler-lab.json
```

Inspect or extract COFF:

```bash
x86decomp coff-inspect candidate.obj
x86decomp coff-extract candidate.obj FunctionName candidate.bin
```

Compare a linked function against a COFF symbol:

```bash
x86decomp diff-function \
  program.exe 0x12340 0x90 candidate.obj FunctionName \
  --report reports/matching/FunctionName.json
```

The report distinguishes:

- `byte_matched`;
- `relocation_normalized_match`;
- `instruction_similar`;
- `mismatch`.

Only the first is raw byte equality. None implies original source recovery.

Generate a continuously buildable hybrid tree:

```bash
x86decomp hybrid-generate projects/program build/hybrid --architecture x86
make -C build/hybrid
```

Patch a verified candidate into a copy of the image:

```bash
x86decomp patch-image program.exe candidate.bin patched.exe \
  --rva 0x12340 \
  --expected-original-sha256 <sha256> \
  --expected-function-sha256 <sha256> \
  --report reports/patch.json
```

Perform a real manifest-driven relink:

```bash
x86decomp relink relink.json --report reports/relink.json
```

The relinker executes the declared linker and objects. It does not pretend to infer
the original linker script or consumed object partition automatically.

Create a local decomp.me-style packet without uploading target material:

```bash
x86decomp decompme-pack \
  projects/program/functions/pe-rva_00012340 \
  work/decompme/pe-rva_00012340
```

Run a version-pinned objdiff command from an explicit manifest:

```bash
x86decomp objdiff-run objdiff.json --report reports/objdiff.json
```

The objdiff adapter records executable/target/candidate hashes, exact arguments,
stdout/stderr, output hash, and parsed JSON or text. It does not reinterpret an
objdiff process result as PE-function proof.

## Functional workflow

Static ABI check:

```bash
x86decomp abi-check function.bin examples/abi/stdcall-two-ints.json \
  --report reports/functional/abi.json
```

One bounded concrete state with Unicorn:

```bash
x86decomp dynamic-validate \
  examples/validators/add_stack_target.bin \
  examples/validators/add_stack_candidate.bin \
  examples/validators/add_stack_harness.json \
  --report reports/functional/unicorn.json
```

Bounded symbolic comparison with the built-in engine:

```bash
x86decomp symbolic-validate target.bin candidate.bin \
  --architecture x86 \
  --stack-argument-words 2 \
  --output-register eax \
  --max-steps 1000 --max-paths 64 \
  --report reports/functional/symbolic.json
```

Optional angr backend:

```bash
x86decomp angr-validate target.bin candidate.bin \
  --architecture x86 --stack-argument-words 2 --output-register eax
```

Capture authorized application coverage under DynamoRIO:

```bash
x86decomp drcov-run program.exe reports/drcov \
  --drrun /path/to/drrun \
  --program-arg --safe-test-mode \
  --report reports/drcov/run.json
```

Dynamic and symbolic reports contain explicit scope statements. They do not claim
whole-program or all-input equivalence beyond their model.

Run bounded application-level integration scenarios:

```bash
x86decomp integration-run examples/integration/bounded-demo.json \
  --allow-host-execution \
  --report reports/functional/integration.json
```

Host execution requires both a manifest acknowledgement and the explicit CLI flag.
For untrusted targets, use `execution.mode=external_wrapper` with a VM/container runner.
The report compares only declared exit codes, stdout/stderr, and output files.

## Ghidra MCP governance

List tools over stdio:

```bash
x86decomp mcp-tools --command-json '["python","-m","ghidra_mcp.server"]'
```

Read-only calls are logged. Probable mutations are refused through the read path.
Mutations require:

1. explicit allowlisting;
2. rationale;
3. evidence IDs;
4. a persisted proposal;
5. exact approval-hash commit.

This makes every Ghidra write reproducible and reviewable.

## Evidence and claims

```bash
x86decomp evidence-add projects/program \
  --kind binary_bytes \
  --source original-image \
  --locator pe-rva:00012340 \
  --assertion 'RET immediate is 8' \
  --independent-group raw-bytes \
  --file reports/function.bin

x86decomp claim-create projects/program \
  --id cl-stack-cleanup-00012340 \
  --subject pe-rva:00012340 \
  --predicate callee_stack_cleanup \
  --object 8
```

A claim reaches `verified` only when the configured gate has at least three supporting
records, three independent failure domains, two evidence kinds, valid file hashes,
and no unresolved contradiction. This is strict process control, not a mathematical
truth guarantee.

## Validator-gated work queue

```bash
x86decomp work-create projects/program/work/tasks.sqlite3 \
  pe-rva:00012340 matching recover_source \
  'Produce a compiling candidate without inventing types.' \
  --validator compile --validator pe_coff_diff
```

A human or agent proposal must attach evidence. A task becomes `accepted` only after
every required validator has recorded a passing report.

## Benchmarks

```bash
x86decomp benchmark-run examples/benchmarks/bounded-demo.json \
  --report reports/benchmarks/demo.json
```

The runner reports separate counts/rates for function boundaries, CFG edges, call
targets, byte matches, instruction similarity, dynamic validation, symbolic
validation, completion failures, and human interventions. It does not collapse these
into a misleading single “percent decompiled.”

## Service

```bash
x86decomp serve projects/program --host 127.0.0.1 --port 8765
```

The optional FastAPI service exposes read-only project/function/report/work data and a
small dashboard. It is not an authentication or multi-tenant boundary; bind it only to
a trusted interface unless placed behind an appropriate gateway.

## Repository layout

```text
src/x86decomp/                  orchestration and validators
ghidra_scripts/                 complete Ghidra exporters and query script
schemas/                        machine-readable contracts
examples/                       executable profiles, harnesses, ABI, integration and benchmark examples
docs/                           architecture, guardrails, contracts, source basis
skills/x86decomp/SKILL.md       evidence-first agent operating skill
tests/                          parser, compiler, COFF, dynamic, symbolic, MCP, relink tests
PROJECT_MEMORY.md               repository-level durable design memory
AGENTS.md                       mandatory contributor and agent rules
FEATURE_PARITY.md               architecture-to-code/command/test parity matrix
VERIFICATION.md                 exact package verification record
```

## Security and authorization

Only analyze software for which the operator has authorization. The toolkit never
implicitly runs a target. `dynamic-validate` runs isolated code bytes in Unicorn;
`drcov-run`, `integration-run`, objdiff, linker, and compiler commands execute external programs only when the user
explicitly invokes them. Host integration execution additionally requires `--allow-host-execution`. See `SECURITY.md` and `docs/guardrails.md`.
