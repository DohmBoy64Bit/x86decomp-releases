# Roadmap

## Version 0.2 architecture-complete baseline

Delivered implementations:

- PE32/i386 and PE32+/AMD64 ingestion.
- Ghidra C, token tree, raw/high P-code, exact ranges, references, symbols and types.
- Capstone cross-check and normalized x86/x64 instruction/CFG comparison.
- COFF parsing, symbol extraction, relocation masking and synthetic object generation.
- Independent matching and functional per-function workflows.
- Compiler cache, flag matrix and user-owned toolchain registry.
- Hybrid assembly fallback, PE patch and manifest-driven relink.
- ABI, Unicorn, Z3, optional angr and DynamoRIO validators.
- SQLite analysis/type graph, MCP mutation transactions and validator-gated work queue.
- Benchmark runner, bounded integration scenario runner, objdiff/decomp.me adapters, and read-only service/dashboard.

## Next depth milestones

These are refinements, not missing architecture boxes:

1. Expand modeled COFF relocation kinds, weak externals, COMDAT selection and auxiliary
   symbol semantics using a larger ground-truth corpus.
2. Add richer Windows exception, RTTI, vtable, static-initializer and TLS reconstruction
   contracts per compiler family.
3. Add platform-specific VM lifecycle automation and richer Windows API/environment summaries around the existing external-wrapper integration runner.
4. Add target-specific linker-layout solvers and whole-image section/data ordering.
5. Expand the built-in symbolic ISA subset and memory alias model while retaining hard
   path/step limits.
6. Add authenticated multi-user service deployment only if needed; the included UI is
   intentionally local/read-only.
7. Build public, legally redistributable ground-truth corpora for compiler/version and
   optimization benchmarking.

No roadmap item should be described as “100% automatic decompilation.” Progress is
measured by decomposed metrics and explicit unsupported cases.
