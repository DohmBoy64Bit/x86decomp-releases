# Supported scope and non-goals

## Implemented formats

- Native Windows PE32 i386.
- Native Windows PE32+ AMD64.
- COFF i386 and AMD64 relocatable objects.
- Function artifacts with one or more discontiguous address ranges.
- C, C++, assembly, binary, relocatable-object and executable compiler outputs.

## Matching mode support

Implemented:

- compiler profile execution and flag matrices;
- user-owned historical toolchain registry;
- PE-function to COFF-symbol extraction;
- raw, relocation-masked and normalized instruction comparison;
- static ABI observations;
- exact-byte assembly fallback;
- synthetic COFF construction with caller-supplied relocations;
- PE patching with checksum update;
- manifest-driven full linker invocation and optional image comparison;
- manifest-driven objdiff CLI execution with pinned inputs and captured output.

The toolkit does not generically infer every consumed COFF relocation, COMDAT choice,
original object boundary, section order, linker script, or proprietary compiler build.
Those are target-specific reconstruction work and must remain explicit evidence.

## Functional mode support

Implemented:

- concrete Unicorn function harnesses;
- deterministic external-call summaries;
- observed register/memory comparisons;
- built-in bounded Capstone/Z3 symbolic comparison;
- optional angr bounded comparison;
- DynamoRIO drcov coverage capture/parsing;
- explicit integration scenario execution comparing exit code, streams and declared files;
- validator-gated integration status.

Finite tests and bounded symbolic models are not universal semantic proof. Windows API,
threading, exceptions, callbacks, devices, timing, and complete process state require
an integration environment supplied by the project.

## Explicitly unsupported as automatic guarantees

- Recovery of original comments, local names, macros, formatting or translation units.
- Guaranteed original class, template, inline or source-file organization.
- Correct static analysis of arbitrary packed, virtualized or self-modifying code.
- Automatic bypass of DRM, anti-debugging or access controls.
- Safe host execution of unknown targets.
- Resolution of every indirect branch, exception edge or dynamic code target.
- Universal all-input program equivalence.
- Generic byte-identical whole-image reconstruction without target-specific evidence.

Unsupported behavior must fail or be labeled unknown; it must never be represented by
a success-shaped placeholder.
