# Architecture

## Objective

Provide one reproducible project that coordinates binary evidence, Ghidra analysis,
independent decoding, candidate source, compilers, matching validators, functional
validators, human/AI work, and durable memory.

The architecture does not define “decompiled” as one boolean. It stores two independent
per-function modes and a chain of narrowly defined validation states.

## Data flow

```text
Original PE32/PE32+
  -> immutable hashes and parsed image manifest
  -> Ghidra project + exact function artifacts
  -> independent Capstone decode and cross-check
  -> global symbol/reference/type/ABI database
  -> candidate C/C++/assembly + hybrid fallback tree
  -> compiler profile / flag experiment matrix
  -> matching validators
       PE bytes <-> COFF symbol
       normalized instructions/CFG
       exact bytes
       patched image
       manifest relink
  -> functional validators
       ABI observations
       Unicorn differential harness
       DynamoRIO coverage
       built-in Z3 bounded symbolic comparison
       optional angr bounded comparison
       manifest-driven integration scenarios
  -> evidence, claims, work-queue acceptance and function status
  -> hash-chained project memory
```

## Layers and ownership

### Immutable input

The binary and attached evidence are content-addressed. A changed hash creates a new
artifact; it never silently updates an existing fact.

### PE ingestion

`pe32.py` and `pe.py` perform bounded parsing without executing the image. The parser
supports i386 PE32 and AMD64 PE32+ and records sections, directories, imports, delay
imports, exports, resources, base relocations, CodeView debug records, TLS callbacks,
load configuration, and x64 runtime-function entries.

### Ghidra adapter

Ghidra remains the primary decompiler and static-analysis engine. Java exporters write
stable JSON/JSONL and exact range bytes. They preserve discontiguous function bodies
and expose both raw and high P-code. The decompiler token tree is exported separately
from rendered C so consumers can retain token/address structure.

### Independent decoder

Capstone provides an independent instruction stream. It is used for operand/branch
normalization, CFG edges, fast indexing, and disagreement detection. It is not used as
a source of C types or semantic proof.

### Analysis database

SQLite owns cross-function entities, references, ABI records, and type constraints.
Constraints retain provenance and conflict state. No LLM or MCP server owns canonical
project state.

### Function workflows

`workflow.json` owns the two independent mode states, active candidate, compiler
profile, report links and blockers. State regressions require an explicit audited
flag.

### Matching subsystem

The COFF parser supports i386 and AMD64 objects, symbols, sections, and relocation
records. The executable-aware diff extracts a PE RVA range, extracts a COFF symbol,
masks only modeled address-dependent fields, compares normalized instructions/CFG,
and emits a classification. Synthetic COFF output is available for exact target-byte
objects where the caller supplies reconstructed relocations. A manifest-driven objdiff
adapter executes a user-pinned objdiff CLI/configuration and captures complete provenance.

### Functional subsystem

Unicorn executes function bytes in a declared memory/register/stack harness. Built-in
symbolic comparison supports a bounded x86/x64 leaf-function instruction subset over
explicit symbolic inputs. angr is an optional secondary backend. DynamoRIO integration
captures observed coverage from explicitly launched applications. The integration
scenario runner compares declared process and file observations under explicit host
consent or an external isolation wrapper.

### Build integration

The hybrid generator creates assembly fallback objects from immutable ranges and
keeps decompiler output out of the default build. The patch backend writes into a copy
of a PE only after optional hash gates. The relink backend invokes a declared linker
with declared objects; it does not infer original linker decisions.

### Governance

Evidence records and claim gates distinguish observations from inference. The MCP
gateway is read-only by default and uses a hash-approved transaction for mutation.
The work queue requires evidence plus named validator reports before acceptance.
Project memory records durable transitions in a tamper-evident chain.

## Dependency direction

```text
CLI/service
  -> project/workflow/work_queue
  -> PE/COFF/Ghidra adapters
  -> compiler/hybrid/patch/relink
  -> ABI/diff/dynamic/symbolic/coverage validators
  -> evidence/claims/memory

all modules -> util/errors
```

No validator may rewrite immutable evidence. No analysis backend may promote its own
output to verified fact. No AI proposal bypasses compiler/runtime/evidence gates.
