"""Optional angr comparative symbolic execution backend for bounded code blobs.

The built-in symbolic engine remains the default deterministic backend. This
module integrates angr when installed and performs finite path comparison over
explicit input/output registers and stack arguments. Results are scoped to the
selected architecture, code blobs, path/step limits, and observable registers.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .errors import ContractError, ExternalToolError
from .util import sha256_bytes, utc_now, write_json


def _load_angr() -> tuple[Any, Any]:
    try:
        import angr  # type: ignore[import-not-found]
        import claripy  # type: ignore[import-not-found]
    except ImportError as exc:
        raise ExternalToolError("angr backend requires the optional 'angr' dependency") from exc
    return angr, claripy


def _arch_name(architecture: str) -> str:
    if architecture == "x86":
        return "x86"
    if architecture == "x86_64":
        return "amd64"
    raise ContractError("architecture must be x86 or x86_64")


def _summaries(
    code: bytes,
    *,
    architecture: str,
    input_registers: tuple[str, ...],
    stack_argument_words: int,
    output_registers: tuple[str, ...],
    max_steps: int,
    max_paths: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    angr, claripy = _load_angr()
    if not code:
        raise ContractError("symbolic code blob may not be empty")
    if max_steps <= 0 or max_paths <= 0:
        raise ContractError("max_steps and max_paths must be positive")
    arch = _arch_name(architecture)
    bits = 32 if architecture == "x86" else 64
    byte_width = bits // 8
    base = 0x100000
    sentinel = 0x200000
    stack = 0x7FFF0000 if architecture == "x86" else 0x7FFF00000000
    project = angr.load_shellcode(code, arch=arch, load_address=base)
    state = project.factory.blank_state(addr=base)
    stack_reg = "esp" if architecture == "x86" else "rsp"
    setattr(state.regs, stack_reg, claripy.BVV(stack, bits))
    state.memory.store(stack, claripy.BVV(sentinel, bits), endness=project.arch.memory_endness)
    inputs: dict[str, Any] = {}
    for register in input_registers:
        if not hasattr(state.regs, register):
            raise ContractError(f"angr architecture has no register {register}")
        symbol = claripy.BVS(f"reg_{register}", bits, explicit_name=True)
        setattr(state.regs, register, symbol)
        inputs[f"register:{register}"] = symbol
    for index in range(stack_argument_words):
        symbol = claripy.BVS(f"stack_arg_{index}", bits, explicit_name=True)
        state.memory.store(stack + byte_width * (index + 1), symbol, endness=project.arch.memory_endness)
        inputs[f"stack:{index}"] = symbol
    manager = project.factory.simulation_manager(state)
    finals: list[Any] = []
    steps = 0
    truncated = False
    while manager.active and steps < max_steps:
        arrived = [candidate for candidate in manager.active if candidate.addr == sentinel]
        if arrived:
            finals.extend(arrived)
            manager.active = [candidate for candidate in manager.active if candidate.addr != sentinel]
        if not manager.active:
            break
        if len(manager.active) > max_paths:
            manager.active = manager.active[:max_paths]
            truncated = True
        manager.step()
        steps += 1
    finals.extend(candidate for candidate in manager.active if candidate.addr == sentinel)
    if manager.active and steps >= max_steps:
        truncated = True
    summaries: list[dict[str, Any]] = []
    for final in finals[:max_paths]:
        outputs = {}
        for register in output_registers:
            if not hasattr(final.regs, register):
                raise ContractError(f"angr architecture has no output register {register}")
            outputs[register] = getattr(final.regs, register)
        summaries.append({"constraints": tuple(final.solver.constraints), "outputs": outputs, "inputs": inputs})
    metadata = {
        "steps": steps,
        "final_path_count": len(summaries),
        "active_path_count": len(manager.active),
        "deadended_path_count": len(manager.deadended),
        "errored_path_count": len(manager.errored),
        "truncated": truncated,
    }
    return summaries, metadata


def _counterexample(left: list[dict[str, Any]], right: list[dict[str, Any]], output_registers: tuple[str, ...]) -> dict[str, int] | None:
    _, claripy = _load_angr()
    for left_path in left:
        alternatives = []
        for right_path in right:
            equal_outputs = [left_path["outputs"][reg] == right_path["outputs"][reg] for reg in output_registers]
            alternatives.append(claripy.And(*right_path["constraints"], *equal_outputs))
        mismatch = claripy.And(*left_path["constraints"], claripy.Not(claripy.Or(*alternatives)) if alternatives else claripy.true())
        solver = claripy.Solver()
        solver.add(mismatch)
        if solver.satisfiable():
            model: dict[str, int] = {}
            for name, symbol in left_path["inputs"].items():
                model[name] = int(solver.eval(symbol, 1)[0])
            return model
    return None


def angr_bounded_compare(
    target: bytes,
    candidate: bytes,
    *,
    architecture: str = "x86",
    input_registers: tuple[str, ...] = (),
    stack_argument_words: int = 0,
    output_registers: tuple[str, ...] | None = None,
    max_steps: int = 1000,
    max_paths: int = 64,
    report_path: Path | None = None,
) -> dict[str, Any]:
    if stack_argument_words < 0:
        raise ContractError("stack_argument_words may not be negative")
    outputs = output_registers or (("eax",) if architecture == "x86" else ("rax",))
    target_paths, target_meta = _summaries(target, architecture=architecture, input_registers=input_registers, stack_argument_words=stack_argument_words, output_registers=outputs, max_steps=max_steps, max_paths=max_paths)
    candidate_paths, candidate_meta = _summaries(candidate, architecture=architecture, input_registers=input_registers, stack_argument_words=stack_argument_words, output_registers=outputs, max_steps=max_steps, max_paths=max_paths)
    forward = _counterexample(target_paths, candidate_paths, outputs)
    reverse = _counterexample(candidate_paths, target_paths, outputs)
    complete = bool(target_paths and candidate_paths and not target_meta["truncated"] and not candidate_meta["truncated"])
    equivalent = complete and forward is None and reverse is None
    report = {
        "schema_version": 1,
        "kind": "angr_bounded_comparison",
        "created_at": utc_now(),
        "architecture": architecture,
        "target_sha256": sha256_bytes(target),
        "candidate_sha256": sha256_bytes(candidate),
        "input_registers": list(input_registers),
        "stack_argument_words": stack_argument_words,
        "output_registers": list(outputs),
        "max_steps": max_steps,
        "max_paths": max_paths,
        "target_execution": target_meta,
        "candidate_execution": candidate_meta,
        "counterexample_target_to_candidate": forward,
        "counterexample_candidate_to_target": reverse,
        "equivalent_within_completed_model": equivalent,
        "scope_statement": "The result covers only angr paths completed within the selected blob model, observables, hooks, and finite path/step bounds; it is not universal program equivalence.",
    }
    if report_path is not None:
        write_json(report_path, report)
    return report


def angr_bounded_compare_files(target: Path, candidate: Path, **kwargs: Any) -> dict[str, Any]:
    left = target.resolve()
    right = candidate.resolve()
    if not left.is_file() or not right.is_file():
        raise ContractError("angr comparison inputs must be files")
    return angr_bounded_compare(left.read_bytes(), right.read_bytes(), **kwargs)
