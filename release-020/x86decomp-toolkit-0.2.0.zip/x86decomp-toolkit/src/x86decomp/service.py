"""Optional local FastAPI service for project state, reports, and work queue."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .errors import ExternalToolError
from .project import verify_project
from .util import load_json
from .work_queue import WorkQueue
from .workflow import load_function_workflow


def create_app(project_root: Path) -> Any:
    try:
        from fastapi import FastAPI, HTTPException
        from fastapi.responses import HTMLResponse
    except ImportError as exc:
        raise ExternalToolError("FastAPI is required; install x86decomp-toolkit[service]") from exc
    root = project_root.resolve()
    app = FastAPI(title="x86decomp toolkit", version="0.2.0")

    @app.get("/api/project")
    def project() -> dict[str, Any]:
        return {"manifest": load_json(root / "project.json"), "verification": verify_project(root)}

    @app.get("/api/functions")
    def functions() -> list[dict[str, Any]]:
        result = []
        for directory in sorted((root / "functions").glob("pe-rva_*")):
            manifest = directory / "function.json"
            if manifest.is_file():
                item = load_json(manifest)
                workflow = directory / "workflow.json"
                if workflow.is_file():
                    item["workflow"] = load_json(workflow)
                result.append(item)
        return result

    @app.get("/api/functions/{function_id:path}/workflow")
    def workflow(function_id: str) -> dict[str, Any]:
        normalized = function_id.replace("pe-rva_", "pe-rva:")
        try:
            return load_function_workflow(root, normalized).to_dict()
        except Exception as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get("/api/work/next")
    def next_task(mode: str | None = None) -> dict[str, Any] | None:
        queue = WorkQueue(root / "work" / "tasks.sqlite3")
        try:
            return queue.next(mode=mode)
        finally:
            queue.close()

    @app.get("/api/reports")
    def reports() -> list[str]:
        return [str(path.relative_to(root)).replace("\\", "/") for path in sorted((root / "reports").rglob("*.json"))]

    @app.get("/", response_class=HTMLResponse)
    def index() -> str:
        return """<!doctype html><html><head><meta charset='utf-8'><title>x86decomp</title>
<style>body{font:15px system-ui;margin:2rem;max-width:1100px}pre{background:#eee;padding:1rem;overflow:auto}.ok{color:green}.bad{color:#b00}</style></head>
<body><h1>x86decomp project</h1><p>This local interface is read-only. Mutations remain evidence-gated through the CLI/MCP transaction journal.</p>
<div id='app'>Loading…</div><script>
Promise.all([fetch('/api/project').then(r=>r.json()),fetch('/api/functions').then(r=>r.json())]).then(([p,f])=>{
 document.getElementById('app').innerHTML=`<h2>Integrity: <span class='${p.verification.valid?'ok':'bad'}'>${p.verification.valid}</span></h2><p>${f.length} function artifacts</p><pre>${JSON.stringify(p,null,2)}</pre>`;
});</script></body></html>"""
    return app


def run_service(project_root: Path, *, host: str = "127.0.0.1", port: int = 8765) -> None:
    try:
        import uvicorn
    except ImportError as exc:
        raise ExternalToolError("Uvicorn is required; install x86decomp-toolkit[service]") from exc
    uvicorn.run(create_app(project_root), host=host, port=port)
