"""Dependency-free COFF object parsing, symbol extraction, and synthetic objects.

This module supports the object formats required by the toolkit's bounded
matching workflow: IMAGE_FILE_MACHINE_I386 and IMAGE_FILE_MACHINE_AMD64 COFF
objects. It does not parse PE images; use :mod:`x86decomp.pe32` for PE32.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from .errors import ContractError, FormatError
from .util import sha256_bytes

IMAGE_FILE_MACHINE_I386 = 0x014C
IMAGE_FILE_MACHINE_AMD64 = 0x8664

I386_RELOCATION_WIDTHS = {
    0x0006: 4,  # IMAGE_REL_I386_DIR32
    0x0007: 4,  # IMAGE_REL_I386_DIR32NB
    0x0014: 4,  # IMAGE_REL_I386_REL32
}
AMD64_RELOCATION_WIDTHS = {
    0x0001: 8,  # IMAGE_REL_AMD64_ADDR64
    0x0002: 4,  # IMAGE_REL_AMD64_ADDR32
    0x0003: 4,  # IMAGE_REL_AMD64_ADDR32NB
    0x0004: 4,  # IMAGE_REL_AMD64_REL32
    0x0005: 4,
    0x0006: 4,
    0x0007: 4,
    0x0008: 4,
    0x0009: 4,
    0x000A: 4,
    0x000B: 4,  # SECREL
}


@dataclass(frozen=True)
class CoffRelocation:
    offset: int
    symbol_index: int
    type: int
    symbol_name: str | None = None

    def width(self, machine: int) -> int | None:
        table = I386_RELOCATION_WIDTHS if machine == IMAGE_FILE_MACHINE_I386 else AMD64_RELOCATION_WIDTHS
        return table.get(self.type)

    def to_dict(self, machine: int) -> dict[str, Any]:
        return {
            "offset": self.offset,
            "symbol_index": self.symbol_index,
            "symbol_name": self.symbol_name,
            "type": self.type,
            "type_hex": f"0x{self.type:04x}",
            "width": self.width(machine),
        }


@dataclass(frozen=True)
class CoffSection:
    index: int
    name: str
    raw_data: bytes
    characteristics: int
    relocations: tuple[CoffRelocation, ...]

    def to_dict(self, machine: int) -> dict[str, Any]:
        return {
            "index": self.index,
            "name": self.name,
            "size": len(self.raw_data),
            "sha256": sha256_bytes(self.raw_data),
            "characteristics": self.characteristics,
            "characteristics_hex": f"0x{self.characteristics:08x}",
            "relocations": [reloc.to_dict(machine) for reloc in self.relocations],
        }


@dataclass(frozen=True)
class CoffSymbol:
    index: int
    name: str
    value: int
    section_number: int
    type: int
    storage_class: int
    auxiliary_count: int

    @property
    def is_function(self) -> bool:
        return (self.type & 0x20) != 0 or self.storage_class in (2, 3)

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "name": self.name,
            "value": self.value,
            "section_number": self.section_number,
            "type": self.type,
            "storage_class": self.storage_class,
            "auxiliary_count": self.auxiliary_count,
            "is_function_candidate": self.is_function,
        }


@dataclass(frozen=True)
class CoffObject:
    path: Path | None
    machine: int
    timestamp: int
    characteristics: int
    sections: tuple[CoffSection, ...]
    symbols: tuple[CoffSymbol, ...]
    raw_sha256: str

    @property
    def architecture(self) -> str:
        if self.machine == IMAGE_FILE_MACHINE_I386:
            return "x86"
        if self.machine == IMAGE_FILE_MACHINE_AMD64:
            return "x86_64"
        return f"unknown-0x{self.machine:04x}"

    def section(self, number: int) -> CoffSection:
        if number <= 0 or number > len(self.sections):
            raise ContractError(f"symbol references invalid section number {number}")
        return self.sections[number - 1]

    def find_symbols(self, name: str) -> list[CoffSymbol]:
        candidates = {name}
        if self.machine == IMAGE_FILE_MACHINE_I386:
            candidates.update({f"_{name}", name.lstrip("_")})
        return [symbol for symbol in self.symbols if symbol.name in candidates]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "format": "COFF",
            "architecture": self.architecture,
            "machine": self.machine,
            "machine_hex": f"0x{self.machine:04x}",
            "timestamp": self.timestamp,
            "characteristics": self.characteristics,
            "raw_sha256": self.raw_sha256,
            "sections": [section.to_dict(self.machine) for section in self.sections],
            "symbols": [symbol.to_dict() for symbol in self.symbols],
        }


@dataclass(frozen=True)
class ExtractedSymbol:
    symbol: CoffSymbol
    section: CoffSection
    offset: int
    size: int
    data: bytes
    relocations: tuple[CoffRelocation, ...]

    def to_dict(self, machine: int) -> dict[str, Any]:
        return {
            "symbol": self.symbol.to_dict(),
            "section": self.section.name,
            "offset": self.offset,
            "size": self.size,
            "sha256": sha256_bytes(self.data),
            "relocations": [reloc.to_dict(machine) for reloc in self.relocations],
        }


class _Reader:
    def __init__(self, data: bytes):
        self.data = data

    def require(self, offset: int, size: int, context: str) -> None:
        if offset < 0 or size < 0 or offset + size > len(self.data):
            raise FormatError(
                f"{context} exceeds file bounds: offset={offset} size={size} file={len(self.data)}"
            )

    def unpack(self, fmt: str, offset: int, context: str) -> tuple[Any, ...]:
        size = struct.calcsize(fmt)
        self.require(offset, size, context)
        return struct.unpack_from(fmt, self.data, offset)


def _read_string_table(reader: _Reader, pointer_to_symbols: int, count: int) -> bytes:
    offset = pointer_to_symbols + count * 18
    if offset == len(reader.data):
        return b"\x04\x00\x00\x00"
    reader.require(offset, 4, "COFF string table size")
    size = struct.unpack_from("<I", reader.data, offset)[0]
    if size < 4:
        raise FormatError("COFF string table size is smaller than 4")
    reader.require(offset, size, "COFF string table")
    return reader.data[offset : offset + size]


def _string_at(table: bytes, offset: int, context: str) -> str:
    if offset < 4 or offset >= len(table):
        raise FormatError(f"{context} string-table offset is invalid: {offset}")
    end = table.find(b"\x00", offset)
    if end < 0:
        raise FormatError(f"unterminated {context} string")
    return table[offset:end].decode("utf-8", errors="replace")


def _decode_symbol_name(raw: bytes, table: bytes) -> str:
    if raw[:4] == b"\x00\x00\x00\x00":
        offset = struct.unpack_from("<I", raw, 4)[0]
        return _string_at(table, offset, "symbol")
    return raw.rstrip(b"\x00").decode("utf-8", errors="replace")


def _decode_section_name(raw: bytes, table: bytes) -> str:
    inline = raw.rstrip(b"\x00").decode("ascii", errors="replace")
    if inline.startswith("/") and inline[1:].isdigit():
        return _string_at(table, int(inline[1:]), "section")
    return inline


def parse_coff_bytes(data: bytes, *, path: Path | None = None) -> CoffObject:
    reader = _Reader(data)
    reader.require(0, 20, "COFF file header")
    machine, section_count, timestamp, symbol_pointer, symbol_count, optional_size, characteristics = reader.unpack(
        "<HHIIIHH", 0, "COFF file header"
    )
    if machine not in (IMAGE_FILE_MACHINE_I386, IMAGE_FILE_MACHINE_AMD64):
        raise FormatError(f"unsupported COFF machine 0x{machine:04x}")
    if optional_size != 0:
        raise FormatError("input appears to be an image, not a COFF object (optional header is present)")
    section_headers_offset = 20
    reader.require(section_headers_offset, section_count * 40, "COFF section table")
    if symbol_count:
        reader.require(symbol_pointer, symbol_count * 18, "COFF symbol table")
    string_table = _read_string_table(reader, symbol_pointer, symbol_count) if symbol_count else b"\x04\x00\x00\x00"

    raw_section_records: list[tuple[str, bytes, int, int, int]] = []
    for section_index in range(section_count):
        offset = section_headers_offset + section_index * 40
        name_raw = data[offset : offset + 8]
        (
            _virtual_size,
            _virtual_address,
            raw_size,
            raw_pointer,
            relocation_pointer,
            _line_pointer,
            relocation_count,
            _line_count,
            section_characteristics,
        ) = reader.unpack("<IIIIIIHHI", offset + 8, "COFF section header")
        name = _decode_section_name(name_raw, string_table)
        reader.require(raw_pointer, raw_size, f"section {name} raw data")
        reader.require(relocation_pointer, relocation_count * 10, f"section {name} relocations")
        raw_section_records.append(
            (name, data[raw_pointer : raw_pointer + raw_size], section_characteristics, relocation_pointer, relocation_count)
        )

    symbols: list[CoffSymbol] = []
    index = 0
    while index < symbol_count:
        offset = symbol_pointer + index * 18
        raw_name = data[offset : offset + 8]
        value, section_number, symbol_type, storage_class, aux_count = reader.unpack(
            "<IhHBB", offset + 8, "COFF symbol"
        )
        symbols.append(
            CoffSymbol(
                index=index,
                name=_decode_symbol_name(raw_name, string_table),
                value=value,
                section_number=section_number,
                type=symbol_type,
                storage_class=storage_class,
                auxiliary_count=aux_count,
            )
        )
        if index + aux_count >= symbol_count:
            raise FormatError("COFF symbol auxiliary count exceeds table")
        index += 1 + aux_count
    symbol_by_index = {symbol.index: symbol for symbol in symbols}

    sections: list[CoffSection] = []
    for section_index, (name, raw_data, section_characteristics, relocation_pointer, relocation_count) in enumerate(raw_section_records, start=1):
        relocations: list[CoffRelocation] = []
        for relocation_index in range(relocation_count):
            offset = relocation_pointer + relocation_index * 10
            virtual_address, symbol_index, relocation_type = reader.unpack(
                "<IIH", offset, f"section {name} relocation"
            )
            if symbol_index >= symbol_count:
                raise FormatError(f"relocation references invalid symbol index {symbol_index}")
            target = symbol_by_index.get(symbol_index)
            relocations.append(
                CoffRelocation(
                    offset=virtual_address,
                    symbol_index=symbol_index,
                    type=relocation_type,
                    symbol_name=None if target is None else target.name,
                )
            )
        sections.append(
            CoffSection(
                index=section_index,
                name=name,
                raw_data=raw_data,
                characteristics=section_characteristics,
                relocations=tuple(relocations),
            )
        )
    return CoffObject(
        path=path,
        machine=machine,
        timestamp=timestamp,
        characteristics=characteristics,
        sections=tuple(sections),
        symbols=tuple(symbols),
        raw_sha256=sha256_bytes(data),
    )


def parse_coff(path: Path) -> CoffObject:
    resolved = path.resolve()
    if not resolved.is_file():
        raise ContractError(f"COFF object does not exist: {resolved}")
    return parse_coff_bytes(resolved.read_bytes(), path=resolved)


def extract_symbol(obj: CoffObject, name: str, *, size: int | None = None) -> ExtractedSymbol:
    matches = [symbol for symbol in obj.find_symbols(name) if symbol.section_number > 0]
    if not matches:
        available = sorted(symbol.name for symbol in obj.symbols if symbol.section_number > 0)
        raise ContractError(f"COFF symbol not found: {name}; available={available[:30]}")
    if len(matches) > 1:
        exact = [symbol for symbol in matches if symbol.name == name]
        if len(exact) == 1:
            symbol = exact[0]
        else:
            raise ContractError(f"COFF symbol name is ambiguous: {name}")
    else:
        symbol = matches[0]
    section = obj.section(symbol.section_number)
    start = symbol.value
    if start < 0 or start > len(section.raw_data):
        raise FormatError(f"symbol {symbol.name} offset lies outside section {section.name}")
    if size is None:
        following = sorted(
            candidate.value
            for candidate in obj.symbols
            if candidate.section_number == symbol.section_number and candidate.value > start
        )
        end = following[0] if following else len(section.raw_data)
    else:
        if size <= 0:
            raise ContractError("symbol extraction size must be positive")
        end = start + size
    if end > len(section.raw_data) or end <= start:
        raise FormatError(f"symbol {symbol.name} has invalid inferred range [{start}, {end})")
    relocations = tuple(
        CoffRelocation(
            offset=relocation.offset - start,
            symbol_index=relocation.symbol_index,
            type=relocation.type,
            symbol_name=relocation.symbol_name,
        )
        for relocation in section.relocations
        if start <= relocation.offset < end
    )
    return ExtractedSymbol(
        symbol=symbol,
        section=section,
        offset=start,
        size=end - start,
        data=section.raw_data[start:end],
        relocations=relocations,
    )


def _encode_symbol_name(name: str, strings: bytearray) -> bytes:
    encoded = name.encode("utf-8")
    if len(encoded) <= 8:
        return encoded.ljust(8, b"\x00")
    offset = 4 + len(strings)
    strings.extend(encoded + b"\x00")
    return b"\x00\x00\x00\x00" + struct.pack("<I", offset)


def build_synthetic_coff(
    *,
    code: bytes,
    symbol_name: str,
    machine: int = IMAGE_FILE_MACHINE_I386,
    relocations: Iterable[CoffRelocation] = (),
    timestamp: int = 0,
) -> bytes:
    """Build a minimal deterministic COFF object containing one `.text` symbol.

    Relocations must refer to symbol index 0 because this object intentionally
    contains one symbol. This is sufficient for reconstructed function objects
    whose unresolved references are represented against that symbol. Multi-
    symbol synthesis belongs in a later object-group construction step.
    """
    if machine not in (IMAGE_FILE_MACHINE_I386, IMAGE_FILE_MACHINE_AMD64):
        raise ContractError("synthetic COFF supports x86 and x86-64 only")
    if not code:
        raise ContractError("synthetic COFF code may not be empty")
    if not symbol_name:
        raise ContractError("synthetic COFF symbol_name may not be empty")
    relocs = tuple(relocations)
    for relocation in relocs:
        width = relocation.width(machine)
        if width is None:
            raise ContractError(f"unsupported relocation type 0x{relocation.type:04x}")
        if relocation.symbol_index != 0:
            raise ContractError("single-symbol synthetic COFF requires relocation symbol_index 0")
        if relocation.offset < 0 or relocation.offset + width > len(code):
            raise ContractError("synthetic relocation lies outside code")

    file_header_size = 20
    section_header_size = 40
    raw_pointer = file_header_size + section_header_size
    relocation_pointer = raw_pointer + len(code)
    symbol_pointer = relocation_pointer + len(relocs) * 10
    strings = bytearray()
    encoded_symbol_name = _encode_symbol_name(symbol_name, strings)
    string_table = struct.pack("<I", 4 + len(strings)) + bytes(strings)
    characteristics = 0x60000020  # code | execute | read
    header = struct.pack(
        "<HHIIIHH",
        machine,
        1,
        timestamp,
        symbol_pointer,
        1,
        0,
        0,
    )
    section_header = b".text\x00\x00\x00" + struct.pack(
        "<IIIIIIHHI",
        0,
        0,
        len(code),
        raw_pointer,
        relocation_pointer if relocs else 0,
        0,
        len(relocs),
        0,
        characteristics,
    )
    relocation_blob = b"".join(
        struct.pack("<IIH", relocation.offset, relocation.symbol_index, relocation.type)
        for relocation in relocs
    )
    symbol_blob = encoded_symbol_name + struct.pack("<IhHBB", 0, 1, 0x20, 2, 0)
    return header + section_header + code + relocation_blob + symbol_blob + string_table


def write_synthetic_coff(
    path: Path,
    *,
    code: bytes,
    symbol_name: str,
    machine: int = IMAGE_FILE_MACHINE_I386,
    relocations: Iterable[CoffRelocation] = (),
) -> dict[str, Any]:
    payload = build_synthetic_coff(
        code=code, symbol_name=symbol_name, machine=machine, relocations=relocations
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    parsed = parse_coff(path)
    return parsed.to_dict()
