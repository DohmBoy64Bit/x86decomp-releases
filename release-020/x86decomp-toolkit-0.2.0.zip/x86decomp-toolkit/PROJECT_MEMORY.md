# Repository project memory

This is the durable design memory for the toolkit source repository. Generated
projects maintain their own authoritative `memory/events.jsonl` and rendered memory.

## Mission

Create an evidence-governed decompilation operating system for native Windows x86 and
x86-64 that automates project creation, static extraction, candidate builds, matching,
functional validation, work coordination and durable decisions without pretending to
recover facts erased by compilation.

## Fixed decisions

1. **Two first-class modes.** Matching and functional status are independent for every
   function.
2. **Native PE scope.** PE32/i386 and PE32+/AMD64 are parsed; managed CLR is not treated
   as native decompilation.
3. **Raw bytes are authoritative evidence.** Ghidra, Capstone, compilers, emulators and
   solvers are analysis/validation sources with recorded versions and scope.
4. **Ghidra is the primary decompiler, not the database owner.** Canonical cross-tool
   state lives in project files/SQLite/evidence/memory.
5. **Per-function artifacts are primary.** Monolithic pseudocode is a report only.
6. **Function bodies are address sets.** Discontiguous ranges remain separate.
7. **COFF-aware matching precedes whole-image reconstruction.** PE↔COFF comparison
   records raw, relocation-normalized and instruction results separately.
8. **Functional proof is bounded.** Concrete harnesses, coverage, symbolic models and
   integration scenarios retain their explicit envelope.
9. **Assembly fallback keeps projects buildable.** Decompiler C is not compiled by
   default until promoted.
10. **Historical compilers are user-owned.** Registry entries hash external tools; the
    toolkit does not redistribute proprietary binaries.
11. **Ghidra MCP is read-only by default.** Mutations use evidence-backed signed
    transactions.
12. **AI is a proposer.** Evidence and named validators control acceptance.
13. **Memory is append-only/hash chained.** Markdown is a derived view.
14. **No hidden network upload or target execution.** External execution requires an
    explicit command and operator authorization.

## Implemented inventory (0.2.0)

### Formats and project

- `pe32.py`, `pe.py`: bounded PE32/PE32+ metadata and directory parsing.
- `coff.py`: i386/AMD64 COFF sections, symbols, relocations, extraction and synthetic
  object generation.
- `project.py`: architecture-aware project initialization/integrity.
- `artifacts.py`: safe function-artifact import/sealing.
- `workflow.py`: matching/functional state machines.

### Static analysis

- Ghidra project/function exporters: ranges, C, token tree, raw/high P-code,
  instructions, references, types, symbols, metrics.
- `disassembly.py`: independent Capstone decode, normalized operands/branches/CFG and
  Ghidra cross-check.
- `analysis_db.py`: entities, references, ABI facts and provenance-bearing type
  constraints with conflict detection.

### Matching

- `compiler.py`: isolated profile execution, tool/source/output hashes and cache.
- `compiler_lab.py`: bounded flag matrix/ranking.
- `toolchains.py`: user-owned toolchain registry and tamper verification.
- `exe_diff.py`: linked PE function versus COFF symbol comparison.
- `abi.py`: bounded static ABI observations.
- `hybrid.py`: exact-byte assembly fallback tree.
- `patching.py`: hash-gated PE copy patch plus checksum.
- `relink.py`: real manifest-driven linker invocation and optional image comparison.
- `objdiff_adapter.py`: exact manifest-driven objdiff CLI execution and provenance.
- `decompme.py`: local per-function scratch packets with no automatic upload.

### Functional

- `dynamic.py`: bounded Unicorn harness comparison.
- `symbolic.py`: bounded Capstone/Z3 comparison.
- `angr_backend.py`: optional bounded angr path comparison.
- `dynamorio.py`: explicit drcov execution and text-log normalization.
- `integration.py`: explicit-consent process scenarios comparing declared streams, exit codes and files.

### Governance and operation

- `evidence.py`: copied evidence and triple-source claim gate.
- `mcp.py`: stdio/HTTP MCP clients and signed mutation journal.
- `work_queue.py`: evidence/validator-gated human/AI work.
- `benchmarks.py`: decomposed benchmark metrics.
- `service.py`: local read-only API/dashboard.
- `memory.py`: hash-chained project memory.

## Critical limitations to retain

- Linked PE images do not preserve every original object/linker decision.
- Relocation masking is only as complete as modeled relocation/reference evidence.
- Synthetic COFF relocations are caller-supplied; they are not magically reconstructed.
- ABI checks are necessary observations, not complete calling-context proof.
- Unicorn harnesses model declared memory/registers/stubs, not a Windows process.
- Built-in and angr symbolic results are finite/model-specific and subject to path and
  instruction limits.
- DynamoRIO records observed paths, not unreachable-path proof.
- Integration scenarios cover only declared commands, inputs, observations and environments; wrapper isolation is not certified by the toolkit.
- An objdiff adapter records the external tool result but does not convert it into stronger PE matching evidence.
- Manifest-driven relink is real execution but not generic original-linker inference.
- x86-64 exception/unwind/runtime-function metadata is parsed, but full C++ exception
  reconstruction remains target/compiler specific.
- Live Ghidra and proprietary compiler behavior requires installation-specific testing.

## Required durable event categories

- `project`, `decision`, `fact`, `hypothesis`, `compiler`, `function`, `type`, `abi`,
  `matching`, `functional`, `mcp-read`, `mcp-mutation`, `benchmark`, `blocker`, `tool`,
  `risk`, `rollback`.

A durable event should state stable IDs, old/new state, command/change, report paths,
input/output hashes, evidence IDs, contradictions and rollback information. Memory may
record a hypothesis but may never relabel it as fact without the evidence gate.
