#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
python3 -m compileall -q src tests scripts
python3 scripts/validate-contracts.py
PYTHONPATH=src python3 -m pytest -q
