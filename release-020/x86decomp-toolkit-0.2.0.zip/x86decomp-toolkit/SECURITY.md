# Security policy

Treat every analyzed binary, PDB, project archive, compiler, linker, objdiff build,
MCP server, Ghidra installation, trace, script, and generated source file as untrusted.

## Execution boundaries

- `init`, `inspect-pe`, manifest verification, COFF parsing, and static artifact export
  do not execute the target.
- `dynamic-validate` executes supplied function bytes inside Unicorn, but malformed code
  may still exercise emulator bugs. Use process/container isolation for hostile inputs.
- `drcov-run` launches a real executable through DynamoRIO. Run it only in a disposable
  VM/sandbox with controlled network, filesystem, credentials, devices, and snapshots.
- `integration-run` rejects host execution unless the manifest acknowledges the risk and
  the operator supplies `--allow-host-execution`. Unknown targets belong behind an
  `external_wrapper` such as a disposable VM runner. The toolkit records but cannot
  certify that a wrapper is a complete security boundary.
- Compiler, linker, objdiff, and toolchain profiles execute external programs without a
  shell. Review executable paths, hashes, arguments, environment, and input files.
- Historical proprietary compilers are user-supplied and must not be redistributed.

## Data and path controls

- Original binaries and attached evidence are copied or referenced with SHA-256 seals.
- Imported function artifacts reject symlinks and path traversal.
- Integration fixtures and observed files are confined beneath per-run work directories.
- Patch operations write a new image and support original/function hash gates.
- Ghidra scripts write beneath the supplied output directory.
- Local decomp.me packets never upload data. Public upload is an operator/legal decision.

## MCP and service controls

- MCP is read-only by default. Mutations require an allowlist, evidence, rationale, a
  persisted proposal hash, and an exact commit. Re-export and validate after mutation.
- The FastAPI dashboard is read-only but has no built-in authentication or multi-tenant
  authorization. Bind to loopback or place behind a trusted gateway.
- Never expose proprietary binaries, source, traces, or evidence through public services
  without authorization.

## Reporting vulnerabilities

Report vulnerabilities with the affected version, operating system, exact command,
minimal reproducer, expected/actual result, and security impact. Do not include
third-party proprietary material.
