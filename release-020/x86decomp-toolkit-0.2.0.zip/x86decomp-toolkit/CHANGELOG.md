# Changelog

## 0.2.0 — 2026-06-27

### Two-mode workflow

- Added independent per-function `matching` and `functional` modes.
- Added monotonic matching states through `full_relink_validated`.
- Added monotonic functional states through `integration_validated`.
- Added explicit blockers, candidates, compiler profiles, report links, audited
  regressions, and memory events.

### Binary formats and static analysis

- Added PE32+/AMD64 parsing alongside PE32/i386.
- Added bounded parsing for resources, delay imports, load configuration, x64 runtime
  functions, exports, imports, relocations, debug/CodeView and TLS.
- Added i386/AMD64 COFF parsing, symbols, relocations, symbol extraction and synthetic
  object generation.
- Expanded Ghidra exports with decompiler token trees, raw/high P-code JSONL, exact
  discontiguous ranges, references, types, symbols and metrics.
- Added Capstone x86/x64 instruction normalization, CFG extraction and Ghidra
  cross-checking.
- Added SQLite entity/reference/ABI/type-constraint storage with conflict detection.

### Matching mode

- Added linked PE function to COFF symbol comparison.
- Added raw byte, relocation-normalized, instruction and CFG classifications.
- Added compiler result caching and bounded flag-matrix experiments.
- Added hash-pinned user-owned historical toolchain registry.
- Added static ABI contracts for x86 conventions and x64 observations.
- Added continuously buildable exact-byte assembly fallback projects.
- Added hash-gated PE copy patching and PE checksum regeneration.
- Added real manifest-driven linker invocation and optional image comparison.
- Added manifest-driven external objdiff execution with full tool/input/output
  provenance.
- Added local decomp.me-style packet generation with no automatic upload.

### Functional mode

- Added bounded Unicorn target/candidate differential execution.
- Added deterministic external-call summaries and explicit register/memory observations.
- Added bounded Capstone/Z3 symbolic comparison and an optional angr backend.
- Added DynamoRIO drcov execution and text-log parsing.
- Added explicit-consent integration scenario execution with target/candidate exit,
  stream and file comparison, separate work trees, and external-wrapper support.

### Governance, orchestration and service

- Added stdio and Streamable HTTP MCP clients.
- Added read-only MCP defaults and hash-approved, evidence-backed mutation transactions.
- Added validator-gated human/AI work queue.
- Added decomposed benchmark corpus runner and metrics.
- Added local read-only FastAPI JSON service/dashboard.
- Added machine-readable schemas for every implemented subsystem.
- Upgraded the evidence-engineer skill to version 2.0.0 with strict truth, security,
  mode, validation and completion contracts.

### Verification

- Expanded the suite to 33 passing tests.
- Added real GCC `-m32`, `lld-link`, Unicorn, Z3, angr, subprocess integration, MCP
  protocol, hybrid Makefile and external-tool adapter checks.
- Added full contract/example validation and Java syntax parsing.

## 0.1.0 — 2026-06-27

- Added project-owned immutable evidence copies and integrity path confinement.
- Added function-artifact import/verification CLI commands and path traversal tests.
- Added compiler executable hashing, unknown-token rejection, and stale-output removal.
- Added an explicit package verification record.
- Added a standard-library-only Python orchestration core.
- Added strict PE32/x86 parsing, project initialization, immutable hashes, and verification.
- Added evidence claims with a three-independent-source verification gate.
- Added tamper-evident project-memory events.
- Added compiler profile execution and byte-level verification reports.
- Added Ghidra project/function exporters and analysis query script.
- Added schemas, contracts, guardrails, CI, tests, and an agent skill.
