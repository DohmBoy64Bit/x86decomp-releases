# Security model

## Default-deny operations

The suite defaults to:

- no network access;
- no automatic installation;
- no execution of uploaded or target Windows binaries;
- no use of undeclared custom environment variables.

Enabling installation does not automatically enable network access. Both flags are independently required for network-backed installers.

## Process execution

The suite executes toolkit commands, compilers, linkers, adapter version commands, a generated minimal PE through Ghidra static analysis, and a harmless host executable under DynamoRIO. It does not natively execute analyzed target PE files.

`allow_host_execution` is reserved for tests that require host-program execution; future tests must check it before launching arbitrary user-selected programs.

## Downloads

Network downloads:

- use official configured repositories;
- record source URL, release tag, asset name, destination, and SHA-256;
- enforce a maximum size;
- reject path traversal and links during extraction;
- extract into a temporary directory before replacing the active installation.

The suite does not currently provide a vendor-signed checksum trust root. A logged SHA-256 proves repeatability of the downloaded bytes, not publisher authenticity.

## Privilege boundary

Package-manager installation may require elevation. The suite displays/logs the exact command and invokes the platform package manager; it does not capture administrator passwords. Run automatic installation only in a disposable or trusted development environment.

## Secrets

Detailed logs include commands, paths, versions, and selected environment configuration. Do not put credentials or secrets in adapter paths, command-line arguments, or `custom_environment`.
