# Changelog

## 0.3.0

- Added exact feature catalog for x86decomp-toolkit 0.3.0.
- Added inventory drift enforcement for modules, commands, schemas, and Ghidra scripts.
- Added AST/coverage correlation for every public toolkit function and method.
- Added all-command CLI parse testing.
- Added no-pytest-skip JUnit enforcement.
- Added source-manifest, JSON Schema, Java syntax, skill-frontmatter, and compileall validation.
- Added clean wheel/source-distribution build and clean-wheel installation tests.
- Added detection-first adapter resolution with custom-path prompts only for missing tools.
- Added opt-in Python, package-manager, and official-release installation paths.
- Added live probes for Python libraries, compilers, linkers, Ghidra, DynamoRIO, objdiff, and build tools.
- Added detailed text, JSONL, JSON, Markdown, HTML, JUnit, and coverage logging.
- Added safe archive extraction and bounded download handling.
- Added harness self-tests covering configuration, detection, prompting, installers, archive safety, inventory, coverage, JUnit, reporting, process handling, and CLI behavior.
