# Repository project memory

This is the durable design memory for the toolkit source repository. Generated
projects maintain their own authoritative `memory/events.jsonl` and rendered memory.

## Mission

Create an evidence-governed decompilation operating system for native Windows x86 and
x86-64 that automates project creation, static extraction, candidate builds, matching,
functional validation, work coordination and durable decisions without pretending to
recover facts erased by compilation.

## Fixed decisions

1. **Two first-class modes.** Matching and functional status are independent for every
   function.
2. **Native PE scope.** PE32/i386 and PE32+/AMD64 are parsed; managed CLR is not treated
   as native decompilation.
3. **Raw bytes are authoritative evidence.** Ghidra, Capstone, compilers, emulators and
   solvers are analysis/validation sources with recorded versions and scope.
4. **Ghidra is the primary decompiler, not the database owner.** Canonical cross-tool
   state lives in project files/SQLite/evidence/memory.
5. **Per-function artifacts are primary.** Monolithic pseudocode is a report only.
6. **Function bodies are address sets.** Discontiguous ranges remain separate.
7. **COFF-aware matching precedes whole-image reconstruction.** PE↔COFF comparison
   records raw, relocation-normalized and instruction results separately.
8. **Functional proof is bounded.** Concrete harnesses, coverage, symbolic models and
   integration scenarios retain their explicit envelope.
9. **Assembly fallback keeps projects buildable.** Decompiler C is not compiled by
   default until promoted.
10. **Historical compilers are user-owned.** Registry entries hash external tools; the
    toolkit does not redistribute proprietary binaries.
11. **Ghidra MCP is read-only by default.** Mutations use evidence-backed signed
    transactions.
12. **AI is a proposer.** Evidence and named validators control acceptance.
13. **Memory is append-only/hash chained.** Markdown is a derived view.
14. **No hidden network upload or target execution.** External execution requires an
    explicit command and operator authorization.
15. **Linker evidence has confidence levels.** Public-symbol object ownership may
    establish order but not byte-accurate contribution extents.
16. **COMDAT decisions are explicit.** Selection, association, winners, discards and
    conflicts are stored rather than flattened into a guessed object layout.
17. **Microsoft metadata recovery is structural.** RTTI, EH, unwind, TLS and initializer
    records are accepted only within validated pointer/count/section bounds.
18. **Whole-image normalization is target specific.** Every ignored byte range is tied
    to the exact reference hash and a named reason.
19. **Symbolic memory is model scoped.** Alias relationships, region sizes, selected
    observations and path completion are part of the result identity.
20. **Uploaded regression bundles are static by default.** Archive creation/inspection
    never executes supplied native code and requires an authorization declaration.
21. **PDB evidence is identity-bound and bounded.** Parse MSF/PDB/TPI/IPI/DBI inventory and require PE RSDS GUID/age correlation; complete CodeView records require separate tooling and evidence.

## Implemented inventory (0.3.0)

### Formats and project

- `pe32.py`, `pe.py`: bounded PE32/PE32+ metadata and directory parsing.
- `coff.py`: classic COFF/bigobj, i386/AMD64 relocations and addends, overflow,
  auxiliary records, weak externals, COMDAT resolution, extraction, and multi-section
  synthetic objects.
- `coff_archive.py`: bounded `.lib`/`.a` members, long-name tables, linker indexes, embedded COFF and import-object records.
- `linker_layout.py`: MSVC/LLD map records, object ownership/order, contribution
  confidence, PE correlation, and COMDAT-aware layout reconstruction.
- `image_match.py`: reference-bound whole-image profiles, relocation rebasing, explicit
  mutable-field normalization, section-layout and byte comparison.
- `pdb.py`: bounded MSF 7.0 streams, PDB identity, TPI/IPI headers, DBI modules, contributions, sources and PE RSDS correlation.
- `msvc_metadata.py`: x86/x64 RTTI/class/vtable structure, x64 unwind, x86 SafeSEH,
  bounded FuncInfo, linked/object TLS and static initializer inventories.
- `project.py`: architecture-aware project initialization/integrity.
- `artifacts.py`: safe function-artifact import/sealing.
- `workflow.py`: matching/functional state machines.

### Static analysis

- Ghidra project/function exporters: ranges, C, token tree, raw/high P-code,
  instructions, references, types, symbols, metrics.
- `disassembly.py`: independent Capstone decode, normalized operands/branches/CFG and
  Ghidra cross-check.
- `analysis_db.py`: entities, references, ABI facts and provenance-bearing type
  constraints with conflict detection.

### Matching

- `compiler.py`: isolated profile execution, tool/source/output hashes and cache.
- `compiler_lab.py`: bounded flag matrix/ranking.
- `toolchains.py`: user-owned toolchain registry and tamper verification.
- `ground_truth.py`: 24-case x86/x64 compiler matrix, exact compiler/version provenance,
  corpus verification, and cross-version/object-layout comparison.
- `exe_diff.py`: linked PE function versus COFF symbol comparison.
- `abi.py`: bounded static ABI observations.
- `hybrid.py`: exact-byte assembly fallback tree.
- `patching.py`: hash-gated PE copy patch plus checksum.
- `relink.py`: real manifest-driven linker invocation and optional image comparison.
- `objdiff_adapter.py`: exact manifest-driven objdiff CLI execution and provenance.
- `decompme.py`: local per-function scratch packets with no automatic upload.
- `test_bundle.py`: deterministic authorized ZIP creation, safe static extraction,
  hashes, bounded PE/COFF/map/metadata/layout/image regression analysis.

### Functional

- `dynamic.py`: bounded Unicorn harness comparison.
- `symbolic.py`: bounded Capstone/Z3 comparison.
- `angr_backend.py`: optional bounded angr path comparison plus symbolic memory
  regions, base-slot alias modeling, byte-addressable observations and counterexamples.
- `dynamorio.py`: explicit drcov execution and text-log normalization.
- `integration.py`: explicit-consent process scenarios comparing declared streams, exit codes and files.

### Governance and operation

- `evidence.py`: copied evidence and triple-source claim gate.
- `mcp.py`: stdio/HTTP MCP clients and signed mutation journal.
- `work_queue.py`: evidence/validator-gated human/AI work.
- `benchmarks.py`: decomposed benchmark metrics.
- `service.py`: local read-only API/dashboard.
- `memory.py`: hash-chained project memory.

## Critical limitations to retain

- Linked PE images do not preserve every original object/linker decision.
- Relocation masking is only as complete as modeled relocation/reference evidence.
- Synthetic COFF relocations are caller-supplied; they are not magically reconstructed.
- ABI checks are necessary observations, not complete calling-context proof.
- Unicorn harnesses model declared memory/registers/stubs, not a Windows process.
- Built-in and angr symbolic results are finite/model-specific and subject to path and
  instruction limits.
- DynamoRIO records observed paths, not unreachable-path proof.
- Integration scenarios cover only declared commands, inputs, observations and environments; wrapper isolation is not certified by the toolkit.
- An objdiff adapter records the external tool result but does not convert it into stronger PE matching evidence.
- Manifest-driven relink is real execution but not generic original-linker inference.
- x86-64 exception/unwind/runtime-function metadata is parsed, but full C++ exception
  reconstruction remains target/compiler specific.
- Live Ghidra and proprietary compiler behavior requires installation-specific testing.

## Version 0.3 bounded-production position

Version 0.3 deepens every requested milestone and preserves the version 0.2 command
surface. It is suitable as a production-oriented framework for authorized,
target-specific projects with controlled inputs and explicit validators. It does not
make generic binary-to-original-source recovery, perfect object partitioning, complete
CodeView record import, arbitrary C++ EH recovery, or all-input equivalence decidable.

Current remaining depth work is target and environment dependent:

- live validation against the operator's Ghidra build, DynamoRIO installation,
  objdiff version, historical MSVC toolsets, PDBs, maps and real commercial images;
- deeper archive directive/default-library and linker-generated symbol semantics beyond the bounded member/import inventory;
- compiler-specific x86 EH map decoding and x64 language-specific data interpretation;
- allocator, heap object, overlapping-region and external-library summaries for
  symbolic models;
- target-specific linker script/order/padding refinement until a chosen image reaches
  its declared raw or normalized gate.

These are recorded as bounded follow-on engineering, not hidden behind success shims.

## Required durable event categories

- `project`, `decision`, `fact`, `hypothesis`, `compiler`, `function`, `type`, `abi`,
  `matching`, `functional`, `mcp-read`, `mcp-mutation`, `benchmark`, `blocker`, `tool`,
  `risk`, `rollback`.

A durable event should state stable IDs, old/new state, command/change, report paths,
input/output hashes, evidence IDs, contradictions and rollback information. Memory may
record a hypothesis but may never relabel it as fact without the evidence gate.
