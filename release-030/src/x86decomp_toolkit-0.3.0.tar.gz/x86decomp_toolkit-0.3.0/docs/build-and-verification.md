# Build and verification

## Development environment

```bash
python -m pip install -e '.[disassembly,dynamic,symbolic,service,dev]'
make verify
```

`make verify` performs:

1. Python bytecode compilation for source, tests and scripts.
2. Draft 2020-12 schema self-validation.
3. Validation of shipped compiler, harness, ABI, laboratory, benchmark and relink examples.
4. Java syntax parsing for every Ghidra script.
5. The complete pytest suite.

Tests exercise real 32-bit object compilation, hybrid assembly generation, PE32 and
PE32+ parsing, PE patch/checksum handling, COFF/bigobj/archive parsing and synthesis, `lld-link` relinking
when available, Capstone decode, ABI checks, Unicorn execution, Z3 comparison, MCP
stdio transactions, evidence gates and tamper detection.

## Package build

```bash
make package
python -m pip install dist/x86decomp_toolkit-0.3.0-py3-none-any.whl
x86decomp --help
```

The wheel contains the Python package. The source archive/ZIP contains Java scripts,
schemas, examples, docs and the skill.

## Ghidra runtime verification

Java syntax validation does not prove runtime API compatibility. Run:

```bash
GHIDRA_HOME=/path/to/ghidra \
  scripts/verify-ghidra.sh path/to/authorized-sample.exe /tmp/x86decomp-ghidra
```

The script imports/analyzes the sample, exports project and function artifacts, parses
every JSON/JSONL record and checks required artifact files.

## External backend verification

- `drcov-run` requires a compatible DynamoRIO installation and an executable runnable
  in the selected isolated environment.
- `angr-validate` requires the optional angr extra.
- historical MSVC profiles require operator-owned compiler installations.
- full relink behavior depends on the declared linker and objects.

Every external run must preserve command, tool hash/version where available, input
hashes, output hashes, stdout/stderr, return code and timeout state.
