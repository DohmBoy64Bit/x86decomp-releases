# Changelog

## 0.3.0 — 2026-06-28

### COFF, COMDAT, and layout

- Added classic COFF and ANON_OBJECT_HEADER_BIGOBJ parsing under one compatible API.
- Added broader i386/AMD64 relocation names, widths, PC-relative classification,
  in-place addends, relocation-overflow handling, alignment decoding, and long names.
- Added section-definition, function-definition, weak-external, file, and raw auxiliary
  records; fixed real Clang weak-external storage-class handling.
- Added COMDAT resolution for NODUPLICATES, ANY, SAME_SIZE, EXACT_MATCH, ASSOCIATIVE,
  LARGEST, and NEWEST, including conflicts and associative parents.
- Added multi-section synthetic object generation and COMDAT object generation.
- Added MSVC/LLD map parsing, public-symbol object ownership, map/object correlation,
  contribution-vs-public evidence separation, object order, and COMDAT-aware layout
  reconstruction.

### Microsoft C++ and runtime metadata

- Added bounded Microsoft RTTI TypeDescriptor, CompleteObjectLocator, class hierarchy,
  PMD base, and vftable address-point recovery for x86 and x64.
- Added x64 runtime-function and UNWIND_INFO decoding, chained unwind records, handler
  and map-symbol correlation, x86 SafeSEH parsing, and conservative EH FuncInfo scans.
- Added linked TLS template/index/callback reporting and object-level `.tls$*` and
  `.CRT$XL*` subsection inventories.
- Added `.CRT$X*` static-initializer subsection ordering, hashes, relocations, and
  initializer-symbol references.

### Compiler corpus and symbolic depth

- Expanded the bundled freestanding ground-truth corpus to 24 C/C++ cases covering
  bitfields, floating point, loops, varargs, indirect/tail calls, vectorization,
  unions, virtual inheritance, templates, member pointers, and multi-catch EH.
- Added x86/x64, O0/O1/O2/Os, and frame-pointer matrix generation with exact compiler
  executable/version hashes.
- Added cross-report compiler/version corpus comparison without inferring semantic
  equivalence or compiler identity from byte appearance.
- Added symbolic region bases, byte-addressable symbolic memory, selected memory
  observations, and equal/distinct/disjoint/may-alias constraints to the angr backend.

### Whole-image matching and authorized test bundles

- Added reference-hash-bound image profiles, section-layout checks, base-relocation
  rebasing, and explicit timestamp/checksum/certificate/debug normalization ranges.
- Added target-specific raw, profile-normalized, and differing whole-image classes.
- Added deterministic authorized ZIP bundle creation and static inspection.
- Added archive traversal, backslash, drive path, duplicate, symlink, size, expansion,
  authorization, and artifact-hash guardrails.
- Added static PE, COFF, COMDAT, map, metadata, layout, and optional whole-image analysis
  for uploaded bundles without executing supplied code.

### Contracts, skill, and regression

- Added bounded COFF static/import archive parsing with long names, dual linker
  indexes, embedded object/COMDAT inspection, and import-object records.
- Added bounded MSF 7.0/PDB parsing for stream layout, GUID/age identity, TPI/IPI
  headers, DBI modules, section contributions, source mappings, and PE RSDS matching.
- Preserved the 0.2.0 CLI and schema fields while adding the v0.3 command surface.
- Added schemas for COMDAT, image-match, symbolic-memory, compiler comparison, and test
  bundle inputs/reports.
- Upgraded the evidence-engineer skill to 3.0.0 with both mode state machines and
  detailed linker, metadata, corpus, alias, image, upload, and release guardrails.
- Added real Clang COFF/TLS/weak-external and LLVM CodeView image regression tests.
- Expanded the test suite from 33 tests in the 0.2.0 release to the v0.3 verified count
  recorded in `VERIFICATION.md`.

## 0.2.0 — 2026-06-27

### Two-mode workflow

- Added independent per-function `matching` and `functional` modes.
- Added monotonic matching states through `full_relink_validated`.
- Added monotonic functional states through `integration_validated`.
- Added explicit blockers, candidates, compiler profiles, report links, audited
  regressions, and memory events.

### Binary formats and static analysis

- Added PE32+/AMD64 parsing alongside PE32/i386.
- Added bounded parsing for resources, delay imports, load configuration, x64 runtime
  functions, exports, imports, relocations, debug/CodeView and TLS.
- Added i386/AMD64 COFF parsing, symbols, relocations, symbol extraction and synthetic
  object generation.
- Expanded Ghidra exports with decompiler token trees, raw/high P-code JSONL, exact
  discontiguous ranges, references, types, symbols and metrics.
- Added Capstone x86/x64 instruction normalization, CFG extraction and Ghidra
  cross-checking.
- Added SQLite entity/reference/ABI/type-constraint storage with conflict detection.

### Matching mode

- Added linked PE function to COFF symbol comparison.
- Added raw byte, relocation-normalized, instruction and CFG classifications.
- Added compiler result caching and bounded flag-matrix experiments.
- Added hash-pinned user-owned historical toolchain registry.
- Added static ABI contracts for x86 conventions and x64 observations.
- Added continuously buildable exact-byte assembly fallback projects.
- Added hash-gated PE copy patching and PE checksum regeneration.
- Added real manifest-driven linker invocation and optional image comparison.
- Added manifest-driven external objdiff execution with full tool/input/output
  provenance.
- Added local decomp.me-style packet generation with no automatic upload.

### Functional mode

- Added bounded Unicorn target/candidate differential execution.
- Added deterministic external-call summaries and explicit register/memory observations.
- Added bounded Capstone/Z3 symbolic comparison and an optional angr backend.
- Added DynamoRIO drcov execution and text-log parsing.
- Added explicit-consent integration scenario execution with target/candidate exit,
  stream and file comparison, separate work trees, and external-wrapper support.

### Governance, orchestration and service

- Added stdio and Streamable HTTP MCP clients.
- Added read-only MCP defaults and hash-approved, evidence-backed mutation transactions.
- Added validator-gated human/AI work queue.
- Added decomposed benchmark corpus runner and metrics.
- Added local read-only FastAPI JSON service/dashboard.
- Added machine-readable schemas for every implemented subsystem.
- Upgraded the evidence-engineer skill to version 2.0.0 with strict truth, security,
  mode, validation and completion contracts.

### Verification

- Expanded the suite to 33 passing tests.
- Added real GCC `-m32`, `lld-link`, Unicorn, Z3, angr, subprocess integration, MCP
  protocol, hybrid Makefile and external-tool adapter checks.
- Added full contract/example validation and Java syntax parsing.

## 0.1.0 — 2026-06-27

- Added project-owned immutable evidence copies and integrity path confinement.
- Added function-artifact import/verification CLI commands and path traversal tests.
- Added compiler executable hashing, unknown-token rejection, and stale-output removal.
- Added an explicit package verification record.
- Added a standard-library-only Python orchestration core.
- Added strict PE32/x86 parsing, project initialization, immutable hashes, and verification.
- Added evidence claims with a three-independent-source verification gate.
- Added tamper-evident project-memory events.
- Added compiler profile execution and byte-level verification reports.
- Added Ghidra project/function exporters and analysis query script.
- Added schemas, contracts, guardrails, CI, tests, and an agent skill.
