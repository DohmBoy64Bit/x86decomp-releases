---
title: test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py
description: Test source reference for test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py`

**SHA-256:** `d2b5626de04bac6ee52935b4db6e5437c56a6edf94ef300504008eccdf4d7812`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_installed_adapter_never_prompts` | function | 20 | 31 |
| `test_missing_adapter_prompts_custom_path_then_accepts` | function | 34 | 51 |
| `test_missing_noninteractive_is_explicit_unresolved` | function | 54 | 59 |
| `test_environment_and_configured_root_detection` | function | 62 | 77 |
| `test_path_detection_preserves_symlink_argv0` | function | 79 | 89 |
| `test_missing_python_adapter_accepts_custom_interpreter` | function | 91 | 98 |
