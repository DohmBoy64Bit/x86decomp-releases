# Project memory — x86decomp-toolkit 0.7.4

## Durable architecture decision

The toolkit is a unified current-release product. All retained behavior lives in capability-oriented current modules. Release-numbered implementations, executables, bridges, installers, overlays, reports, and test baselines are not part of the active repository.

## Stable product decisions

- `x86decomp` is the only toolkit executable.
- `x86decomp-test` is the only verification executable.
- The canonical interface contains 33 groups and 173 routes.
- Governance, reconstruction, native PE work, and assembly materialization are current capability packages.
- Byte-form assembly is the default exact-preservation path.
- Matching and functional validation are separate state machines.
- Project schemas are additive and namespaced by capability.
- External tools are optional adapters whose absence is reported as BLOCKED, never skipped silently.
- Native execution requires consent and bounded isolation.
- Every release must update the recursive catalog and synchronized architecture artifacts.

## Release discipline

The source tree is distributed as a complete release. Package managers or replacement source archives handle installation. The toolkit does not mutate an older source tree through embedded release installers.
