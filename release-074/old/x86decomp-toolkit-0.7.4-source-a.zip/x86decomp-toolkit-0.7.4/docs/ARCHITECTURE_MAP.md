# Toolkit architecture map — 0.7.4

Plain-text companion: `docs/ARCHITECTURE_MAP_ASCII.txt`  
Verification companion: `test-suite/docs/ARCHITECTURE_MAP.md` and `test-suite/docs/ARCHITECTURE_MAP_ASCII.txt`

```mermaid
flowchart LR
  ING[Immutable ingestion] --> STATIC[Static-analysis plane]
  STATIC --> CONTROL[Project control plane]
  CONTROL --> CANDIDATE[Candidate-generation plane]
  CANDIDATE --> BUILD[Compiler and linker plane]
  BUILD --> MATCH[Matching-decompilation lane]
  BUILD --> FUNCTIONAL[Functional-decompilation lane]
  MATCH --> ACCEPT[Acceptance, evidence, and feedback]
  FUNCTIONAL --> ACCEPT

  CLI[x86decomp unified CLI] --> CORE[Core command plane]
  CLI --> ROUTER[33 groups / 173 routes]
  ROUTER --> GOV[Governance]
  ROUTER --> RECON[Reconstruction]
  ROUTER --> NATIVE[Native PE]
  ROUTER --> ASM[Assembly]
  GOV --> CONTROL
  RECON --> CANDIDATE
  NATIVE --> MATCH
  ASM --> BUILD

  MATCH --> M0[not_started]
  M0 --> M1[instruction_similar]
  M1 --> M2[full_relink_validated]
  FUNCTIONAL --> F0[not_started]
  F0 --> F1[differentially_validated]
  F1 --> F2[symbolically_bounded]
  F2 --> F3[integration_validated]
```

## Boundaries

- Immutable ingestion records artifacts before interpretation.
- Static analysis does not imply runtime behavior.
- Project control preserves evidence, audit, review, and workflow state.
- Candidate generation produces proposals, not facts.
- Compiler and linker evidence is preserved with exact commands and hashes.
- Matching and functional lanes remain separate.
- Acceptance requires the named verifier and durable evidence.
- The active tree contains one current command plane and no release-specific execution plane.
