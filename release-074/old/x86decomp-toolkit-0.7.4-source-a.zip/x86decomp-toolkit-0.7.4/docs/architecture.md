# Architecture — 0.7.4

The toolkit has one current command plane and four capability packages layered over shared project, evidence, workflow, and adapter services.

1. `x86decomp.cli` registers core commands and the canonical capability router.
2. `x86decomp.canonical` exposes 33 groups and 173 routes.
3. `x86decomp.governance` manages hypotheses, campaigns, reviews, proofs, workers, consensus, and audit evidence.
4. `x86decomp.reconstruction` manages modules, translation units, headers, builds, ABI contracts, provenance, libraries, generated tests, capsules, and semantic changesets.
5. `x86decomp.native` manages PE boundaries, function slots, matching, patch planning, hybrid composition, staging context, closed loops, runtime checks, and Windows tools.
6. `x86decomp.assembly` manages byte, annotated, and mnemonic materialization plus relocation resolution and round-trip evidence.
7. Root modules provide binary parsing, compilation, diffing, orchestration, symbolic and dynamic validation, project state, security, and reproducibility.
8. `x86decomp_testkit` recursively inventories and verifies the complete current surface.

The active repository contains no source-tree release migration plane.
