# Test-suite changelog

## 0.7.4

- Replaced release-baseline and delta verification with one recursive current-surface catalog.
- Added recursive module, function/method, and nested-schema discovery.
- Removed version-specific coverage auditors, executable-shim tests, installer tests, and upgrade-report checks.
- Pinned one toolkit executable and one test-suite executable.
- Added historical-reference, upgrade-artifact, placeholder, documentation, and exact-entry-point gates.
- Preserved adapter detection, safe installation, process isolation, no-silent-skip behavior, reporting, packaging checks, and coverage floors.
