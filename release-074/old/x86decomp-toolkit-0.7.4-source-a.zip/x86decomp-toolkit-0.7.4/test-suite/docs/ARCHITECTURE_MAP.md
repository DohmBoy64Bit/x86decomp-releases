# Test-suite architecture map — 0.7.4

Toolkit map: `docs/ARCHITECTURE_MAP.md`  
Plain-text companion: `test-suite/docs/ARCHITECTURE_MAP_ASCII.txt`

```mermaid
flowchart LR
  CONFIG[Configuration] --> RESOLVE[Adapter resolution]
  RESOLVE --> INSTALLED[installed adapter]
  RESOLVE --> CUSTOM[custom path]
  RESOLVE --> CONSENT[consent-gated installation]
  RESOLVE --> BLOCKED[BLOCKED]

  CATALOG[Pinned surface] --> INVENTORY[Recursive current inventory]
  INVENTORY --> DRIFT[catalog drift]
  INVENTORY --> BUILTIN[Built-in verification]
  BUILTIN --> PROCESS[Safe process execution]
  PROCESS --> RESULT[Unified result]
  RESULT --> PASS[PASS]
  RESULT --> FAIL[FAIL]
  RESULT --> ERROR[ERROR]
  RESULT --> BLOCKED
  PASS --> GATE[Strict release gate]
  FAIL --> GATE
  ERROR --> GATE
  BLOCKED --> GATE
```

The harness inventories the complete current source tree, schemas, commands, canonical routes, adapters, and function/method bodies. Missing optional integrations are BLOCKED with evidence. Tests cannot be silently skipped.
