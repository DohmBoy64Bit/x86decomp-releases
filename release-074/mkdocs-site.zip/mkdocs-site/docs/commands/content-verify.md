---
title: x86decomp content-verify
description: The v0.7.4 parser declares this command without additional descriptive
  help text.
original_path: commands/content-verify.html
---

<a id="command-content-verify"></a>

Section: Command reference

# `x86decomp content-verify`

The v0.7.4 parser declares this command without additional descriptive help text.

Metadata: current · root command · 1 runnable path

## Help

```
x86decomp content-verify --help
```

Metadata: current · core

## `x86decomp content-verify`

The v0.7.4 parser declares this command without additional descriptive help text.

### Usage

```
x86decomp content-verify [-h] store
```

### Syntax example

```
x86decomp content-verify example
```

### Arguments

| Argument | Source-declared parser metadata |
| --- | --- |
| `store` required · type: _path | No argument help text is declared; parser destination is `store`. |

> **Source basis.** Parser definition: `src/x86decomp/cli.py`; SHA-256 `21e0654ced2f5dd0588adcbedec328613fba524ff1e0a91ef07d63cbbf88288c`. Descriptions above use only parser-declared text or an explicit no-help notice.
