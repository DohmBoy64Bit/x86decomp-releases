---
title: x86decomp reproduce-verify
description: The v0.7.4 parser declares this command without additional descriptive
  help text.
original_path: commands/reproduce-verify.html
---

<a id="command-reproduce-verify"></a>

Section: Command reference

# `x86decomp reproduce-verify`

The v0.7.4 parser declares this command without additional descriptive help text.

Metadata: current · root command · 1 runnable path

## Help

```
x86decomp reproduce-verify --help
```

Metadata: current · core

## `x86decomp reproduce-verify`

The v0.7.4 parser declares this command without additional descriptive help text.

### Usage

```
x86decomp reproduce-verify [-h] project manifest
```

### Syntax example

```
x86decomp reproduce-verify ./work ./output.json
```

### Arguments

| Argument | Source-declared parser metadata |
| --- | --- |
| `project` required · type: _path | No argument help text is declared; parser destination is `project`. |
| `manifest` required · type: _path | No argument help text is declared; parser destination is `manifest`. |

> **Source basis.** Parser definition: `src/x86decomp/cli.py`; SHA-256 `21e0654ced2f5dd0588adcbedec328613fba524ff1e0a91ef07d63cbbf88288c`. Descriptions above use only parser-declared text or an explicit no-help notice.
