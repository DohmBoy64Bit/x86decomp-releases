"""Additive integration hook for the legacy x86decomp CLI.

The v0.5 command surface is exposed as the single legacy-safe top-level command
`v050`. The standalone `x86decomp-v050` entry point remains available.
"""
from __future__ import annotations

import argparse
from typing import Any

from .v050.cli import main as v050_main


def register_v050_commands(subparsers: Any) -> None:
    parser = subparsers.add_parser("v050", help="v0.5 evidence-driven convergence control plane")
    parser.add_argument("v050_args", nargs=argparse.REMAINDER)
    parser.set_defaults(_v050_handler=lambda args: v050_main(args.v050_args))
