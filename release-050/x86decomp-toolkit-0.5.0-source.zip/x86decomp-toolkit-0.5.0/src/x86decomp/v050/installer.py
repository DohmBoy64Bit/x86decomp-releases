from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import tomllib
import zipfile
from pathlib import Path
from typing import Any

from .common import ContractError, sha256_file, utc_now

OVERLAY_DIRS = ["src/x86decomp/v050", "schemas/v050", "tests/v050", "test-suite/tests/v050", "test-suite/src/x86decomp_testkit/data", "docs/releases/0.5.0"]
OVERLAY_FILES = [
    "MANIFEST.in",
    "test-suite/MANIFEST.in",
    "src/x86decomp/v050_cli.py", "src/x86decomp/cli.py", "src/x86decomp/worker.py",
    "docs/ARCHITECTURE_MAP.md", "docs/ARCHITECTURE_MAP_ASCII.txt",
    "test-suite/docs/ARCHITECTURE_MAP.md", "test-suite/docs/ARCHITECTURE_MAP_ASCII.txt",
    "test-suite/docs/TEST_PLAN.md", "skills/x86decomp/SKILL.md", "docs/v050-evidence-convergence.md",
    "scripts/apply-v050-upgrade.py", "scripts/build-v050-overlay.py", "scripts/validate-contracts.py",
    "test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py",
    "test-suite/tests/test_inventory_reports_process.py",
    "test-suite/README.md",
    "test-suite/MAINTENANCE.md",
    "test-suite/VERIFICATION.md",
    "test-suite/CHANGELOG.md",
    "test-suite/INTEGRATION.md",
    "test-suite/SECURITY.md",
    "test-suite/docs/ARCHITECTURE.md",
    "test-suite/docs/LOGGING.md",
    "test-suite/src/x86decomp_testkit/__init__.py",
    "test-suite/src/x86decomp_testkit/adapters/download.py",
]

MANIFEST_NAME = "MANIFEST.sha256"
MANIFEST_EXCLUDED_DIRS = {
    ".git", ".hg", ".svn", ".pytest_cache", "__pycache__", "build", "dist",
    ".venv", "venv", "test-results", ".x86decomp-upgrade-backups",
}
MANIFEST_EXCLUDED_FILES = {
    ".coverage", "coverage.json", "coverage.xml", "junit.xml", "overlay.zip.tmp",
}

EXPECTED_SUPERSESSION_FILES = {
    "MANIFEST.in",
    "test-suite/MANIFEST.in",
    "src/x86decomp/cli.py",
    "src/x86decomp/worker.py",
    "scripts/validate-contracts.py",
    "test-suite/src/x86decomp_testkit/data/feature_catalog.json",
    "test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py",
    "test-suite/tests/test_inventory_reports_process.py",
    "test-suite/README.md",
    "test-suite/MAINTENANCE.md",
    "test-suite/VERIFICATION.md",
    "test-suite/CHANGELOG.md",
    "test-suite/INTEGRATION.md",
    "test-suite/SECURITY.md",
    "test-suite/src/x86decomp_testkit/__init__.py",
    "test-suite/src/x86decomp_testkit/adapters/download.py",
}

ROOT_DOC_FRAGMENTS = {
    "README.md": "docs/releases/0.5.0/README.md",
    "CHANGELOG.md": "docs/releases/0.5.0/CHANGELOG.md",
    "FEATURE_PARITY.md": "docs/releases/0.5.0/FEATURE_PARITY.md",
    "PROJECT_MEMORY.md": "docs/releases/0.5.0/PROJECT_MEMORY.md",
    "SECURITY.md": "docs/releases/0.5.0/SECURITY.md",
    "AGENTS.md": "docs/releases/0.5.0/AGENTS.md",
    "VERIFICATION.md": "docs/releases/0.5.0/VERIFICATION.md",
}



def _tree_hashes(root: Path) -> dict[str, str]:
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink():
            result[path.relative_to(root).as_posix()] = sha256_file(path)
    return result


def _manifest_path_is_excluded(relative: Path) -> bool:
    if relative == Path(MANIFEST_NAME):
        return True
    if relative.name in MANIFEST_EXCLUDED_FILES or relative.suffix in {".pyc", ".pyo"}:
        return True
    return any(part in MANIFEST_EXCLUDED_DIRS or part.endswith(".egg-info") for part in relative.parts)


def _manifest_entries(root: Path) -> list[tuple[str, str]]:
    entries: list[tuple[str, str]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(root)
        if _manifest_path_is_excluded(relative):
            continue
        entries.append((sha256_file(path), relative.as_posix()))
    return entries


def _write_sha256_manifest(root: Path) -> str:
    manifest = root / MANIFEST_NAME
    payload = "".join(f"{digest}  {name}\n" for digest, name in _manifest_entries(root))
    manifest.write_text(payload, encoding="utf-8", newline="\n")
    return manifest.relative_to(root.parent).as_posix()


def _regenerate_existing_manifests(staged: Path) -> list[str]:
    regenerated: list[str] = []
    suite_root = staged / "test-suite"
    suite_manifest = suite_root / MANIFEST_NAME
    root_manifest = staged / MANIFEST_NAME
    # Preserve the inherited manifest contract only when the source tree already had it.
    # The nested suite is sealed first so the root manifest captures its final digest.
    if suite_manifest.is_file():
        _write_sha256_manifest(suite_root)
        regenerated.append("test-suite/MANIFEST.sha256")
    if root_manifest.is_file():
        _write_sha256_manifest(staged)
        regenerated.append("MANIFEST.sha256")
    return regenerated


def _verify_sha256_manifest(root: Path) -> None:
    manifest = root / MANIFEST_NAME
    if not manifest.is_file():
        return
    seen: set[str] = set()
    for line_number, raw in enumerate(manifest.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        try:
            digest, name = raw.split("  ", 1)
        except ValueError as exc:
            raise ContractError(f"malformed {manifest}: line {line_number}") from exc
        if len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest):
            raise ContractError(f"invalid SHA-256 in {manifest}: line {line_number}")
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts or "\\" in name or ":" in name:
            raise ContractError(f"unsafe manifest path in {manifest}: {name}")
        normalized = relative.as_posix()
        if normalized in seen:
            raise ContractError(f"duplicate manifest path in {manifest}: {normalized}")
        seen.add(normalized)
        target = root / relative
        if not target.is_file() or target.is_symlink():
            raise ContractError(f"missing manifest member: {target}")
        if sha256_file(target) != digest:
            raise ContractError(f"manifest hash mismatch: {target}")



def _project_version(pyproject: Path) -> str:
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    return str(data.get("project", {}).get("version", ""))


def _patch_pyproject(text: str) -> str:
    lines = text.splitlines()
    section = ""
    version_done = False
    script_entries = {
        "x86decomp-v050": 'x86decomp-v050 = "x86decomp.v050.cli:main"',
        "x86decomp-apply-v050": 'x86decomp-apply-v050 = "x86decomp.v050.installer:main"',
    }
    scripts_seen: set[str] = set()
    scripts_section_seen = False
    package_data_seen = False
    package_data_section_seen = False
    output: list[str] = []

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            if section == "project.scripts":
                for name, entry in script_entries.items():
                    if name not in scripts_seen:
                        output.append(entry)
                        scripts_seen.add(name)
            if section == "tool.setuptools.package-data" and not package_data_seen:
                output.append('"x86decomp.v050" = ["py.typed", "data/*.zip"]')
                package_data_seen = True
            section = stripped[1:-1]
            scripts_section_seen = scripts_section_seen or section == "project.scripts"
            package_data_section_seen = package_data_section_seen or section == "tool.setuptools.package-data"
        if section == "project" and stripped.startswith("version") and "=" in line:
            prefix = line[: len(line) - len(line.lstrip())]
            line = f'{prefix}version = "0.5.0"'
            version_done = True
        if section == "project.scripts":
            for name, entry in script_entries.items():
                if stripped.startswith(name):
                    line = entry
                    scripts_seen.add(name)
                    break
        if section == "tool.setuptools.package-data" and stripped.startswith('"x86decomp.v050"'):
            line = '"x86decomp.v050" = ["py.typed", "data/*.zip"]'
            package_data_seen = True
        output.append(line)
    if section == "project.scripts":
        for name, entry in script_entries.items():
            if name not in scripts_seen:
                output.append(entry)
                scripts_seen.add(name)
    if section == "tool.setuptools.package-data" and not package_data_seen:
        output.append('"x86decomp.v050" = ["py.typed", "data/*.zip"]')
        package_data_seen = True
    if not version_done:
        raise ContractError("could not locate [project] version in pyproject.toml")
    if not scripts_section_seen:
        output.extend(["", "[project.scripts]"])
        for name, entry in script_entries.items():
            output.append(entry)
            scripts_seen.add(name)
    if not package_data_section_seen:
        output.extend(["", "[tool.setuptools.package-data]", '"x86decomp.v050" = ["py.typed", "data/*.zip"]'])
        package_data_seen = True
    return "\n".join(output) + "\n"



def _merge_marked_release_document(existing: str, fragment: str, name: str) -> str:
    start = f"<!-- X86DECOMP-V050:{name}:START -->"
    end = f"<!-- X86DECOMP-V050:{name}:END -->"
    block = f"{start}\n{fragment.strip()}\n{end}\n"
    if start in existing or end in existing:
        if start not in existing or end not in existing or existing.index(start) > existing.index(end):
            raise ContractError(f"malformed v0.5 release markers in {name}")
        before, remainder = existing.split(start, 1)
        _, after = remainder.split(end, 1)
        return before.rstrip() + "\n\n" + block + after.lstrip("\n")
    if name == "CHANGELOG.md" and existing.lstrip().startswith("# Changelog"):
        heading_end = existing.find("\n")
        return existing[: heading_end + 1].rstrip() + "\n\n" + block + "\n" + existing[heading_end + 1 :].lstrip("\n")
    return existing.rstrip() + "\n\n" + block


def _merge_root_documents(staged: Path, overlay: Path) -> list[str]:
    updated: list[str] = []
    for destination_name, fragment_name in ROOT_DOC_FRAGMENTS.items():
        fragment_path = overlay / fragment_name
        if not fragment_path.is_file():
            raise ContractError(f"missing release document fragment: {fragment_name}")
        destination = staged / destination_name
        existing = destination.read_text(encoding="utf-8") if destination.is_file() else f"# {destination_name.removesuffix('.md').replace('_', ' ').title()}\n"
        merged = _merge_marked_release_document(existing, fragment_path.read_text(encoding="utf-8"), destination_name)
        destination.write_text(merged, encoding="utf-8")
        updated.append(destination_name)
    return updated

def _remove_path(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink(missing_ok=True)
    elif path.is_dir():
        shutil.rmtree(path)


def _restore_backup(target: Path, backup: Path, changed_paths: list[str]) -> None:
    for relative in sorted(set(changed_paths), key=lambda item: (item.count("/"), item), reverse=True):
        _remove_path(target / relative)
    with tarfile.open(backup, "r:gz") as archive:
        for member in archive.getmembers():
            relative = Path(member.name)
            if relative.is_absolute() or ".." in relative.parts or "\\" in member.name or ":" in member.name:
                raise ContractError(f"unsafe backup member: {member.name}")
            if member.issym() or member.islnk() or member.isdev():
                raise ContractError(f"unsupported backup member type: {member.name}")
            destination = target / relative
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            if not member.isfile():
                raise ContractError(f"unsupported backup member: {member.name}")
            source = archive.extractfile(member)
            if source is None:
                raise ContractError(f"unreadable backup member: {member.name}")
            destination.parent.mkdir(parents=True, exist_ok=True)
            with source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)
            os.chmod(destination, member.mode & 0o777)


def _safe_backup(target: Path, paths: list[Path], destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(destination, "w:gz", format=tarfile.PAX_FORMAT) as archive:
        for path in sorted(paths):
            if path.exists():
                if path.is_symlink():
                    raise ContractError(f"refusing to back up symlinked release path: {path}")
                archive.add(path, arcname=path.relative_to(target), recursive=True, filter=lambda info: _normalize_tar(info))


def _normalize_tar(info: tarfile.TarInfo) -> tarfile.TarInfo:
    if info.issym() or info.islnk() or info.isdev():
        raise ContractError(f"refusing unsupported backup member: {info.name}")
    info.uid = info.gid = 0; info.uname = info.gname = ""; info.mtime = 0
    return info


def plan_upgrade(target_root: str | Path, overlay_root: str | Path) -> dict[str, Any]:
    target = Path(target_root).resolve(); overlay = Path(overlay_root).resolve()
    pyproject = target / "pyproject.toml"
    failures = []
    if not pyproject.is_file(): failures.append("missing pyproject.toml")
    if not (target / "src/x86decomp").is_dir(): failures.append("missing src/x86decomp")
    if not (target / "test-suite").is_dir(): failures.append("missing integrated test-suite")
    version = _project_version(pyproject) if pyproject.is_file() else ""
    if version not in {"0.4.0", "0.5.0"}: failures.append(f"expected toolkit 0.4.0 or idempotent 0.5.0, found {version!r}")
    conflicts = []
    for relative in OVERLAY_DIRS:
        source = overlay / relative
        if not source.exists():
            continue
        for source_file in source.rglob("*"):
            if not source_file.is_file() or source_file.is_symlink():
                continue
            destination_file = target / relative / source_file.relative_to(source)
            if destination_file.exists() and version == "0.4.0" and sha256_file(destination_file) != sha256_file(source_file):
                destination_relative = destination_file.relative_to(target).as_posix()
                if destination_relative in EXPECTED_SUPERSESSION_FILES:
                    continue
                conflicts.append(destination_relative)
    for relative in OVERLAY_FILES:
        source = overlay / relative; destination = target / relative
        if destination.exists() and source.exists() and version == "0.4.0" and sha256_file(destination) != sha256_file(source):
            # Canonical docs/skill are expected to change and are backed up, not conflicts.
            if relative.startswith(("docs/", "test-suite/docs/", "skills/")) or relative in EXPECTED_SUPERSESSION_FILES:
                continue
            conflicts.append(relative)
    failures.extend(f"overlay collision: {item}" for item in sorted(set(conflicts)))
    return {"target": str(target), "overlay": str(overlay), "current_version": version, "target_version": "0.5.0", "passed": not failures, "failures": failures, "strategy": "additive namespaced modules with tested, backed-up compatibility supersessions; no legacy capability is removed"}


def apply_upgrade(target_root: str | Path, overlay_root: str | Path, *, dry_run: bool = False, run_tests: bool = True) -> dict[str, Any]:
    target = Path(target_root).resolve(); overlay = Path(overlay_root).resolve()
    plan = plan_upgrade(target, overlay)
    if not plan["passed"]: raise ContractError("upgrade preflight failed: " + "; ".join(plan["failures"]))
    if dry_run: return {**plan, "dry_run": True, "changed": False}
    backup = target / ".x86decomp-upgrade-backups" / f"0.4.0-to-0.5.0-{utc_now().replace(':','').replace('-','')}.tar.gz"
    paths = [target / "pyproject.toml", target / "V050_UPGRADE_REPORT.json"] + [target / p for p in OVERLAY_DIRS + OVERLAY_FILES] + [target / p for p in ROOT_DOC_FRAGMENTS]
    if (target / "test-suite/pyproject.toml").exists(): paths.append(target / "test-suite/pyproject.toml")
    for manifest_name in (MANIFEST_NAME, f"test-suite/{MANIFEST_NAME}"):
        if (target / manifest_name).exists(): paths.append(target / manifest_name)
    _safe_backup(target, paths, backup)
    staging = Path(tempfile.mkdtemp(prefix="x86decomp-v050-stage-", dir=target.parent))
    commit_started = False
    changed_paths: list[str] = []
    try:
        shutil.copytree(target, staging / target.name, symlinks=True, dirs_exist_ok=True)
        staged = staging / target.name
        for relative in OVERLAY_DIRS:
            source = overlay / relative; destination = staged / relative
            if source.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(source, destination, dirs_exist_ok=True)
        for relative in OVERLAY_FILES:
            source = overlay / relative
            if source.exists():
                destination = staged / relative; destination.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source, destination)
        (staged / "pyproject.toml").write_text(_patch_pyproject((staged / "pyproject.toml").read_text(encoding="utf-8")), encoding="utf-8")
        updated_documents = _merge_root_documents(staged, overlay)
        suite_pyproject = staged / "test-suite/pyproject.toml"
        if suite_pyproject.exists():
            text = suite_pyproject.read_text(encoding="utf-8")
            text = text.replace('version = "0.4.0"', 'version = "0.5.0"', 1)
            suite_pyproject.write_text(text, encoding="utf-8")
        expected_manifests = [name for name in (f"test-suite/{MANIFEST_NAME}", MANIFEST_NAME) if (staged / name).is_file()]
        report = {
            "format": "x86decomp-v050-upgrade-report-v1",
            "from": plan["current_version"],
            "to": "0.5.0",
            "applied_at": utc_now(),
            "backup": str(backup.relative_to(target)),
            "legacy_source_deleted": False,
            "legacy_capabilities_removed": False,
            "compatibility_supersessions": sorted(EXPECTED_SUPERSESSION_FILES),
            "root_documents_merged": updated_documents,
            "regenerated_manifests": expected_manifests,
        }
        (staged / "V050_UPGRADE_REPORT.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        regenerated_manifests = _regenerate_existing_manifests(staged)
        if regenerated_manifests != expected_manifests:
            raise ContractError("manifest regeneration plan changed during staging")
        if (staged / "test-suite" / MANIFEST_NAME).is_file(): _verify_sha256_manifest(staged / "test-suite")
        if (staged / MANIFEST_NAME).is_file(): _verify_sha256_manifest(staged)
        commands = [
            [sys.executable, "-m", "compileall", "-q", "src", "tests", "scripts", "test-suite/src", "test-suite/tests"],
            [sys.executable, "scripts/validate-contracts.py"],
            [sys.executable, "-m", "pytest", "-q"],
            [sys.executable, "-m", "pytest", "-q", "test-suite/tests"],
        ] if run_tests else []
        results = []
        for command in commands:
            env = os.environ.copy(); python_paths = [str(staged / "src"), str(staged / "test-suite/src")]; existing_pythonpath = env.get("PYTHONPATH"); python_paths.extend([existing_pythonpath] if existing_pythonpath else []); env["PYTHONPATH"] = os.pathsep.join(python_paths); env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
            completed = subprocess.run(command, cwd=staged, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=3600)
            results.append({"command": command, "returncode": completed.returncode, "output": completed.stdout[-20000:]})
            if completed.returncode != 0:
                raise ContractError(f"upgrade verification failed: {' '.join(command)}\n{completed.stdout[-4000:]}")
        # Replace only after the staged tree passes. Copying rather than renaming keeps
        # the target directory identity stable for callers. Any commit error restores
        # the affected pre-upgrade paths and removes newly created v0.5 paths.
        final_files = OVERLAY_FILES + ["pyproject.toml", "V050_UPGRADE_REPORT.json", *ROOT_DOC_FRAGMENTS, *regenerated_manifests]
        changed_paths = [*OVERLAY_DIRS, *final_files]
        if suite_pyproject.exists(): changed_paths.append("test-suite/pyproject.toml")
        commit_started = True
        for relative in OVERLAY_DIRS:
            source = staged / relative; destination = target / relative
            if source.exists(): shutil.copytree(source, destination, dirs_exist_ok=True)
        for relative in final_files:
            source = staged / relative
            if source.exists():
                destination = target / relative; destination.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source, destination)
        if suite_pyproject.exists(): shutil.copy2(suite_pyproject, target / "test-suite/pyproject.toml")
        commit_started = False
        return {**plan, "dry_run": False, "changed": True, "backup": str(backup), "verification": results, "final_tree_sha256": hashlib.sha256(json.dumps(_tree_hashes(target), sort_keys=True).encode()).hexdigest()}
    except BaseException:
        if commit_started:
            _restore_backup(target, backup, changed_paths)
        raise
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def _default_overlay() -> tuple[Path, Path | None]:
    source_root = Path(__file__).resolve().parents[3]
    if (source_root / "pyproject.toml").is_file() and (source_root / "schemas/v050").is_dir():
        return source_root, None
    archive = Path(__file__).resolve().parent / "data" / "overlay.zip"
    if not archive.is_file():
        raise ContractError("installed upgrade package is missing data/overlay.zip")
    temporary = Path(tempfile.mkdtemp(prefix="x86decomp-v050-overlay-"))
    with zipfile.ZipFile(archive) as bundle:
        for info in bundle.infolist():
            path = Path(info.filename)
            if path.is_absolute() or ".." in path.parts or "\\" in info.filename or ":" in info.filename:
                raise ContractError(f"unsafe packaged overlay member: {info.filename}")
        bundle.extractall(temporary)
    return temporary, temporary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Apply the additive x86decomp-toolkit 0.5.0 upgrade")
    parser.add_argument("target_root"); parser.add_argument("--overlay-root"); parser.add_argument("--dry-run", action="store_true"); parser.add_argument("--no-tests", action="store_true")
    args = parser.parse_args(argv)
    cleanup: Path | None = None
    try:
        if args.overlay_root:
            overlay = Path(args.overlay_root).resolve()
        else:
            overlay, cleanup = _default_overlay()
        print(json.dumps(apply_upgrade(args.target_root,overlay,dry_run=args.dry_run,run_tests=not args.no_tests),indent=2,sort_keys=True)); return 0
    except (ContractError,OSError,ValueError,subprocess.SubprocessError) as exc:
        print(json.dumps({"error":type(exc).__name__,"message":str(exc)},sort_keys=True),file=sys.stderr); return 2
    finally:
        if cleanup is not None:
            shutil.rmtree(cleanup, ignore_errors=True)

if __name__ == "__main__": raise SystemExit(main())
