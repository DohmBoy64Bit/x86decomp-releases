from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "test-suite/src/x86decomp_testkit/data"


def test_every_v040_cataloged_feature_is_retained_in_v050() -> None:
    baseline = json.loads((DATA / "feature_catalog.v040.baseline.json").read_text(encoding="utf-8"))
    current = json.loads((DATA / "feature_catalog.json").read_text(encoding="utf-8"))

    assert baseline["toolkit_version"] == "0.4.0"
    assert current["toolkit_version"] == "0.5.0"
    assert current["compatibility_baseline"] == "0.4.0"

    for key in (
        "modules",
        "all_function_symbols",
        "cli_commands",
        "schemas",
        "ghidra_scripts",
        "adapters",
        "workflow_states",
    ):
        removed = sorted(set(baseline[key]) - set(current[key]))
        assert removed == [], f"0.4.0 {key} removed without a tested supersession: {removed}"

    assert len(current["modules"]) == len(baseline["modules"]) + 1
    assert len(current["all_function_symbols"]) == len(baseline["all_function_symbols"]) + 1
    assert len(current["cli_commands"]) == len(baseline["cli_commands"]) + 1
    assert current["schemas"] == baseline["schemas"]
    assert current["ghidra_scripts"] == baseline["ghidra_scripts"]
    assert current["adapters"] == baseline["adapters"]
    assert current["workflow_states"] == baseline["workflow_states"]
