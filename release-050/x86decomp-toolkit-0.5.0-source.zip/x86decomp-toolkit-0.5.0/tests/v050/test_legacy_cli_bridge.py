from __future__ import annotations

import json

from x86decomp.cli import _build_parser, main


def test_legacy_cli_retains_old_commands_and_adds_v050_bridge() -> None:
    parser = _build_parser()
    choices: set[str] = set()
    for action in parser._actions:
        if action.__class__.__name__ == "_SubParsersAction":
            choices.update(action.choices)
    assert "init" in choices
    assert "release-gate" in choices
    assert "v050" in choices
    assert len(choices) == 107


def test_legacy_v050_bridge_dispatches_without_double_emission(tmp_path, capsys) -> None:
    result = main(["v050", "--project", str(tmp_path), "project", "init"])
    assert result == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["schema_extension_version"] == 4
    assert payload["passed"] is True
    assert payload["database"] == str(tmp_path.resolve() / "state/project-state.sqlite3")
