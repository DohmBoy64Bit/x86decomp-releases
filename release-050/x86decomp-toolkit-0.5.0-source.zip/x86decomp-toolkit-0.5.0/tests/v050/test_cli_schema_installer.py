from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from x86decomp.v050.cli import build_parser, main
from x86decomp.v050.installer import apply_upgrade, plan_upgrade

ROOT=Path(__file__).resolve().parents[2]


def test_every_schema_meta_validates() -> None:
    files=sorted((ROOT/"schemas/v050").glob("*.json")); assert len(files) >= 10
    for path in files: Draft202012Validator.check_schema(json.loads(path.read_text()))


def test_cli_help_and_init(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    parser=build_parser(); assert "campaign" in parser.format_help()
    assert main(["--project",str(tmp_path/"p"),"project","init"]) == 0
    assert json.loads(capsys.readouterr().out)["passed"]


def test_cli_hypothesis_flow(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    project=tmp_path/"p"
    assert main(["--project",str(project),"hypothesis","create","x is unsigned","function","f","--origin","test"]) == 0
    created=json.loads(capsys.readouterr().out)
    assert created["state"] == "proposed"
    assert main(["--project",str(project),"hypothesis","show",created["hypothesis_id"]]) == 0


def _fake_repo(tmp_path: Path) -> Path:
    repo=tmp_path/"repo"; (repo/"src/x86decomp").mkdir(parents=True); (repo/"test-suite").mkdir(); (repo/"docs").mkdir(); (repo/"skills/x86decomp").mkdir(parents=True)
    (repo/"src/x86decomp/legacy.py").write_text("LEGACY=True\n")
    (repo/"src/x86decomp/cli.py").write_text("LEGACY_CLI=True\n")
    (repo/"src/x86decomp/worker.py").write_text("LEGACY_WORKER=True\n")
    (repo/"scripts").mkdir()
    (repo/"scripts/validate-contracts.py").write_text("LEGACY_VALIDATOR=True\n")
    (repo/"pyproject.toml").write_text('[build-system]\nrequires=["setuptools"]\nbuild-backend="setuptools.build_meta"\n[project]\nname="x86decomp-toolkit"\nversion="0.4.0"\n[project.scripts]\nx86decomp="x86decomp.cli:main"\n')
    (repo/"test-suite/pyproject.toml").write_text('[project]\nname="x86decomp-test-suite"\nversion="0.4.0"\n')
    for name in ("README.md","CHANGELOG.md","FEATURE_PARITY.md","PROJECT_MEMORY.md","SECURITY.md","AGENTS.md","VERIFICATION.md"):
        heading = "Changelog" if name == "CHANGELOG.md" else name.removesuffix(".md")
        (repo/name).write_text(f"# {heading}\n\nLEGACY-{name}\n")
    return repo



def _verify_manifest(root: Path) -> set[str]:
    names: set[str] = set()
    for line in (root/"MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
        digest,name=line.split("  ",1)
        assert name not in names
        names.add(name)
        assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest
    return names


def _seed_manifests(repo: Path) -> None:
    suite=repo/"test-suite"
    suite_payload=hashlib.sha256((suite/"pyproject.toml").read_bytes()).hexdigest()+"  pyproject.toml\n"
    (suite/"MANIFEST.sha256").write_text(suite_payload)
    root_entries=[]
    for name in ("pyproject.toml","src/x86decomp/legacy.py","test-suite/MANIFEST.sha256"):
        root_entries.append(f"{hashlib.sha256((repo/name).read_bytes()).hexdigest()}  {name}\n")
    (repo/"MANIFEST.sha256").write_text("".join(root_entries))

def test_installer_dry_run_preserves_repo(tmp_path: Path) -> None:
    repo=_fake_repo(tmp_path); before=(repo/"pyproject.toml").read_bytes()
    result=apply_upgrade(repo,ROOT,dry_run=True)
    assert result["passed"] and not result["changed"]
    assert (repo/"pyproject.toml").read_bytes() == before


def test_installer_additive_no_tests(tmp_path: Path) -> None:
    repo=_fake_repo(tmp_path); result=apply_upgrade(repo,ROOT,run_tests=False)
    assert result["changed"]
    assert (repo/"src/x86decomp/legacy.py").read_text() == "LEGACY=True\n"
    assert (repo/"src/x86decomp/v050/store.py").is_file()
    assert "register_v050_commands" in (repo/"src/x86decomp/cli.py").read_text()
    assert "def execute_worker_request" in (repo/"src/x86decomp/worker.py").read_text()
    assert "recursive schema" in (repo/"scripts/validate-contracts.py").read_text()
    text=(repo/"pyproject.toml").read_text(); assert 'version = "0.5.0"' in text and "x86decomp-v050" in text and "x86decomp-apply-v050" in text
    assert '"x86decomp.v050" = ["py.typed", "data/*.zip"]' in text
    assert any((repo/".x86decomp-upgrade-backups").glob("*.tar.gz"))
    for name in ("README.md","CHANGELOG.md","FEATURE_PARITY.md","PROJECT_MEMORY.md","SECURITY.md","AGENTS.md","VERIFICATION.md"):
        merged=(repo/name).read_text(); assert f"LEGACY-{name}" in merged and f"X86DECOMP-V050:{name}:START" in merged
    second=apply_upgrade(repo,ROOT,run_tests=False); assert second["changed"]
    assert (repo/"README.md").read_text().count("X86DECOMP-V050:README.md:START") == 1



def test_installer_regenerates_nested_and_root_manifests(tmp_path: Path) -> None:
    repo=_fake_repo(tmp_path); _seed_manifests(repo)
    result=apply_upgrade(repo,ROOT,run_tests=False)
    assert result["changed"]
    suite_names=_verify_manifest(repo/"test-suite")
    root_names=_verify_manifest(repo)
    assert "tests/v050/test_v050_release_contract.py" in suite_names
    assert "src/x86decomp/v050/installer.py" in root_names
    assert "test-suite/MANIFEST.sha256" in root_names
    assert "V050_UPGRADE_REPORT.json" in root_names
    report=json.loads((repo/"V050_UPGRADE_REPORT.json").read_text())
    assert report["regenerated_manifests"] == ["test-suite/MANIFEST.sha256","MANIFEST.sha256"]
    assert report["legacy_capabilities_removed"] is False
    assert "src/x86decomp/cli.py" in report["compatibility_supersessions"]


def test_installer_rolls_back_final_commit_failure(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import shutil as shutil_module
    repo=_fake_repo(tmp_path); _seed_manifests(repo)
    original_pyproject=(repo/"pyproject.toml").read_bytes()
    original_readme=(repo/"README.md").read_bytes()
    original_root_manifest=(repo/"MANIFEST.sha256").read_bytes()
    real_copy2=shutil_module.copy2
    committed=0
    def fail_during_commit(source, destination, *args, **kwargs):
        nonlocal committed
        destination_path=Path(destination).resolve()
        if repo.resolve() in destination_path.parents:
            committed += 1
            if committed == 2:
                raise OSError("simulated final commit failure")
        return real_copy2(source,destination,*args,**kwargs)
    monkeypatch.setattr("x86decomp.v050.installer.shutil.copy2",fail_during_commit)
    with pytest.raises(OSError,match="simulated final commit failure"):
        apply_upgrade(repo,ROOT,run_tests=False)
    assert (repo/"pyproject.toml").read_bytes() == original_pyproject
    assert (repo/"README.md").read_bytes() == original_readme
    assert (repo/"MANIFEST.sha256").read_bytes() == original_root_manifest
    assert not (repo/"src/x86decomp/v050").exists()
    assert not (repo/"V050_UPGRADE_REPORT.json").exists()
    assert (repo/"src/x86decomp/legacy.py").read_text() == "LEGACY=True\n"

def test_installer_rejects_wrong_version(tmp_path: Path) -> None:
    repo=_fake_repo(tmp_path); (repo/"pyproject.toml").write_text((repo/"pyproject.toml").read_text().replace("0.4.0","0.3.0"))
    assert not plan_upgrade(repo,ROOT)["passed"]


def test_standalone_process_help() -> None:
    env=os.environ.copy(); env["PYTHONPATH"]=str(ROOT/"src")
    result=subprocess.run([sys.executable,"-m","x86decomp.v050","--help"],cwd=ROOT,env=env,stdout=subprocess.PIPE,text=True)
    assert result.returncode == 0 and "campaign" in result.stdout and "proof" in result.stdout

def test_common_helpers_and_cli_json_arg(tmp_path: Path) -> None:
    from x86decomp.v050.cli import _json_arg
    from x86decomp.v050.common import atomic_write_bytes, atomic_write_json, dedupe_preserve, read_json, stable_id
    assert _json_arg('{"x":1}',{}) == {"x":1}
    assert stable_id("x",1) == stable_id("x",1)
    raw=tmp_path/"raw"; atomic_write_bytes(raw,b"abc"); assert raw.read_bytes()==b"abc"
    document=tmp_path/"d.json"; atomic_write_json(document,{"b":2}); assert read_json(document)=={"b":2}
    assert dedupe_preserve(["a","b","a"]) == ["a","b"]


def test_all_leaf_commands_parse_help() -> None:
    parser=build_parser()
    leaves=[]
    def walk(current,prefix=()):
        children=[]
        for action in current._actions:
            if action.__class__.__name__ == '_SubParsersAction':
                for name,child in action.choices.items(): children.append((name,child))
        if not children:
            leaves.append(prefix); return
        for name,child in children: walk(child,prefix+(name,))
    walk(parser)
    assert len(leaves) == 67
    for command in leaves:
        with pytest.raises(SystemExit) as caught:
            parser.parse_args([*command,"--help"])
        assert caught.value.code == 0


def test_installer_main_and_default_overlay(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    from x86decomp.v050.installer import _default_overlay, main as installer_main
    overlay,cleanup=_default_overlay(); assert (overlay/"schemas/v050").is_dir(); assert cleanup is None
    repo=_fake_repo(tmp_path)
    assert installer_main([str(repo),"--overlay-root",str(ROOT),"--dry-run"]) == 0
    assert json.loads(capsys.readouterr().out)["dry_run"]


def test_packaged_overlay_is_deterministic_and_complete(tmp_path: Path) -> None:
    import importlib.util
    import zipfile
    script=ROOT/"scripts/build-v050-overlay.py"
    spec=importlib.util.spec_from_file_location("build_v050_overlay",script); assert spec and spec.loader
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    first=tmp_path/"one.zip"; second=tmp_path/"two.zip"
    module.build(ROOT,first); module.build(ROOT,second)
    assert first.read_bytes() == second.read_bytes()
    with zipfile.ZipFile(first) as archive:
        names=set(archive.namelist())
    assert "src/x86decomp/v050/store.py" in names
    assert "schemas/v050/campaign.schema.json" in names
    assert "docs/releases/0.5.0/VERIFICATION.md" in names
    assert "src/x86decomp/worker.py" in names
    assert "src/x86decomp/cli.py" in names
    assert "scripts/validate-contracts.py" in names
    assert "scripts/apply-v050-upgrade.py" in names
    assert "MANIFEST.in" in names
    assert "test-suite/MANIFEST.in" in names
    assert "test-suite/docs/TEST_PLAN.md" in names
    assert "test-suite/src/x86decomp_testkit/data/feature_catalog.json" in names
    assert not any("__pycache__" in name or name.endswith("overlay.zip") or name.endswith("overlay.zip.tmp") for name in names)
    embedded=ROOT/"src/x86decomp/v050/data/overlay.zip"
    if embedded.is_file():
        with zipfile.ZipFile(embedded) as archive:
            embedded_names=set(archive.namelist())
        assert not any(name.endswith("overlay.zip") or name.endswith("overlay.zip.tmp") for name in embedded_names)

    # Exercise the exact in-tree output path: the builder creates overlay.zip.tmp
    # while scanning members, so both the final archive and its temporary sibling
    # must be excluded even when they exist under an overlay directory.
    synthetic=tmp_path/"synthetic"
    data_dir=synthetic/"src/x86decomp/v050/data"
    data_dir.mkdir(parents=True)
    (data_dir/"keep.txt").write_text("kept",encoding="utf-8")
    module.OVERLAY_DIRS=["src/x86decomp/v050"]
    module.OVERLAY_FILES=[]
    synthetic_overlay=data_dir/"overlay.zip"
    module.build(synthetic,synthetic_overlay)
    with zipfile.ZipFile(synthetic_overlay) as archive:
        synthetic_names=set(archive.namelist())
    assert synthetic_names == {"src/x86decomp/v050/data/keep.txt"}
