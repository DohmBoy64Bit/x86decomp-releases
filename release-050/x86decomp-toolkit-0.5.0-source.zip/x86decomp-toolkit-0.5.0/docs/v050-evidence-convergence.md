# Evidence-driven convergence in 0.5.0

A campaign is a durable investigation, not a fixed pipeline. It chooses the highest-value bounded action from persisted evidence: urgent analyst review, contradiction investigation, counterexample minimization, scheduled hypothesis experiment, candidate evaluation, or unknown inventory. Every choice records its rationale and consumes an explicit budget.

Hypotheses hold uncertain propositions. Evidence links state support, contradiction, or context; weight; kind; independence group; artifact hash; and details. Correlated reports in the same independence group contribute only their strongest weight. Acceptance remains a governance decision with a strict gate.

Candidate branches are immutable-by-content views over source artifacts. Evaluation records do not silently promote candidates. Promotion requires at least one passing metric and no recorded failure.

Counterexample minimization uses deterministic delta debugging over bytes. The original payload is retained, every minimized payload remains hash-bound, and regression promotion writes both fixture and metadata.

Consensus groups adapter observations by subject and property. It exposes disagreements and weighted group support. An analyst resolution records exactly why one value was selected and may be locked.

Proof bundles are deterministic archives with a manifest, per-member hashes, audit tip, obligations, results, assumptions, and truth-boundary text. Optional HMAC authenticates the manifest when users share a secret out of band.
