# Security policy — 0.5.0

All 0.4 security rules remain active. The v0.5 additions impose these further controls:

- Project schema changes are namespaced and transactional.
- Candidate and family artifacts reject symlinks and path traversal and are SHA-256 addressed.
- Proof bundles reject absolute paths, parent traversal, backslashes/drive paths, duplicates, symlinks, excessive members, and excessive expansion.
- Changesets verify every hash-chain link and require an exact local base tip.
- Plugins are pinned by executable hash, run with argument arrays, a minimal environment, timeouts, output bounds, and a versioned JSON envelope.
- Plugins do not receive database handles and cannot mutate canonical project state through the plugin protocol.
- Worker endpoints must use `https://` or `unix://` for a passing doctor result; an endpoint alone is not a security boundary.
- Binary-family operations are static and never execute supplied binaries.
- Counterexample predicates used programmatically must run inside the caller’s declared validation boundary.
- Unknown native target execution remains opt-in and belongs in an operator-controlled disposable environment.

No registered plugin, worker, container, emulator, or remote service is automatically trusted merely because it is available.
