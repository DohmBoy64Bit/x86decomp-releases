# Changelog

## 0.5.0 — 2026-06-29

### Evidence-driven autonomous convergence

- Added persistent campaigns with goals, branches, deterministic next-action explanations, explicit budgets, pause/resume/stop/block states, and audit history.
- Added a hypothesis/evidence ledger with dependency-cycle prevention, independence-group weighting, contradiction handling, analyst locks, and a strict acceptance gate.
- Added reproducible candidate branches, content-addressed files, metric evaluations, comparisons, and validated promotion rules.
- Added counterexample storage, deterministic byte-level delta minimization, and permanent regression-fixture promotion.
- Added cross-adapter consensus and disagreement analysis with evidence provenance and locked analyst resolution.
- Added a semantic knowledge graph and bounded inbound/outbound impact analysis.
- Added analyst review queues with assignment, evidence requests, decisions, and automation-resistant locks.
- Added static binary-family correlation and explicit limits against source/semantic identity inference.
- Added proof obligations, exact result vocabulary, deterministic proof bundles, member hashes, safe ZIP handling, and optional HMAC verification.
- Added worker capability registry and hash-pinned plugin protocol with bounded subprocess execution and typed JSON envelopes.
- Added portable append-only changesets with chain verification and base/tip conflict checks.

### Compatibility and project state

- Added project schema extension version 4 entirely in `v050_*` tables inside the existing SQLite project state database.
- Preserved legacy tables and files; no legacy table is dropped, renamed, or rewritten.
- Added `x86decomp-v050` as a separate console entry point and activated `x86decomp v050 ...` as an additive compatibility bridge. All 106 prior `x86decomp` commands remain unchanged and cataloged.
- Added a staging-first transactional installer with backups, collision detection, dry-run mode, staged verification, and no partial target mutation before checks pass.
- Added the installed `x86decomp-apply-v050` entry point and verified its embedded-overlay transaction against a fresh 0.4.0 tree with the complete declared verification environment.
- Added machine-readable v0.5 schemas, a feature delta catalog, and the preserved exact 0.4 baseline catalog with set-inclusion regression enforcement.

### Regression, skill, and architecture contracts

- Verified 188 unique repository tests and 26 standalone verifier tests with zero failures and zero skips.
- Verified 515/515 cataloged top-level function bodies, all 107 legacy commands, 77.90% statement coverage, and 52.57% branch coverage.
- Fixed the retained worker launch path to avoid thread-unsafe POSIX `preexec_fn` use while preserving the legacy callback as a directly tested compatibility symbol.

- Added native and integrated-harness tests covering state transitions, evidence gates, audit tamper detection, content addressing, minimization, proof integrity, plugin hash pinning, worker selection, installer preservation, schema validation, and zero-placeholder policy.
- Updated the evidence-engineering skill to 5.0.0.
- Updated all four synchronized Mermaid/ASCII architecture artifacts.
- Preserved the 0.4 matching and functional workflow states unchanged.

### Truth boundary

- Finite tests remain finite tests; they are never called universal proof.
- Cross-tool consensus does not establish truth by majority vote.
- Binary-family similarity does not establish source identity or semantic equivalence.
- Plugin and worker registration does not turn a process/container into a complete security boundary.
