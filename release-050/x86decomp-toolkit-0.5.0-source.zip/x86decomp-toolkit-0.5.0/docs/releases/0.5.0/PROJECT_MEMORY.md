# Project memory — x86decomp-toolkit 0.5.0

## Permanent inherited decisions

1. Matching and functional decompilation remain independent per-function modes.
2. Ghidra remains an analysis adapter, not the canonical database.
3. AI output remains a proposal and cannot count as evidence or accept itself.
4. Three-source review remains a governance gate, not certainty.
5. Every validator names its finite scope and non-claims.
6. Unknown target facts remain unknown until evidence or an explicit operator decision resolves them.
7. Static import never grants native execution consent.
8. No placeholder, fake success, inert adapter, or silent downgrade is allowed.
9. Every previous release surface is preserved or receives a tested migration/compatibility path.
10. A feature may be removed only when a complete successor supersedes it and compatibility is explicitly tested.

## 0.5 architecture decision

The v0.5 control plane is additive to v0.4. Project schema extension version 4 uses only `v050_*` tables. It does not drop, rename, reinterpret, or backfill legacy project tables. The old `x86decomp` entry point retains every prior command and receives one additive `v050` compatibility bridge; `x86decomp-v050` also carries the complete new hierarchy. The bridge supersedes no old command.

## Campaign decision

A campaign planner may select and explain a next action, but it cannot invent evidence, bypass locks, exceed budgets, or silently convert blocked/unknown outcomes into success. Planning remains deterministic for an identical persisted state.

## Hypothesis decision

Uncertainty is first-class. Accepted hypotheses require three independent supporting groups, two evidence kinds, accepted dependencies, and no unresolved contradictory evidence. Confidence collapses correlated observations by independence group.

## Candidate and counterexample decision

Candidate source trees are content-addressed and reproducible. Counterexamples are immutable on capture, retain original backups during minimization, and become regression fixtures only through an explicit promotion.

## Consensus decision

Adapter agreement is an observation. Majority agreement is not truth. Resolutions retain method, rationale, actor, and optional lock.

## Proof decision

Proof terminology is exact. Proof bundles distinguish byte identity, structural equivalence, bounded symbolic proof, finite behavioral testing, partial validation, assumption dependence, unresolved state, and failure. A bundle is evidence packaging, not a universal theorem.

## Extension decision

Plugins use a versioned JSON protocol, exact executable hashes, argument arrays, minimal environment, timeout, output bounds, and no direct database mutation authority. Workers are capability records; remote trust requires operator-controlled transport and environment pinning.

## Release decision

The integrated 0.5 release gate requires the complete 0.4 source tree, exact 0.4 feature catalog, zero old-command loss, zero schema loss, all old and new tests with zero skips, all function bodies exercised, package clean-install tests, synchronized maps/skill/docs, and honest BLOCKED reporting for unavailable live adapters.
