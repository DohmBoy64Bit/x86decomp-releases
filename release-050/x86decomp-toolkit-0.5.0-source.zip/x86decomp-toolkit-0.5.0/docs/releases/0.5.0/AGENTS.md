# 0.5.0 agent and contributor additions

- Preserve every retained 0.4 surface. Remove a feature only when a complete successor supersedes it and regression-tested compatibility exists.
- Do not add placeholders, fake adapters, inert command branches, fabricated evidence, silent downgrades, or success responses for unsupported work.
- Keep the toolkit Mermaid map, toolkit ASCII map, test-suite Mermaid map, and test-suite ASCII map synchronized in the same change.
- Update skill, schemas, tests, feature catalogs, parity records, project memory, changelog, security notes, and verification records atomically with executable behavior.
- Treat campaigns, hypotheses, consensus, and proof bundles as evidence-governance mechanisms, not authorities that can manufacture truth.
- Preserve analyst locks and report contradictions or blocked states explicitly.
