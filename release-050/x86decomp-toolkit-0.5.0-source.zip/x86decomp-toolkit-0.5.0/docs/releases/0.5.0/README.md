# x86decomp-toolkit 0.5.0 — evidence-driven convergence

Version 0.5.0 adds an additive, namespaced control plane for campaigns, hypotheses, reconstruction candidates, counterexamples, consensus, impact analysis, review queues, binary families, proof bundles, workers, plugins, and audit changesets.

The existing `x86decomp` command retains all 106 prior commands and adds the active `v050` compatibility bridge as command 107. The same 67-leaf control plane is also exposed through `x86decomp-v050`; schema extension version 4 uses only `v050_*` tables. All 0.4 modules, functions, schemas, adapters, matching states, functional states, and project records remain supported and are checked against the preserved 0.4 catalog.

See `docs/v050-evidence-convergence.md` and `docs/releases/0.5.0/VERIFICATION.md`. Finite validation remains finite and no proof bundle claims original-source recovery or universal equivalence.

## Install and apply the transactional upgrade

Install the toolkit with the complete verification environment when applying the release to a 0.4.0 source tree:

```bash
python -m pip install 'x86decomp-toolkit[full,pe,dev]==0.5.0'
x86decomp-apply-v050 /path/to/x86decomp-toolkit-0.4.0
```

The upgrader uses its embedded deterministic overlay, creates a backup, stages the entire update, runs compileall, recursive contract validation, all repository tests, and the standalone verifier, and commits only after every gate passes. A minimal installation may invoke `--no-tests`, but that bypass is not part of the release verification path.

