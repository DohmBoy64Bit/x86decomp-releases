# Feature-parity matrix — 0.5.0 additive delta

All 0.4.0 features remain owned by their existing modules. This matrix lists only new executable surfaces.

| Requirement | Implementation | Tests |
|---|---|---|
| Persistent campaigns and budgets | `v050/campaigns.py` | lifecycle, budget, branch, planner tests |
| Hypothesis/evidence ledger | `v050/hypotheses.py` | gate, contradiction, dependency-cycle tests |
| Candidate branches and artifacts | `v050/candidates.py` | clone, compare, traversal, promotion tests |
| Counterexample minimization | `v050/counterexamples.py` | ddmin, hash, regression promotion tests |
| Cross-adapter consensus | `v050/consensus.py` | conflict, resolution, lock tests |
| Program knowledge graph | `v050/knowledge_graph.py` | bounded impact traversal tests |
| Analyst review queue | `v050/reviews.py` | assignment, decision, lock tests |
| Binary families | `v050/family.py` | fixed-block correlation and non-claim tests |
| Proof obligations/bundles | `v050/proofs.py` | scope evaluation, deterministic ZIP, HMAC and confinement tests |
| Worker capability registry | `v050/workers.py` | selection, status, doctor tests |
| Plugin SDK boundary | `v050/plugins.py` | manifest, executable hash, capability, bounded invocation tests |
| Portable audit changesets | `v050/changesets.py` | chain, round-trip, base conflict tests |
| Namespaced project schema v4 | `v050/store.py` | legacy-table preservation, integrity and audit tamper tests |
| New command hierarchy | `v050/cli.py`, `v050_cli.py`, retained `cli.py` bridge | 67-leaf parser, standalone process help, `x86decomp v050` dispatch, and 107-command catalog tests |
| Staging-first updater | `v050/installer.py` | dry-run, additive install, wrong-version tests |
| Machine contracts | `schemas/v050/*.json` | Draft 2020-12 meta-validation |
| Four synchronized maps | canonical Mermaid/ASCII files | integrated release-contract test |
| Skill v5 and zero placeholders | `skills/x86decomp/SKILL.md` | release-contract source scan |

## Retained 0.4 surfaces

The preserved baseline catalog proves inclusion of all 60 modules, 514 functions/methods, 106 commands, 52 root schemas, three Ghidra scripts, 31 adapters, and both workflow modes from 0.4.0. The integrated catalog adds one module, one function, and one command without removing a baseline item.

The upgrade does not replace PE/PDB/COFF parsing, matching/functional workflow states, compilers, linkers, Ghidra adapters, dynamic/symbolic validators, target packs, templates, content storage, durable orchestration, workers, release gates, reproducibility, security, or the comprehensive verifier. Those remain in their existing 0.4 modules and are required inputs to the final integrated regression gate.
