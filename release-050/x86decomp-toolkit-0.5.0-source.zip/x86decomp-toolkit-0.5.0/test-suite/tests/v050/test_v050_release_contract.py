from __future__ import annotations

from pathlib import Path


def test_v050_overlay_preserves_all_canonical_architecture_artifacts() -> None:
    root=Path(__file__).resolve().parents[3]
    required=[root/"docs/ARCHITECTURE_MAP.md",root/"docs/ARCHITECTURE_MAP_ASCII.txt",root/"test-suite/docs/ARCHITECTURE_MAP.md",root/"test-suite/docs/ARCHITECTURE_MAP_ASCII.txt"]
    # Files are populated as part of the same release transaction.
    assert all(path.is_file() for path in required)
    assert all("0.5.0" in path.read_text(encoding="utf-8") for path in required)


def test_v050_zero_placeholder_policy() -> None:
    root=Path(__file__).resolve().parents[3]
    forbidden=("NotImplementedError", "TODO: implement", "pass  # placeholder")
    for path in (root/"src/x86decomp/v050").glob("*.py"):
        text=path.read_text(encoding="utf-8")
        assert not any(token in text for token in forbidden), path


def test_v050_feature_delta_catalog_exact() -> None:
    import ast
    import json
    import sys
    root=Path(__file__).resolve().parents[3]
    sys.path.insert(0,str(root/"src"))
    from x86decomp.v050.cli import build_parser
    catalog=json.loads((root/"test-suite/src/x86decomp_testkit/data/feature_catalog.v050.delta.json").read_text())
    modules=[]; functions=[]
    for path in sorted((root/"src/x86decomp/v050").glob("*.py")):
        modules.append("x86decomp.v050."+path.stem)
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)): functions.append(f"{path.stem}:{node.name}")
    commands=[]
    def walk(parser,prefix=()):
        children=[]
        for action in parser._actions:
            if action.__class__.__name__ == "_SubParsersAction":
                children.extend((name,child) for name,child in action.choices.items())
        if not children:
            if prefix: commands.append(" ".join(prefix))
            return
        for name,child in children: walk(child,prefix+(name,))
    walk(build_parser())
    assert catalog["modules"] == sorted(modules)
    assert catalog["defined_functions_and_methods"] == sorted(functions)
    assert catalog["commands"] == sorted(commands)
    assert catalog["schemas"] == sorted(path.name for path in (root/"schemas/v050").glob("*.json"))


def test_v050_source_manifests_are_exact_and_valid() -> None:
    import hashlib
    root=Path(__file__).resolve().parents[3]
    excluded_dirs={".git",".hg",".svn",".pytest_cache","__pycache__","build","dist",".venv","venv","test-results",".x86decomp-upgrade-backups"}
    excluded_files={".coverage","coverage.json","coverage.xml","junit.xml","PKG-INFO","setup.cfg"}
    def expected(base: Path) -> dict[str,str]:
        result={}
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.is_symlink(): continue
            relative=path.relative_to(base)
            if relative == Path("MANIFEST.sha256"): continue
            if relative.name in excluded_files or relative.suffix in {".pyc",".pyo"}: continue
            if any(part in excluded_dirs or part.endswith(".egg-info") for part in relative.parts): continue
            result[relative.as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
        return result
    def actual(base: Path) -> dict[str,str]:
        result={}
        for line in (base/"MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
            digest,name=line.split("  ",1)
            assert name not in result
            result[name]=digest
        return result
    assert actual(root/"test-suite") == expected(root/"test-suite")
    assert actual(root) == expected(root)


def test_v050_test_suite_runtime_and_user_agent_are_versioned() -> None:
    import x86decomp_testkit
    from x86decomp_testkit.adapters.download import USER_AGENT

    assert x86decomp_testkit.__version__ == "0.5.0"
    assert USER_AGENT == "x86decomp-test-suite/0.5.0"
