# Verification record — x86decomp comprehensive test suite 0.5.0

## Scope

This record covers the integrated and independently packaged no-silent-skip harness under `test-suite/` for x86decomp-toolkit 0.5.0. The exact 0.4.0 catalog is preserved as a compatibility baseline and every baseline module, function/method, command, schema, Ghidra script, adapter, and workflow mode must remain in the current catalog.

## Repository layers

The complete unique repository collection passed:

```text
root toolkit tests:                          125
standalone verifier tests:                    26
packaged harness self-tests:                  17
supplemental toolkit tests:                    20
total unique tests:                           188
failed:                                         0
skipped:                                        0
```

The official `make verify` path also repeats the 26 standalone tests as an independent package-boundary gate after the monolithic run.

## Coverage and no-omission contract

The comprehensive coverage audit reported:

```text
515 / 515 cataloged top-level function/method bodies executed
107 / 107 legacy CLI commands parser-tested
145 coverage-run pytest cases, zero skipped
statement coverage: 77.90021156558534%
branch coverage:    52.57318224740321%
```

The original 0.4.0 surface—60 modules, 514 functions/methods, 106 commands, 52 root schemas, three Ghidra scripts, 31 adapters, and two workflow modes—is checked as a subset of the current 0.5.0 catalog. Coverage floors remain 70% statements and 50% branches.

## Comprehensive run

Run `run-20260629T225453918Z-36a0d510` reported:

```text
156 PASS
0 FAIL
0 ERROR
7 BLOCKED
exit code 0 in non-strict mode
```

Blocked on this host: container runtime, DynamoRIO, Ghidra, llvm-readobj, historical MSVC, objdiff, and pip-audit. These remain visible and become exit code 2 in strict mode; they are never skipped or converted to passes.

## Packaging

The harness built and clean-installed the toolkit wheel and source distribution, verified installed command help, package data, root/nested manifests, and the deterministic v0.5 overlay. The separately packaged test-suite wheel and source distribution are version 0.5.0 and include the current catalog, preserved baseline catalog, v0.5 delta catalog, schemas, self-tests, docs, and CLI.

## Interpretation

This suite prevents silent regression and environmental omission within its declared contracts. Executing every body once is not proof of every branch or input, and unavailable live adapters remain explicit verification gaps.
