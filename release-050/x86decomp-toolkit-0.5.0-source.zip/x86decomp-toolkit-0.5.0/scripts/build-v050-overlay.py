#!/usr/bin/env python3
from __future__ import annotations

import argparse
import zipfile
from pathlib import Path

OVERLAY_DIRS = [
    "src/x86decomp/v050", "schemas/v050", "tests/v050", "test-suite/tests/v050",
    "test-suite/src/x86decomp_testkit/data", "docs/releases/0.5.0",
]
OVERLAY_FILES = [
    "MANIFEST.in",
    "test-suite/MANIFEST.in",
    "src/x86decomp/v050_cli.py", "src/x86decomp/cli.py", "src/x86decomp/worker.py", "docs/ARCHITECTURE_MAP.md",
    "docs/ARCHITECTURE_MAP_ASCII.txt", "test-suite/docs/ARCHITECTURE_MAP.md",
    "test-suite/docs/ARCHITECTURE_MAP_ASCII.txt", "test-suite/docs/TEST_PLAN.md", "skills/x86decomp/SKILL.md",
    "docs/v050-evidence-convergence.md", "scripts/apply-v050-upgrade.py",
    "scripts/build-v050-overlay.py", "scripts/validate-contracts.py",
    "test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py",
    "test-suite/tests/test_inventory_reports_process.py",
    "test-suite/README.md",
    "test-suite/MAINTENANCE.md",
    "test-suite/VERIFICATION.md",
    "test-suite/CHANGELOG.md",
    "test-suite/INTEGRATION.md",
    "test-suite/SECURITY.md",
    "test-suite/docs/ARCHITECTURE.md",
    "test-suite/docs/LOGGING.md",
    "test-suite/src/x86decomp_testkit/__init__.py",
    "test-suite/src/x86decomp_testkit/adapters/download.py",
]

def members(root: Path):
    output: list[Path] = []
    for relative in OVERLAY_DIRS:
        base = root / relative
        if base.is_dir():
            output.extend(path for path in base.rglob("*") if path.is_file() and not path.is_symlink() and path.name not in {"overlay.zip", "overlay.zip.tmp"} and "__pycache__" not in path.parts)
    for relative in OVERLAY_FILES:
        path = root / relative
        if not path.is_file() or path.is_symlink():
            raise SystemExit(f"missing or unsafe overlay member: {relative}")
        output.append(path)
    return sorted(set(output), key=lambda path: path.relative_to(root).as_posix())

def build(root: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in members(root):
            name = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100644 & 0xFFFF) << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    temporary.replace(output)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    build(root, (args.output or root / "src/x86decomp/v050/data/overlay.zip").resolve())
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
