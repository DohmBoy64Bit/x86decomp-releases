#!/usr/bin/env python3
from x86decomp.v050.installer import main
raise SystemExit(main())
