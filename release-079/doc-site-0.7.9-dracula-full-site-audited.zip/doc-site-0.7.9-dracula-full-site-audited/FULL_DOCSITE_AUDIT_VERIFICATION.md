---
title: Full Docsite Audit
description: Full documentation-site audit for x86decomp 0.7.9.
---

# Full Docsite Audit

Generated: `2026-07-05T12:34:12.745621+00:00`

**Status:** `pass`  
**Error count:** `0`

## Counts

| Metric | Count |
| --- | ---: |
| `built_html_pages` | 513 |
| `canonical_groups` | 59 |
| `canonical_routes` | 239 |
| `markdown_hash_entries` | 511 |
| `markdown_pages` | 511 |
| `python_modules` | 145 |
| `python_symbols` | 1299 |
| `root_commands` | 166 |
| `root_manifest_entries` | 440 |
| `schemas` | 97 |
| `source_manifest_entries` | 440 |
| `test_sources` | 60 |
| `test_suite_manifest_entries` | 63 |

## Errors

No errors reported by the full docsite audit.
