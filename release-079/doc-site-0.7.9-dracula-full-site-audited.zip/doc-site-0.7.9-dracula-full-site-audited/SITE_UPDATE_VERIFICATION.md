# Site Update Verification

Generated: `2026-07-05T12:34:52.898967+00:00`

**Status:** `PASS`

## Checks

| Check | Result |
| --- | --- |
| Full docsite audit | `pass` with `0` errors |
| End-user site verification | `PASS` |
| Markdown hash verification | `PASS` for `511` Markdown pages |
| Dracula theme preserved | `true` |

## Counts

| Metric | Count |
| --- | ---: |
| `built_html_pages` | 513 |
| `canonical_groups` | 59 |
| `canonical_routes` | 239 |
| `markdown_hash_entries` | 511 |
| `markdown_pages` | 511 |
| `python_modules` | 145 |
| `python_symbols` | 1299 |
| `root_commands` | 166 |
| `root_manifest_entries` | 440 |
| `schemas` | 97 |
| `source_manifest_entries` | 440 |
| `test_sources` | 60 |
| `test_suite_manifest_entries` | 63 |

## Note

MkDocs itself was not installed in this execution environment; static pages were synchronized from the existing Dracula site package and verified by the bundled end-user and full-docsite audits.
