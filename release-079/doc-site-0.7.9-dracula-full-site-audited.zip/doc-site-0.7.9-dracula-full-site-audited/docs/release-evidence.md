---
title: Release evidence
description: 0.7.9 synchronized documentation evidence.
---

# Release evidence

This documentation source has been updated from the live x86decomp 0.7.9 parser and source inventory.

```json
{
  "canonical_groups": 44,
  "canonical_routes": 201,
  "functions_and_methods": 905,
  "ghidra_scripts": 3,
  "modules": 114,
  "root_commands": 151,
  "schemas": 97,
  "version": "0.7.9"
}
```

The full optional adapter-aware harness was not rerun in this environment because optional native-analysis dependencies were unavailable.


## v0.7.9 release evidence

- Root commands: 166
- Canonical groups: 59
- Canonical routes: 239
- Python modules: 114
- Function/method symbols: 948
- Schemas: 97
- Adapters: 36
- Added universal acceleration helpers from real-project lessons while preserving the Dracula MkDocs layout.


## Full docsite hash/parity audit

The current site includes `release-artifacts/FULL_DOCSITE_HASH_PARITY_AUDIT.md`, `release-artifacts/FULL_DOCSITE_HASH_PARITY_AUDIT.json`, and `release-artifacts/DOCSITE_MARKDOWN_HASHES.json`. These artifacts verify Markdown hashes, source-manifest coverage, command coverage, schema coverage, module/function/test coverage, local links, MkDocs strict build output, search indexing, and stale-version scanning for the published docs.

## 0.7.9 docstring and command evidence

- [Docstring Audit](release-artifacts/DOCSTRING_AUDIT_0.7.9.md)
- [Command Reference 0.7.9](release-artifacts/COMMAND_REFERENCE_0.7.9.md)
- [Release Verification 0.7.9](release-artifacts/RELEASE_VERIFICATION_0.7.9.md)
