---
title: x86decomp 0.7.9 Documentation
description: Evidence-governed x86/x86-64 decompilation toolkit documentation.
---

# x86decomp 0.7.9 Documentation

Use this MkDocs site to install the toolkit, create projects, run matching and functional workflows, use bounded local-model C generation, and verify release evidence.

<div class="doc-stat-grid">
<div><strong>166</strong><span>toolkit root commands</span></div>
<div><strong>239</strong><span>canonical routes</span></div>
<div><strong>114</strong><span>Python modules</span></div>
<div><strong>97</strong><span>JSON Schemas</span></div>
<div><strong>229</strong><span>test functions</span></div>
<div><strong>36</strong><span>adapter declarations</span></div>
</div>

## Start here

- [Getting started](getting-started.md)
- [Workflows](workflows.md)
- [Local LLM C generation](local-llm.md)
- [Project Examples](project-examples.md)
- [Complete command reference](commands/index.md)
- [Release verification](verification.md)

## Scope

The model is a proposal engine only. Exact byte acceptance comes from deterministic compilation, COFF extraction, complete relocation resolution, and raw byte identity. Analyze and execute only authorized targets in appropriately isolated environments.


## Universal decompilation acceleration

Version 0.7.9 preserves the existing acceleration and adapter-capability surface and adds a complete docstring-audit documentation pass. See [Docstring Audit](release-artifacts/DOCSTRING_AUDIT_0.7.9.md).


## 0.7.9 adapter capabilities

The harness now reports protocol capabilities separately from product adapters. `lm-studio-http` can satisfy OpenAI-compatible local-LLM coverage through a loopback `/v1/models` probe without marking `ollama`, `llama-server`, `localai`, or `vllm` as installed.

## 0.7.9 docstring audit

The 0.7.9 release adds source-grounded professional docstrings across the editable Python implementation surface and publishes docstring audit evidence in the release artifacts section.
