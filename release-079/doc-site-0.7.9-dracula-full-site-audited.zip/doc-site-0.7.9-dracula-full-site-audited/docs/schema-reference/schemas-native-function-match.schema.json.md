---
title: "x86decomp function-match"
description: "Exact source-derived schema reference for schemas/native/function-match.schema.json"
---

# `schemas/native/function-match.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/native/function-match.schema.json` |
| SHA-256 | `e598ca859f33c96b62fe8dac7fcf78ec77b53e4b8f178b9f19e1f288e2725cd1` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.invalid/schemas/native/function-match.schema.json` |
| Title | x86decomp function-match |
| Top-level type | `object` |
| Top-level properties | 5 |
| Required fields | 5 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `True` |

## Required fields

- `classification`
- `function_id`
- `replacement_safe`
- `rva`
- `slot_size`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `classification` | `enum` | yes | Not declared |
| `function_id` | `string` | yes | Not declared |
| `replacement_safe` | `boolean` | yes | Not declared |
| `rva` | `integer` | yes | Not declared |
| `slot_size` | `integer` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
