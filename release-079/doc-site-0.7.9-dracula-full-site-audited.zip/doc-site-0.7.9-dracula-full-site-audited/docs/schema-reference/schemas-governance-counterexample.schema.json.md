---
title: "counterexample"
description: "Exact source-derived schema reference for schemas/governance/counterexample.schema.json"
---

# `schemas/governance/counterexample.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/governance/counterexample.schema.json` |
| SHA-256 | `0e2b706ed1bf89e6c07a483dd171dbb23fbac4f67c87ef1df16be6c2fe50d19c` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `Not declared` |
| Title | counterexample |
| Top-level type | `object` |
| Top-level properties | 7 |
| Required fields | 6 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `False` |

## Required fields

- `current_sha256`
- `predicate`
- `scope_id`
- `scope_kind`
- `size_bytes`
- `state`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `current_sha256` | `string` | yes | Not declared |
| `predicate` | `object` | yes | Not declared |
| `provenance` | `object` | no | Not declared |
| `scope_id` | `string` | yes | Not declared |
| `scope_kind` | `string` | yes | Not declared |
| `size_bytes` | `integer` | yes | Not declared |
| `state` | `enum` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
