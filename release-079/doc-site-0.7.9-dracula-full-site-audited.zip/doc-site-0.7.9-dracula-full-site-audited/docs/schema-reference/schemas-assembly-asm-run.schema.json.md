---
title: "v0.7.9 assembly run"
description: "Exact source-derived schema reference for schemas/assembly/asm-run.schema.json"
---

# `schemas/assembly/asm-run.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/assembly/asm-run.schema.json` |
| SHA-256 | `67a3e0685e52ccc31959e29edf46976be78fa063de2ce06e40794fc6724b341f` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.local/schemas/assembly/asm-run.schema.json` |
| Title | v0.7.9 assembly run |
| Top-level type | `object` |
| Top-level properties | 5 |
| Required fields | 5 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `True` |

## Required fields

- `architecture`
- `asm_format`
- `run_id`
- `status`
- `summary`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `enum` | yes | Not declared |
| `asm_format` | `enum` | yes | Not declared |
| `run_id` | `string` | yes | Not declared |
| `status` | `enum` | yes | Not declared |
| `summary` | `object` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
