---
title: "Generated regression test"
description: "Exact source-derived schema reference for schemas/reconstruction/generated-test.schema.json"
---

# `schemas/reconstruction/generated-test.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/reconstruction/generated-test.schema.json` |
| SHA-256 | `8e99342ae82922d0c5c17c41e857074a5a2cec9b1269e23572aea09b5715a7b5` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.dev/schemas/reconstruction/generated-test.schema.json` |
| Title | Generated regression test |
| Top-level type | `object` |
| Top-level properties | 7 |
| Required fields | 7 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `False` |

## Required fields

- `content_sha256`
- `generated_test_id`
- `name`
- `relative_path`
- `scope_id`
- `scope_kind`
- `test_kind`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `content_sha256` | `string` | yes | Not declared |
| `generated_test_id` | `string` | yes | Not declared |
| `name` | `string` | yes | Not declared |
| `relative_path` | `string` | yes | Not declared |
| `scope_id` | `string` | yes | Not declared |
| `scope_kind` | `string` | yes | Not declared |
| `test_kind` | `enum` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
