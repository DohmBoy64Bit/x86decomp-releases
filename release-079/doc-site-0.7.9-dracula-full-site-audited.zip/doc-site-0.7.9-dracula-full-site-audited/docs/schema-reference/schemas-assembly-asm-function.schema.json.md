---
title: "v0.7.9 function assembly result"
description: "Exact source-derived schema reference for schemas/assembly/asm-function.schema.json"
---

# `schemas/assembly/asm-function.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/assembly/asm-function.schema.json` |
| SHA-256 | `de807efd22b872039da1842e21044fc74fc6d8681aab5086e396b06bcdf02c5e` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.local/schemas/assembly/asm-function.schema.json` |
| Title | v0.7.9 function assembly result |
| Top-level type | `object` |
| Top-level properties | 14 |
| Required fields | 8 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `True` |

## Required fields

- `classification`
- `exact_match`
- `format`
- `function_id`
- `input_sha256`
- `rva`
- `source_sha256`
- `symbol`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `byte_escape_count` | `integer` | no | Not declared |
| `classification` | `enum` | yes | Not declared |
| `exact_match` | `boolean` | yes | Not declared |
| `format` | `enum` | yes | Not declared |
| `function_id` | `string` | yes | Not declared |
| `input_sha256` | `string` | yes | Not declared |
| `instruction_count` | `integer` | no | Not declared |
| `mnemonic_count` | `integer` | no | Not declared |
| `relocation_count` | `integer` | no | Not declared |
| `resolved_relocation_count` | `integer` | no | Not declared |
| `rva` | `integer` | yes | Not declared |
| `source_sha256` | `string` | yes | Not declared |
| `symbol` | `string` | yes | Not declared |
| `unresolved_relocation_count` | `integer` | no | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
