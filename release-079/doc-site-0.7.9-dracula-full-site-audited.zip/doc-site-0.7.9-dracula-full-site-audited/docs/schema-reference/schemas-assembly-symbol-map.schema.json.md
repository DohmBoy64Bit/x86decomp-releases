---
title: "v0.7.9 original-RVA symbol map"
description: "Exact source-derived schema reference for schemas/assembly/symbol-map.schema.json"
---

# `schemas/assembly/symbol-map.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/assembly/symbol-map.schema.json` |
| SHA-256 | `05ca28d1dadbc24dc86b537785538c6750895a5a453440645fa0eab7dc7ac005` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.local/schemas/assembly/symbol-map.schema.json` |
| Title | v0.7.9 original-RVA symbol map |
| Top-level type | `object` |
| Top-level properties | 0 |
| Required fields | 0 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `{'oneOf': [{'type': 'integer', 'minimum': 0}, {'type': 'string', 'pattern': '^(0[xX][0-9a-fA-F]+|[0-9]+)$'}, {'type': 'object', 'required': ['rva'], 'properties': {'rva': {'oneOf': [{'type': 'integer', 'minimum': 0}, {'type': 'string', 'pattern': '^(0[xX][0-9a-fA-F]+|[0-9]+)$'}]}, 'section_rva': {'oneOf': [{'type': 'null'}, {'type': 'integer', 'minimum': 0}, {'type': 'string', 'pattern': '^(0[xX][0-9a-fA-F]+|[0-9]+)$'}]}, 'section_index': {'oneOf': [{'type': 'null'}, {'type': 'integer', 'minimum': 1}]}, 'kind': {'type': 'string'}}, 'additionalProperties': False}]}` |

## Required fields

This schema declares no top-level required fields.

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| _No top-level properties declared._ |  |  |  |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
