---
title: "x86decomp staging-symbol"
description: "Exact source-derived schema reference for schemas/native/staging-symbol.schema.json"
---

# `schemas/native/staging-symbol.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/native/staging-symbol.schema.json` |
| SHA-256 | `44b3ce02db0758435f6a230a9ad37bd00c3a6308bf71761836050e5c90c6c4d0` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.invalid/schemas/native/staging-symbol.schema.json` |
| Title | x86decomp staging-symbol |
| Top-level type | `object` |
| Top-level properties | 4 |
| Required fields | 4 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `True` |

## Required fields

- `declaration`
- `status`
- `symbol_kind`
- `symbol_name`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `declaration` | `string` | yes | Not declared |
| `status` | `enum` | yes | Not declared |
| `symbol_kind` | `string` | yes | Not declared |
| `symbol_name` | `string` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
