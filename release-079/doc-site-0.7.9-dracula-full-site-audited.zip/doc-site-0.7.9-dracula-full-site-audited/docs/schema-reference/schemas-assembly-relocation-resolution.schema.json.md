---
title: "v0.7.9 COFF relocation resolution"
description: "Exact source-derived schema reference for schemas/assembly/relocation-resolution.schema.json"
---

# `schemas/assembly/relocation-resolution.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/assembly/relocation-resolution.schema.json` |
| SHA-256 | `5a805a84d6babd0e905a296a7f4443a5b848e1c3e73d6ab1f6279a7954959ea4` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.local/schemas/assembly/relocation-resolution.schema.json` |
| Title | v0.7.9 COFF relocation resolution |
| Top-level type | `object` |
| Top-level properties | 8 |
| Required fields | 8 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `True` |

## Required fields

- `architecture`
- `base_rva`
- `exact_match`
- `object`
- `relocations`
- `resolved_count`
- `symbol`
- `unresolved_count`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `enum` | yes | Not declared |
| `base_rva` | `integer` | yes | Not declared |
| `exact_match` | `boolean` | yes | Not declared |
| `object` | `string` | yes | Not declared |
| `relocations` | `array` | yes | Not declared |
| `resolved_count` | `integer` | yes | Not declared |
| `symbol` | `string` | yes | Not declared |
| `unresolved_count` | `integer` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
