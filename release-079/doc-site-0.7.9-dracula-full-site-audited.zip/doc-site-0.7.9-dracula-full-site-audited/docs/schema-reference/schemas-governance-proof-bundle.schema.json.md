---
title: "proof bundle manifest"
description: "Exact source-derived schema reference for schemas/governance/proof-bundle.schema.json"
---

# `schemas/governance/proof-bundle.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/governance/proof-bundle.schema.json` |
| SHA-256 | `f12ed09701d8e5f97360bc08567e40d1cfd67ec5eff5cd2c0f9515ed75801049` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `Not declared` |
| Title | proof bundle manifest |
| Top-level type | `object` |
| Top-level properties | 4 |
| Required fields | 3 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `False` |

## Required fields

- `files`
- `format`
- `release`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `audit_tip` | `string, null` | no | Not declared |
| `files` | `object` | yes | Not declared |
| `format` | `Not declared` | yes | Not declared |
| `release` | `Not declared` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
