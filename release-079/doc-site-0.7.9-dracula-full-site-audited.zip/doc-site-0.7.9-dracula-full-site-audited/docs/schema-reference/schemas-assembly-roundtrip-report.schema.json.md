---
title: "v0.7.9 mnemonic round-trip report"
description: "Exact source-derived schema reference for schemas/assembly/roundtrip-report.schema.json"
---

# `schemas/assembly/roundtrip-report.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/assembly/roundtrip-report.schema.json` |
| SHA-256 | `d244fc6ddab57b67fdf08da4f60490bcf30f7ebb0078ef652766ca15ff79bebe` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.local/schemas/assembly/roundtrip-report.schema.json` |
| Title | v0.7.9 mnemonic round-trip report |
| Top-level type | `object` |
| Top-level properties | 10 |
| Required fields | 9 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `True` |

## Required fields

- `architecture`
- `classification`
- `exact_match`
- `input_sha256`
- `object`
- `resolved_sha256`
- `rva`
- `source`
- `symbol`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `architecture` | `enum` | yes | Not declared |
| `classification` | `enum` | yes | Not declared |
| `exact_match` | `boolean` | yes | Not declared |
| `input_sha256` | `string` | yes | Not declared |
| `object` | `string` | yes | Not declared |
| `resolved_sha256` | `string` | yes | Not declared |
| `rva` | `integer` | yes | Not declared |
| `semantic_equivalence_claimed` | `Not declared` | no | Not declared |
| `source` | `string` | yes | Not declared |
| `symbol` | `string` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
