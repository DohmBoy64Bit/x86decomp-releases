---
title: "Reconstruction capsule manifest"
description: "Exact source-derived schema reference for schemas/reconstruction/capsule.schema.json"
---

# `schemas/reconstruction/capsule.schema.json`

This page is generated from the exact schema file in the v0.7.9 source tree. It is not an inferred or hand-written summary.

| Field | Value |
| --- | --- |
| Scope | `toolkit` |
| Source path | `schemas/reconstruction/capsule.schema.json` |
| SHA-256 | `1d0a091a5d2de1f52f4395d4cc5972ee3fcec1d20cfbdbc80b7c490776188e90` |
| `$schema` | `https://json-schema.org/draft/2020-12/schema` |
| `$id` | `https://x86decomp.dev/schemas/reconstruction/capsule.schema.json` |
| Title | Reconstruction capsule manifest |
| Top-level type | `object` |
| Top-level properties | 4 |
| Required fields | 4 |
| Definitions / `$defs` | 0 |
| `additionalProperties` | `False` |

## Required fields

- `external_requirements`
- `members`
- `schema`
- `toolkit_version`

## Top-level properties

| Property | Type | Required | Description |
| --- | --- | --- | --- |
| `external_requirements` | `array` | yes | Not declared |
| `members` | `array` | yes | Not declared |
| `schema` | `Not declared` | yes | Not declared |
| `toolkit_version` | `Not declared` | yes | Not declared |

## Definition keys

This schema declares no top-level `definitions` or `$defs` object.

## Source verification

The schema audit verifies that this page names the same source path and SHA-256 hash as the file in the v0.7.9 toolkit archive, and that the source schema passes JSON Schema meta-validation.
