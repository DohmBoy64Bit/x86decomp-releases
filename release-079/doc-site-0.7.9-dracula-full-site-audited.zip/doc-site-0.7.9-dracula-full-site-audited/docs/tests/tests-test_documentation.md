---
title: tests/test_documentation.py
description: Test source reference for tests/test_documentation.py.
---

# `tests/test_documentation.py`

**SHA-256:** `f6cef98bbef2df5c193fbe09d1c45a26c4c2558d786ef1b3177aa622dc9a9e39`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_release_documents_and_maps_are_current` | function | 13 | 35 |
| `test_test_plan_counts_match_feature_catalog` | function | 38 | 58 |
| `test_four_architecture_artifacts_exist_and_cross_link` | function | 61 | 74 |
