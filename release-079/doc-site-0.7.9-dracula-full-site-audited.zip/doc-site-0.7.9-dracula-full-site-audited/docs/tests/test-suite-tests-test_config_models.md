---
title: test-suite/tests/test_config_models.py
description: Test source reference for test-suite/tests/test_config_models.py.
---

# `test-suite/tests/test_config_models.py`

**SHA-256:** `17f1ae8d2f331b61b344445d0cc0f2dad8b46f39e777cae3836c6b4381871b6e`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_config_roundtrip_and_relative_resolution` | function | 14 | 41 |
| `test_status_counts_and_strict_exit_code` | function | 44 | 71 |
