---
title: test-suite/tests/test_architecture_maps.py
description: Test source reference for test-suite/tests/test_architecture_maps.py.
---

# `test-suite/tests/test_architecture_maps.py`

**SHA-256:** `53f8105c17f6ee3889e426a69a20ef50935ac93a6a265e43f534d6f72fc26693`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_all_architecture_map_artifacts_exist_and_are_versioned` | function | 34 | 44 |
| `test_toolkit_mermaid_and_ascii_maps_cover_same_major_planes_and_states` | function | 47 | 74 |
| `test_test_suite_mermaid_and_ascii_maps_cover_same_resolution_and_gate_contract` | function | 77 | 103 |
| `test_architecture_map_cross_links_and_ascii_format_contract` | function | 106 | 126 |
