---
title: tests/native/test_staging_loop_runtime_windows.py
description: Test source reference for tests/native/test_staging_loop_runtime_windows.py.
---

# `tests/native/test_staging_loop_runtime_windows.py`

**SHA-256:** `ba3d54a7302157c38b1dc17c827d03dbff822a48096cc567d0688c385e4cb5ea`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_staging_context_resolution_and_compile_check` | function | 21 | 32 |
| `test_closed_loop_requires_consent_and_records_verified_result` | function | 35 | 46 |
| `test_runtime_static_validation_and_crash_mapping` | function | 49 | 60 |
| `test_windows_launcher_prefers_batch_on_windows_and_response_files` | function | 63 | 73 |
