---
title: test-suite/tests/test_archive_security.py
description: Test source reference for test-suite/tests/test_archive_security.py.
---

# `test-suite/tests/test_archive_security.py`

**SHA-256:** `6e68e59f12f9593f838f1cee1365eb028901767764c784099996542c75816373`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_safe_zip_and_tar_extraction` | function | 17 | 37 |
| `test_rejects_traversal_and_links` | function | 40 | 58 |
| `test_release_asset_selection_is_deterministic` | function | 61 | 72 |
| `test_download_file_hash_and_size_limit` | function | 74 | 89 |
