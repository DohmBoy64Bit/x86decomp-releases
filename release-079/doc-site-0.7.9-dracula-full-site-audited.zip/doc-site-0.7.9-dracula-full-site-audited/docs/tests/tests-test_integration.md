---
title: tests/test_integration.py
description: Test source reference for tests/test_integration.py.
---

# `tests/test_integration.py`

**SHA-256:** `82f41b4bbbe8add7b6609303d9d85f7d64d6bf6fe50c9acf6ceaf6e2f8bb57d0`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_integration_requires_explicit_host_consent` | function | 80 | 87 |
| `test_integration_equivalence_and_difference` | function | 90 | 103 |
