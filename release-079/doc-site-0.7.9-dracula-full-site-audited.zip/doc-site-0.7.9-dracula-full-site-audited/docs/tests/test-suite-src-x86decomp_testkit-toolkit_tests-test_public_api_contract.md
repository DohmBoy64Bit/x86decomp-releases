---
title: test-suite/src/x86decomp_testkit/toolkit_tests/test_public_api_contract.py
description: Test source reference for test-suite/src/x86decomp_testkit/toolkit_tests/test_public_api_contract.py.
---

# `test-suite/src/x86decomp_testkit/toolkit_tests/test_public_api_contract.py`

**SHA-256:** `06f79772fcde1a6eece4075ac2da5807566f8d002f4fa4045a8add1b5d4998d5`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_unified_canonical_entry_point` | function | 79 | 93 |
| `test_abi_contract_loading` | function | 96 | 116 |
| `test_analysis_database_complete_public_surface` | function | 119 | 148 |
| `test_angr_public_file_wrappers` | function | 151 | 174 |
| `test_benchmark_metrics_and_runner` | function | 177 | 193 |
| `test_coff_remaining_value_objects_and_writer` | function | 196 | 215 |
| `test_compiler_lab_with_deterministic_fake_compiler` | function | 218 | 254 |
| `test_diff_disassembly_and_crosscheck` | function | 257 | 274 |
| `test_dynamic_file_wrapper_and_spec_loader` | function | 277 | 297 |
| `test_dynamorio_runner_with_fake_subprocess` | function | 300 | 328 |
| `test_evidence_contradiction_require_verified_and_project_memory` | function | 348 | 360 |
| `test_exe_diff_extract_and_compare` | function | 363 | 375 |
| `test_ghidra_run_export_success` | function | 378 | 387 |
| `test_remaining_value_objects_and_peview` | function | 390 | 408 |
| `test_service_create_and_run` | function | 411 | 423 |
| `test_symbolic_clone_and_file_wrapper` | function | 426 | 442 |
| `test_toolchain_snapshot_util_contract_and_workqueue` | function | 445 | 468 |
| `test_cli_main_executes_public_entrypoint` | function | 471 | 481 |
| `test_streamable_http_mcp_public_methods` | function | 484 | 567 |
| `test_private_function_surface_regression` | function | 570 | 606 |
| `test_remaining_current_function_surface` | function | 609 | 679 |
