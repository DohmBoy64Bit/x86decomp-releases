---
title: tests/assembly/test_annotation_materialize.py
description: Test source reference for tests/assembly/test_annotation_materialize.py.
---

# `tests/assembly/test_annotation_materialize.py`

**SHA-256:** `8826c17e58afe3196a8f1b0be7c76001a39c790f7e3bb30dba7057a652126295`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_byte_form_is_exact_native_compatibility_output` | function | 24 | 35 |
| `test_annotation_is_idempotent_and_keeps_bytes` | function | 38 | 57 |
| `test_x86_external_and_local_calls_roundtrip_exactly` | function | 77 | 102 |
| `test_x64_rip_relative_data_reference_roundtrips` | function | 105 | 119 |
| `test_noncanonical_instruction_falls_back_per_instruction` | function | 122 | 138 |
| `test_unknown_target_uses_byte_fallback_without_false_claim` | function | 141 | 155 |
| `test_verify_existing_source_reports_exact_and_mismatch` | function | 158 | 191 |
| `test_undecodable_tail_uses_complete_byte_form_fallback` | function | 194 | 209 |
