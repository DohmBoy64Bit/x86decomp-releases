---
title: tests/reconstruction/test_project_headers_builds.py
description: Test source reference for tests/reconstruction/test_project_headers_builds.py.
---

# `tests/reconstruction/test_project_headers_builds.py`

**SHA-256:** `e414e5333698c6e470bb2007314f7196bf695ea9765d5345d5be46b557fae899`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_store_is_additive_and_layout_is_evidence_labeled` | function | 17 | 37 |
| `test_headers_reject_cycles_and_generate_compileable_shape` | function | 40 | 54 |
| `test_historical_and_portable_build_modes_remain_distinct` | function | 57 | 75 |
