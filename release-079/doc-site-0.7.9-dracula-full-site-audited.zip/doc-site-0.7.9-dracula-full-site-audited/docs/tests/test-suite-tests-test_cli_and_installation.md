---
title: test-suite/tests/test_cli_and_installation.py
description: Test source reference for test-suite/tests/test_cli_and_installation.py.
---

# `test-suite/tests/test_cli_and_installation.py`

**SHA-256:** `169278c3cbbf49f9ee14734d4488d7c1d42b93a31dbb59287b6bb63a698a266c`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_cli_init_config_catalog_and_missing_config` | function | 19 | 29 |
| `test_install_python_command_and_failure` | function | 32 | 62 |
