---
title: test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py
description: Test source reference for test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py`

**SHA-256:** `2bc8eb32228962016085f7869d3c3c8669d728c18e26b2342471cbb3a4e9fff6`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_inventory_catalog_and_public_coverage` | function | 38 | 60 |
| `test_junit_process_logging_and_reports` | function | 63 | 94 |
| `test_suite_schemas_and_catalog_are_valid` | function | 96 | 115 |
| `test_recursive_inventory_includes_capability_packages_and_nested_schemas` | function | 118 | 135 |
