---
title: tests/test_abi_disassembly.py
description: Test source reference for tests/test_abi_disassembly.py.
---

# `tests/test_abi_disassembly.py`

**SHA-256:** `17701bdea84b983219f6929aca6d3dc61146cb93dd3e798c292f8711d507284f`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_stdcall_ret_cleanup` | function | 13 | 20 |
