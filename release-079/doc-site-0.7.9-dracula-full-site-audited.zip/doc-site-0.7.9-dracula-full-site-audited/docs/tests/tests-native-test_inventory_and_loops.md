---
title: tests/native/test_inventory_and_loops.py
description: Test source reference for tests/native/test_inventory_and_loops.py.
---

# `tests/native/test_inventory_and_loops.py`

**SHA-256:** `cf7d59f5a4ef2b820c4e36156c08902f9f71d531474db18258faed92077f6ce3`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_native_cli_json_helpers` | function | 21 | 30 |
| `test_project_inventory_audit_pe_inventory_reports_and_doctor` | function | 33 | 56 |
| `test_native_list_and_verify_paths` | function | 59 | 82 |
