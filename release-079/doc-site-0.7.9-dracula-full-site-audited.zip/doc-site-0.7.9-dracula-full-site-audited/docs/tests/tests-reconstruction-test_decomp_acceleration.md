---
title: tests/reconstruction/test_decomp_acceleration.py
description: Test source reference for tests/reconstruction/test_decomp_acceleration.py.
---

# `tests/reconstruction/test_decomp_acceleration.py`

**SHA-256:** `084276e431cedc058e2618f0452234fcf2ca65b7c84b9aaf5db07c3f1c78ccf5`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_llm_job_create_and_range` | function | 41 | 57 |
| `test_source_map_and_candidate_promotion` | function | 60 | 78 |
| `test_planning_helpers` | function | 81 | 99 |
