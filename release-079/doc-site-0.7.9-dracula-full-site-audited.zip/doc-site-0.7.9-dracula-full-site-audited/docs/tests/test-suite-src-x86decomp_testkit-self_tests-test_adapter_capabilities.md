---
title: test-suite/src/x86decomp_testkit/self_tests/test_adapter_capabilities.py
description: Test source reference for test-suite/src/x86decomp_testkit/self_tests/test_adapter_capabilities.py.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_adapter_capabilities.py`

**SHA-256:** `800f2386254e83a620495ac5890a423ea405fa6337ed209753eb309df9e5dfc5`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_lm_studio_http_satisfies_openai_capability_without_product_aliasing` | function | 56 | 87 |
| `test_non_loopback_http_endpoint_requires_network_opt_in` | function | 90 | 98 |
| `test_loopback_host_classifier_is_strict` | function | 101 | 108 |
