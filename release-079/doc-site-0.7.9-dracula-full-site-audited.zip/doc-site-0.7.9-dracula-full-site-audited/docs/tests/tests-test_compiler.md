---
title: tests/test_compiler.py
description: Test source reference for tests/test_compiler.py.
---

# `tests/test_compiler.py`

**SHA-256:** `d706d02771c6c2728af1768d1c1b6b4a9d1a3a689984a48186462e159643bccd`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_compile_i386_object` | function | 21 | 35 |
