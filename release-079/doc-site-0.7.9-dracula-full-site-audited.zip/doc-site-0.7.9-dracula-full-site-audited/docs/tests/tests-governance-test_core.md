---
title: tests/governance/test_core.py
description: Test source reference for tests/governance/test_core.py.
---

# `tests/governance/test_core.py`

**SHA-256:** `fa6f659a75fc991a8244596935c88e7aa6f2dcdfaee0d653ab1beb2b806fb182`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_store_is_additive_and_audit_chain` | function | 32 | 45 |
| `test_audit_tamper_detected` | function | 48 | 56 |
| `test_hypothesis_gate_and_accept` | function | 59 | 71 |
| `test_hypothesis_contradiction_blocks_acceptance` | function | 74 | 82 |
| `test_hypothesis_dependency_cycle_rejected` | function | 85 | 92 |
| `test_campaign_lifecycle_and_planner` | function | 95 | 104 |
| `test_campaign_budget_blocks` | function | 107 | 114 |
| `test_campaign_branch` | function | 117 | 124 |
| `test_candidate_branch_compare_and_promotion` | function | 127 | 137 |
| `test_candidate_rejects_traversal` | function | 140 | 146 |
| `test_ddmin_and_counterexample_promotion` | function | 149 | 160 |
| `test_consensus_conflict_and_resolution` | function | 163 | 173 |
| `test_graph_impact` | function | 176 | 183 |
| `test_review_lock_resists_automation` | function | 186 | 193 |
| `test_family_correlation_is_bounded` | function | 196 | 206 |
| `test_remaining_public_list_snapshot_and_review_paths` | function | 208 | 221 |
| `test_family_report_path` | function | 224 | 230 |
