---
title: test-suite/tests/test_inventory_reports_process.py
description: Test source reference for test-suite/tests/test_inventory_reports_process.py.
---

# `test-suite/tests/test_inventory_reports_process.py`

**SHA-256:** `9aa18706c5aa74891201025b03e22e9c4a30467f5875810a58962de57e36c6fc`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_inventory_catalog_and_public_coverage` | function | 38 | 60 |
| `test_junit_process_logging_and_reports` | function | 63 | 94 |
| `test_suite_schemas_and_catalog_are_valid` | function | 96 | 115 |
| `test_recursive_inventory_includes_capability_packages_and_nested_schemas` | function | 118 | 135 |
