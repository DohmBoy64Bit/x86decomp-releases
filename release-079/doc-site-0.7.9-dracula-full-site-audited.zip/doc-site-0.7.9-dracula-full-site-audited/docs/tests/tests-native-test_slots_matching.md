---
title: tests/native/test_slots_matching.py
description: Test source reference for tests/native/test_slots_matching.py.
---

# `tests/native/test_slots_matching.py`

**SHA-256:** `70a46698f2508a6d1e15ef1bc50041328f7663041942f64a320002eff2c72f54`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_slot_audit_classifies_exact_padding_and_overlap` | function | 13 | 27 |
| `test_padding_comparison_is_tail_only_and_protected_aware` | function | 30 | 37 |
| `test_batch_matching_records_safe_and_fallback` | function | 40 | 54 |
| `test_short_candidate_requires_padding_only_remainder` | function | 57 | 69 |
