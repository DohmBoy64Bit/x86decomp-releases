---
title: tests/test_decompme_objdiff.py
description: Test source reference for tests/test_decompme_objdiff.py.
---

# `tests/test_decompme_objdiff.py`

**SHA-256:** `24378946f68f75ed85ade7ba86228a6f35ca6a98ad07156751c5e85c1fc33cf7`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_create_local_decompme_packet` | function | 15 | 45 |
| `test_manifest_driven_objdiff_adapter` | function | 48 | 84 |
