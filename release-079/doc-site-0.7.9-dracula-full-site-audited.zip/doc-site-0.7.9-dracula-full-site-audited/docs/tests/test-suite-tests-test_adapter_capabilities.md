---
title: test-suite/tests/test_adapter_capabilities.py
description: Test source reference for test-suite/tests/test_adapter_capabilities.py.
---

# `test-suite/tests/test_adapter_capabilities.py`

**SHA-256:** `3795838f0ddb6b2d4f3d137d10160a0b95f425f606e994f1a8093eb28b8beba1`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_lm_studio_http_satisfies_openai_capability_without_product_aliasing` | function | 56 | 87 |
| `test_non_loopback_http_endpoint_requires_network_opt_in` | function | 90 | 98 |
| `test_loopback_host_classifier_is_strict` | function | 101 | 108 |
