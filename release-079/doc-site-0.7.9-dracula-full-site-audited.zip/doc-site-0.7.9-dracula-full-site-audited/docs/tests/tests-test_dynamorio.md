---
title: tests/test_dynamorio.py
description: Test source reference for tests/test_dynamorio.py.
---

# `tests/test_dynamorio.py`

**SHA-256:** `db5a82b54103fe3b6f10a610461e1571f4d256df8d58f5e170410ee080723c67`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_parse_drcov_text` | function | 17 | 37 |
| `test_angr_backend_has_explicit_optional_dependency_error` | function | 40 | 57 |
