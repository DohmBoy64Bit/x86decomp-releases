---
title: test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py
description: Test source reference for test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py`

**SHA-256:** `a479512db3de83ee9ad57ab1b81049248767d36765119bf4fd57a5cca30aba11`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_safe_zip_and_tar_extraction` | function | 17 | 37 |
| `test_rejects_traversal_and_links` | function | 40 | 58 |
| `test_release_asset_selection_is_deterministic` | function | 61 | 72 |
| `test_download_file_hash_and_size_limit` | function | 74 | 89 |
