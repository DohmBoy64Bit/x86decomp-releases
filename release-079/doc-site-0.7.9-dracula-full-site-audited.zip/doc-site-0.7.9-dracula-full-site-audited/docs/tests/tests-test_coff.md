---
title: tests/test_coff.py
description: Test source reference for tests/test_coff.py.
---

# `tests/test_coff.py`

**SHA-256:** `86bf9dde7b1b30f39e791550be46d72b5deb6d70674a33ec3bab09e92a5202be`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_synthetic_coff_round_trip` | function | 10 | 20 |
| `test_synthetic_coff_relocation` | function | 23 | 33 |
