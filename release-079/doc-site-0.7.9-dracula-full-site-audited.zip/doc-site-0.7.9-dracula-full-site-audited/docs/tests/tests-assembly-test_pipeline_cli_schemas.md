---
title: tests/assembly/test_pipeline_cli_schemas.py
description: Test source reference for tests/assembly/test_pipeline_cli_schemas.py.
---

# `tests/assembly/test_pipeline_cli_schemas.py`

**SHA-256:** `c0648e3ddae044d9f6bbbf45e9cbaf993517d65a4af5e37a5244594c5f6b36eb`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_pipeline_all_three_formats_and_durable_reports` | function | 69 | 89 |
| `test_assembly_project_cli_and_all_leaf_help` | function | 92 | 108 |
| `test_main_cli_exposes_assembly_capabilities` | function | 111 | 122 |
| `test_assembly_schemas_and_symbol_map_contracts` | function | 125 | 137 |
| `test_store_keeps_all_prior_schema_layers` | function | 140 | 150 |
| `test_pipeline_persists_relocation_evidence` | function | 153 | 167 |
| `test_hybrid_generate_keeps_bytes_default_and_allows_explicit_modes` | function | 170 | 195 |
| `test_failed_batch_is_recorded_durably` | function | 198 | 219 |
