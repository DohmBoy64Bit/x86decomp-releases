---
title: tests/test_ghidra.py
description: Test source reference for tests/test_ghidra.py.
---

# `tests/test_ghidra.py`

**SHA-256:** `096a793486a8f6c1200d2258f699b421b43257f8989cf24e903831d865996c3c`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_build_export_command_is_argument_array` | function | 19 | 49 |
