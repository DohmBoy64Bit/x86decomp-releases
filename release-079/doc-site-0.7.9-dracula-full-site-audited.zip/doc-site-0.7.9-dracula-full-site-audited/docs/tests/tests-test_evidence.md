---
title: tests/test_evidence.py
description: Test source reference for tests/test_evidence.py.
---

# `tests/test_evidence.py`

**SHA-256:** `eafd6d37794df612f9452d351ade4f4374a8da6c0a1677f54477c3ee3bf5cc05`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_three_independent_sources_verify_claim` | function | 20 | 58 |
| `test_same_group_does_not_verify` | function | 60 | 88 |
