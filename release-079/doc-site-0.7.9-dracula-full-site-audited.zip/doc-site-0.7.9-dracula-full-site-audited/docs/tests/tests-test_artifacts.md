---
title: tests/test_artifacts.py
description: Test source reference for tests/test_artifacts.py.
---

# `tests/test_artifacts.py`

**SHA-256:** `b6bd1e77bbbe3842c3dfc006aff9dd7316b1265ff3a1c140f403b74e8806bfaa`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_import_and_verify` | function | 43 | 52 |
| `test_integrity_path_escape_is_rejected` | function | 54 | 68 |
