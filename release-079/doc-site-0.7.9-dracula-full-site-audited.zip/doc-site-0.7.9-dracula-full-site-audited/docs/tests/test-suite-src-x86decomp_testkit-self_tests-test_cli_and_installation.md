---
title: test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py
description: Test source reference for test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py`

**SHA-256:** `7c5a42f6e99d35232a729cf2e1b8de6e9636c16871bca670714a98efc233b7b0`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_cli_init_config_catalog_and_missing_config` | function | 19 | 29 |
| `test_install_python_command_and_failure` | function | 32 | 62 |
