---
title: tests/test_diffing.py
description: Test source reference for tests/test_diffing.py.
---

# `tests/test_diffing.py`

**SHA-256:** `741fbeae4f60d0e573e23cc14158cafdcb76724f503179283f0dd37abe4d19ef`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_equal` | function | 17 | 25 |
| `test_mismatch` | function | 27 | 34 |
