---
title: tests/test_coff_archive.py
description: Test source reference for tests/test_coff_archive.py.
---

# `tests/test_coff_archive.py`

**SHA-256:** `ef5b8543e36a10c86383f456abcc79add5e35f46fc58cf976a20d847993a057a`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_real_coff_archive_members_symbols_and_comdat` | function | 18 | 58 |
| `test_static_library_is_inspected_in_safe_bundle` | function | 62 | 92 |
| `test_real_import_library_records` | function | 98 | 127 |
