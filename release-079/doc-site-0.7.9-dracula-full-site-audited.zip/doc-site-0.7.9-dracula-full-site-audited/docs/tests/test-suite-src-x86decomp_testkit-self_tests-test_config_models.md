---
title: test-suite/src/x86decomp_testkit/self_tests/test_config_models.py
description: Test source reference for test-suite/src/x86decomp_testkit/self_tests/test_config_models.py.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_config_models.py`

**SHA-256:** `360885038379a556c0545f1420251c77aaa2d168cc199b94f8075f5ac2311709`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_config_roundtrip_and_relative_resolution` | function | 14 | 41 |
| `test_status_counts_and_strict_exit_code` | function | 44 | 71 |
