---
title: tests/native/test_cli_schemas.py
description: Test source reference for tests/native/test_cli_schemas.py.
---

# `tests/native/test_cli_schemas.py`

**SHA-256:** `cad4c6043e87820721c5bb46b5c747efb637aad233e4714cc656b0b0700e6a95`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_native_project_init_and_all_leaf_help` | function | 38 | 49 |
| `test_main_cli_exposes_native_capabilities` | function | 52 | 63 |
| `test_native_schemas_meta_validate` | function | 66 | 72 |
| `test_native_store_keeps_all_prior_schema_layers` | function | 75 | 81 |
