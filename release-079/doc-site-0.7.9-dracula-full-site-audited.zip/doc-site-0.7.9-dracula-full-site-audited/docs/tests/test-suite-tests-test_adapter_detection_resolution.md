---
title: test-suite/tests/test_adapter_detection_resolution.py
description: Test source reference for test-suite/tests/test_adapter_detection_resolution.py.
---

# `test-suite/tests/test_adapter_detection_resolution.py`

**SHA-256:** `fc8c6c20faeb3589005c088d6c55dec7acbbfd3e4a3a1e2732ab118214789d75`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_installed_adapter_never_prompts` | function | 28 | 47 |
| `test_missing_adapter_prompts_custom_path_then_accepts` | function | 50 | 75 |
| `test_missing_noninteractive_is_explicit_unresolved` | function | 78 | 87 |
| `test_environment_and_configured_root_detection` | function | 90 | 109 |
| `test_path_detection_preserves_symlink_argv0` | function | 111 | 130 |
| `test_missing_python_adapter_accepts_custom_interpreter` | function | 132 | 143 |
