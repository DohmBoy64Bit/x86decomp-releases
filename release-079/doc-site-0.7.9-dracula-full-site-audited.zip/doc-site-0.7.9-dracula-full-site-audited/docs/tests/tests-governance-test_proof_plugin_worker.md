---
title: tests/governance/test_proof_plugin_worker.py
description: Test source reference for tests/governance/test_proof_plugin_worker.py.
---

# `tests/governance/test_proof_plugin_worker.py`

**SHA-256:** `c0909a9e96789fa822334ea2f9645c3c41a72cff2a3dafb152aa43b526cb8bfe`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_proof_ledger_and_bundle` | function | 21 | 34 |
| `test_proof_bundle_rejects_outside_artifact` | function | 37 | 43 |
| `test_plugin_install_doctor_invoke` | function | 58 | 67 |
| `test_plugin_rejects_undeclared_capability` | function | 70 | 76 |
| `test_worker_registry_selection_and_doctor` | function | 79 | 87 |
| `test_changeset_round_trip` | function | 90 | 99 |
| `test_changeset_base_mismatch` | function | 102 | 110 |
| `test_plugin_list_and_proof_inspect` | function | 112 | 119 |
