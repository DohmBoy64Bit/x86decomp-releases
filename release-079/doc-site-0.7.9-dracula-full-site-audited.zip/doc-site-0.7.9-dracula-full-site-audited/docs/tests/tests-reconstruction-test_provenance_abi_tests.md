---
title: tests/reconstruction/test_provenance_abi_tests.py
description: Test source reference for tests/reconstruction/test_provenance_abi_tests.py.
---

# `tests/reconstruction/test_provenance_abi_tests.py`

**SHA-256:** `0ed3d5f50ae720a16b27bf88a50d1971030589a11c6596c1a5e66fcd29fd4688`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_provenance_round_trip_edit_reconciliation_and_locks` | function | 20 | 37 |
| `test_abi_contract_verification_comparison_and_explicit_shim` | function | 40 | 53 |
| `test_generated_tests_are_evidence_bound_and_counterexamples_promote` | function | 56 | 71 |
