---
title: test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py
description: Test source reference for test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py.
---

# `test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py`

**SHA-256:** `eddbb2781cfc0412c060669b7ddc734607791987fa1c243926308727e6a7f548`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_installed_adapter_never_prompts` | function | 28 | 47 |
| `test_missing_adapter_prompts_custom_path_then_accepts` | function | 50 | 75 |
| `test_missing_noninteractive_is_explicit_unresolved` | function | 78 | 87 |
| `test_environment_and_configured_root_detection` | function | 90 | 109 |
| `test_path_detection_preserves_symlink_argv0` | function | 111 | 125 |
| `test_missing_python_adapter_accepts_custom_interpreter` | function | 127 | 138 |
