---
title: tests/assembly/test_helpers_and_relocations.py
description: Test source reference for tests/assembly/test_helpers_and_relocations.py.
---

# `tests/assembly/test_helpers_and_relocations.py`

**SHA-256:** `d64ad18081440cde706ef8b24adae9ef24240d0ab87736b5cb81ec0081579260`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_assembly_cli_json_integer_and_error_helpers` | function | 17 | 31 |
| `test_symbol_address_error_and_render_helpers` | function | 34 | 46 |
| `test_relocation_inspection_paths` | function | 49 | 69 |
