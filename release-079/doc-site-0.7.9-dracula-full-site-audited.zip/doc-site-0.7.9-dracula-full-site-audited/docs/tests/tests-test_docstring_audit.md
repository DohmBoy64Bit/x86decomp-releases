---
title: tests/test_docstring_audit.py
description: Test source reference for tests/test_docstring_audit.py.
---

# `tests/test_docstring_audit.py`

**SHA-256:** `981de0362a6076ed3d1cb0ac5df8b55c969851ac2c5d7edb016b0f37d364642c`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_every_python_symbol_has_a_docstring` | function | 36 | 47 |
| `test_docstring_audit_report_matches_current_release` | function | 50 | 58 |
| `test_command_reference_matches_canonical_surface` | function | 61 | 68 |
