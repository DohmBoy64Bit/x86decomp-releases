---
title: tests/reconstruction/test_cli_schemas_retention.py
description: Test source reference for tests/reconstruction/test_cli_schemas_retention.py.
---

# `tests/reconstruction/test_cli_schemas_retention.py`

**SHA-256:** `6f40dc1083132137b7683474bbe157c29fdfc887af930745ce203f71d00a6d27`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_reconstruction_json_argument_validation` | function | 35 | 44 |
| `test_reconstruction_cli_has_complete_project_scale_surface` | function | 46 | 56 |
| `test_every_reconstruction_leaf_command_parses_help` | function | 60 | 73 |
| `test_main_cli_exposes_reconstruction_capabilities` | function | 75 | 90 |
| `test_all_reconstruction_schemas_are_meta_valid` | function | 93 | 99 |
| `test_governance_capabilities_are_in_the_unified_catalog` | function | 102 | 111 |
