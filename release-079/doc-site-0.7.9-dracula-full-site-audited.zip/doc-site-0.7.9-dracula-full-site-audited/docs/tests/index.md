---
title: Test Source Reference
description: Source-derived test file and test-node coverage for x86decomp 0.7.9.
---

# Test Source Reference

This index covers **60** test source files. It documents collected test definitions but does not claim every optional external adapter was available during the release environment.

| Test source | Test functions/classes | SHA-256 |
| --- | ---: | --- |
| [`test-suite/src/x86decomp_testkit/self_tests/test_adapter_capabilities.py`](test-suite-src-x86decomp_testkit-self_tests-test_adapter_capabilities.md) | 3 | `800f2386254e83a620495ac5890a423ea405fa6337ed209753eb309df9e5dfc5` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py`](test-suite-src-x86decomp_testkit-self_tests-test_adapter_detection_resolution.md) | 6 | `eddbb2781cfc0412c060669b7ddc734607791987fa1c243926308727e6a7f548` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py`](test-suite-src-x86decomp_testkit-self_tests-test_archive_security.md) | 4 | `a479512db3de83ee9ad57ab1b81049248767d36765119bf4fd57a5cca30aba11` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py`](test-suite-src-x86decomp_testkit-self_tests-test_cli_and_installation.md) | 2 | `7c5a42f6e99d35232a729cf2e1b8de6e9636c16871bca670714a98efc233b7b0` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_config_models.py`](test-suite-src-x86decomp_testkit-self_tests-test_config_models.md) | 2 | `360885038379a556c0545f1420251c77aaa2d168cc199b94f8075f5ac2311709` |
| [`test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py`](test-suite-src-x86decomp_testkit-self_tests-test_inventory_reports_process.md) | 4 | `2bc8eb32228962016085f7869d3c3c8669d728c18e26b2342471cbb3a4e9fff6` |
| [`test-suite/src/x86decomp_testkit/toolkit_tests/test_public_api_contract.py`](test-suite-src-x86decomp_testkit-toolkit_tests-test_public_api_contract.md) | 21 | `06f79772fcde1a6eece4075ac2da5807566f8d002f4fa4045a8add1b5d4998d5` |
| [`test-suite/tests/test_adapter_capabilities.py`](test-suite-tests-test_adapter_capabilities.md) | 3 | `3795838f0ddb6b2d4f3d137d10160a0b95f425f606e994f1a8093eb28b8beba1` |
| [`test-suite/tests/test_adapter_detection_resolution.py`](test-suite-tests-test_adapter_detection_resolution.md) | 6 | `fc8c6c20faeb3589005c088d6c55dec7acbbfd3e4a3a1e2732ab118214789d75` |
| [`test-suite/tests/test_architecture_maps.py`](test-suite-tests-test_architecture_maps.md) | 4 | `53f8105c17f6ee3889e426a69a20ef50935ac93a6a265e43f534d6f72fc26693` |
| [`test-suite/tests/test_archive_security.py`](test-suite-tests-test_archive_security.md) | 4 | `6e68e59f12f9593f838f1cee1365eb028901767764c784099996542c75816373` |
| [`test-suite/tests/test_cli_and_installation.py`](test-suite-tests-test_cli_and_installation.md) | 2 | `169278c3cbbf49f9ee14734d4488d7c1d42b93a31dbb59287b6bb63a698a266c` |
| [`test-suite/tests/test_config_models.py`](test-suite-tests-test_config_models.md) | 2 | `17f1ae8d2f331b61b344445d0cc0f2dad8b46f39e777cae3836c6b4381871b6e` |
| [`test-suite/tests/test_inventory_reports_process.py`](test-suite-tests-test_inventory_reports_process.md) | 4 | `9aa18706c5aa74891201025b03e22e9c4a30467f5875810a58962de57e36c6fc` |
| [`tests/assembly/test_annotation_materialize.py`](tests-assembly-test_annotation_materialize.md) | 8 | `8826c17e58afe3196a8f1b0be7c76001a39c790f7e3bb30dba7057a652126295` |
| [`tests/assembly/test_helpers_and_relocations.py`](tests-assembly-test_helpers_and_relocations.md) | 3 | `d64ad18081440cde706ef8b24adae9ef24240d0ab87736b5cb81ec0081579260` |
| [`tests/assembly/test_pipeline_cli_schemas.py`](tests-assembly-test_pipeline_cli_schemas.md) | 8 | `c0648e3ddae044d9f6bbbf45e9cbaf993517d65a4af5e37a5244594c5f6b36eb` |
| [`tests/governance/test_core.py`](tests-governance-test_core.md) | 17 | `fa6f659a75fc991a8244596935c88e7aa6f2dcdfaee0d653ab1beb2b806fb182` |
| [`tests/governance/test_governance_cli_schemas.py`](tests-governance-test_governance_cli_schemas.md) | 5 | `6bfc0da4dc3ecabcc3b95803e6978298070733b7ba7f538c2946c4f977a60ba9` |
| [`tests/governance/test_proof_plugin_worker.py`](tests-governance-test_proof_plugin_worker.md) | 8 | `c0909a9e96789fa822334ea2f9645c3c41a72cff2a3dafb152aa43b526cb8bfe` |
| [`tests/governance/test_worker_thread_safety.py`](tests-governance-test_worker_thread_safety.md) | 2 | `d128f0ebbc38c9591744620796073fe792466e303c706420b0e7b85ed0dd5c12` |
| [`tests/native/test_cli_schemas.py`](tests-native-test_cli_schemas.md) | 4 | `cad4c6043e87820721c5bb46b5c747efb637aad233e4714cc656b0b0700e6a95` |
| [`tests/native/test_inventory_and_loops.py`](tests-native-test_inventory_and_loops.md) | 3 | `cf7d59f5a4ef2b820c4e36156c08902f9f71d531474db18258faed92077f6ce3` |
| [`tests/native/test_pe_hybrid.py`](tests-native-test_pe_hybrid.md) | 4 | `71a4a6cf701f8abab032f32a443602fccf853948dd195bcf5345bb5654d039dd` |
| [`tests/native/test_slots_matching.py`](tests-native-test_slots_matching.md) | 4 | `70a46698f2508a6d1e15ef1bc50041328f7663041942f64a320002eff2c72f54` |
| [`tests/native/test_staging_loop_runtime_windows.py`](tests-native-test_staging_loop_runtime_windows.md) | 4 | `ba3d54a7302157c38b1dc17c827d03dbff822a48096cc567d0688c385e4cb5ea` |
| [`tests/reconstruction/test_capsules_security_changesets.py`](tests-reconstruction-test_capsules_security_changesets.md) | 4 | `a3a3a82532cd54a206ce69c14a6c8c2a30d916ec7acc27a8f4bd050d5027e703` |
| [`tests/reconstruction/test_cli_schemas_retention.py`](tests-reconstruction-test_cli_schemas_retention.md) | 6 | `6f40dc1083132137b7683474bbe157c29fdfc887af930745ce203f71d00a6d27` |
| [`tests/reconstruction/test_decomp_acceleration.py`](tests-reconstruction-test_decomp_acceleration.md) | 3 | `084276e431cedc058e2618f0452234fcf2ca65b7c84b9aaf5db07c3f1c78ccf5` |
| [`tests/reconstruction/test_project_headers_builds.py`](tests-reconstruction-test_project_headers_builds.md) | 3 | `e414e5333698c6e470bb2007314f7196bf695ea9765d5345d5be46b557fae899` |
| [`tests/reconstruction/test_provenance_abi_tests.py`](tests-reconstruction-test_provenance_abi_tests.md) | 3 | `0ed3d5f50ae720a16b27bf88a50d1971030589a11c6596c1a5e66fcd29fd4688` |
| [`tests/reconstruction/test_real_project_acceleration.py`](tests-reconstruction-test_real_project_acceleration.md) | 3 | `b3123bae9f28883f6abb8913774921ed1e44765325fa6c33e7918cdd73cc5ffa` |
| [`tests/test_abi_disassembly.py`](tests-test_abi_disassembly.md) | 1 | `17701bdea84b983219f6929aca6d3dc61146cb93dd3e798c292f8711d507284f` |
| [`tests/test_artifacts.py`](tests-test_artifacts.md) | 2 | `b6bd1e77bbbe3842c3dfc006aff9dd7316b1265ff3a1c140f403b74e8806bfaa` |
| [`tests/test_coff.py`](tests-test_coff.md) | 2 | `86bf9dde7b1b30f39e791550be46d72b5deb6d70674a33ec3bab09e92a5202be` |
| [`tests/test_coff_archive.py`](tests-test_coff_archive.md) | 3 | `ef5b8543e36a10c86383f456abcc79add5e35f46fc58cf976a20d847993a057a` |
| [`tests/test_compiler.py`](tests-test_compiler.md) | 1 | `d706d02771c6c2728af1768d1c1b6b4a9d1a3a689984a48186462e159643bccd` |
| [`tests/test_decompme_objdiff.py`](tests-test_decompme_objdiff.md) | 2 | `24378946f68f75ed85ade7ba86228a6f35ca6a98ad07156751c5e85c1fc33cf7` |
| [`tests/test_diffing.py`](tests-test_diffing.md) | 2 | `741fbeae4f60d0e573e23cc14158cafdcb76724f503179283f0dd37abe4d19ef` |
| [`tests/test_docstring_audit.py`](tests-test_docstring_audit.md) | 3 | `981de0362a6076ed3d1cb0ac5df8b55c969851ac2c5d7edb016b0f37d364642c` |
| [`tests/test_documentation.py`](tests-test_documentation.md) | 3 | `f6cef98bbef2df5c193fbe09d1c45a26c4c2558d786ef1b3177aa622dc9a9e39` |
| [`tests/test_dynamic_symbolic.py`](tests-test_dynamic_symbolic.md) | 2 | `505a23a84ed9953f28849fa2bb775bf633b9dfef7ed522ebf9665b52b3f7cfa8` |
| [`tests/test_dynamorio.py`](tests-test_dynamorio.md) | 2 | `db5a82b54103fe3b6f10a610461e1571f4d256df8d58f5e170410ee080723c67` |
| [`tests/test_evidence.py`](tests-test_evidence.md) | 2 | `eafd6d37794df612f9452d351ade4f4374a8da6c0a1677f54477c3ee3bf5cc05` |
| [`tests/test_ghidra.py`](tests-test_ghidra.md) | 1 | `096a793486a8f6c1200d2258f699b421b43257f8989cf24e903831d865996c3c` |
| [`tests/test_integration.py`](tests-test_integration.md) | 2 | `82f41b4bbbe8add7b6609303d9d85f7d64d6bf6fe50c9acf6ceaf6e2f8bb57d0` |
| [`tests/test_linker_metadata_corpus.py`](tests-test_linker_metadata_corpus.md) | 10 | `695cd6e5d00f8544ec59a4da46a6858a761fc6749487019302584c3765b3b3d6` |
| [`tests/test_local_llm.py`](tests-test_local_llm.md) | 8 | `5184b3e8967fcb3b378b1caac35f13cd3cf9eb3a6b37c0a0cc28e93ededb3e29` |
| [`tests/test_mcp.py`](tests-test_mcp.md) | 1 | `339f8a3c5439a86388cbc73b562508bdda69d2abfcf623624692d361b1b71e23` |
| [`tests/test_memory.py`](tests-test_memory.md) | 2 | `a0cd83c578d8e7e55734406d151ffc0395ef08fcfc4800d82c1ca81e5e1cd4bc` |
| [`tests/test_modes_and_db.py`](tests-test_modes_and_db.md) | 2 | `e96dc81329ee5f170ea6cf9ff3110a28ed660a9943d1fb22d717b6b02759e40c` |
| [`tests/test_pdb.py`](tests-test_pdb.md) | 2 | `dcd2bc88b811ff086723f0828aa4e2eb186359d46f7a0774fc5070b1d5dc715d` |
| [`tests/test_pe32.py`](tests-test_pe32.md) | 2 | `4356af1e41ff9840d708f9b108142d6de497a4bb0f744a730b005d5b8a7fc48e` |
| [`tests/test_pe64_patch_hybrid.py`](tests-test_pe64_patch_hybrid.md) | 3 | `55e4c2d0f0082bca5cb2c955df03e6abfa9754377b7041308b6265e4bd78dc69` |
| [`tests/test_production.py`](tests-test_production.md) | 22 | `abecb31053cdf69e7794e2a08e9fe742328b7b0156249a9512505dfa9d0375e2` |
| [`tests/test_project.py`](tests-test_project.md) | 2 | `7061ca9326201e2d192858f99131995ecd6e423dc97185e139eb87fb2561e262` |
| [`tests/test_release_contract.py`](tests-test_release_contract.md) | 8 | `76701995957fe469bfe7ef4490a5de743c374ee8785dc558c2d4a86a887856ef` |
| [`tests/test_relink.py`](tests-test_relink.md) | 1 | `4c569edff294c5f50a27afb4c690130dd5a78f7a51afbdc0a59e121d0494be83` |
| [`tests/test_test_bundle.py`](tests-test_test_bundle.md) | 5 | `0cd94504e9502f2deb63b9bada00b938b6642330ee2ab395df8584838cc45631` |
| [`tests/test_workqueue.py`](tests-test_workqueue.md) | 1 | `371e4a3a4cfad1f142a735efd0d891236242eb441ff6a91c34886bcd1f9fb826` |
