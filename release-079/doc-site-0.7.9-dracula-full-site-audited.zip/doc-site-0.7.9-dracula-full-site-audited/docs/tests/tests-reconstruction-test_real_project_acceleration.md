---
title: tests/reconstruction/test_real_project_acceleration.py
description: Test source reference for tests/reconstruction/test_real_project_acceleration.py.
---

# `tests/reconstruction/test_real_project_acceleration.py`

**SHA-256:** `b3123bae9f28883f6abb8913774921ed1e44765325fa6c33e7918cdd73cc5ffa`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_universal_function_pattern_and_text_swap` | function | 60 | 95 |
| `test_project_health_hygiene_runtime_and_policy` | function | 98 | 117 |
| `test_toolchain_rules_and_cleanup` | function | 120 | 139 |
