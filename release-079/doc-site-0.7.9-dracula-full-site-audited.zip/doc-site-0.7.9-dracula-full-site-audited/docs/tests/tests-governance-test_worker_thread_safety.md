---
title: tests/governance/test_worker_thread_safety.py
description: Test source reference for tests/governance/test_worker_thread_safety.py.
---

# `tests/governance/test_worker_thread_safety.py`

**SHA-256:** `d128f0ebbc38c9591744620796073fe792466e303c706420b0e7b85ed0dd5c12`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_worker_uses_exec_wrapper_without_thread_unsafe_preexec` | function | 17 | 46 |
| `test_legacy_preexec_compatibility_callback_is_executable` | function | 49 | 88 |
