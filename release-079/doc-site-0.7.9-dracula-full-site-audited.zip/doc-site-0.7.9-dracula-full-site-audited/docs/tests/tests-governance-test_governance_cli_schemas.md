---
title: tests/governance/test_governance_cli_schemas.py
description: Test source reference for tests/governance/test_governance_cli_schemas.py.
---

# `tests/governance/test_governance_cli_schemas.py`

**SHA-256:** `6bfc0da4dc3ecabcc3b95803e6978298070733b7ba7f538c2946c4f977a60ba9`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_every_governance_schema_meta_validates` | function | 18 | 26 |
| `test_governance_cli_help_and_init` | function | 29 | 37 |
| `test_governance_cli_hypothesis_flow` | function | 40 | 49 |
| `test_contract_helpers_and_cli_json_arg` | function | 52 | 68 |
| `test_all_governance_leaf_commands_parse_help` | function | 71 | 99 |
