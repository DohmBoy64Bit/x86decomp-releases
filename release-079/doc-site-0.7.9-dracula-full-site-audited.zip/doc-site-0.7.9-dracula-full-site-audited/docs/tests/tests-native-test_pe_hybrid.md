---
title: tests/native/test_pe_hybrid.py
description: Test source reference for tests/native/test_pe_hybrid.py.
---

# `tests/native/test_pe_hybrid.py`

**SHA-256:** `71a4a6cf701f8abab032f32a443602fccf853948dd195bcf5345bb5654d039dd`

| Test symbol | Kind | Line | End line |
| --- | --- | ---: | ---: |
| `test_safe_patch_and_text_swap_preserve_pe_container` | function | 15 | 27 |
| `test_section_export_and_synthetic_coff_for_pe32_and_pe64` | function | 30 | 38 |
| `test_hybrid_composer_promotes_only_verified_candidates` | function | 41 | 55 |
| `test_hybrid_composer_rejects_candidate_changed_after_match` | function | 58 | 73 |
