---
title: x86decomp.reconstruction.store
description: Source module reference for x86decomp.reconstruction.store.
---

# `x86decomp.reconstruction.store`

**Source path:** `src/x86decomp/reconstruction/store.py`  
**SHA-256:** `11bf1f6653ffea84e45a267b26bd10f9ff37275c3fe16fbccf7bac89ccc82ce9`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ReconstructionStore` | class | 145 | 193 | Project-scale schema layered on the governance store. |
| `initialize` | function | 148 | 160 | Initialize the requested operation. |
| `check` | function | 162 | 180 | Check the requested operation. |
| `decode` | function | 183 | 193 | Decode the requested operation. |
