---
title: x86decomp.local_llm.profiles
description: Source module reference for x86decomp.local_llm.profiles.
---

# `x86decomp.local_llm.profiles`

**Source path:** `src/x86decomp/local_llm/profiles.py`  
**SHA-256:** `d328d7e66d9ca3b018a8d566e68eee830487cde685ebfa386bb0031319096e87`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `provider_catalog` | function | 73 | 86 | Return the immutable built-in provider preset catalog. |
| `_normalized_base_url` | function | 89 | 106 | Implement normalized base url. |
| `is_loopback_host` | function | 109 | 117 | Return whether a hostname is an explicit local loopback identity. |
| `resolved_addresses_are_loopback` | function | 120 | 139 | Resolve a host and require every result to be loopback. |
| `create_profile` | function | 142 | 179 | Create and persist a validated provider profile. |
| `load_profile` | function | 182 | 190 | Load profile. |
| `validate_profile` | function | 193 | 251 | Validate and normalize a local-model profile. |
| `public_profile` | function | 254 | 263 | Return report-safe profile metadata without secret values. |
