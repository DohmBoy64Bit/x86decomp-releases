---
title: x86decomp.service
description: Source module reference for x86decomp.service.
---

# `x86decomp.service`

**Source path:** `src/x86decomp/service.py`  
**SHA-256:** `b6a0ada61638ee6e763273b60b85990d86fb913c8bd8fe6c16bbfb220c01f027`  
**Documented symbols:** 16

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_json_files` | function | 24 | 39 | Implement json files. |
| `service_snapshot` | function | 42 | 78 | Return a read-only, serializable project-control-plane snapshot. |
| `create_app` | function | 81 | 226 | Create app. |
| `health` | function | 95 | 106 | Implement health. |
| `project` | function | 109 | 114 | Implement project. |
| `target_pack` | function | 117 | 129 | Implement target pack. |
| `pipelines` | function | 132 | 137 | Implement pipelines. |
| `convergence` | function | 140 | 145 | Implement convergence. |
| `reproducibility` | function | 148 | 153 | Implement reproducibility. |
| `security` | function | 156 | 161 | Implement security. |
| `functions` | function | 164 | 178 | Implement functions. |
| `workflow` | function | 181 | 190 | Implement workflow. |
| `next_task` | function | 193 | 202 | Implement next task. |
| `reports` | function | 205 | 210 | Implement reports. |
| `index` | function | 213 | 225 | Implement index. |
| `run_service` | function | 229 | 238 | Run service. |
