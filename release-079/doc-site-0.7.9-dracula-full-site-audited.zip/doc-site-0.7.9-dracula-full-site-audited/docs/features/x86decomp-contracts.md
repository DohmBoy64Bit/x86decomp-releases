---
title: x86decomp.contracts
description: Source module reference for x86decomp.contracts.
---

# `x86decomp.contracts`

**Source path:** `src/x86decomp/contracts.py`  
**SHA-256:** `e9800d3102a382ac416a9e7ef7d1b13e89b87a3d8b502e9cd220fb57039de60e`  
**Documented symbols:** 13

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ContractError` | class | 20 | 21 | Raised when an input violates a stable project contract. |
| `utc_now` | function | 24 | 29 | Implement utc now. |
| `canonical_json` | function | 32 | 37 | Implement canonical json. |
| `sha256_bytes` | function | 40 | 45 | Implement sha256 bytes. |
| `sha256_file` | function | 48 | 57 | Implement sha256 file. |
| `stable_id` | function | 60 | 66 | Implement stable id. |
| `random_id` | function | 69 | 74 | Implement random id. |
| `validate_id` | function | 77 | 84 | Validate id. |
| `ensure_relative_path` | function | 87 | 96 | Ensure relative path. |
| `atomic_write_bytes` | function | 99 | 119 | Implement atomic write bytes. |
| `atomic_write_json` | function | 122 | 127 | Implement atomic write json. |
| `read_json` | function | 130 | 136 | Read json. |
| `dedupe_preserve` | function | 139 | 150 | Implement dedupe preserve. |
