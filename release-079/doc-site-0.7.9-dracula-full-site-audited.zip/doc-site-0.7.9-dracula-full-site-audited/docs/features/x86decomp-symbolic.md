---
title: x86decomp.symbolic
description: Source module reference for x86decomp.symbolic.
---

# `x86decomp.symbolic`

**Source path:** `src/x86decomp/symbolic.py`  
**SHA-256:** `8520505b9631b4ef5c1f6416455f3214e32a6cbd1bb106672379c94087be6fab`  
**Documented symbols:** 27

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_deps` | function | 18 | 31 | Implement deps. |
| `UnsupportedSymbolicInstruction` | class | 34 | 39 | Implement the UnsupportedSymbolicInstruction class using its declared base class contract. |
| `SymState` | class | 43 | 67 | Store the validated fields for sym state records. |
| `clone` | function | 55 | 67 | Implement clone. |
| `Outcome` | class | 71 | 78 | Store the validated fields for outcome records. |
| `_aliases` | function | 108 | 113 | Implement aliases. |
| `_read_reg` | function | 116 | 129 | Read reg. |
| `_write_reg` | function | 132 | 154 | Write reg. |
| `_concrete` | function | 157 | 163 | Implement concrete. |
| `_memory_address` | function | 166 | 186 | Implement memory address. |
| `_read_memory` | function | 189 | 201 | Read memory. |
| `_write_memory` | function | 204 | 216 | Write memory. |
| `_read_operand` | function | 219 | 232 | Read operand. |
| `_write_operand` | function | 235 | 248 | Write operand. |
| `_coerce_pair` | function | 251 | 261 | Implement coerce pair. |
| `_set_logic_flags` | function | 264 | 272 | Set logic flags. |
| `_set_add_flags` | function | 275 | 288 | Set add flags. |
| `_set_sub_flags` | function | 291 | 304 | Set sub flags. |
| `_condition` | function | 307 | 327 | Implement condition. |
| `_condition_for_family` | function | 330 | 351 | Resolve Jcc, SETcc, and CMOVcc names through the same flag model. |
| `_set_adc_flags` | function | 354 | 371 | Set adc flags. |
| `_set_sbb_flags` | function | 374 | 390 | Set sbb flags. |
| `_is_sat` | function | 393 | 400 | Implement is sat. |
| `symbolic_execute` | function | 403 | 690 | Implement symbolic execute. |
| `_constraint_formula` | function | 693 | 698 | Implement constraint formula. |
| `bounded_symbolic_compare` | function | 701 | 781 | Implement bounded symbolic compare. |
| `bounded_symbolic_compare_files` | function | 784 | 795 | Implement bounded symbolic compare files. |
