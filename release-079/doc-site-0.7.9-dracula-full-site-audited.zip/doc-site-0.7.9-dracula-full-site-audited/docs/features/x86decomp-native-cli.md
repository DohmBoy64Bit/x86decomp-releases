---
title: x86decomp.native.cli
description: Source module reference for x86decomp.native.cli.
---

# `x86decomp.native.cli`

**Source path:** `src/x86decomp/native/cli.py`  
**SHA-256:** `5ac5e7e670f3a15a99019111f8d87ae405189ec8558b7e12b8c383ae0efd1f56`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_json` | function | 26 | 33 | Implement json. |
| `_json_file` | function | 36 | 41 | Implement json file. |
| `_emit` | function | 44 | 50 | Emit the requested operation. |
| `build_parser` | function | 53 | 111 | Build parser. |
| `dispatch` | function | 114 | 169 | Dispatch the requested operation. |
| `main` | function | 172 | 180 | Run the command-line entry point. |
