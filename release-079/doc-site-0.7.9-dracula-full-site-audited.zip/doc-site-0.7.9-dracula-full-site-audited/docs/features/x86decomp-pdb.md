---
title: x86decomp.pdb
description: Source module reference for x86decomp.pdb.
---

# `x86decomp.pdb`

**Source path:** `src/x86decomp/pdb.py`  
**SHA-256:** `d6acf3c37dae9cba250d26f5e033a129f65aa7a450403d66b43602a0e1951718`  
**Documented symbols:** 24

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_require` | function | 29 | 35 | Implement require. |
| `_u16` | function | 38 | 44 | Implement u16. |
| `_u32` | function | 47 | 53 | Implement u32. |
| `_cstring` | function | 56 | 66 | Implement cstring. |
| `_align4` | function | 69 | 74 | Implement align4. |
| `PDBStream` | class | 78 | 98 | Store the validated fields for p d b stream records. |
| `to_dict` | function | 88 | 98 | Convert dict. |
| `PDBFile` | class | 102 | 153 | Store the validated fields for p d b file records. |
| `to_dict` | function | 121 | 153 | Convert dict. |
| `_MSF` | class | 156 | 248 | Represent m s f state and behavior. |
| `__init__` | function | 161 | 190 | Initialize the instance with the supplied constructor arguments. |
| `_block` | function | 192 | 200 | Implement block. |
| `_parse_directory` | function | 202 | 236 | Parse directory. |
| `stream` | function | 238 | 248 | Implement stream. |
| `_parse_info` | function | 251 | 270 | Parse info. |
| `_parse_tpi` | function | 273 | 321 | Parse tpi. |
| `_parse_modules` | function | 324 | 389 | Parse modules. |
| `_parse_source_info` | function | 392 | 441 | Parse source info. |
| `_parse_section_contributions` | function | 444 | 475 | Parse section contributions. |
| `_parse_section_map` | function | 478 | 510 | Parse section map. |
| `_parse_dbi` | function | 513 | 626 | Parse dbi. |
| `_correlate_pe` | function | 629 | 661 | Implement correlate pe. |
| `parse_pdb_bytes` | function | 664 | 701 | Parse pdb bytes. |
| `parse_pdb` | function | 704 | 715 | Parse pdb. |
