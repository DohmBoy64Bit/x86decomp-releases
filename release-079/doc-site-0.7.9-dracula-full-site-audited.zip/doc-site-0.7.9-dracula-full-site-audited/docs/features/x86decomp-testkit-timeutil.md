---
title: x86decomp_testkit.timeutil
description: Source module reference for x86decomp_testkit.timeutil.
---

# `x86decomp_testkit.timeutil`

**Source path:** `test-suite/src/x86decomp_testkit/timeutil.py`  
**SHA-256:** `719af79e77cce1a3eb5c205fb41b4d5a8a71bb091abee48e95f91896714ab4d2`  
**Documented symbols:** 1

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `utc_now` | function | 10 | 15 | Implement utc now. |
