---
title: x86decomp.local_llm.matching
description: Source module reference for x86decomp.local_llm.matching.
---

# `x86decomp.local_llm.matching`

**Source path:** `src/x86decomp/local_llm/matching.py`  
**SHA-256:** `dd41013ecbb2a586d448e3b58731edafd852e9c3bb38d9efbc416ba01cd2f4e5`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_parse_candidate` | function | 36 | 92 | Parse candidate. |
| `_prepare_output` | function | 95 | 109 | Prepare output. |
| `_feedback_from_compile` | function | 112 | 123 | Implement feedback from compile. |
| `_feedback_from_diff` | function | 126 | 140 | Implement feedback from diff. |
| `generate_candidate` | function | 143 | 184 | Generate and validate one uncompiled C proposal. |
| `run_match_loop` | function | 187 | 376 | Run bounded local generation, compilation, relocation, and exact comparison. |
| `verify_match_report` | function | 379 | 434 | Verify report invariants and every referenced accepted artifact hash. |
