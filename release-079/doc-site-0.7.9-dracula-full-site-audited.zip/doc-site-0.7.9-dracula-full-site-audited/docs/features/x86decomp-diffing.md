---
title: x86decomp.diffing
description: Source module reference for x86decomp.diffing.
---

# `x86decomp.diffing`

**Source path:** `src/x86decomp/diffing.py`  
**SHA-256:** `edb1a9112f25efb1b3c22012ce3a6db3756c422bcc5c978f584a4721ab5fa67c`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `compare_bytes` | function | 13 | 61 | Compare bytes. |
| `compare_files` | function | 64 | 84 | Compare files. |
