---
title: x86decomp.disassembly
description: Source module reference for x86decomp.disassembly.
---

# `x86decomp.disassembly`

**Source path:** `src/x86decomp/disassembly.py`  
**SHA-256:** `6f1e8a26d500e0fe88a58dfb85ed319ddb05d1c8a4d94c33d9e76456984e682f`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_capstone` | function | 14 | 26 | Implement capstone. |
| `InstructionRecord` | class | 30 | 61 | Store the validated fields for instruction record records. |
| `to_dict` | function | 45 | 61 | Convert dict. |
| `_is_known_address` | function | 64 | 69 | Implement is known address. |
| `decode_instructions` | function | 72 | 161 | Decode instructions. |
| `control_flow_edges` | function | 164 | 178 | Implement control flow edges. |
| `compare_instruction_streams` | function | 181 | 244 | Compare instruction streams. |
| `cross_check_ghidra_instructions` | function | 247 | 305 | Implement cross check ghidra instructions. |
