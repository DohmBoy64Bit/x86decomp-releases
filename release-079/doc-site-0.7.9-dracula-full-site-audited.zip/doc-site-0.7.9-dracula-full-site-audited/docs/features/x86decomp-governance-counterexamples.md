---
title: x86decomp.governance.counterexamples
description: Source module reference for x86decomp.governance.counterexamples.
---

# `x86decomp.governance.counterexamples`

**Source path:** `src/x86decomp/governance/counterexamples.py`  
**SHA-256:** `0b7de9b304d5ebd8725df86d7f372d5f5d58f76cfcfae4d96531dc7a866efeab`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `CounterexampleStore` | class | 18 | 125 | Represent counterexample store state and behavior. |
| `__init__` | function | 23 | 30 | Initialize the instance with the supplied constructor arguments. |
| `add` | function | 32 | 52 | Add the requested operation. |
| `minimize` | function | 54 | 81 | Implement minimize. |
| `promote_to_regression` | function | 83 | 101 | Implement promote to regression. |
| `get` | function | 103 | 116 | Return the requested operation. |
| `list` | function | 118 | 125 | List the requested operation. |
| `ddmin_bytes` | function | 128 | 154 | Delta-debug a byte string while preserving predicate(data) == True. |
