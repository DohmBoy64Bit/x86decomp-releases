---
title: x86decomp.local_llm.transport
description: Source module reference for x86decomp.local_llm.transport.
---

# `x86decomp.local_llm.transport`

**Source path:** `src/x86decomp/local_llm/transport.py`  
**SHA-256:** `73334c5044e30fde321fce58b670f1392936b9ee0863fd2b6fadbc6c522ece17`  
**Documented symbols:** 16

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ModelResponse` | class | 20 | 28 | Store the validated fields for model response records. |
| `_SameOriginRedirectHandler` | class | 31 | 47 | Implement the _SameOriginRedirectHandler class using its declared base class contract. |
| `redirect_request` | function | 36 | 47 | Implement redirect request. |
| `_endpoint` | function | 50 | 55 | Implement endpoint. |
| `_opener` | function | 58 | 67 | Implement opener. |
| `_headers` | function | 70 | 83 | Implement headers. |
| `_read_json_response` | function | 86 | 110 | Read json response. |
| `_request_json` | function | 113 | 131 | Implement request json. |
| `_model_ids` | function | 134 | 157 | Implement model ids. |
| `_ollama_model_matches` | function | 160 | 169 | Implement ollama model matches. |
| `probe_profile` | function | 172 | 187 | Probe a provider's model-list endpoint without generating text. |
| `_candidate_schema` | function | 190 | 205 | Implement candidate schema. |
| `_openai_body` | function | 208 | 229 | Implement openai body. |
| `_ollama_body` | function | 232 | 248 | Implement ollama body. |
| `_extract_content` | function | 251 | 268 | Extract content. |
| `chat` | function | 271 | 305 | Generate one bounded response, retrying once without structured mode when unsupported. |
