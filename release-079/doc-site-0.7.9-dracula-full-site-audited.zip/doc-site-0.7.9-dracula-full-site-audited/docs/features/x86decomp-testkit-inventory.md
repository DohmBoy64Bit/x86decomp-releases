---
title: x86decomp_testkit.inventory
description: Source module reference for x86decomp_testkit.inventory.
---

# `x86decomp_testkit.inventory`

**Source path:** `test-suite/src/x86decomp_testkit/inventory.py`  
**SHA-256:** `b2edc05bea5a73042102ad2f2b9a20afe865653062bfa2566de09836a0913fc3`  
**Documented symbols:** 16

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `PublicSymbol` | class | 20 | 51 | Store the validated fields for public symbol records. |
| `symbol_id` | function | 32 | 37 | Implement symbol id. |
| `to_dict` | function | 39 | 51 | Convert dict. |
| `_direct_body_lines` | function | 54 | 68 | Implement direct body lines. |
| `_python_files` | function | 71 | 79 | Implement python files. |
| `_module_name` | function | 82 | 92 | Implement module name. |
| `_discover_symbols` | function | 95 | 128 | Implement discover symbols. |
| `discover_public_symbols` | function | 131 | 136 | Implement discover public symbols. |
| `discover_all_function_symbols` | function | 139 | 144 | Implement discover all function symbols. |
| `discover_modules` | function | 147 | 152 | Implement discover modules. |
| `discover_schemas` | function | 155 | 161 | Implement discover schemas. |
| `discover_ghidra_scripts` | function | 164 | 170 | Implement discover ghidra scripts. |
| `discover_cli_commands` | function | 173 | 194 | Implement discover CLI commands. |
| `build_inventory` | function | 197 | 212 | Build inventory. |
| `load_feature_catalog` | function | 215 | 223 | Load feature catalog. |
| `audit_catalog` | function | 226 | 253 | Audit catalog. |
