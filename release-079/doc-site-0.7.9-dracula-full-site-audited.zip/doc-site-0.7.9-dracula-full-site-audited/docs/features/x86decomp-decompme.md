---
title: x86decomp.decompme
description: Source module reference for x86decomp.decompme.
---

# `x86decomp.decompme`

**Source path:** `src/x86decomp/decompme.py`  
**SHA-256:** `a06142a71d3fb98077c1ef69241f94260795be98eda93614c4bfb6824d21eb3f`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_copy_required` | function | 14 | 24 | Copy required. |
| `create_decompme_packet` | function | 27 | 101 | Build a local, reviewable function packet. |
