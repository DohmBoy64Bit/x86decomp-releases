---
title: x86decomp.project
description: Source module reference for x86decomp.project.
---

# `x86decomp.project`

**Source path:** `src/x86decomp/project.py`  
**SHA-256:** `b90b32ad6555ea844b165178c98f3538359f7ce48ee186713bb4e5ac1969149c`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `initialize_project` | function | 61 | 152 | Initialize project. |
| `_resolve_binary_path` | function | 155 | 169 | Resolve binary path. |
| `verify_project` | function | 172 | 232 | Verify project. |
| `require_valid_project` | function | 235 | 243 | Implement require valid project. |
