---
title: x86decomp.assembly.annotation
description: Source module reference for x86decomp.assembly.annotation.
---

# `x86decomp.assembly.annotation`

**Source path:** `src/x86decomp/assembly/annotation.py`  
**SHA-256:** `3248350668dc758ce9649887aef7eeb5e03d08b446e34667cfec938fb1135d45`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `validate_symbol` | function | 18 | 25 | Validate symbol. |
| `render_byte_assembly` | function | 28 | 43 | Render the original compatibility form. This output intentionally preserves byte-form assembly semantics. |
| `parse_byte_directives` | function | 46 | 69 | Parse byte directives. |
| `_chunk_comments` | function | 72 | 83 | Implement chunk comments. |
| `render_annotated_assembly` | function | 86 | 105 | Render byte-identical directives with idempotent Capstone comments. |
| `annotate_source` | function | 108 | 133 | Implement annotate source. |
| `byte_directive_lines` | function | 136 | 143 | Implement byte directive lines. |
