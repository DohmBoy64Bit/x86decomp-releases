---
title: x86decomp.security_audit
description: Source module reference for x86decomp.security_audit.
---

# `x86decomp.security_audit`

**Source path:** `src/x86decomp/security_audit.py`  
**SHA-256:** `09a91fb4a4b34b3627eed7c2530ce98d48df8deedd78473db63e54c3158f9f54`  
**Documented symbols:** 5

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_secret_findings` | function | 30 | 43 | Implement secret findings. |
| `generate_sbom` | function | 47 | 83 | Generate sbom. |
| `audit_source_tree` | function | 86 | 142 | Audit source tree. |
| `verify_release_manifest` | function | 145 | 177 | Verify release manifest. |
| `run_dependency_vulnerability_audit` | function | 180 | 253 | Run an installed pip-audit executable and preserve its exact findings. |
