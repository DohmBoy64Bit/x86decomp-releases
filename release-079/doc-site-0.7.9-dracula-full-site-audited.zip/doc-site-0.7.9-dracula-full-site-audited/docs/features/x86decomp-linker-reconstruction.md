---
title: x86decomp.linker_reconstruction
description: Source module reference for x86decomp.linker_reconstruction.
---

# `x86decomp.linker_reconstruction`

**Source path:** `src/x86decomp/linker_reconstruction.py`  
**SHA-256:** `47fb01c254ef454393c8e1ed84318f2971ebda6ce59161357811db3d1d7f35eb`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `build_linker_reconstruction_plan` | function | 21 | 146 | Build linker reconstruction plan. |
| `write_relink_manifest_from_plan` | function | 149 | 160 | Write relink manifest from plan. |
