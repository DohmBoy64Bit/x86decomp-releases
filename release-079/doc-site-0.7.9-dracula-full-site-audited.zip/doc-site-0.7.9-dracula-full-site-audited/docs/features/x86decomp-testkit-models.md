---
title: x86decomp_testkit.models
description: Source module reference for x86decomp_testkit.models.
---

# `x86decomp_testkit.models`

**Source path:** `test-suite/src/x86decomp_testkit/models.py`  
**SHA-256:** `46fc3d5c0df07a9ee343b88a398e2e0b21e92999100ce8308991bef1d0789ea9`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `Status` | class | 13 | 21 | Enumerate the supported status values. |
| `AdapterKind` | class | 24 | 33 | Enumerate the supported adapter kind values. |
| `ProbeResult` | class | 37 | 55 | Store the validated fields for probe result records. |
| `to_dict` | function | 50 | 55 | Convert dict. |
| `AdapterSpec` | class | 59 | 80 | Store the validated fields for adapter spec records. |
| `TestResult` | class | 84 | 110 | Store the validated fields for test result records. |
| `to_dict` | function | 103 | 110 | Convert dict. |
| `RunSummary` | class | 114 | 173 | Store the validated fields for run summary records. |
| `counts` | function | 131 | 139 | Implement counts. |
| `exit_code` | function | 141 | 151 | Implement exit code. |
| `to_dict` | function | 153 | 173 | Convert dict. |
| `normalized_path` | function | 176 | 181 | Implement normalized path. |
