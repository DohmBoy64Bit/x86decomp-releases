---
title: x86decomp.governance.workers
description: Source module reference for x86decomp.governance.workers.
---

# `x86decomp.governance.workers`

**Source path:** `src/x86decomp/governance/workers.py`  
**SHA-256:** `b79000abc587fa7c0c6bf0a91a0411398ea4a46c1fa4ece1501238a85ddfced6`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `WorkerRegistry` | class | 16 | 110 | Represent worker registry state and behavior. |
| `__init__` | function | 21 | 27 | Initialize the instance with the supplied constructor arguments. |
| `register` | function | 29 | 45 | Register the requested operation. |
| `get` | function | 47 | 58 | Return the requested operation. |
| `list` | function | 60 | 70 | List the requested operation. |
| `select` | function | 72 | 84 | Select the requested operation. |
| `set_status` | function | 86 | 97 | Set status. |
| `doctor` | function | 99 | 110 | Implement doctor. |
