---
title: x86decomp_testkit.toolkit_tests.test_public_api_contract
description: Source module reference for x86decomp_testkit.toolkit_tests.test_public_api_contract.
---

# `x86decomp_testkit.toolkit_tests.test_public_api_contract`

**Source path:** `test-suite/src/x86decomp_testkit/toolkit_tests/test_public_api_contract.py`  
**SHA-256:** `06f79772fcde1a6eece4075ac2da5807566f8d002f4fa4045a8add1b5d4998d5`  
**Documented symbols:** 32

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `test_unified_canonical_entry_point` | function | 79 | 93 | Verify unified canonical entry point. |
| `test_abi_contract_loading` | function | 96 | 116 | Verify abi contract loading. |
| `test_analysis_database_complete_public_surface` | function | 119 | 148 | Verify analysis database complete public surface. |
| `test_angr_public_file_wrappers` | function | 151 | 174 | Verify angr public file wrappers. |
| `test_benchmark_metrics_and_runner` | function | 177 | 193 | Verify benchmark metrics and runner. |
| `test_coff_remaining_value_objects_and_writer` | function | 196 | 215 | Verify coff remaining value objects and writer. |
| `test_compiler_lab_with_deterministic_fake_compiler` | function | 218 | 254 | Verify compiler lab with deterministic fake compiler. |
| `test_diff_disassembly_and_crosscheck` | function | 257 | 274 | Verify diff disassembly and crosscheck. |
| `test_dynamic_file_wrapper_and_spec_loader` | function | 277 | 297 | Verify dynamic file wrapper and spec loader. |
| `test_dynamorio_runner_with_fake_subprocess` | function | 300 | 328 | Verify dynamorio runner with fake subprocess. |
| `fake_run` | function | 311 | 324 | Implement fake run. |
| `_verified_store` | function | 331 | 345 | Implement verified store. |
| `test_evidence_contradiction_require_verified_and_project_memory` | function | 348 | 360 | Verify evidence contradiction require verified and project memory. |
| `test_exe_diff_extract_and_compare` | function | 363 | 375 | Verify exe diff extract and compare. |
| `test_ghidra_run_export_success` | function | 378 | 387 | Verify ghidra run export success. |
| `test_remaining_value_objects_and_peview` | function | 390 | 408 | Verify remaining value objects and peview. |
| `test_service_create_and_run` | function | 411 | 423 | Verify service create and run. |
| `test_symbolic_clone_and_file_wrapper` | function | 426 | 442 | Verify symbolic clone and file wrapper. |
| `test_toolchain_snapshot_util_contract_and_workqueue` | function | 445 | 468 | Verify toolchain snapshot util contract and workqueue. |
| `test_cli_main_executes_public_entrypoint` | function | 471 | 481 | Verify cli main executes public entrypoint. |
| `test_streamable_http_mcp_public_methods` | function | 484 | 567 | Verify streamable http mcp public methods. |
| `Headers` | class | 491 | 508 | Represent headers state and behavior. |
| `get` | function | 496 | 501 | Return the requested operation. |
| `get_content_type` | function | 503 | 508 | Return content type. |
| `Response` | class | 510 | 543 | Represent response state and behavior. |
| `__init__` | function | 517 | 522 | Initialize the instance with the supplied constructor arguments. |
| `__enter__` | function | 524 | 529 | Enter the context manager and return the active resource. |
| `__exit__` | function | 531 | 536 | Exit the context manager and release managed resources. |
| `read` | function | 538 | 543 | Read the requested operation. |
| `fake_urlopen` | function | 545 | 560 | Implement fake urlopen. |
| `test_private_function_surface_regression` | function | 570 | 606 | Exercise the remaining internal function bodies so no defined function is omitted. |
| `test_remaining_current_function_surface` | function | 609 | 679 | Verify remaining current function surface. |
