---
title: x86decomp_testkit.self_tests.test_archive_security
description: Source module reference for x86decomp_testkit.self_tests.test_archive_security.
---

# `x86decomp_testkit.self_tests.test_archive_security`

**Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_archive_security.py`  
**SHA-256:** `a479512db3de83ee9ad57ab1b81049248767d36765119bf4fd57a5cca30aba11`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `test_safe_zip_and_tar_extraction` | function | 17 | 37 | Verify safe zip and tar extraction. |
| `test_rejects_traversal_and_links` | function | 40 | 58 | Verify rejects traversal and links. |
| `test_release_asset_selection_is_deterministic` | function | 61 | 72 | Verify release asset selection is deterministic. |
| `test_download_file_hash_and_size_limit` | function | 74 | 89 | Verify download file hash and size limit. |
