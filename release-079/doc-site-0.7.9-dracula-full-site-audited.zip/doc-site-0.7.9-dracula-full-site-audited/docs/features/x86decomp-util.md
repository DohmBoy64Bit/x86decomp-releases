---
title: x86decomp.util
description: Source module reference for x86decomp.util.
---

# `x86decomp.util`

**Source path:** `src/x86decomp/util.py`  
**SHA-256:** `082a07950a91fbd4e88d3fee8be06604ad6792995965d13b22782d2d04b2b0a9`  
**Documented symbols:** 13

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `utc_now` | function | 17 | 19 | Return a stable RFC 3339 UTC timestamp. |
| `sha256_bytes` | function | 22 | 27 | Implement sha256 bytes. |
| `sha256_file` | function | 30 | 39 | Implement sha256 file. |
| `canonical_json_bytes` | function | 42 | 49 | Implement canonical json bytes. |
| `load_json` | function | 52 | 58 | Load json. |
| `atomic_write_bytes` | function | 61 | 78 | Implement atomic write bytes. |
| `atomic_write_text` | function | 81 | 86 | Implement atomic write text. |
| `write_json` | function | 89 | 95 | Write json. |
| `copy_file_atomic` | function | 98 | 113 | Copy file atomic. |
| `ensure_relative_path` | function | 116 | 124 | Resolve candidate and reject paths that escape root. |
| `require_mapping` | function | 127 | 134 | Implement require mapping. |
| `require_string` | function | 137 | 145 | Implement require string. |
| `require_int` | function | 148 | 158 | Implement require int. |
