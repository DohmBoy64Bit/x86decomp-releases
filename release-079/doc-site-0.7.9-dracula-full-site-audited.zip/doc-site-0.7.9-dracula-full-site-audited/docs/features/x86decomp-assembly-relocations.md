---
title: x86decomp.assembly.relocations
description: Source module reference for x86decomp.assembly.relocations.
---

# `x86decomp.assembly.relocations`

**Source path:** `src/x86decomp/assembly/relocations.py`  
**SHA-256:** `342c6c66f6d250724c11789728b9593bfe0413369a548e8ed338f60d5a183660`  
**Documented symbols:** 13

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `SymbolAddress` | class | 28 | 58 | Store the validated fields for symbol address records. |
| `safe_name` | function | 40 | 45 | Implement safe name. |
| `to_dict` | function | 47 | 58 | Convert dict. |
| `normalize_symbol_map` | function | 61 | 112 | Normalize symbol map. |
| `supported_relocations` | function | 115 | 136 | Implement supported relocations. |
| `_read_addend` | function | 139 | 146 | Read addend. |
| `_write_value` | function | 149 | 160 | Write value. |
| `_object_symbol_target` | function | 163 | 185 | Implement object symbol target. |
| `_resolve_target` | function | 188 | 214 | Resolve target. |
| `_compute_value` | function | 217 | 275 | Implement compute value. |
| `RelocationResolver` | class | 278 | 420 | Resolve COFF relocation fields under an explicit original-RVA symbol map. |
| `inspect` | function | 281 | 303 | Inspect the requested operation. |
| `resolve` | function | 305 | 420 | Resolve the requested operation. |
