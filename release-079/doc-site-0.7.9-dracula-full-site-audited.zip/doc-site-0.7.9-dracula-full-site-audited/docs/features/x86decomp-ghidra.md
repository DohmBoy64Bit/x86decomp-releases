---
title: x86decomp.ghidra
description: Source module reference for x86decomp.ghidra.
---

# `x86decomp.ghidra`

**Source path:** `src/x86decomp/ghidra.py`  
**SHA-256:** `bc498b5953f80b266be1ccc22193529e86eadf2f534ec9a8f95f8018cfcdc8ca`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `build_export_command` | function | 14 | 65 | Build export command. |
| `run_export` | function | 68 | 111 | Run export. |
