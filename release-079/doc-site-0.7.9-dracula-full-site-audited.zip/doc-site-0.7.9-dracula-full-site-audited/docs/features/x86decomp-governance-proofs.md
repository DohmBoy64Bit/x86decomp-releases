---
title: x86decomp.governance.proofs
description: Source module reference for x86decomp.governance.proofs.
---

# `x86decomp.governance.proofs`

**Source path:** `src/x86decomp/governance/proofs.py`  
**SHA-256:** `52ef6f147a33896493423cfea94e9e6d6a4e933425574cd884e4b0efb38ea917`  
**Documented symbols:** 13

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ProofLedger` | class | 23 | 107 | Represent proof ledger state and behavior. |
| `__init__` | function | 28 | 34 | Initialize the instance with the supplied constructor arguments. |
| `create_obligation` | function | 36 | 50 | Create obligation. |
| `add_result` | function | 52 | 69 | Add result. |
| `obligation` | function | 71 | 84 | Implement obligation. |
| `result` | function | 86 | 97 | Implement result. |
| `evaluate` | function | 99 | 107 | Evaluate the requested operation. |
| `ProofBundle` | class | 110 | 234 | Deterministic, path-safe, independently verifiable proof package. |
| `_zip_info` | function | 114 | 122 | Implement zip info. |
| `export` | function | 125 | 167 | Export the requested operation. |
| `_validate_member` | function | 170 | 177 | Validate member. |
| `verify` | function | 180 | 226 | Verify the requested operation. |
| `inspect` | function | 229 | 234 | Inspect the requested operation. |
