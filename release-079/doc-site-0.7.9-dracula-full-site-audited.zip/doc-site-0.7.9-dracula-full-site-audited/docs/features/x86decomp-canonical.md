---
title: x86decomp.canonical
description: Source module reference for x86decomp.canonical.
---

# `x86decomp.canonical`

**Source path:** `src/x86decomp/canonical.py`  
**SHA-256:** `d4439c3235715d61e8d40bf234eacbbf57ea1cfa4a0e66da0de7e320ba091caf`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_subparsers` | function | 68 | 76 | Implement subparsers. |
| `_source_parsers` | function | 79 | 87 | Implement source parsers. |
| `_group_parsers` | function | 90 | 99 | Implement group parsers. |
| `_leaf_parsers` | function | 102 | 111 | Implement leaf parsers. |
| `_route_owner` | function | 114 | 135 | Implement route owner. |
| `canonical_routes` | function | 138 | 150 | Implement canonical routes. |
| `canonical_groups` | function | 153 | 158 | Implement canonical groups. |
| `command_catalog` | function | 161 | 185 | Implement command catalog. |
| `register_canonical_commands` | function | 188 | 232 | Register canonical commands. |
| `dispatch` | function | 235 | 245 | Dispatch the requested operation. |
| `build_parser` | function | 248 | 259 | Build parser. |
| `main` | function | 262 | 274 | Run the command-line entry point. |
