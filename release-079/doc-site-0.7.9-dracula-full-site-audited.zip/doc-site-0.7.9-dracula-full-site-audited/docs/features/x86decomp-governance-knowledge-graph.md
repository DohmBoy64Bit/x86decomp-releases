---
title: x86decomp.governance.knowledge_graph
description: Source module reference for x86decomp.governance.knowledge_graph.
---

# `x86decomp.governance.knowledge_graph`

**Source path:** `src/x86decomp/governance/knowledge_graph.py`  
**SHA-256:** `d0156e19a57fd16070ff83b7d26811eafc2654d94738e204d9c946dcc9c38906`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `KnowledgeGraph` | class | 15 | 120 | Represent knowledge graph state and behavior. |
| `__init__` | function | 20 | 26 | Initialize the instance with the supplied constructor arguments. |
| `upsert_node` | function | 28 | 44 | Insert or update node. |
| `add_edge` | function | 46 | 68 | Add edge. |
| `get_node` | function | 70 | 81 | Return node. |
| `impact` | function | 83 | 120 | Implement impact. |
