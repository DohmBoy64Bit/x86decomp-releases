---
title: x86decomp.models
description: Source module reference for x86decomp.models.
---

# `x86decomp.models`

**Source path:** `src/x86decomp/models.py`  
**SHA-256:** `146aea4d76c8ffdaac11014e3ba91be56b2c6c140a31c0ec972c2b7272ac85d8`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `EvidenceKind` | class | 12 | 23 | Enumerate the supported evidence kind values. |
| `ClaimState` | class | 26 | 34 | Enumerate the supported claim state values. |
| `VerificationStatus` | class | 37 | 44 | Enumerate the supported verification status values. |
| `EvidenceItem` | class | 48 | 70 | Store the validated fields for evidence item records. |
| `to_dict` | function | 63 | 70 | Convert dict. |
| `Claim` | class | 74 | 97 | Store the validated fields for claim records. |
| `to_dict` | function | 90 | 97 | Convert dict. |
