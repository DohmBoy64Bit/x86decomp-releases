---
title: x86decomp.reconstruction.capsules
description: Source module reference for x86decomp.reconstruction.capsules.
---

# `x86decomp.reconstruction.capsules`

**Source path:** `src/x86decomp/reconstruction/capsules.py`  
**SHA-256:** `4229ec1aca3b55d5d511b8c74b0f295ba062ec2b32cded079d61d66680e7ebda`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `Capsules` | class | 15 | 84 | Represent capsules state and behavior. |
| `__init__` | function | 20 | 25 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 26 | 45 | Create the requested operation. |
| `inspect` | function | 46 | 53 | Inspect the requested operation. |
| `verify` | function | 54 | 71 | Verify the requested operation. |
| `reproduce` | function | 72 | 84 | Implement reproduce. |
