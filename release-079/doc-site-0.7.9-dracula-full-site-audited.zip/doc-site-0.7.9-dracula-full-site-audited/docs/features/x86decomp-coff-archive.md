---
title: x86decomp.coff_archive
description: Source module reference for x86decomp.coff_archive.
---

# `x86decomp.coff_archive`

**Source path:** `src/x86decomp/coff_archive.py`  
**SHA-256:** `c7570a5fe202d3fdbadc6a80e4c7170937f97a418fb06e052138c9ea132d70ff`  
**Documented symbols:** 13

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ArchiveMember` | class | 27 | 68 | Store the validated fields for archive member records. |
| `to_dict` | function | 46 | 68 | Convert dict. |
| `CoffArchive` | class | 72 | 95 | Store the validated fields for coff archive records. |
| `to_dict` | function | 82 | 95 | Convert dict. |
| `_decimal` | function | 98 | 109 | Implement decimal. |
| `_octal` | function | 112 | 123 | Implement octal. |
| `_long_name` | function | 126 | 135 | Implement long name. |
| `_parse_import_object` | function | 138 | 176 | Parse import object. |
| `_cstring_sequence` | function | 179 | 194 | Implement cstring sequence. |
| `_first_linker_symbols` | function | 197 | 212 | Implement first linker symbols. |
| `_second_linker_symbols` | function | 215 | 243 | Implement second linker symbols. |
| `parse_coff_archive_bytes` | function | 246 | 359 | Parse coff archive bytes. |
| `parse_coff_archive` | function | 362 | 373 | Parse coff archive. |
