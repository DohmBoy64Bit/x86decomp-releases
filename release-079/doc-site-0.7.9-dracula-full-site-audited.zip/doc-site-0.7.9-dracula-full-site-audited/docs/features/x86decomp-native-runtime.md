---
title: x86decomp.native.runtime
description: Source module reference for x86decomp.native.runtime.
---

# `x86decomp.native.runtime`

**Source path:** `src/x86decomp/native/runtime.py`  
**SHA-256:** `26b504f1bf3bfde6f020a73e351ce2c308bcfe76b6d1a787959d4da24ef8a133`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `RuntimeValidation` | class | 18 | 85 | Represent runtime validation state and behavior. |
| `__init__` | function | 23 | 28 | Initialize the instance with the supplied constructor arguments. |
| `validate_image` | function | 30 | 44 | Validate image. |
| `launch` | function | 46 | 63 | Implement launch. |
| `map_crash` | function | 65 | 73 | Implement map crash. |
| `_record` | function | 75 | 85 | Implement record. |
