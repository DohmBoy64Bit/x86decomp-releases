---
title: x86decomp.harness_generator
description: Source module reference for x86decomp.harness_generator.
---

# `x86decomp.harness_generator`

**Source path:** `src/x86decomp/harness_generator.py`  
**SHA-256:** `ac505699980552d530aacee528e160cd7eac69c69536ba5c4c2029c96f9142e1`  
**Documented symbols:** 3

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_deterministic_word` | function | 17 | 23 | Implement deterministic word. |
| `generate_execution_harness` | function | 26 | 144 | Generate execution harness. |
| `generate_execution_harness_from_files` | function | 147 | 173 | Generate execution harness from files. |
