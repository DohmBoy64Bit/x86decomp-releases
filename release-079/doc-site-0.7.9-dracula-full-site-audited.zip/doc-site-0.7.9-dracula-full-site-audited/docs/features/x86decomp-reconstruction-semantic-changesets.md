---
title: x86decomp.reconstruction.semantic_changesets
description: Source module reference for x86decomp.reconstruction.semantic_changesets.
---

# `x86decomp.reconstruction.semantic_changesets`

**Source path:** `src/x86decomp/reconstruction/semantic_changesets.py`  
**SHA-256:** `43de7e317b417308d83a71f46c4f94ef1e4e8ab0b8760fd654a36e446c0f18c5`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `SemanticChangeSets` | class | 12 | 92 | Represent semantic change sets state and behavior. |
| `__init__` | function | 17 | 22 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 23 | 31 | Create the requested operation. |
| `get` | function | 32 | 41 | Return the requested operation. |
| `add_operation` | function | 42 | 54 | Add operation. |
| `merge` | function | 55 | 71 | Merge the requested operation. |
| `conflicts` | function | 72 | 77 | Implement conflicts. |
| `verify` | function | 78 | 84 | Verify the requested operation. |
| `rebase` | function | 85 | 92 | Implement rebase. |
