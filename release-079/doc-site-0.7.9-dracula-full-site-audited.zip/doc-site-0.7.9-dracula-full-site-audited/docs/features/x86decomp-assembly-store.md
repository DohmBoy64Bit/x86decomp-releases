---
title: x86decomp.assembly.store
description: Source module reference for x86decomp.assembly.store.
---

# `x86decomp.assembly.store`

**Source path:** `src/x86decomp/assembly/store.py`  
**SHA-256:** `b342aee1dee18093c50e36048b20261e01a228b87d9012908283281b6f778ffe`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `AssemblyStore` | class | 52 | 129 | Additive relocation-aware assembly schema layered on the current native reconstruction state. |
| `initialize` | function | 55 | 78 | Initialize the requested operation. |
| `check` | function | 80 | 114 | Check the requested operation. |
| `decode` | function | 117 | 129 | Decode the requested operation. |
