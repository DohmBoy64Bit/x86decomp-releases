---
title: x86decomp.reconstruction.security
description: Source module reference for x86decomp.reconstruction.security.
---

# `x86decomp.reconstruction.security`

**Source path:** `src/x86decomp/reconstruction/security.py`  
**SHA-256:** `10da3972c26f4fe18a410318b27167a880f635027972ddf7b6bdd7a03554e1d4`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `SecurityReview` | class | 12 | 69 | Represent security review state and behavior. |
| `__init__` | function | 17 | 22 | Initialize the instance with the supplied constructor arguments. |
| `finding` | function | 23 | 33 | Implement finding. |
| `get` | function | 34 | 41 | Return the requested operation. |
| `scan` | function | 42 | 52 | Scan the requested operation. |
| `policy` | function | 53 | 61 | Implement policy. |
| `report` | function | 62 | 69 | Report the requested operation. |
