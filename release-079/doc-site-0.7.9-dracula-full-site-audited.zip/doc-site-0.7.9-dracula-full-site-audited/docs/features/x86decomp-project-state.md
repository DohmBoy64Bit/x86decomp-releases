---
title: x86decomp.project_state
description: Source module reference for x86decomp.project_state.
---

# `x86decomp.project_state`

**Source path:** `src/x86decomp/project_state.py`  
**SHA-256:** `527021546292d6ec262cb216dbead563995938d08c329bf359acfcfbf9c6056e`  
**Documented symbols:** 21

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ProjectCheck` | class | 70 | 92 | Store the validated fields for project check records. |
| `to_dict` | function | 81 | 92 | Convert dict. |
| `ProjectStateDatabase` | class | 95 | 231 | Represent project state database state and behavior. |
| `__init__` | function | 100 | 119 | Initialize the instance with the supplied constructor arguments. |
| `close` | function | 121 | 126 | Close the requested operation. |
| `__enter__` | function | 128 | 133 | Enter the context manager and return the active resource. |
| `__exit__` | function | 135 | 140 | Exit the context manager and release managed resources. |
| `transaction` | function | 143 | 155 | Implement transaction. |
| `integrity_check` | function | 157 | 163 | Implement integrity check. |
| `record_migration` | function | 165 | 187 | Implement record migration. |
| `snapshot` | function | 189 | 212 | Implement snapshot. |
| `upsert_artifact_reference` | function | 214 | 224 | Insert or update artifact reference. |
| `artifact_digests` | function | 226 | 231 | Implement artifact digests. |
| `state_database_path` | function | 234 | 239 | Implement state database path. |
| `create_project_backup` | function | 242 | 274 | Create a deterministic gzip tar backup without following symlinks. |
| `_migration_2_to_3` | function | 277 | 309 | Implement migration 2 to 3. |
| `migrate_project` | function | 312 | 375 | Implement migrate project. |
| `check_project_state` | function | 378 | 418 | Check project state. |
| `repair_project_state` | function | 421 | 448 | Repair only reconstructible indexes; never rewrite evidence or binaries. |
| `project_gc` | function | 451 | 458 | Implement project gc. |
| `restore_project_backup` | function | 461 | 506 | Safely restore a project backup into an empty destination. |
