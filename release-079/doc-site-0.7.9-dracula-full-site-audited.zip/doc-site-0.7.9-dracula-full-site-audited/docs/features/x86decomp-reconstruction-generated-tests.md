---
title: x86decomp.reconstruction.generated_tests
description: Source module reference for x86decomp.reconstruction.generated_tests.
---

# `x86decomp.reconstruction.generated_tests`

**Source path:** `src/x86decomp/reconstruction/generated_tests.py`  
**SHA-256:** `e4edf5dd3e810739349c188bd9cee357a2e0f4b14a4617d7fd9a99143499a64a`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `GeneratedTests` | class | 13 | 77 | Represent generated tests state and behavior. |
| `__init__` | function | 18 | 23 | Initialize the instance with the supplied constructor arguments. |
| `add` | function | 24 | 36 | Add the requested operation. |
| `synthesize` | function | 37 | 47 | Implement synthesize. |
| `promote_counterexample` | function | 48 | 56 | Implement promote counterexample. |
| `get` | function | 57 | 64 | Return the requested operation. |
| `list` | function | 65 | 71 | List the requested operation. |
| `explain` | function | 72 | 77 | Implement explain. |
