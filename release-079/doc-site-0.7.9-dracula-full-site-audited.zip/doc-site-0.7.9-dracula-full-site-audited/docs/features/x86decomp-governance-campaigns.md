---
title: x86decomp.governance.campaigns
description: Source module reference for x86decomp.governance.campaigns.
---

# `x86decomp.governance.campaigns`

**Source path:** `src/x86decomp/governance/campaigns.py`  
**SHA-256:** `35bef687b89488ce516b5003b5e00393d60c1f39d73dedc741f412d86fc27840`  
**Documented symbols:** 17

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `CampaignEngine` | class | 17 | 257 | Persistent, deterministic campaign control and next-action planning. |
| `__init__` | function | 20 | 26 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 28 | 50 | Create the requested operation. |
| `_validate_budget` | function | 53 | 66 | Validate budget. |
| `transition` | function | 68 | 88 | Implement transition. |
| `start` | function | 90 | 95 | Implement start. |
| `pause` | function | 97 | 102 | Implement pause. |
| `resume` | function | 104 | 109 | Implement resume. |
| `stop` | function | 111 | 116 | Implement stop. |
| `consume_budget` | function | 118 | 144 | Implement consume budget. |
| `branch` | function | 146 | 165 | Implement branch. |
| `get_branch` | function | 167 | 176 | Return branch. |
| `snapshot` | function | 178 | 188 | Implement snapshot. |
| `_decision` | function | 191 | 198 | Implement decision. |
| `plan_next` | function | 200 | 234 | Plan next. |
| `get` | function | 236 | 248 | Return the requested operation. |
| `list` | function | 250 | 257 | List the requested operation. |
