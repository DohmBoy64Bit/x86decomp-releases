---
title: x86decomp.objdiff_adapter
description: Source module reference for x86decomp.objdiff_adapter.
---

# `x86decomp.objdiff_adapter`

**Source path:** `src/x86decomp/objdiff_adapter.py`  
**SHA-256:** `4f827970a05e733492dd15f3d04680ff053ab08f43d83a7874b974d1bd5fc7ef`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_resolve_executable` | function | 24 | 39 | Resolve executable. |
| `run_objdiff_manifest` | function | 42 | 179 | Run objdiff manifest. |
