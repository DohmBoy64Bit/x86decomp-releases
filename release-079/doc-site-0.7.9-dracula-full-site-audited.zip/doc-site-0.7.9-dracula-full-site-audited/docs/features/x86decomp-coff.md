---
title: x86decomp.coff
description: Source module reference for x86decomp.coff.
---

# `x86decomp.coff`

**Source path:** `src/x86decomp/coff.py`  
**SHA-256:** `3cbec2e28585b9dd69e5f16f360b88d32f195f74f35d5f43862289b8e6285ec0`  
**Documented symbols:** 68

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `relocation_name` | function | 127 | 133 | Implement relocation name. |
| `relocation_width` | function | 136 | 142 | Implement relocation width. |
| `relocation_is_pc_relative` | function | 145 | 152 | Implement relocation is pc relative. |
| `CoffRelocation` | class | 156 | 189 | Store the validated fields for coff relocation records. |
| `width` | function | 167 | 172 | Implement width. |
| `to_dict` | function | 174 | 189 | Convert dict. |
| `SectionDefinitionAux` | class | 193 | 228 | Store the validated fields for section definition aux records. |
| `selection_name` | function | 206 | 211 | Implement selection name. |
| `to_dict` | function | 213 | 228 | Convert dict. |
| `FunctionDefinitionAux` | class | 232 | 253 | Store the validated fields for function definition aux records. |
| `to_dict` | function | 242 | 253 | Convert dict. |
| `WeakExternalAux` | class | 257 | 276 | Store the validated fields for weak external aux records. |
| `to_dict` | function | 265 | 276 | Convert dict. |
| `FileAux` | class | 280 | 292 | Store the validated fields for file aux records. |
| `to_dict` | function | 287 | 292 | Convert dict. |
| `RawAux` | class | 296 | 308 | Store the validated fields for raw aux records. |
| `to_dict` | function | 303 | 308 | Convert dict. |
| `CoffSection` | class | 315 | 397 | Store the validated fields for coff section records. |
| `is_comdat` | function | 335 | 340 | Implement is comdat. |
| `comdat_selection_name` | function | 343 | 348 | Implement comdat selection name. |
| `alignment_power` | function | 351 | 361 | Implement alignment power. |
| `alignment` | function | 364 | 370 | Implement alignment. |
| `to_dict` | function | 372 | 397 | Convert dict. |
| `CoffSymbol` | class | 401 | 473 | Store the validated fields for coff symbol records. |
| `is_function` | function | 416 | 423 | Implement is function. |
| `section_definition` | function | 426 | 434 | Implement section definition. |
| `function_definition` | function | 437 | 445 | Implement function definition. |
| `weak_external` | function | 448 | 456 | Implement weak external. |
| `to_dict` | function | 458 | 473 | Convert dict. |
| `CoffObject` | class | 477 | 548 | Store the validated fields for coff object records. |
| `architecture` | function | 493 | 502 | Implement architecture. |
| `section` | function | 504 | 511 | Implement section. |
| `find_symbols` | function | 513 | 521 | Find symbols. |
| `symbol_by_index` | function | 523 | 528 | Implement symbol by index. |
| `to_dict` | function | 530 | 548 | Convert dict. |
| `ExtractedSymbol` | class | 552 | 576 | Store the validated fields for extracted symbol records. |
| `to_dict` | function | 564 | 576 | Convert dict. |
| `ComdatCandidate` | class | 580 | 611 | Store the validated fields for comdat candidate records. |
| `to_dict` | function | 595 | 611 | Convert dict. |
| `ComdatResolution` | class | 615 | 643 | Store the validated fields for comdat resolution records. |
| `valid` | function | 625 | 630 | Implement valid. |
| `to_dict` | function | 632 | 643 | Convert dict. |
| `SyntheticSymbolSpec` | class | 647 | 657 | Store the validated fields for synthetic symbol spec records. |
| `SyntheticSectionSpec` | class | 661 | 673 | Store the validated fields for synthetic section spec records. |
| `_Reader` | class | 676 | 705 | Represent reader state and behavior. |
| `__init__` | function | 681 | 686 | Initialize the instance with the supplied constructor arguments. |
| `require` | function | 688 | 696 | Implement require. |
| `unpack` | function | 698 | 705 | Implement unpack. |
| `_read_string_table` | function | 708 | 723 | Read string table. |
| `_string_at` | function | 726 | 736 | Implement string at. |
| `_decode_symbol_name` | function | 739 | 747 | Decode symbol name. |
| `_decode_section_name` | function | 750 | 758 | Decode section name. |
| `_parse_header` | function | 761 | 812 | Return variant, machine, sections, timestamp, symptr, symcount, |
| `_parse_auxiliary_records` | function | 815 | 874 | Parse auxiliary records. |
| `_read_addend` | function | 877 | 884 | Read addend. |
| `parse_coff_bytes` | function | 887 | 1086 | Parse coff bytes. |
| `parse_coff` | function | 1089 | 1097 | Parse coff. |
| `extract_symbol` | function | 1100 | 1156 | Extract symbol. |
| `collect_comdat_candidates` | function | 1159 | 1187 | Collect comdat candidates. |
| `resolve_comdats` | function | 1190 | 1288 | Resolve COMDAT groups using PE/COFF selection semantics. |
| `_encode_name` | function | 1291 | 1301 | Implement encode name. |
| `_section_aux_bytes` | function | 1304 | 1321 | Implement section aux bytes. |
| `build_synthetic_coff_object` | function | 1324 | 1438 | Build a deterministic classic COFF object with multiple sections. |
| `synthetic_symbol_indices` | function | 1441 | 1453 | Implement synthetic symbol indices. |
| `build_synthetic_coff` | function | 1456 | 1493 | Backward-compatible one-section synthetic COFF builder. |
| `build_comdat_coff` | function | 1496 | 1562 | Build comdat coff. |
| `write_synthetic_coff` | function | 1565 | 1583 | Write synthetic coff. |
| `write_synthetic_coff_object` | function | 1586 | 1603 | Write synthetic coff object. |
