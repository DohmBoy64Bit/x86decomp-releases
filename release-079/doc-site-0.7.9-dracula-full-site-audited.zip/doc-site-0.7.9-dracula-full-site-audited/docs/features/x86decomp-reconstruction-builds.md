---
title: x86decomp.reconstruction.builds
description: Source module reference for x86decomp.reconstruction.builds.
---

# `x86decomp.reconstruction.builds`

**Source path:** `src/x86decomp/reconstruction/builds.py`  
**SHA-256:** `735fe9dd2682609e98c015149b00e153a8b381ad6c8c2a36d5b393e16f8abae4`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `BuildManager` | class | 14 | 142 | Represent build manager state and behavior. |
| `__init__` | function | 19 | 24 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 25 | 36 | Create the requested operation. |
| `add_target` | function | 37 | 48 | Add target. |
| `add_variant` | function | 49 | 59 | Add variant. |
| `show` | function | 60 | 69 | Implement show. |
| `show_target` | function | 70 | 79 | Implement show target. |
| `show_variant` | function | 80 | 88 | Implement show variant. |
| `generate` | function | 89 | 111 | Generate the requested operation. |
| `validate` | function | 112 | 125 | Validate the requested operation. |
| `compare_modes` | function | 126 | 133 | Compare modes. |
| `matrix` | function | 134 | 142 | Implement matrix. |
