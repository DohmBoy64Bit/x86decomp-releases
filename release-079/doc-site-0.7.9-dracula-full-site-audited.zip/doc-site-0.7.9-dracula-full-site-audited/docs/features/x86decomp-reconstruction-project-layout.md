---
title: x86decomp.reconstruction.project_layout
description: Source module reference for x86decomp.reconstruction.project_layout.
---

# `x86decomp.reconstruction.project_layout`

**Source path:** `src/x86decomp/reconstruction/project_layout.py`  
**SHA-256:** `232e1274e25b6dfdc478ad3bb4db48b983fc758629e8ac6e997f684cf37a6ba3`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ProjectLayout` | class | 14 | 149 | Represent project layout state and behavior. |
| `__init__` | function | 19 | 24 | Initialize the instance with the supplied constructor arguments. |
| `create_module` | function | 26 | 38 | Create module. |
| `add_member` | function | 40 | 51 | Add member. |
| `create_translation_unit` | function | 53 | 67 | Create translation unit. |
| `add_translation_unit_member` | function | 69 | 80 | Add translation unit member. |
| `synthesize` | function | 82 | 99 | Deterministically group inventory records by explicit object/library/source hints. |
| `show_module` | function | 101 | 111 | Implement show module. |
| `show_translation_unit` | function | 113 | 123 | Implement show translation unit. |
| `list_modules` | function | 125 | 131 | List modules. |
| `explain_boundaries` | function | 133 | 139 | Implement explain boundaries. |
| `export` | function | 141 | 149 | Export the requested operation. |
