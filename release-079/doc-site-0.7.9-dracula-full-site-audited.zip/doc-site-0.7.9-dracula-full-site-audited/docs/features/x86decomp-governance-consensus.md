---
title: x86decomp.governance.consensus
description: Source module reference for x86decomp.governance.consensus.
---

# `x86decomp.governance.consensus`

**Source path:** `src/x86decomp/governance/consensus.py`  
**SHA-256:** `e78ab5d5f0e630461ca2407eca86ac78892dcf413783008d367caf315f96e187`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ConsensusEngine` | class | 15 | 138 | Represent consensus engine state and behavior. |
| `__init__` | function | 20 | 26 | Initialize the instance with the supplied constructor arguments. |
| `record` | function | 28 | 42 | Implement record. |
| `scan` | function | 44 | 88 | Scan the requested operation. |
| `conflicts` | function | 90 | 95 | Implement conflicts. |
| `resolve` | function | 97 | 120 | Resolve the requested operation. |
| `explain` | function | 122 | 138 | Implement explain. |
