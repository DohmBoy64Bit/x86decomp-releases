---
title: x86decomp_testkit.adapters.capabilities
description: Source module reference for x86decomp_testkit.adapters.capabilities.
---

# `x86decomp_testkit.adapters.capabilities`

**Source path:** `test-suite/src/x86decomp_testkit/adapters/capabilities.py`  
**SHA-256:** `d5d3c8c2148013adaf5211e436caf18a22e3eccf7210c56b9838c188a18d9168`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `CapabilityResult` | class | 25 | 40 | Store the validated fields for capability result records. |
| `to_dict` | function | 35 | 40 | Convert dict. |
| `host_is_loopback` | function | 43 | 59 | Implement host is loopback. |
| `endpoint_is_allowed` | function | 62 | 70 | Implement endpoint is allowed. |
| `normalize_endpoint` | function | 73 | 84 | Normalize endpoint. |
| `probe_openai_compatible_endpoint` | function | 87 | 115 | Implement probe openai compatible endpoint. |
| `capabilities_from_adapters` | function | 118 | 150 | Implement capabilities from adapters. |
| `capability_map` | function | 153 | 158 | Implement capability map. |
| `write_capability_report` | function | 161 | 168 | Write capability report. |
