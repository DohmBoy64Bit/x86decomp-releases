---
title: x86decomp.project_template
description: Source module reference for x86decomp.project_template.
---

# `x86decomp.project_template`

**Source path:** `src/x86decomp/project_template.py`  
**SHA-256:** `d98f3268208db58c5c5f94be9c9bb3e4b5e79bcd618f82e234b3772232c69bc0`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_artifact_roles` | function | 21 | 26 | Implement artifact roles. |
| `derive_template_contract` | function | 29 | 89 | Derive a target project shape only from recorded facts and decisions. |
| `_write_project_helper` | function | 92 | 138 | Write project helper. |
| `materialize_project_template` | function | 141 | 201 | Create a deterministic, non-fabricated project working layout. |
