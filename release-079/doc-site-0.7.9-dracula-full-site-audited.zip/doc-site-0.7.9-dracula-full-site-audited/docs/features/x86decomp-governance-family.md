---
title: x86decomp.governance.family
description: Source module reference for x86decomp.governance.family.
---

# `x86decomp.governance.family`

**Source path:** `src/x86decomp/governance/family.py`  
**SHA-256:** `97739ca38d58997f044a3d213258b5eb5641ff918c3fd158b6b90c29ec23a12b`  
**Documented symbols:** 10

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `BinaryFamilyStore` | class | 15 | 148 | Static, content-addressed related-binary correlation. |
| `__init__` | function | 18 | 25 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 27 | 38 | Create the requested operation. |
| `add` | function | 40 | 63 | Add the requested operation. |
| `_block_fingerprints` | function | 66 | 73 | Implement block fingerprints. |
| `correlate` | function | 75 | 99 | Implement correlate. |
| `get` | function | 101 | 110 | Return the requested operation. |
| `member` | function | 112 | 123 | Implement member. |
| `correlation` | function | 125 | 136 | Implement correlation. |
| `report` | function | 138 | 148 | Report the requested operation. |
