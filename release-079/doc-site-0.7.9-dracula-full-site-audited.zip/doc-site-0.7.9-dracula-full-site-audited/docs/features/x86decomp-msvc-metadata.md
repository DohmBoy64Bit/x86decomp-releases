---
title: x86decomp.msvc_metadata
description: Source module reference for x86decomp.msvc_metadata.
---

# `x86decomp.msvc_metadata`

**Source path:** `src/x86decomp/msvc_metadata.py`  
**SHA-256:** `32a200966ff4612e9e68acaffe8708611663bba1b57213171c3626bcfc0752b2`  
**Documented symbols:** 41

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `TypeDescriptorRecord` | class | 27 | 51 | Store the validated fields for type descriptor record records. |
| `to_dict` | function | 39 | 51 | Convert dict. |
| `BaseClassRecord` | class | 55 | 87 | Store the validated fields for base class record records. |
| `to_dict` | function | 70 | 87 | Convert dict. |
| `CompleteObjectLocatorRecord` | class | 91 | 123 | Store the validated fields for complete object locator record records. |
| `to_dict` | function | 107 | 123 | Convert dict. |
| `VTableRecord` | class | 127 | 147 | Store the validated fields for v table record records. |
| `to_dict` | function | 137 | 147 | Convert dict. |
| `UnwindCodeRecord` | class | 151 | 175 | Store the validated fields for unwind code record records. |
| `to_dict` | function | 163 | 175 | Convert dict. |
| `UnwindInfoRecord` | class | 179 | 217 | Store the validated fields for unwind info record records. |
| `to_dict` | function | 198 | 217 | Convert dict. |
| `PEView` | class | 220 | 351 | Represent p e view state and behavior. |
| `__init__` | function | 225 | 234 | Initialize the instance with the supplied constructor arguments. |
| `rva_to_offset` | function | 236 | 241 | Implement rva to offset. |
| `valid_rva` | function | 243 | 252 | Implement valid rva. |
| `read` | function | 254 | 262 | Read the requested operation. |
| `u16` | function | 264 | 269 | Implement u16. |
| `u32` | function | 271 | 276 | Implement u32. |
| `i32` | function | 278 | 283 | Implement i32. |
| `u64` | function | 285 | 290 | Implement u64. |
| `pointer` | function | 292 | 297 | Implement pointer. |
| `va_to_rva` | function | 299 | 307 | Implement va to rva. |
| `encoded_pointer_to_rva` | function | 309 | 316 | Implement encoded pointer to rva. |
| `c_string` | function | 318 | 327 | Implement c string. |
| `executable_rva` | function | 329 | 338 | Implement executable rva. |
| `readonly_data_sections` | function | 340 | 351 | Implement readonly data sections. |
| `_display_type_name` | function | 354 | 364 | Implement display type name. |
| `scan_type_descriptors` | function | 367 | 401 | Scan type descriptors. |
| `_parse_base_class` | function | 404 | 440 | Parse base class. |
| `_parse_hierarchy` | function | 443 | 473 | Parse hierarchy. |
| `scan_complete_object_locators` | function | 476 | 522 | Scan complete object locators. |
| `scan_vtables` | function | 525 | 561 | Scan vtables. |
| `_decode_unwind_codes` | function | 582 | 641 | Decode unwind codes. |
| `parse_x64_unwind` | function | 644 | 701 | Parse x64 unwind. |
| `parse_safe_seh` | function | 704 | 718 | Parse safe seh. |
| `tls_report` | function | 721 | 747 | Implement tls report. |
| `scan_exception_func_info` | function | 750 | 800 | Find structurally plausible MSVC EH3 FuncInfo records. |
| `scan_coff_tls` | function | 804 | 841 | Inventory COFF TLS template and callback subsections. |
| `scan_static_initializers` | function | 843 | 897 | Scan static initializers. |
| `analyze_msvc_metadata` | function | 900 | 960 | Analyze msvc metadata. |
