---
title: x86decomp_testkit.live_adapters
description: Source module reference for x86decomp_testkit.live_adapters.
---

# `x86decomp_testkit.live_adapters`

**Source path:** `test-suite/src/x86decomp_testkit/live_adapters.py`  
**SHA-256:** `8c775c76f52b6d5e47a201d7a3b8df317e4e2f9e92a2f4c1ec35a09e05372adb`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_path_for` | function | 25 | 53 | Implement path for. |
| `_python_adapter_test` | function | 56 | 83 | Implement python adapter test. |
| `_generic_executable_test` | function | 86 | 111 | Implement generic executable test. |
| `_compiler_test` | function | 114 | 147 | Implement compiler test. |
| `_lld_link_test` | function | 150 | 188 | Implement lld link test. |
| `_ghidra_test` | function | 191 | 226 | Implement ghidra test. |
| `_dynamorio_test` | function | 229 | 258 | Implement dynamorio test. |
| `_objdiff_test` | function | 261 | 285 | Implement objdiff test. |
| `run_live_adapter_tests` | function | 288 | 321 | Run live adapter tests. |
