---
title: x86decomp.abi
description: Source module reference for x86decomp.abi.
---

# `x86decomp.abi`

**Source path:** `src/x86decomp/abi.py`  
**SHA-256:** `19374cc480409edc6727c5f64a3d3b88e8eafea06f9661f3e2cb5eaf4ff3cbc2`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `CallingConvention` | class | 15 | 25 | Enumerate the supported calling convention values. |
| `FloatMode` | class | 28 | 37 | Enumerate the supported float mode values. |
| `ABIContract` | class | 41 | 104 | Store the validated fields for a b i contract records. |
| `from_dict` | function | 58 | 104 | Build an object from dict. |
| `optional_nonnegative` | function | 73 | 83 | Implement optional nonnegative. |
| `load_abi_contract` | function | 107 | 112 | Load abi contract. |
| `analyze_abi` | function | 115 | 178 | Analyze abi. |
| `validate_abi` | function | 181 | 283 | Validate abi. |
