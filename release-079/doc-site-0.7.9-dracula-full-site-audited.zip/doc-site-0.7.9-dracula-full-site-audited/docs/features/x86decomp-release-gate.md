---
title: x86decomp.release_gate
description: Source module reference for x86decomp.release_gate.
---

# `x86decomp.release_gate`

**Source path:** `src/x86decomp/release_gate.py`  
**SHA-256:** `474e7088ca5a62c47ff3dea36473289c6c282c067036a27e0b81499716857fc9`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_workflow_gate` | function | 32 | 66 | Implement workflow gate. |
| `_claim_gate` | function | 69 | 83 | Implement claim gate. |
| `_pipeline_gate` | function | 86 | 101 | Implement pipeline gate. |
| `evaluate_release_gate` | function | 104 | 184 | Evaluate release gate. |
