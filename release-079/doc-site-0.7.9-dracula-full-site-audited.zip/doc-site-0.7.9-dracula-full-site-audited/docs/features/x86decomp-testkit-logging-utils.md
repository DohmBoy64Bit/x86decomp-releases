---
title: x86decomp_testkit.logging_utils
description: Source module reference for x86decomp_testkit.logging_utils.
---

# `x86decomp_testkit.logging_utils`

**Source path:** `test-suite/src/x86decomp_testkit/logging_utils.py`  
**SHA-256:** `3aa2134a373131a1f7f4a2c6cbfa286cf1a439ab1a6aea6ff869fb03aa041049`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `JsonlEventLogger` | class | 18 | 45 | Represent jsonl event logger state and behavior. |
| `__init__` | function | 23 | 29 | Initialize the instance with the supplied constructor arguments. |
| `emit` | function | 31 | 45 | Emit the requested operation. |
| `configure_logging` | function | 48 | 82 | Implement configure logging. |
