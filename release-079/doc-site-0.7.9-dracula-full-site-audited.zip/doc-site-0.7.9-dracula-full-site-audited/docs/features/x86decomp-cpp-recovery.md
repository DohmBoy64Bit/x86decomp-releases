---
title: x86decomp.cpp_recovery
description: Source module reference for x86decomp.cpp_recovery.
---

# `x86decomp.cpp_recovery`

**Source path:** `src/x86decomp/cpp_recovery.py`  
**SHA-256:** `7fce33467b1cac0b20872de9f91b6c6a480f651835a982259d33fc8c19944659`  
**Documented symbols:** 3

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_function_prefix` | function | 19 | 29 | Implement function prefix. |
| `_adjustor_thunk_candidate` | function | 32 | 60 | Implement adjustor thunk candidate. |
| `recover_cpp_model` | function | 63 | 208 | Recover cpp model. |
