---
title: x86decomp.dynamic
description: Source module reference for x86decomp.dynamic.
---

# `x86decomp.dynamic`

**Source path:** `src/x86decomp/dynamic.py`  
**SHA-256:** `ed8d363f0febd985bce713214aef4913b933f2aa5dc56cf31ae441938e7f9296`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_unicorn` | function | 21 | 33 | Implement unicorn. |
| `_align_down` | function | 36 | 41 | Implement align down. |
| `_align_up` | function | 44 | 49 | Implement align up. |
| `MemoryRegion` | class | 53 | 60 | Store the validated fields for memory region records. |
| `ExecutionSpec` | class | 64 | 81 | Store the validated fields for execution spec records. |
| `load_execution_spec` | function | 84 | 172 | Load execution spec. |
| `_register_map` | function | 175 | 193 | Register map. |
| `_map_region` | function | 196 | 209 | Implement map region. |
| `execute_code` | function | 212 | 317 | Execute code. |
| `code_hook` | function | 259 | 284 | Implement code hook. |
| `differential_validate` | function | 320 | 369 | Implement differential validate. |
| `differential_validate_files` | function | 372 | 394 | Implement differential validate files. |
