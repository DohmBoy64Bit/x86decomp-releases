---
title: x86decomp.artifacts
description: Source module reference for x86decomp.artifacts.
---

# `x86decomp.artifacts`

**Source path:** `src/x86decomp/artifacts.py`  
**SHA-256:** `4beb225f70d47626a1966cdff4382b6f89150b2a713f94792a89513ae8f57265`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `function_id_from_rva` | function | 16 | 23 | Implement function id from rva. |
| `validate_function_manifest` | function | 26 | 50 | Validate function manifest. |
| `import_function_artifact` | function | 53 | 84 | Import function artifact. |
| `verify_function_artifact` | function | 87 | 129 | Verify function artifact. |
