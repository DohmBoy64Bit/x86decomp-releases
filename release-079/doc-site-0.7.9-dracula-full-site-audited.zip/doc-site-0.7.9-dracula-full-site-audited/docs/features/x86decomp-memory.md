---
title: x86decomp.memory
description: Source module reference for x86decomp.memory.
---

# `x86decomp.memory`

**Source path:** `src/x86decomp/memory.py`  
**SHA-256:** `7109340091656fa0d4cfec3e8d88ce6bfda69fd97b506a64e494be9b41d68f59`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ProjectMemory` | class | 14 | 158 | Represent project memory state and behavior. |
| `__init__` | function | 19 | 30 | Initialize the instance with the supplied constructor arguments. |
| `read_events` | function | 32 | 51 | Read events. |
| `append` | function | 53 | 87 | Implement append. |
| `verify` | function | 89 | 109 | Verify the requested operation. |
| `require_valid` | function | 111 | 118 | Implement require valid. |
| `render` | function | 120 | 158 | Render the requested operation. |
