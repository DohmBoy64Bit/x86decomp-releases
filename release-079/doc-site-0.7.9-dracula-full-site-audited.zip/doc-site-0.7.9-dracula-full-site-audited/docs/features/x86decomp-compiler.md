---
title: x86decomp.compiler
description: Source module reference for x86decomp.compiler.
---

# `x86decomp.compiler`

**Source path:** `src/x86decomp/compiler.py`  
**SHA-256:** `196e82c7e7b027db89da85c0a1d7e00e51eddcbf14fe83dd5fa06045135f3da3`  
**Documented symbols:** 5

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `load_profile` | function | 19 | 59 | Load profile. |
| `_tool_version` | function | 62 | 78 | Implement tool version. |
| `_resolve_executable` | function | 81 | 94 | Resolve executable. |
| `compiler_cache_key` | function | 97 | 114 | Implement compiler cache key. |
| `run_compiler_profile` | function | 117 | 253 | Run compiler profile. |
