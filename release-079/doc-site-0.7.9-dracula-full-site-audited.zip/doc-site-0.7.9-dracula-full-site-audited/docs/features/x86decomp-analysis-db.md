---
title: x86decomp.analysis_db
description: Source module reference for x86decomp.analysis_db.
---

# `x86decomp.analysis_db`

**Source path:** `src/x86decomp/analysis_db.py`  
**SHA-256:** `32b2075b6e7c37421e15653d74d867f12071218c2352ad9f93090753a8c942d2`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `AnalysisDatabase` | class | 70 | 293 | Represent analysis database state and behavior. |
| `__init__` | function | 75 | 84 | Initialize the instance with the supplied constructor arguments. |
| `close` | function | 86 | 91 | Close the requested operation. |
| `__enter__` | function | 93 | 98 | Enter the context manager and return the active resource. |
| `__exit__` | function | 100 | 109 | Exit the context manager and release managed resources. |
| `upsert_entity` | function | 111 | 142 | Insert or update entity. |
| `add_reference` | function | 144 | 164 | Add reference. |
| `add_type_constraint` | function | 166 | 189 | Add type constraint. |
| `detect_constraint_conflicts` | function | 191 | 208 | Detect constraint conflicts. |
| `accept_constraint` | function | 210 | 224 | Implement accept constraint. |
| `ingest_function_artifact` | function | 226 | 283 | Ingest function artifact. |
| `query` | function | 285 | 293 | Query the requested operation. |
