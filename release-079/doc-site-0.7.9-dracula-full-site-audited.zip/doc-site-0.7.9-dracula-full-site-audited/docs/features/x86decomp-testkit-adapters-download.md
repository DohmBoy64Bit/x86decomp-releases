---
title: x86decomp_testkit.adapters.download
description: Source module reference for x86decomp_testkit.adapters.download.
---

# `x86decomp_testkit.adapters.download`

**Source path:** `test-suite/src/x86decomp_testkit/adapters/download.py`  
**SHA-256:** `b544d6a5d72648f02ed5bcd6dc5e2d07f0ce97792b2a5bc30ca19128cb60468b`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `platform_key` | function | 25 | 36 | Implement platform key. |
| `github_latest_release` | function | 39 | 52 | Implement github latest release. |
| `select_release_asset` | function | 55 | 71 | Select release asset. |
| `download_file` | function | 74 | 100 | Implement download file. |
| `_safe_destination` | function | 103 | 115 | Implement safe destination. |
| `safe_extract_archive` | function | 118 | 170 | Implement safe extract archive. |
