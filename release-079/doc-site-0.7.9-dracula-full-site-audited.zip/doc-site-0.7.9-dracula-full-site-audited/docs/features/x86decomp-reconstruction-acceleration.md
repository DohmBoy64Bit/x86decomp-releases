---
title: x86decomp.reconstruction.acceleration
description: Source module reference for x86decomp.reconstruction.acceleration.
---

# `x86decomp.reconstruction.acceleration`

**Source path:** `src/x86decomp/reconstruction/acceleration.py`  
**SHA-256:** `6cad6ea294d9015ff076686e66679d84d12ac86863f1251c9d1eb107c006a4ed`  
**Documented symbols:** 70

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_safe_rel` | function | 32 | 43 | Implement safe rel. |
| `_read_text_if_exists` | function | 46 | 51 | Read text if exists. |
| `_body_ranges` | function | 54 | 69 | Implement body ranges. |
| `_contiguous_single_range` | function | 72 | 83 | Implement contiguous single range. |
| `_read_range_bytes` | function | 86 | 105 | Read range bytes. |
| `_read_mnemonics` | function | 108 | 140 | Read mnemonics. |
| `_function_name` | function | 143 | 152 | Implement function name. |
| `llm_job_from_function_packet` | function | 155 | 238 | Create one local-LLM job from a verified function artifact directory. |
| `llm_job_from_range` | function | 241 | 312 | Create one local-LLM job from an explicitly supplied file offset/RVA range. |
| `llm_batch_create` | function | 315 | 344 | Implement llm batch create. |
| `llm_batch_match` | function | 347 | 374 | Implement llm batch match. |
| `candidate_promote` | function | 377 | 407 | Implement candidate promote. |
| `source_map_annotate` | function | 410 | 429 | Implement source map annotate. |
| `source_map_verify` | function | 432 | 450 | Implement source map verify. |
| `module_assign` | function | 453 | 465 | Implement module assign. |
| `module_suggest` | function | 468 | 487 | Implement module suggest. |
| `type_propagate` | function | 490 | 503 | Implement type propagate. |
| `header_synthesize_project` | function | 506 | 526 | Implement header synthesize project. |
| `vtable_recover` | function | 529 | 535 | Implement vtable recover. |
| `class_scaffold` | function | 538 | 556 | Implement class scaffold. |
| `diff_explain` | function | 559 | 574 | Diff explain. |
| `triage_next` | function | 577 | 589 | Implement triage next. |
| `playability_smoke_plan` | function | 592 | 601 | Implement playability smoke plan. |
| `asset_inventory` | function | 604 | 616 | Implement asset inventory. |
| `mod_branch_init` | function | 619 | 626 | Implement mod branch init. |
| `regression_compare` | function | 629 | 637 | Implement regression compare. |
| `_json_out` | function | 666 | 673 | Implement json out. |
| `_read_any_text` | function | 676 | 684 | Read any text. |
| `_file_report` | function | 687 | 693 | Implement file report. |
| `function_discover` | function | 696 | 736 | Discover candidate function entry offsets using architecture profiles. |
| `function_boundary_reconcile` | function | 739 | 762 | Implement function boundary reconcile. |
| `function_list_sort` | function | 765 | 789 | Implement function list sort. |
| `sort_key` | function | 776 | 786 | Implement sort key. |
| `function_list_classify` | function | 792 | 816 | Implement function list classify. |
| `pattern_catalog` | function | 819 | 825 | Implement pattern catalog. |
| `pattern_scan` | function | 828 | 854 | Implement pattern scan. |
| `pattern_generate` | function | 857 | 877 | Implement pattern generate. |
| `pattern_match` | function | 880 | 891 | Implement pattern match. |
| `pattern_promote` | function | 894 | 902 | Implement pattern promote. |
| `image_text_compose` | function | 905 | 953 | Implement image text compose. |
| `_pe_section` | function | 956 | 978 | Implement pe section. |
| `text_swap_plan` | function | 981 | 993 | Implement text swap plan. |
| `text_swap_inject` | function | 996 | 1020 | Implement text swap inject. |
| `text_swap_verify` | function | 1023 | 1035 | Implement text swap verify. |
| `text_swap_build` | function | 1038 | 1047 | Implement text swap build. |
| `progress_reconcile` | function | 1050 | 1070 | Implement progress reconcile. |
| `project_health` | function | 1073 | 1086 | Implement project health. |
| `source_stage_classify` | function | 1089 | 1117 | Implement source stage classify. |
| `ghidra_mcp_probe` | function | 1120 | 1133 | Implement ghidra mcp probe. |
| `_json_rpc` | function | 1136 | 1144 | Implement json rpc. |
| `ghidra_mcp_functions` | function | 1147 | 1154 | Implement ghidra mcp functions. |
| `ghidra_mcp_decompile` | function | 1157 | 1164 | Implement ghidra mcp decompile. |
| `ghidra_mcp_batch_decompile` | function | 1167 | 1182 | Implement ghidra mcp batch decompile. |
| `ghidra_mcp_sync_names` | function | 1185 | 1197 | Implement ghidra mcp sync names. |
| `compiler_rule_learn` | function | 1200 | 1210 | Implement compiler rule learn. |
| `compiler_rule_report` | function | 1213 | 1220 | Implement compiler rule report. |
| `compiler_compare_flags` | function | 1223 | 1233 | Implement compiler compare flags. |
| `runtime_identify` | function | 1236 | 1250 | Implement runtime identify. |
| `runtime_quarantine` | function | 1253 | 1264 | Implement runtime quarantine. |
| `runtime_match_library` | function | 1267 | 1274 | Implement runtime match library. |
| `subsystem_detect` | function | 1277 | 1292 | Implement subsystem detect. |
| `state_machine_detect` | function | 1295 | 1309 | Implement state machine detect. |
| `project_doctor_paths` | function | 1312 | 1327 | Implement project doctor paths. |
| `script_port_audit` | function | 1330 | 1346 | Implement script port audit. |
| `toolchain_hash_tree` | function | 1349 | 1357 | Implement toolchain hash tree. |
| `toolchain_verify_local` | function | 1360 | 1373 | Implement toolchain verify local. |
| `toolchain_redact_package` | function | 1376 | 1391 | Implement toolchain redact package. |
| `decompiler_cleanup` | function | 1394 | 1416 | Implement decompiler cleanup. |
| `candidate_search` | function | 1419 | 1431 | Implement candidate search. |
| `release_goal_moddable_source` | function | 1434 | 1442 | Implement release goal moddable source. |
