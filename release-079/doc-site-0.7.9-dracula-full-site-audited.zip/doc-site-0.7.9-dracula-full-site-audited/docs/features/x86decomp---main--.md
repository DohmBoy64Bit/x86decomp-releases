---
title: x86decomp.__main__
description: Source module reference for x86decomp.__main__.
---

# `x86decomp.__main__`

**Source path:** `src/x86decomp/__main__.py`  
**SHA-256:** `336059ec26a38ee5838ff80ef13592f080c197e6c0c2b22b52e6c80f9a411b32`  
**Documented symbols:** 0

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| _No class or function symbols declared._ |  |  |  |  |
