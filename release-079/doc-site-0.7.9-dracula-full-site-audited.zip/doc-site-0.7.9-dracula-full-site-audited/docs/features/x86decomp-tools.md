---
title: x86decomp.tools
description: Source module reference for x86decomp.tools.
---

# `x86decomp.tools`

**Source path:** `src/x86decomp/tools.py`  
**SHA-256:** `e3129edc727557d1ef57b36cadb748ea60b0a738c8dfb5427309a509ccaf4bb3`  
**Documented symbols:** 3

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_capture` | function | 22 | 40 | Implement capture. |
| `discover_analyze_headless` | function | 43 | 64 | Implement discover analyze headless. |
| `snapshot_tools` | function | 67 | 85 | Implement snapshot tools. |
