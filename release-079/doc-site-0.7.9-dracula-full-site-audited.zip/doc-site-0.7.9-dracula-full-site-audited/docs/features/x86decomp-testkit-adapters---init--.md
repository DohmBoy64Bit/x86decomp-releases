---
title: x86decomp_testkit.adapters.__init__
description: Source module reference for x86decomp_testkit.adapters.__init__.
---

# `x86decomp_testkit.adapters.__init__`

**Source path:** `test-suite/src/x86decomp_testkit/adapters/__init__.py`  
**SHA-256:** `deca05faa2e023c5a66121ffc86647c0741d430b0e0640cd0ad9ca38a5d4c984`  
**Documented symbols:** 0

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| _No class or function symbols declared._ |  |  |  |  |
