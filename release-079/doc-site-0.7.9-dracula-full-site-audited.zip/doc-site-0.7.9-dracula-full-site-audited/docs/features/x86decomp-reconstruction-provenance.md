---
title: x86decomp.reconstruction.provenance
description: Source module reference for x86decomp.reconstruction.provenance.
---

# `x86decomp.reconstruction.provenance`

**Source path:** `src/x86decomp/reconstruction/provenance.py`  
**SHA-256:** `8393270fb681c732162a52c8bf7a79e303966026bd4cd49a98135a9eba4c2f33`  
**Documented symbols:** 11

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ProvenanceLedger` | class | 14 | 118 | Represent provenance ledger state and behavior. |
| `__init__` | function | 19 | 24 | Initialize the instance with the supplied constructor arguments. |
| `record` | function | 25 | 38 | Implement record. |
| `get` | function | 39 | 46 | Return the requested operation. |
| `source` | function | 47 | 56 | Implement source. |
| `binary` | function | 57 | 65 | Implement binary. |
| `lock` | function | 66 | 75 | Implement lock. |
| `unlock` | function | 76 | 84 | Implement unlock. |
| `reconcile` | function | 85 | 103 | Implement reconcile. |
| `impact` | function | 104 | 110 | Implement impact. |
| `export` | function | 111 | 118 | Export the requested operation. |
