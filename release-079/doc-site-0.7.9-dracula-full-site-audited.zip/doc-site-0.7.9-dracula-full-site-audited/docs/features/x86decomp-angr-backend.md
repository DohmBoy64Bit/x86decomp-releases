---
title: x86decomp.angr_backend
description: Source module reference for x86decomp.angr_backend.
---

# `x86decomp.angr_backend`

**Source path:** `src/x86decomp/angr_backend.py`  
**SHA-256:** `00565b40ff59b20bab492feb2424b5e3d5372333f6938db7e75832b0e3e14adb`  
**Documented symbols:** 11

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_load_angr` | function | 18 | 28 | Load angr. |
| `_arch_name` | function | 31 | 40 | Implement arch name. |
| `_summaries` | function | 43 | 119 | Implement summaries. |
| `_counterexample` | function | 122 | 141 | Implement counterexample. |
| `angr_bounded_compare` | function | 144 | 190 | Implement angr bounded compare. |
| `angr_bounded_compare_files` | function | 193 | 202 | Implement angr bounded compare files. |
| `_load_memory_harness` | function | 205 | 233 | Load memory harness. |
| `_memory_summaries` | function | 236 | 404 | Implement memory summaries. |
| `_memory_counterexample` | function | 407 | 437 | Implement memory counterexample. |
| `angr_memory_alias_compare` | function | 440 | 479 | Implement angr memory alias compare. |
| `angr_memory_alias_compare_files` | function | 482 | 500 | Implement angr memory alias compare files. |
