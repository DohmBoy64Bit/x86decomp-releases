---
title: x86decomp.patching
description: Source module reference for x86decomp.patching.
---

# `x86decomp.patching`

**Source path:** `src/x86decomp/patching.py`  
**SHA-256:** `d7afd59bb5a8b9fb2cc4ab6d7d9bef7e9a0826fa03d8059d9f702f7d0c3d7597`  
**Documented symbols:** 3

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_checksum_offset` | function | 15 | 25 | Implement checksum offset. |
| `calculate_pe_checksum` | function | 28 | 44 | Implement calculate pe checksum. |
| `patch_pe_function` | function | 47 | 107 | Implement patch pe function. |
