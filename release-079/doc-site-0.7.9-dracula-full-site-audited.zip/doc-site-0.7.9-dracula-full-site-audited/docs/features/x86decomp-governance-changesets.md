---
title: x86decomp.governance.changesets
description: Source module reference for x86decomp.governance.changesets.
---

# `x86decomp.governance.changesets`

**Source path:** `src/x86decomp/governance/changesets.py`  
**SHA-256:** `f0ec58e174c68bf370ace009b9a5df1dcd968032f7cdc024585841c413cf5e65`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ChangeSet` | class | 17 | 101 | Portable, append-only governance audit changesets with base-tip conflict checks. |
| `export` | function | 21 | 47 | Export the requested operation. |
| `inspect` | function | 50 | 77 | Inspect the requested operation. |
| `apply` | function | 80 | 101 | Apply the requested operation. |
