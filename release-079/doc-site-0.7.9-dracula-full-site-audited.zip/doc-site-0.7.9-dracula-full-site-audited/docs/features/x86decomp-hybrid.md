---
title: x86decomp.hybrid
description: Source module reference for x86decomp.hybrid.
---

# `x86decomp.hybrid`

**Source path:** `src/x86decomp/hybrid.py`  
**SHA-256:** `f6122a0b1ae5b5bbe13ec5b2c70c450832a072077f87d3944bbc284f9d515240`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_assembly_bytes` | function | 15 | 25 | Implement assembly bytes. |
| `generate_hybrid_project` | function | 28 | 225 | Generate a continuously buildable hybrid tree. |
