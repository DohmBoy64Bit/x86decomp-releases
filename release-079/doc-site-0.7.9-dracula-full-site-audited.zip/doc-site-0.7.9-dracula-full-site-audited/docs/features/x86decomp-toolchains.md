---
title: x86decomp.toolchains
description: Source module reference for x86decomp.toolchains.
---

# `x86decomp.toolchains`

**Source path:** `src/x86decomp/toolchains.py`  
**SHA-256:** `86efec3cc250b93d4a0405dabccca0bc143f75bd7aefdcbb1b0b924d037a0f8d`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `register_toolchain` | function | 12 | 47 | Register toolchain. |
| `verify_toolchain` | function | 50 | 66 | Verify toolchain. |
