---
title: x86decomp_testkit.reports
description: Source module reference for x86decomp_testkit.reports.
---

# `x86decomp_testkit.reports`

**Source path:** `test-suite/src/x86decomp_testkit/reports.py`  
**SHA-256:** `d662c531c718cc09e1a8dca5b5fafe09c3af7d2369448c1e554c970c000fc2ea`  
**Documented symbols:** 5

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `write_json_report` | function | 15 | 21 | Write json report. |
| `write_adapter_report` | function | 24 | 34 | Write adapter report. |
| `_status_icon` | function | 37 | 47 | Implement status icon. |
| `write_markdown_report` | function | 50 | 120 | Write markdown report. |
| `write_html_report` | function | 123 | 168 | Write html report. |
