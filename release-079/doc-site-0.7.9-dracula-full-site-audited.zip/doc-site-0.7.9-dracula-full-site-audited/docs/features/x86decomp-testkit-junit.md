---
title: x86decomp_testkit.junit
description: Source module reference for x86decomp_testkit.junit.
---

# `x86decomp_testkit.junit`

**Source path:** `test-suite/src/x86decomp_testkit/junit.py`  
**SHA-256:** `227da8f309da760c655fc04a1af8da18369316ee77fecc718ecb89f60b3d0225`  
**Documented symbols:** 1

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `parse_junit` | function | 12 | 31 | Parse junit. |
