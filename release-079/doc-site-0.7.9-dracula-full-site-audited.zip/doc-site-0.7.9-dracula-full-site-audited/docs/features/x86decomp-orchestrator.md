---
title: x86decomp.orchestrator
description: Source module reference for x86decomp.orchestrator.
---

# `x86decomp.orchestrator`

**Source path:** `src/x86decomp/orchestrator.py`  
**SHA-256:** `ddccc91f1ab154ee35a0fcb41a32f0f9e5434f65898350044e4fa985c92cabc7`  
**Documented symbols:** 28

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `JobState` | class | 32 | 42 | Enumerate the supported job state values. |
| `PipelineStage` | class | 90 | 165 | Store the validated fields for pipeline stage records. |
| `from_dict` | function | 108 | 165 | Build an object from dict. |
| `strings` | function | 121 | 129 | Implement strings. |
| `PipelineManifest` | class | 169 | 208 | Store the validated fields for pipeline manifest records. |
| `load` | function | 179 | 208 | Load the requested operation. |
| `Orchestrator` | class | 211 | 759 | Represent orchestrator state and behavior. |
| `__init__` | function | 216 | 248 | Initialize the instance with the supplied constructor arguments. |
| `close` | function | 250 | 255 | Close the requested operation. |
| `__enter__` | function | 257 | 262 | Enter the context manager and return the active resource. |
| `__exit__` | function | 264 | 269 | Exit the context manager and release managed resources. |
| `_transaction` | function | 271 | 276 | Implement transaction. |
| `register` | function | 278 | 321 | Register the requested operation. |
| `_idempotency_key` | function | 323 | 349 | Implement idempotency key. |
| `_event` | function | 351 | 359 | Implement event. |
| `_completed_result_is_intact` | function | 361 | 384 | Verify materialized outputs before reusing a succeeded job. |
| `_materialize_outputs` | function | 386 | 422 | Materialize outputs. |
| `_dependency_states` | function | 424 | 436 | Implement dependency states. |
| `run` | function | 438 | 472 | Run the requested operation. |
| `_set_state` | function | 474 | 491 | Set state. |
| `_run_stage` | function | 493 | 608 | Run stage. |
| `cancellation_requested` | function | 575 | 588 | Implement cancellation requested. |
| `recover_stale_jobs` | function | 610 | 653 | Reset only RUNNING jobs whose durable heartbeat is older than the bound. |
| `cancel` | function | 655 | 676 | Implement cancel. |
| `retry` | function | 678 | 705 | Implement retry. |
| `_update_pipeline_status` | function | 707 | 725 | Update pipeline status. |
| `status` | function | 727 | 759 | Implement status. |
| `create_default_pipeline` | function | 762 | 843 | Generate a concrete pipeline for the current project. |
