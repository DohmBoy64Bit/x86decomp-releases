---
title: x86decomp.compiler_lab
description: Source module reference for x86decomp.compiler_lab.
---

# `x86decomp.compiler_lab`

**Source path:** `src/x86decomp/compiler_lab.py`  
**SHA-256:** `03778a548bc2f9a43ec6019172513dfd3c851c87b4d62b090a7275c10c897f47`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_variant_arguments` | function | 16 | 29 | Implement variant arguments. |
| `run_compiler_lab` | function | 32 | 133 | Run compiler lab. |
