---
title: x86decomp.exe_diff
description: Source module reference for x86decomp.exe_diff.
---

# `x86decomp.exe_diff`

**Source path:** `src/x86decomp/exe_diff.py`  
**SHA-256:** `2419a2c829cf0c21b791cd2d60d79c47cc8a809e9b4081260de814558a613562`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `rva_to_file_offset` | function | 16 | 33 | Implement rva to file offset. |
| `extract_pe_bytes` | function | 36 | 54 | Extract pe bytes. |
| `_masked_copy` | function | 57 | 67 | Implement masked copy. |
| `_candidate_relocation_masks` | function | 70 | 87 | Implement candidate relocation masks. |
| `_pe_base_relocation_masks` | function | 90 | 101 | Implement pe base relocation masks. |
| `compare_pe_function_to_coff_symbol` | function | 104 | 212 | Compare pe function to coff symbol. |
