---
title: x86decomp_testkit.coverage_audit
description: Source module reference for x86decomp_testkit.coverage_audit.
---

# `x86decomp_testkit.coverage_audit`

**Source path:** `test-suite/src/x86decomp_testkit/coverage_audit.py`  
**SHA-256:** `1219f250d9a6e8ee9a0e50da6956cf53198b34a8583e66e315e7b6b5a37f9f86`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_coverage_file` | function | 14 | 28 | Implement coverage file. |
| `audit_public_symbol_execution` | function | 31 | 72 | Audit public symbol execution. |
