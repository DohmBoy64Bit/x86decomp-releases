---
title: x86decomp.governance.hypotheses
description: Source module reference for x86decomp.governance.hypotheses.
---

# `x86decomp.governance.hypotheses`

**Source path:** `src/x86decomp/governance/hypotheses.py`  
**SHA-256:** `36c989a9b4b2466826b7d23114f912624992f088bbfc579a8ba47e975707855a`  
**Documented symbols:** 14

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `Hypothesis` | class | 41 | 56 | Store the validated fields for hypothesis records. |
| `_row_to_hypothesis` | function | 59 | 76 | Implement row to hypothesis. |
| `HypothesisLedger` | class | 79 | 308 | Represent hypothesis ledger state and behavior. |
| `__init__` | function | 84 | 90 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 92 | 116 | Create the requested operation. |
| `get` | function | 118 | 127 | Return the requested operation. |
| `list` | function | 129 | 147 | List the requested operation. |
| `add_dependency` | function | 149 | 162 | Add dependency. |
| `_has_dependency_cycle` | function | 164 | 177 | Implement has dependency cycle. |
| `attach_evidence` | function | 179 | 211 | Implement attach evidence. |
| `_recalculate_confidence` | function | 213 | 232 | Implement recalculate confidence. |
| `transition` | function | 234 | 258 | Implement transition. |
| `acceptance_gate` | function | 260 | 295 | Implement acceptance gate. |
| `describe` | function | 297 | 308 | Implement describe. |
