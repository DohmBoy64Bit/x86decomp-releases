---
title: x86decomp_testkit.suites
description: Source module reference for x86decomp_testkit.suites.
---

# `x86decomp_testkit.suites`

**Source path:** `test-suite/src/x86decomp_testkit/suites.py`  
**SHA-256:** `31e14e5356019c8a439ddaad8bcd8bf30f666c90dd0df944eb337c0abd04fe91`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_missing` | function | 29 | 41 | Implement missing. |
| `_result` | function | 43 | 58 | Implement result. |
| `run_inventory_tests` | function | 61 | 106 | Run inventory tests. |
| `run_cli_surface_tests` | function | 109 | 134 | Run cli surface tests. |
| `_verify_manifest` | function | 137 | 166 | Verify manifest. |
| `_validate_schemas` | function | 169 | 187 | Validate schemas. |
| `_validate_java` | function | 190 | 207 | Validate java. |
| `_validate_skill` | function | 210 | 231 | Validate skill. |
| `run_structural_tests` | function | 234 | 302 | Run structural tests. |
| `run_harness_self_tests` | function | 306 | 350 | Run harness self tests. |
| `run_pytest_and_coverage` | function | 352 | 437 | Run pytest and coverage. |
| `run_packaging_tests` | function | 440 | 512 | Run packaging tests. |
