---
title: x86decomp.native.windows_tools
description: Source module reference for x86decomp.native.windows_tools.
---

# `x86decomp.native.windows_tools`

**Source path:** `src/x86decomp/native/windows_tools.py`  
**SHA-256:** `114878e22c461d1a391cf7523c22ab72cffb1488e115adb18f293b417c6b4d89`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `discover_ghidra_launcher` | function | 17 | 33 | Implement discover ghidra launcher. |
| `write_response_file` | function | 36 | 50 | Write response file. |
| `quote` | function | 42 | 48 | Implement quote. |
| `WindowsTools` | class | 53 | 92 | Represent windows tools state and behavior. |
| `__init__` | function | 58 | 63 | Initialize the instance with the supplied constructor arguments. |
| `doctor` | function | 65 | 92 | Implement doctor. |
