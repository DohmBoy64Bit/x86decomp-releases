---
title: x86decomp_testkit.adapters.installation
description: Source module reference for x86decomp_testkit.adapters.installation.
---

# `x86decomp_testkit.adapters.installation`

**Source path:** `test-suite/src/x86decomp_testkit/adapters/installation.py`  
**SHA-256:** `86bc67472d7286c46f34ec1f3179d9476ea9ea3d124a2766f614e61ef204dc22`  
**Documented symbols:** 10

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_yes` | function | 86 | 91 | Implement yes. |
| `_find_package_manager` | function | 94 | 102 | Find package manager. |
| `_run_checked` | function | 105 | 114 | Run checked. |
| `install_python_adapter` | function | 117 | 125 | Install python adapter. |
| `install_github_release` | function | 128 | 183 | Install github release. |
| `install_package_manager_adapter` | function | 186 | 212 | Install package manager adapter. |
| `_validate_custom_path` | function | 215 | 249 | Validate custom path. |
| `_automatic_install_available` | function | 252 | 262 | Implement automatic install available. |
| `install_adapter` | function | 265 | 277 | Install adapter. |
| `resolve_missing_adapters` | function | 280 | 386 | Detect first, then prompt only for missing adapters. |
