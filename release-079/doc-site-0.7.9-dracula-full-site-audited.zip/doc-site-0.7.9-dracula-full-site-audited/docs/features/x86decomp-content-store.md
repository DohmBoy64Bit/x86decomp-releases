---
title: x86decomp.content_store
description: Source module reference for x86decomp.content_store.
---

# `x86decomp.content_store`

**Source path:** `src/x86decomp/content_store.py`  
**SHA-256:** `2456a185850e867f9bb7d4b9c7c41e1bc7e42b30664b80b0aff143bcd1edc5de`  
**Documented symbols:** 18

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `StoredArtifact` | class | 23 | 54 | Store the validated fields for stored artifact records. |
| `to_dict` | function | 33 | 54 | Convert dict. |
| `display` | function | 38 | 48 | Implement display. |
| `ContentStore` | class | 57 | 318 | Immutable SHA-256 store rooted at ``root``. |
| `__init__` | function | 60 | 73 | Initialize the instance with the supplied constructor arguments. |
| `_paths` | function | 75 | 83 | Implement paths. |
| `_validate_digest` | function | 86 | 92 | Validate digest. |
| `_locked` | function | 95 | 115 | Cross-process advisory lock using an exclusive lock file. |
| `put_bytes` | function | 117 | 152 | Implement put bytes. |
| `put_file` | function | 154 | 173 | Implement put file. |
| `get` | function | 175 | 184 | Return the requested operation. |
| `read_bytes` | function | 186 | 195 | Read bytes. |
| `add_reference` | function | 197 | 215 | Add reference. |
| `remove_reference` | function | 217 | 227 | Remove reference. |
| `referenced_digests` | function | 229 | 238 | Implement referenced digests. |
| `verify` | function | 240 | 273 | Verify the requested operation. |
| `garbage_collect` | function | 275 | 304 | Implement garbage collect. |
| `export_index` | function | 306 | 318 | Export index. |
