---
title: x86decomp.native.staging
description: Source module reference for x86decomp.native.staging.
---

# `x86decomp.native.staging`

**Source path:** `src/x86decomp/native/staging.py`  
**SHA-256:** `4bdb9ce836e7ef930a466763d3802ba38075076c2a96644bb448cb50ee7c1409`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `StagingBridge` | class | 29 | 109 | Represent staging bridge state and behavior. |
| `__init__` | function | 34 | 39 | Initialize the instance with the supplied constructor arguments. |
| `scan` | function | 41 | 55 | Scan the requested operation. |
| `generate_context` | function | 57 | 78 | Generate context. |
| `resolve` | function | 80 | 93 | Resolve the requested operation. |
| `unresolved` | function | 95 | 100 | Implement unresolved. |
| `compile_check` | function | 102 | 109 | Compile check. |
