---
title: x86decomp.governance.store
description: Source module reference for x86decomp.governance.store.
---

# `x86decomp.governance.store`

**Source path:** `src/x86decomp/governance/store.py`  
**SHA-256:** `323d39ddec11ce65bcc69e84f1c1902e2e9fcb37fa08e5a59b9c2c0291a85e43`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `GovernanceStore` | class | 293 | 441 | Transactional governance extension store. |
| `__init__` | function | 300 | 306 | Initialize the instance with the supplied constructor arguments. |
| `initialize` | function | 308 | 328 | Initialize the requested operation. |
| `connect` | function | 330 | 341 | Implement connect. |
| `transaction` | function | 344 | 358 | Implement transaction. |
| `audit` | function | 360 | 397 | Audit the requested operation. |
| `verify_audit_chain` | function | 399 | 421 | Verify audit chain. |
| `check` | function | 423 | 441 | Check the requested operation. |
