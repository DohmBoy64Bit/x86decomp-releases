---
title: x86decomp.native.slots
description: Source module reference for x86decomp.native.slots.
---

# `x86decomp.native.slots`

**Source path:** `src/x86decomp/native/slots.py`  
**SHA-256:** `77c0261469bdb96f14416302214257203366e290447b2cdea28c0214c42b0d6e`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_int` | function | 16 | 28 | Implement int. |
| `inventory_from_project` | function | 31 | 55 | Implement inventory from project. |
| `FunctionSlots` | class | 58 | 201 | Represent function slots state and behavior. |
| `__init__` | function | 63 | 69 | Initialize the instance with the supplied constructor arguments. |
| `audit` | function | 71 | 145 | Audit the requested operation. |
| `audit_project` | function | 147 | 160 | Audit project. |
| `list` | function | 162 | 173 | List the requested operation. |
| `show` | function | 175 | 187 | Implement show. |
| `export_fixes` | function | 189 | 201 | Export fixes. |
