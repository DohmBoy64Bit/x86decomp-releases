---
title: x86decomp_testkit.self_tests.test_adapter_capabilities
description: Source module reference for x86decomp_testkit.self_tests.test_adapter_capabilities.
---

# `x86decomp_testkit.self_tests.test_adapter_capabilities`

**Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_adapter_capabilities.py`  
**SHA-256:** `800f2386254e83a620495ac5890a423ea405fa6337ed209753eb309df9e5dfc5`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_ModelsHandler` | class | 19 | 45 | Implement the _ModelsHandler class using its declared base class contract. |
| `do_GET` | function | 24 | 38 | Implement do g e t. |
| `log_message` | function | 40 | 45 | Implement log message. |
| `_config` | function | 48 | 53 | Implement config. |
| `test_lm_studio_http_satisfies_openai_capability_without_product_aliasing` | function | 56 | 87 | Verify lm studio http satisfies openai capability without product aliasing. |
| `test_non_loopback_http_endpoint_requires_network_opt_in` | function | 90 | 98 | Verify non loopback http endpoint requires network opt in. |
| `test_loopback_host_classifier_is_strict` | function | 101 | 108 | Verify loopback host classifier is strict. |
