---
title: x86decomp.governance.reviews
description: Source module reference for x86decomp.governance.reviews.
---

# `x86decomp.governance.reviews`

**Source path:** `src/x86decomp/governance/reviews.py`  
**SHA-256:** `567c40e0ecffcf33abb85c90fa2779dfa9182f25004e523561289388cfa445d6`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ReviewQueue` | class | 16 | 142 | Represent review queue state and behavior. |
| `__init__` | function | 21 | 27 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 29 | 44 | Create the requested operation. |
| `assign` | function | 46 | 62 | Implement assign. |
| `decide` | function | 64 | 91 | Implement decide. |
| `lock` | function | 93 | 104 | Implement lock. |
| `get` | function | 106 | 120 | Return the requested operation. |
| `list` | function | 122 | 142 | List the requested operation. |
