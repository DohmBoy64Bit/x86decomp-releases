---
title: x86decomp_testkit.adapters.catalog
description: Source module reference for x86decomp_testkit.adapters.catalog.
---

# `x86decomp_testkit.adapters.catalog`

**Source path:** `test-suite/src/x86decomp_testkit/adapters/catalog.py`  
**SHA-256:** `c158c7c36969fbca87a9fb55048dbf82bd9786e0bb65439a048339077d8bec32`  
**Documented symbols:** 1

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `adapter_catalog` | function | 10 | 398 | Implement adapter catalog. |
