---
title: x86decomp_testkit.config
description: Source module reference for x86decomp_testkit.config.
---

# `x86decomp_testkit.config`

**Source path:** `test-suite/src/x86decomp_testkit/config.py`  
**SHA-256:** `feb72c1d2de5203e55879f2801b1f6a0deb23f0ed5301281880b48b4c9382ab4`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `TestConfig` | class | 18 | 101 | Store the validated fields for test config records. |
| `to_dict` | function | 39 | 61 | Convert dict. |
| `from_dict` | function | 64 | 101 | Build an object from dict. |
| `resolve` | function | 71 | 79 | Resolve the requested operation. |
| `load_config` | function | 104 | 112 | Load config. |
| `save_config` | function | 115 | 121 | Save config. |
