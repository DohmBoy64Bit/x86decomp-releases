---
title: x86decomp.test_bundle
description: Source module reference for x86decomp.test_bundle.
---

# `x86decomp.test_bundle`

**Source path:** `src/x86decomp/test_bundle.py`  
**SHA-256:** `e1dcf5b807da9db692f5d2b272a89f0de4c93db117c8b8e2b3a433757131d4d9`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `BundleLimits` | class | 49 | 57 | Store the validated fields for bundle limits records. |
| `_safe_member_path` | function | 60 | 74 | Implement safe member path. |
| `_is_symlink` | function | 77 | 83 | Implement is symlink. |
| `_validate_archive_infos` | function | 86 | 116 | Validate archive infos. |
| `_extract_safely` | function | 119 | 151 | Extract safely. |
| `_manifest_artifacts` | function | 154 | 208 | Implement manifest artifacts. |
| `_single_role` | function | 211 | 219 | Implement single role. |
| `create_test_bundle` | function | 222 | 306 | Create a deterministic authorized static test bundle. |
| `inspect_test_bundle` | function | 309 | 434 | Verify and statically inspect a test bundle without executing its contents. |
