---
title: x86decomp.native.store
description: Source module reference for x86decomp.native.store.
---

# `x86decomp.native.store`

**Source path:** `src/x86decomp/native/store.py`  
**SHA-256:** `2480b542c92bf87d153d5d6c4535c2d645e17c31ea9d5597d2e9f72e1b8782b0`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `NativeStore` | class | 77 | 142 | Native-PE reconstruction schema layered on current reconstruction data. |
| `initialize` | function | 80 | 99 | Initialize the requested operation. |
| `check` | function | 101 | 129 | Check the requested operation. |
| `decode` | function | 132 | 142 | Decode the requested operation. |
