---
title: x86decomp_testkit.self_tests.__init__
description: Source module reference for x86decomp_testkit.self_tests.__init__.
---

# `x86decomp_testkit.self_tests.__init__`

**Source path:** `test-suite/src/x86decomp_testkit/self_tests/__init__.py`  
**SHA-256:** `215a0bbdde51d68f044c3f65562c90b2716ed2e0c813d506fe01bbe7fa87b5d6`  
**Documented symbols:** 0

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| _No class or function symbols declared._ |  |  |  |  |
