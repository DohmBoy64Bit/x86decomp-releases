---
title: x86decomp.__init__
description: Source module reference for x86decomp.__init__.
---

# `x86decomp.__init__`

**Source path:** `src/x86decomp/__init__.py`  
**SHA-256:** `af29a046c66c297208ea04806323574e07ce82b6c7d6dbda5d2d2b4c26f42395`  
**Documented symbols:** 0

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| _No class or function symbols declared._ |  |  |  |  |
