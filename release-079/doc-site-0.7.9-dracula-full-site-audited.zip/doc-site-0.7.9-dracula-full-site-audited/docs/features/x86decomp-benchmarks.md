---
title: x86decomp.benchmarks
description: Source module reference for x86decomp.benchmarks.
---

# `x86decomp.benchmarks`

**Source path:** `src/x86decomp/benchmarks.py`  
**SHA-256:** `712497d2ac96ede3685919e9c23b0a118649815c9535b8302216d78d45f9aaf9`  
**Documented symbols:** 3

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `classification_metrics` | function | 17 | 35 | Implement classification metrics. |
| `_resolve` | function | 38 | 45 | Resolve the requested operation. |
| `run_benchmark_corpus` | function | 48 | 160 | Run benchmark corpus. |
