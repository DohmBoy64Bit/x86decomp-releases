---
title: x86decomp.native.matching
description: Source module reference for x86decomp.native.matching.
---

# `x86decomp.native.matching`

**Source path:** `src/x86decomp/native/matching.py`  
**SHA-256:** `20dfc1939425700dd4e6b4a99b783f43bfeaf5b3d7ff57b57827036467e42a1f`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `rva_to_file_offset` | function | 20 | 31 | Implement rva to file offset. |
| `extract_candidate` | function | 34 | 43 | Extract candidate. |
| `compare_function_bytes` | function | 46 | 91 | Compare function bytes. |
| `FunctionMatching` | class | 94 | 194 | Represent function matching state and behavior. |
| `__init__` | function | 99 | 104 | Initialize the instance with the supplied constructor arguments. |
| `batch` | function | 106 | 173 | Implement batch. |
| `report` | function | 175 | 187 | Report the requested operation. |
| `mismatches` | function | 189 | 194 | Implement mismatches. |
