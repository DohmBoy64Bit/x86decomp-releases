---
title: x86decomp.image_match
description: Source module reference for x86decomp.image_match.
---

# `x86decomp.image_match`

**Source path:** `src/x86decomp/image_match.py`  
**SHA-256:** `f579bdfb33dbe869ca4d49c1d98f8d658bc93d479a7b764227c3ff75be5a7bff`  
**Documented symbols:** 10

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ByteRange` | class | 21 | 35 | Store the validated fields for byte range records. |
| `to_dict` | function | 30 | 35 | Convert dict. |
| `_pe_offsets` | function | 38 | 61 | Implement pe offsets. |
| `derive_layout_profile` | function | 64 | 104 | Derive layout profile. |
| `_mask_ranges` | function | 107 | 117 | Implement mask ranges. |
| `_rva_to_file_offset` | function | 120 | 131 | Implement rva to file offset. |
| `_profile_ranges` | function | 134 | 170 | Implement profile ranges. |
| `_apply_rebase` | function | 173 | 202 | Apply rebase. |
| `_mismatches` | function | 205 | 219 | Implement mismatches. |
| `compare_whole_images` | function | 222 | 324 | Compare whole images. |
