---
title: x86decomp_testkit.orchestrator
description: Source module reference for x86decomp_testkit.orchestrator.
---

# `x86decomp_testkit.orchestrator`

**Source path:** `test-suite/src/x86decomp_testkit/orchestrator.py`  
**SHA-256:** `fb4646c04d7541dd3df3f02165fffaa1e7a208c456c9bfdc5be9a6580c347b9d`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `package_root` | function | 29 | 34 | Implement package root. |
| `suite_root` | function | 37 | 44 | Implement suite root. |
| `feature_catalog_path` | function | 47 | 52 | Implement feature catalog path. |
| `run_all` | function | 55 | 124 | Run all. |
