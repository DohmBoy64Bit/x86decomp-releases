---
title: x86decomp.worker
description: Source module reference for x86decomp.worker.
---

# `x86decomp.worker`

**Source path:** `src/x86decomp/worker.py`  
**SHA-256:** `41e2607de1e96823ecd67a0728ffb76d7a18acd141a1eebd296e0298946eb20f`  
**Documented symbols:** 13

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `WorkerLimits` | class | 27 | 45 | Store the validated fields for worker limits records. |
| `validate` | function | 38 | 45 | Validate the requested operation. |
| `WorkerRequest` | class | 49 | 61 | Store the validated fields for worker request records. |
| `WorkerResult` | class | 65 | 106 | Store the validated fields for worker result records. |
| `to_dict` | function | 85 | 106 | Convert dict. |
| `discover_worker_capabilities` | function | 109 | 124 | Implement discover worker capabilities. |
| `_bounded_environment` | function | 127 | 163 | Implement bounded environment. |
| `_preexec` | function | 166 | 193 | Return the legacy resource-limit callback for API compatibility. |
| `apply` | function | 177 | 191 | Apply the requested operation. |
| `_confined_paths` | function | 196 | 213 | Implement confined paths. |
| `_container_command` | function | 216 | 242 | Implement container command. |
| `execute_worker_request` | function | 245 | 400 | Execute worker request. |
| `resource_wrapped_command` | function | 286 | 312 | Implement resource wrapped command. |
