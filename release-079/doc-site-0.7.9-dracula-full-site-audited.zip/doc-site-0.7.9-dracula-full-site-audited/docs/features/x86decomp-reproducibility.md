---
title: x86decomp.reproducibility
description: Source module reference for x86decomp.reproducibility.
---

# `x86decomp.reproducibility`

**Source path:** `src/x86decomp/reproducibility.py`  
**SHA-256:** `be5b3fc7930e74d7d4a6ba3bb765d3f93a90623cfd08972fd48834f1c1f126d4`  
**Documented symbols:** 3

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_version` | function | 26 | 53 | Implement version. |
| `build_reproduction_manifest` | function | 56 | 125 | Build reproduction manifest. |
| `verify_reproduction_manifest` | function | 128 | 171 | Verify reproduction manifest. |
