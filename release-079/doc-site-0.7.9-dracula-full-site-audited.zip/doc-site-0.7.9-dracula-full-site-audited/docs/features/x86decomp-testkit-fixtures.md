---
title: x86decomp_testkit.fixtures
description: Source module reference for x86decomp_testkit.fixtures.
---

# `x86decomp_testkit.fixtures`

**Source path:** `test-suite/src/x86decomp_testkit/fixtures.py`  
**SHA-256:** `83d1a1a26c9e06f79686b952427f7d17e284c50c51691489dd923bd59494719f`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `write_json` | function | 13 | 20 | Write json. |
| `build_minimal_pe32` | function | 23 | 57 | Build minimal pe32. |
| `build_minimal_pe64` | function | 60 | 95 | Build minimal pe64. |
| `create_common_fixtures` | function | 98 | 148 | Create common fixtures. |
