---
title: x86decomp.native.closed_loop
description: Source module reference for x86decomp.native.closed_loop.
---

# `x86decomp.native.closed_loop`

**Source path:** `src/x86decomp/native/closed_loop.py`  
**SHA-256:** `e531c7ee8aac0f3fb3e28eceb5bded1dfcfb36c3fb97b41fe52927f8a0e1fd90`  
**Documented symbols:** 5

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ClosedLoop` | class | 18 | 69 | Represent closed loop state and behavior. |
| `__init__` | function | 23 | 28 | Initialize the instance with the supplied constructor arguments. |
| `run` | function | 30 | 52 | Run the requested operation. |
| `show` | function | 54 | 62 | Implement show. |
| `list` | function | 64 | 69 | List the requested operation. |
