---
title: x86decomp.governance.cli
description: Source module reference for x86decomp.governance.cli.
---

# `x86decomp.governance.cli`

**Source path:** `src/x86decomp/governance/cli.py`  
**SHA-256:** `991f9c7fc1edace4169b2bd893c2fdfcf42713bc3f6fdb929d07c09d009865a8`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_json_arg` | function | 29 | 39 | Implement json arg. |
| `_emit` | function | 42 | 49 | Emit the requested operation. |
| `_store` | function | 52 | 57 | Store the requested operation. |
| `build_parser` | function | 60 | 155 | Build parser. |
| `dispatch` | function | 158 | 252 | Dispatch the requested operation. |
| `main` | function | 255 | 267 | Run the command-line entry point. |
