---
title: x86decomp.integration
description: Source module reference for x86decomp.integration.
---

# `x86decomp.integration`

**Source path:** `src/x86decomp/integration.py`  
**SHA-256:** `e4b2cce07efed7c9e7afa46162a9c57e7e34e5cce32cc7ddc16d50c6a6c7f4e1`  
**Documented symbols:** 10

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_require_string_list` | function | 24 | 33 | Implement require string list. |
| `_resolve_existing` | function | 36 | 46 | Resolve existing. |
| `_parse_stdin` | function | 49 | 72 | Parse stdin. |
| `_copy_fixtures` | function | 75 | 107 | Copy fixtures. |
| `_substitute_command` | function | 110 | 125 | Implement substitute command. |
| `_bounded_output` | function | 128 | 140 | Implement bounded output. |
| `_run_side` | function | 143 | 222 | Run side. |
| `_observe_file` | function | 225 | 280 | Implement observe file. |
| `_compare_stream` | function | 283 | 306 | Compare stream. |
| `run_integration_scenarios` | function | 309 | 513 | Execute and compare all declared integration scenarios. |
