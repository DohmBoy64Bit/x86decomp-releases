---
title: x86decomp.governance.plugins
description: Source module reference for x86decomp.governance.plugins.
---

# `x86decomp.governance.plugins`

**Source path:** `src/x86decomp/governance/plugins.py`  
**SHA-256:** `881bf42446a199dca5cde5dbcef3c2b282afe63dcdae7cf2d457a8df244789e7`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `PluginRegistry` | class | 20 | 150 | Represent plugin registry state and behavior. |
| `__init__` | function | 25 | 31 | Initialize the instance with the supplied constructor arguments. |
| `validate_manifest` | function | 34 | 49 | Validate manifest. |
| `install` | function | 51 | 70 | Install the requested operation. |
| `get` | function | 72 | 84 | Return the requested operation. |
| `list` | function | 86 | 93 | List the requested operation. |
| `doctor` | function | 95 | 107 | Implement doctor. |
| `invoke` | function | 109 | 150 | Implement invoke. |
