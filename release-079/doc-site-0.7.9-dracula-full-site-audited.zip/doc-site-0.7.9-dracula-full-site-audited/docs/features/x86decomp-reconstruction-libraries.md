---
title: x86decomp.reconstruction.libraries
description: Source module reference for x86decomp.reconstruction.libraries.
---

# `x86decomp.reconstruction.libraries`

**Source path:** `src/x86decomp/reconstruction/libraries.py`  
**SHA-256:** `baa6df511aa0534152054763406921674ed715ccbeced60a92dd7528c07a6f28`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `LibraryRecognition` | class | 11 | 57 | Represent library recognition state and behavior. |
| `__init__` | function | 16 | 21 | Initialize the instance with the supplied constructor arguments. |
| `identify` | function | 22 | 32 | Implement identify. |
| `get` | function | 33 | 40 | Return the requested operation. |
| `candidates` | function | 41 | 47 | Implement candidates. |
| `disposition` | function | 48 | 57 | Implement disposition. |
