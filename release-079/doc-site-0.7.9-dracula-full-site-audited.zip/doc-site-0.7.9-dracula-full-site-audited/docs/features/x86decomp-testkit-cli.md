---
title: x86decomp_testkit.cli
description: Source module reference for x86decomp_testkit.cli.
---

# `x86decomp_testkit.cli`

**Source path:** `test-suite/src/x86decomp_testkit/cli.py`  
**SHA-256:** `45a9a5df80b74ade90b7a3139e26a59540e7cfd55257da3187a0d393e9ca6c3b`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_path` | function | 20 | 25 | Implement path. |
| `_base_parser` | function | 28 | 67 | Implement base parser. |
| `_load` | function | 70 | 77 | Load the requested operation. |
| `main` | function | 80 | 148 | Run the command-line entry point. |
