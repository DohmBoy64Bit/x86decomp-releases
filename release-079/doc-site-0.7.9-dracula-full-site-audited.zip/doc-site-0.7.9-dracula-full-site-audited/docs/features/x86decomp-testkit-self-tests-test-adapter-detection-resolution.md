---
title: x86decomp_testkit.self_tests.test_adapter_detection_resolution
description: Source module reference for x86decomp_testkit.self_tests.test_adapter_detection_resolution.
---

# `x86decomp_testkit.self_tests.test_adapter_detection_resolution`

**Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_adapter_detection_resolution.py`  
**SHA-256:** `eddbb2781cfc0412c060669b7ddc734607791987fa1c243926308727e6a7f548`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_config` | function | 18 | 25 | Implement config. |
| `test_installed_adapter_never_prompts` | function | 28 | 47 | Verify installed adapter never prompts. |
| `prompt` | function | 37 | 43 | Implement prompt. |
| `test_missing_adapter_prompts_custom_path_then_accepts` | function | 50 | 75 | Verify missing adapter prompts custom path then accepts. |
| `prompt` | function | 63 | 69 | Implement prompt. |
| `test_missing_noninteractive_is_explicit_unresolved` | function | 78 | 87 | Verify missing noninteractive is explicit unresolved. |
| `test_environment_and_configured_root_detection` | function | 90 | 109 | Verify environment and configured root detection. |
| `test_path_detection_preserves_symlink_argv0` | function | 111 | 125 | Verify path detection preserves symlink argv0. |
| `test_missing_python_adapter_accepts_custom_interpreter` | function | 127 | 138 | Verify missing python adapter accepts custom interpreter. |
