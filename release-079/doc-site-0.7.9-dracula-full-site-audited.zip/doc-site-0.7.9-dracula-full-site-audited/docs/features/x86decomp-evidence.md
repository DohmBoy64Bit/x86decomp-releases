---
title: x86decomp.evidence
description: Source module reference for x86decomp.evidence.
---

# `x86decomp.evidence`

**Source path:** `src/x86decomp/evidence.py`  
**SHA-256:** `497d40bffd30d57f710bd957aa8f1048d5fac88763633dc984e0762f7e29ab8d`  
**Documented symbols:** 13

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_validate_id` | function | 17 | 25 | Validate id. |
| `EvidenceStore` | class | 28 | 296 | Filesystem-backed evidence and claims with deterministic validation rules. |
| `__init__` | function | 31 | 42 | Initialize the instance with the supplied constructor arguments. |
| `add_evidence` | function | 44 | 91 | Add evidence. |
| `get_evidence` | function | 93 | 116 | Return evidence. |
| `create_claim` | function | 118 | 151 | Create claim. |
| `get_claim` | function | 153 | 177 | Return claim. |
| `save_claim` | function | 179 | 185 | Save claim. |
| `attach_evidence` | function | 187 | 199 | Implement attach evidence. |
| `add_contradiction` | function | 201 | 212 | Add contradiction. |
| `audit_evidence_integrity` | function | 214 | 238 | Audit evidence integrity. |
| `verify_claim` | function | 240 | 284 | Apply the strict verification gate and persist the resulting state. |
| `require_verified` | function | 286 | 296 | Implement require verified. |
