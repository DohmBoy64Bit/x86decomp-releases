---
title: x86decomp.reconstruction.cli
description: Source module reference for x86decomp.reconstruction.cli.
---

# `x86decomp.reconstruction.cli`

**Source path:** `src/x86decomp/reconstruction/cli.py`  
**SHA-256:** `5b0fb0226bc1f2d18382eda0787bf868c1c05d979fc0e20ca378645c637bc18c`  
**Documented symbols:** 6

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_json` | function | 55 | 62 | Implement json. |
| `_emit` | function | 64 | 70 | Emit the requested operation. |
| `_store` | function | 72 | 77 | Store the requested operation. |
| `build_parser` | function | 79 | 293 | Build parser. |
| `dispatch` | function | 295 | 474 | Dispatch the requested operation. |
| `main` | function | 476 | 484 | Run the command-line entry point. |
