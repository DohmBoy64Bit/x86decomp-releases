---
title: x86decomp.reconstruction.abi_contracts
description: Source module reference for x86decomp.reconstruction.abi_contracts.
---

# `x86decomp.reconstruction.abi_contracts`

**Source path:** `src/x86decomp/reconstruction/abi_contracts.py`  
**SHA-256:** `11b0bf5dc8b890b84e8bb212f6fe2b43fad602b72e8b84af0ad525d648ee33ce`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `ABIContracts` | class | 14 | 85 | Represent a b i contracts state and behavior. |
| `__init__` | function | 19 | 24 | Initialize the instance with the supplied constructor arguments. |
| `recover` | function | 25 | 43 | Recover the requested operation. |
| `get` | function | 44 | 51 | Return the requested operation. |
| `verify` | function | 52 | 61 | Verify the requested operation. |
| `compare` | function | 62 | 68 | Compare the requested operation. |
| `export` | function | 69 | 74 | Export the requested operation. |
| `shim` | function | 75 | 85 | Implement shim. |
