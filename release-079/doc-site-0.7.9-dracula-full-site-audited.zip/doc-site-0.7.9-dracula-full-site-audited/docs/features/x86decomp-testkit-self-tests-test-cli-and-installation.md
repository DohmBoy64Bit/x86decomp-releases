---
title: x86decomp_testkit.self_tests.test_cli_and_installation
description: Source module reference for x86decomp_testkit.self_tests.test_cli_and_installation.
---

# `x86decomp_testkit.self_tests.test_cli_and_installation`

**Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_cli_and_installation.py`  
**SHA-256:** `7c5a42f6e99d35232a729cf2e1b8de6e9636c16871bca670714a98efc233b7b0`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `test_cli_init_config_catalog_and_missing_config` | function | 19 | 29 | Verify cli init config catalog and missing config. |
| `test_install_python_command_and_failure` | function | 32 | 62 | Verify install python command and failure. |
| `run_ok` | function | 41 | 47 | Run ok. |
| `run_bad` | function | 53 | 58 | Run bad. |
