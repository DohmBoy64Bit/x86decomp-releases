---
title: x86decomp.work_queue
description: Source module reference for x86decomp.work_queue.
---

# `x86decomp.work_queue`

**Source path:** `src/x86decomp/work_queue.py`  
**SHA-256:** `b322c6b3231b62a5135f30c31670b0aa69afe0fed1fd8872542fd587aa7df50e`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `WorkQueue` | class | 35 | 157 | Represent work queue state and behavior. |
| `__init__` | function | 40 | 49 | Initialize the instance with the supplied constructor arguments. |
| `close` | function | 51 | 56 | Close the requested operation. |
| `create` | function | 58 | 83 | Create the requested operation. |
| `get` | function | 85 | 97 | Return the requested operation. |
| `claim` | function | 99 | 110 | Implement claim. |
| `propose` | function | 112 | 126 | Implement propose. |
| `record_validator` | function | 128 | 144 | Implement record validator. |
| `next` | function | 146 | 157 | Implement next. |
