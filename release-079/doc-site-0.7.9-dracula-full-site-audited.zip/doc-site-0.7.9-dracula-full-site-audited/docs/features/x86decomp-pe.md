---
title: x86decomp.pe
description: Source module reference for x86decomp.pe.
---

# `x86decomp.pe`

**Source path:** `src/x86decomp/pe.py`  
**SHA-256:** `427b2646a0b5c672efc41c8ecb3654aa3019c25626f70b6cc56b8fda84fbec23`  
**Documented symbols:** 19

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `TLS64Info` | class | 43 | 69 | Store the validated fields for t l s64 info records. |
| `to_dict` | function | 56 | 69 | Convert dict. |
| `RuntimeFunction` | class | 73 | 91 | Store the validated fields for runtime function records. |
| `to_dict` | function | 82 | 91 | Convert dict. |
| `PE64Image` | class | 95 | 176 | Store the validated fields for p e64 image records. |
| `entry_va` | function | 128 | 133 | Implement entry va. |
| `to_dict` | function | 135 | 176 | Convert dict. |
| `_parse_imports64` | function | 179 | 213 | Parse imports64. |
| `_parse_tls64` | function | 216 | 238 | Parse tls64. |
| `_parse_delay_imports64` | function | 241 | 288 | Parse delay imports64. |
| `to_rva` | function | 257 | 268 | Convert rva. |
| `_parse_load_config64` | function | 291 | 325 | Parse load config64. |
| `u16` | function | 302 | 307 | Implement u16. |
| `u32` | function | 308 | 313 | Implement u32. |
| `u64` | function | 314 | 319 | Implement u64. |
| `_parse_runtime_functions` | function | 328 | 339 | Parse runtime functions. |
| `parse_pe64` | function | 342 | 418 | Parse pe64. |
| `inspect_pe_kind` | function | 421 | 434 | Inspect pe kind. |
| `parse_pe` | function | 437 | 447 | Parse pe. |
