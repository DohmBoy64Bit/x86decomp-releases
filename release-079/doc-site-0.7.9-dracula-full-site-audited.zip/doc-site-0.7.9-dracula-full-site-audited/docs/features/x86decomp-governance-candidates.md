---
title: x86decomp.governance.candidates
description: Source module reference for x86decomp.governance.candidates.
---

# `x86decomp.governance.candidates`

**Source path:** `src/x86decomp/governance/candidates.py`  
**SHA-256:** `bf96a7b189e51bc3e172fdecb57933e2b12e69c17b8e0b18b05e88fa45855cf0`  
**Documented symbols:** 10

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `CandidateStore` | class | 18 | 202 | Represent candidate store state and behavior. |
| `__init__` | function | 23 | 30 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 32 | 51 | Create the requested operation. |
| `_clone_files` | function | 53 | 64 | Implement clone files. |
| `add_file` | function | 66 | 99 | Add file. |
| `record_evaluation` | function | 101 | 118 | Implement record evaluation. |
| `compare` | function | 120 | 144 | Compare the requested operation. |
| `transition` | function | 146 | 172 | Implement transition. |
| `get` | function | 174 | 191 | Return the requested operation. |
| `list` | function | 193 | 202 | List the requested operation. |
