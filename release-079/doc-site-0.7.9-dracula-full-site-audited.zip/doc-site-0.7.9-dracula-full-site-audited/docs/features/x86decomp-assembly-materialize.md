---
title: x86decomp.assembly.materialize
description: Source module reference for x86decomp.assembly.materialize.
---

# `x86decomp.assembly.materialize`

**Source path:** `src/x86decomp/assembly/materialize.py`  
**SHA-256:** `e2e64acdaa1fc6cf47b0a61ec9ea5f7520518e24d08fc232258eafaf03697ff4`  
**Documented symbols:** 16

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `AssemblerError` | class | 25 | 34 | Assembler failure with source line numbers retained for focused fallback. |
| `__init__` | function | 28 | 34 | Initialize the instance with the supplied constructor arguments. |
| `InstructionCandidate` | class | 38 | 58 | Store the validated fields for instruction candidate records. |
| `end` | function | 53 | 58 | Implement end. |
| `_capstone` | function | 61 | 71 | Implement capstone. |
| `_safe_symbol` | function | 74 | 79 | Implement safe symbol. |
| `_preferred_addresses` | function | 82 | 100 | Implement preferred addresses. |
| `_replace_address_token` | function | 103 | 116 | Implement replace address token. |
| `_instruction_candidates` | function | 119 | 215 | Implement instruction candidates. |
| `_render_source_with_line_map` | function | 218 | 253 | Render source with line map. |
| `_render_source` | function | 256 | 275 | Render source. |
| `discover_assembler` | function | 278 | 302 | Implement discover assembler. |
| `assemble_coff` | function | 305 | 358 | Implement assemble coff. |
| `_unit_for_offset` | function | 361 | 366 | Implement unit for offset. |
| `verify_existing_source` | function | 369 | 424 | Assemble an existing source file and verify its resolved bytes exactly. |
| `materialize_function` | function | 427 | 659 | Materialize readable assembly and prove exact bytes, falling back per instruction. |
