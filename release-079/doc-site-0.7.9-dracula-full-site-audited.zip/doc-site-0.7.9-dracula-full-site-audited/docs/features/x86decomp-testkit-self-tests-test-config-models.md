---
title: x86decomp_testkit.self_tests.test_config_models
description: Source module reference for x86decomp_testkit.self_tests.test_config_models.
---

# `x86decomp_testkit.self_tests.test_config_models`

**Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_config_models.py`  
**SHA-256:** `360885038379a556c0545f1420251c77aaa2d168cc199b94f8075f5ac2311709`  
**Documented symbols:** 3

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `test_config_roundtrip_and_relative_resolution` | function | 14 | 41 | Verify config roundtrip and relative resolution. |
| `test_status_counts_and_strict_exit_code` | function | 44 | 71 | Verify status counts and strict exit code. |
| `result` | function | 49 | 54 | Implement result. |
