---
title: x86decomp.pe32
description: Source module reference for x86decomp.pe32.
---

# `x86decomp.pe32`

**Source path:** `src/x86decomp/pe32.py`  
**SHA-256:** `a643fe999a42f726b62f22179e3172b1541d9c146d5704510521b7ffa23ed44c`  
**Documented symbols:** 50

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `DataDirectory` | class | 42 | 56 | Store the validated fields for data directory records. |
| `to_dict` | function | 51 | 56 | Convert dict. |
| `Section` | class | 60 | 96 | Store the validated fields for section records. |
| `mapped_size` | function | 74 | 79 | Implement mapped size. |
| `to_dict` | function | 81 | 96 | Convert dict. |
| `ImportSymbol` | class | 100 | 122 | Store the validated fields for import symbol records. |
| `to_dict` | function | 111 | 122 | Convert dict. |
| `ImportLibrary` | class | 126 | 139 | Store the validated fields for import library records. |
| `to_dict` | function | 134 | 139 | Convert dict. |
| `ExportSymbol` | class | 143 | 164 | Store the validated fields for export symbol records. |
| `to_dict` | function | 153 | 164 | Convert dict. |
| `BaseRelocation` | class | 168 | 181 | Store the validated fields for base relocation records. |
| `to_dict` | function | 176 | 181 | Convert dict. |
| `DebugRecord` | class | 185 | 213 | Store the validated fields for debug record records. |
| `to_dict` | function | 199 | 213 | Convert dict. |
| `TLSInfo` | class | 217 | 243 | Store the validated fields for t l s info records. |
| `to_dict` | function | 230 | 243 | Convert dict. |
| `ResourceLeaf` | class | 249 | 272 | Store the validated fields for resource leaf records. |
| `to_dict` | function | 260 | 272 | Convert dict. |
| `DelayImportLibrary` | class | 276 | 296 | Store the validated fields for delay import library records. |
| `to_dict` | function | 286 | 296 | Convert dict. |
| `LoadConfigInfo` | class | 300 | 340 | Store the validated fields for load config info records. |
| `to_dict` | function | 320 | 340 | Convert dict. |
| `PE32Image` | class | 344 | 423 | Store the validated fields for p e32 image records. |
| `entry_va` | function | 376 | 381 | Implement entry va. |
| `to_dict` | function | 383 | 423 | Convert dict. |
| `_Reader` | class | 426 | 488 | Represent reader state and behavior. |
| `__init__` | function | 431 | 436 | Initialize the instance with the supplied constructor arguments. |
| `require` | function | 438 | 446 | Implement require. |
| `unpack` | function | 448 | 455 | Implement unpack. |
| `u16` | function | 457 | 462 | Implement u16. |
| `u32` | function | 464 | 469 | Implement u32. |
| `u64` | function | 471 | 476 | Implement u64. |
| `c_string` | function | 478 | 488 | Implement c string. |
| `_rva_to_offset` | function | 491 | 513 | Implement rva to offset. |
| `_directory` | function | 516 | 524 | Implement directory. |
| `_parse_imports` | function | 527 | 600 | Parse imports. |
| `_parse_exports` | function | 603 | 670 | Parse exports. |
| `_parse_relocations` | function | 673 | 707 | Parse relocations. |
| `_parse_debug_records` | function | 710 | 772 | Parse debug records. |
| `_parse_tls` | function | 775 | 821 | Parse tls. |
| `_parse_resources` | function | 825 | 899 | Parse resources. |
| `read_name` | function | 844 | 855 | Read name. |
| `walk` | function | 857 | 896 | Walk the requested operation. |
| `_parse_delay_imports` | function | 902 | 966 | Parse delay imports. |
| `to_rva` | function | 926 | 937 | Convert rva. |
| `_parse_load_config` | function | 969 | 1017 | Parse load config. |
| `u16_at` | function | 988 | 993 | Implement u16 at. |
| `u32_at` | function | 995 | 1000 | Implement u32 at. |
| `parse_pe32` | function | 1019 | 1154 | Parse pe32. |
