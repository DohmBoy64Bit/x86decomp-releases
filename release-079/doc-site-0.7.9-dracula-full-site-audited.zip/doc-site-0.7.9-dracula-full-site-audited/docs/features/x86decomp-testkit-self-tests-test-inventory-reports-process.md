---
title: x86decomp_testkit.self_tests.test_inventory_reports_process
description: Source module reference for x86decomp_testkit.self_tests.test_inventory_reports_process.
---

# `x86decomp_testkit.self_tests.test_inventory_reports_process`

**Source path:** `test-suite/src/x86decomp_testkit/self_tests/test_inventory_reports_process.py`  
**SHA-256:** `2bc8eb32228962016085f7869d3c3c8669d728c18e26b2342471cbb3a4e9fff6`  
**Documented symbols:** 5

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_mini_toolkit` | function | 19 | 35 | Implement mini toolkit. |
| `test_inventory_catalog_and_public_coverage` | function | 38 | 60 | Verify inventory catalog and public coverage. |
| `test_junit_process_logging_and_reports` | function | 63 | 94 | Verify junit process logging and reports. |
| `test_suite_schemas_and_catalog_are_valid` | function | 96 | 115 | Verify suite schemas and catalog are valid. |
| `test_recursive_inventory_includes_capability_packages_and_nested_schemas` | function | 118 | 135 | Verify recursive inventory includes capability packages and nested schemas. |
