---
title: x86decomp.cli
description: Source module reference for x86decomp.cli.
---

# `x86decomp.cli`

**Source path:** `src/x86decomp/cli.py`  
**SHA-256:** `e7f15faf5e1116d4a9d17289531bca368d7a2eb8c3aab985a0c4fb4f273da25a`  
**Documented symbols:** 8

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_print` | function | 82 | 87 | Print the requested operation. |
| `_path` | function | 90 | 95 | Implement path. |
| `_int` | function | 98 | 103 | Implement int. |
| `_json_object` | function | 106 | 114 | Implement json object. |
| `_build_parser` | function | 117 | 260 | Build parser. |
| `_mcp_client` | function | 263 | 275 | Implement mcp client. |
| `_run` | function | 278 | 452 | Run the requested operation. |
| `main` | function | 455 | 469 | Run the command-line entry point. |
