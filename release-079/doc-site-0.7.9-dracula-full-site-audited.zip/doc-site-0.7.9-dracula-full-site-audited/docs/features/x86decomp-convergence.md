---
title: x86decomp.convergence
description: Source module reference for x86decomp.convergence.
---

# `x86decomp.convergence`

**Source path:** `src/x86decomp/convergence.py`  
**SHA-256:** `8890983fa2c813778a03c5de33fc9af76556ec91e03ee82417436e9e000bdea2`  
**Documented symbols:** 3

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_section_kind` | function | 20 | 36 | Implement section kind. |
| `analyze_image_convergence` | function | 39 | 170 | Analyze image convergence. |
| `append_convergence_history` | function | 173 | 185 | Implement append convergence history. |
