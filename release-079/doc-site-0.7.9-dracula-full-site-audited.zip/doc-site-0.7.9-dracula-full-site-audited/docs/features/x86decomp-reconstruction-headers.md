---
title: x86decomp.reconstruction.headers
description: Source module reference for x86decomp.reconstruction.headers.
---

# `x86decomp.reconstruction.headers`

**Source path:** `src/x86decomp/reconstruction/headers.py`  
**SHA-256:** `7ed70ada722a41b5e3bc9903f72eadd8287361e64cd0d10250702e330c31137e`  
**Documented symbols:** 10

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `HeaderManager` | class | 13 | 121 | Represent header manager state and behavior. |
| `__init__` | function | 18 | 23 | Initialize the instance with the supplied constructor arguments. |
| `create` | function | 24 | 36 | Create the requested operation. |
| `declare` | function | 37 | 50 | Implement declare. |
| `include` | function | 51 | 61 | Implement include. |
| `cycles` | function | 62 | 87 | Implement cycles. |
| `visit` | function | 75 | 85 | Implement visit. |
| `show` | function | 88 | 98 | Implement show. |
| `synthesize` | function | 99 | 113 | Implement synthesize. |
| `validate` | function | 114 | 121 | Validate the requested operation. |
