---
title: x86decomp.target_pack
description: Source module reference for x86decomp.target_pack.
---

# `x86decomp.target_pack`

**Source path:** `src/x86decomp/target_pack.py`  
**SHA-256:** `01eaaa164ac4f6b850a11fe3dcdef0a1541e1fc02fa5dba7dd3b0ce2fa6f8144`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `SupportingArtifact` | class | 30 | 45 | Store the validated fields for supporting artifact records. |
| `to_dict` | function | 40 | 45 | Convert dict. |
| `_toml_string` | function | 48 | 53 | Implement toml string. |
| `_write_target_toml` | function | 56 | 99 | Write target toml. |
| `_safe_artifact` | function | 102 | 110 | Implement safe artifact. |
| `infer_target_pack` | function | 113 | 323 | Infer target pack. |
| `load_target_pack` | function | 326 | 338 | Load target pack. |
| `verify_target_pack` | function | 341 | 372 | Verify target pack. |
| `generate_project_from_target_pack` | function | 375 | 460 | Generate project from target pack. |
