---
title: x86decomp.local_llm.prompts
description: Source module reference for x86decomp.local_llm.prompts.
---

# `x86decomp.local_llm.prompts`

**Source path:** `src/x86decomp/local_llm/prompts.py`  
**SHA-256:** `1a89a3d472c4f347049f2c4aa3db4931a03aafcbe4aa83dbabfe1e3814e5e2fb`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_text` | function | 15 | 31 | Implement text. |
| `_integer` | function | 34 | 41 | Implement integer. |
| `_resolve_job_path` | function | 44 | 55 | Resolve job path. |
| `load_job` | function | 58 | 137 | Load and normalize a local-LLM generation/matching job. |
| `_evidence_block` | function | 140 | 155 | Implement evidence block. |
| `build_messages` | function | 158 | 202 | Build a deterministic two-message prompt with explicit trust boundaries. |
| `prompt_record` | function | 205 | 218 | Implement prompt record. |
