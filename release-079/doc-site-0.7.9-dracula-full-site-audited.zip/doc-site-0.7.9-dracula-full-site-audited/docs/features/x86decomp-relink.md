---
title: x86decomp.relink
description: Source module reference for x86decomp.relink.
---

# `x86decomp.relink`

**Source path:** `src/x86decomp/relink.py`  
**SHA-256:** `4f1fb3c198bb72a76cfee702eb3972989b85737dcd1b15dc0a74b227853e4ddd`  
**Documented symbols:** 1

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `run_full_relink` | function | 23 | 126 | Run full relink. |
