---
title: x86decomp_testkit.adapters.detection
description: Source module reference for x86decomp_testkit.adapters.detection.
---

# `x86decomp_testkit.adapters.detection`

**Source path:** `test-suite/src/x86decomp_testkit/adapters/detection.py`  
**SHA-256:** `37a12a0fb0b05dfb418b7bf4b4d969b6824a4c83f0575fa927b0cb27e7678c09`  
**Documented symbols:** 11

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_module_version` | function | 21 | 41 | Implement module version. |
| `_run_version` | function | 44 | 62 | Run version. |
| `_windows_executable_suffixes` | function | 65 | 70 | Implement windows executable suffixes. |
| `_prefer_windows_executable` | function | 73 | 85 | Implement prefer windows executable. |
| `_candidate_from_root` | function | 88 | 112 | Implement candidate from root. |
| `_known_windows_msvc_roots` | function | 115 | 143 | Implement known windows msvc roots. |
| `_find_recursive` | function | 146 | 161 | Find recursive. |
| `_with_capabilities` | function | 164 | 177 | Implement with capabilities. |
| `_detect_http_endpoint` | function | 180 | 201 | Detect http endpoint. |
| `detect_adapter` | function | 204 | 325 | Detect adapter. |
| `detect_all` | function | 328 | 333 | Detect all. |
