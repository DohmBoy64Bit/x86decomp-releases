---
title: x86decomp.mcp
description: Source module reference for x86decomp.mcp.
---

# `x86decomp.mcp`

**Source path:** `src/x86decomp/mcp.py`  
**SHA-256:** `fc36275198b9519bab0720c8a0bd7552d4c9110e61d6d41833f2b0b065bc79a7`  
**Documented symbols:** 27

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `MCPTool` | class | 23 | 30 | Store the validated fields for m c p tool records. |
| `StdioMCPClient` | class | 33 | 184 | Represent stdio m c p client state and behavior. |
| `__init__` | function | 38 | 56 | Initialize the instance with the supplied constructor arguments. |
| `_send` | function | 58 | 66 | Implement send. |
| `_request` | function | 68 | 97 | Implement request. |
| `initialize` | function | 99 | 114 | Initialize the requested operation. |
| `_ensure_initialized` | function | 116 | 122 | Ensure initialized. |
| `list_tools` | function | 124 | 145 | List tools. |
| `call_tool` | function | 147 | 153 | Implement call tool. |
| `close` | function | 155 | 170 | Close the requested operation. |
| `__enter__` | function | 172 | 177 | Enter the context manager and return the active resource. |
| `__exit__` | function | 179 | 184 | Exit the context manager and release managed resources. |
| `StreamableHTTPMCPClient` | class | 187 | 293 | Represent streamable h t t p m c p client state and behavior. |
| `__init__` | function | 192 | 203 | Initialize the instance with the supplied constructor arguments. |
| `_request` | function | 205 | 241 | Implement request. |
| `_notify` | function | 243 | 254 | Implement notify. |
| `initialize` | function | 256 | 264 | Initialize the requested operation. |
| `_ensure_initialized` | function | 266 | 272 | Ensure initialized. |
| `list_tools` | function | 274 | 281 | List tools. |
| `call_tool` | function | 283 | 289 | Implement call tool. |
| `close` | function | 291 | 293 | Streamable HTTP has no persistent local process to close. |
| `is_probable_mutation` | function | 301 | 307 | Implement is probable mutation. |
| `GhidraMCPGateway` | class | 310 | 388 | Separates read calls from hash-approved mutation transactions. |
| `__init__` | function | 313 | 322 | Initialize the instance with the supplied constructor arguments. |
| `read` | function | 324 | 333 | Read the requested operation. |
| `propose_mutation` | function | 335 | 363 | Implement propose mutation. |
| `commit_mutation` | function | 365 | 388 | Implement commit mutation. |
