---
title: x86decomp.assembly.pipeline
description: Source module reference for x86decomp.assembly.pipeline.
---

# `x86decomp.assembly.pipeline`

**Source path:** `src/x86decomp/assembly/pipeline.py`  
**SHA-256:** `a6180daf4c6c7d0d7294bca95c008a4320291742934f98c7de5910cf73107202`  
**Documented symbols:** 9

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_load_json` | function | 29 | 37 | Load json. |
| `_resolve_path` | function | 40 | 46 | Resolve path. |
| `_function_bytes` | function | 49 | 69 | Implement function bytes. |
| `_symbol_map` | function | 72 | 96 | Implement symbol map. |
| `AssemblyPipeline` | class | 99 | 374 | Represent assembly pipeline state and behavior. |
| `__init__` | function | 104 | 110 | Initialize the instance with the supplied constructor arguments. |
| `batch` | function | 112 | 341 | Implement batch. |
| `report` | function | 343 | 361 | Report the requested operation. |
| `list_runs` | function | 363 | 374 | List runs. |
