---
title: x86decomp.ground_truth
description: Source module reference for x86decomp.ground_truth.
---

# `x86decomp.ground_truth`

**Source path:** `src/x86decomp/ground_truth.py`  
**SHA-256:** `979b31406ae94025082d3703821acc57073597753dc7976a6345be675a856a72`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_resolve_executable` | function | 24 | 37 | Resolve executable. |
| `_version` | function | 40 | 51 | Implement version. |
| `_expand_flag_matrix` | function | 54 | 81 | Expand flag matrix. |
| `build_ground_truth_corpus` | function | 84 | 204 | Build ground truth corpus. |
| `verify_ground_truth_corpus` | function | 207 | 227 | Verify ground truth corpus. |
| `compare_ground_truth_corpora` | function | 231 | 311 | Compare successful corpus builds across compiler/version reports. |
| `create_builtin_manifest` | function | 313 | 383 | Create builtin manifest. |
