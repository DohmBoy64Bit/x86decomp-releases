---
title: x86decomp.workflow
description: Source module reference for x86decomp.workflow.
---

# `x86decomp.workflow`

**Source path:** `src/x86decomp/workflow.py`  
**SHA-256:** `976e4f4a4549f66a5c2aeae205048ee2f41342b7f5d6261f39e55c21d704df97`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `DecompilationMode` | class | 21 | 27 | Enumerate the supported decompilation mode values. |
| `SourceStage` | class | 30 | 39 | Enumerate the supported source stage values. |
| `MatchingStatus` | class | 42 | 55 | Enumerate the supported matching status values. |
| `FunctionalStatus` | class | 58 | 70 | Enumerate the supported functional status values. |
| `FunctionWorkflow` | class | 81 | 151 | Store the validated fields for function workflow records. |
| `to_dict` | function | 99 | 116 | Convert dict. |
| `from_dict` | function | 119 | 151 | Build an object from dict. |
| `_state_path` | function | 154 | 160 | Implement state path. |
| `initialize_function_workflow` | function | 163 | 194 | Initialize function workflow. |
| `load_function_workflow` | function | 197 | 205 | Load function workflow. |
| `save_function_workflow` | function | 208 | 214 | Save function workflow. |
| `update_function_workflow` | function | 217 | 271 | Update function workflow. |
