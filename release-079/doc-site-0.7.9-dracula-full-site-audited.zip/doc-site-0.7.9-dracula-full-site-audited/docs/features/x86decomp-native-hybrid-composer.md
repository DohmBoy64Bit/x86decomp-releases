---
title: x86decomp.native.hybrid_composer
description: Source module reference for x86decomp.native.hybrid_composer.
---

# `x86decomp.native.hybrid_composer`

**Source path:** `src/x86decomp/native/hybrid_composer.py`  
**SHA-256:** `f298eba0690a26a3e5b16ee1916570c11702962fd6678c2e06fad8959c71f071`  
**Documented symbols:** 4

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `HybridComposer` | class | 17 | 84 | Represent hybrid composer state and behavior. |
| `__init__` | function | 22 | 27 | Initialize the instance with the supplied constructor arguments. |
| `compose` | function | 29 | 69 | Compose the requested operation. |
| `verify` | function | 71 | 84 | Verify the requested operation. |
