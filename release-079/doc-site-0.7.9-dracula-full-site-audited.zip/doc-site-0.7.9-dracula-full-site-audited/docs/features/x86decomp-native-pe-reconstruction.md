---
title: x86decomp.native.pe_reconstruction
description: Source module reference for x86decomp.native.pe_reconstruction.
---

# `x86decomp.native.pe_reconstruction`

**Source path:** `src/x86decomp/native/pe_reconstruction.py`  
**SHA-256:** `bb0184f5e87f1d566df0f0580e2f3c5243b87d65610778706497c7260410f31d`  
**Documented symbols:** 11

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_section_header_records` | function | 22 | 42 | Implement section header records. |
| `plan_patch` | function | 45 | 63 | Plan patch. |
| `apply_operations` | function | 66 | 77 | Apply operations. |
| `PEReconstruction` | class | 80 | 175 | Represent p e reconstruction state and behavior. |
| `__init__` | function | 85 | 90 | Initialize the instance with the supplied constructor arguments. |
| `inventory` | function | 92 | 98 | Implement inventory. |
| `export_sections` | function | 100 | 116 | Export sections. |
| `export_coff` | function | 118 | 133 | Export coff. |
| `create_plan` | function | 135 | 144 | Create plan. |
| `apply_plan` | function | 146 | 159 | Apply plan. |
| `text_swap` | function | 161 | 175 | Implement text swap. |
