---
title: x86decomp_testkit.process
description: Source module reference for x86decomp_testkit.process.
---

# `x86decomp_testkit.process`

**Source path:** `test-suite/src/x86decomp_testkit/process.py`  
**SHA-256:** `9f5d5d03d63efb311b66c48183a1d70254d17fcb51545ace25f0186f6d083f97`  
**Documented symbols:** 2

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `run_process_test` | function | 18 | 94 | Run process test. |
| `blocked_result` | function | 97 | 113 | Implement blocked result. |
