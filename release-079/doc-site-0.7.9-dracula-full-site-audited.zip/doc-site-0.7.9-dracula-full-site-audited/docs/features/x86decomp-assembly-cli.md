---
title: x86decomp.assembly.cli
description: Source module reference for x86decomp.assembly.cli.
---

# `x86decomp.assembly.cli`

**Source path:** `src/x86decomp/assembly/cli.py`  
**SHA-256:** `68178425eaab3ee9b6b0610b5e68b5e67f9e787634ebbf274fc228da704f95ab`  
**Documented symbols:** 7

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_json_file` | function | 24 | 32 | Implement json file. |
| `_json_array` | function | 35 | 48 | Implement json array. |
| `_int` | function | 51 | 56 | Implement int. |
| `_emit` | function | 59 | 66 | Emit the requested operation. |
| `build_parser` | function | 69 | 158 | Build parser. |
| `dispatch` | function | 161 | 264 | Dispatch the requested operation. |
| `main` | function | 267 | 279 | Run the command-line entry point. |
