---
title: x86decomp.compiler_worker
description: Source module reference for x86decomp.compiler_worker.
---

# `x86decomp.compiler_worker`

**Source path:** `src/x86decomp/compiler_worker.py`  
**SHA-256:** `e675204ff873ae8788813f2d83aed800fe43da5bac360ae105c594315ca32189`  
**Documented symbols:** 1

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `run_compiler_worker` | function | 24 | 139 | Run compiler worker. |
