---
title: x86decomp.linker_layout
description: Source module reference for x86decomp.linker_layout.
---

# `x86decomp.linker_layout`

**Source path:** `src/x86decomp/linker_layout.py`  
**SHA-256:** `d7a3f215125eef1f3750a43254d2281713740c8aadba0fdef9f0d88b6f80356d`  
**Documented symbols:** 12

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `MapSegment` | class | 35 | 57 | Store the validated fields for map segment records. |
| `to_dict` | function | 46 | 57 | Convert dict. |
| `MapContribution` | class | 61 | 81 | Store the validated fields for map contribution records. |
| `to_dict` | function | 71 | 81 | Convert dict. |
| `MapPublic` | class | 85 | 109 | Store the validated fields for map public records. |
| `to_dict` | function | 97 | 109 | Convert dict. |
| `LinkerMap` | class | 113 | 147 | Store the validated fields for linker map records. |
| `to_dict` | function | 128 | 147 | Convert dict. |
| `parse_msvc_map_text` | function | 150 | 248 | Parse msvc map text. |
| `parse_msvc_map` | function | 251 | 259 | Parse msvc map. |
| `_normalize_object_key` | function | 262 | 270 | Normalize object key. |
| `reconstruct_linker_layout` | function | 273 | 401 | Implement reconstruct linker layout. |
