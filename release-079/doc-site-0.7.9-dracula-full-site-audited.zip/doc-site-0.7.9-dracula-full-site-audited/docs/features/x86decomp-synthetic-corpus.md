---
title: x86decomp.synthetic_corpus
description: Source module reference for x86decomp.synthetic_corpus.
---

# `x86decomp.synthetic_corpus`

**Source path:** `src/x86decomp/synthetic_corpus.py`  
**SHA-256:** `f5e89194d1ef3ed29fc861ae16f3662a5736181a2672c0725eae758503b70894`  
**Documented symbols:** 15

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| `_symbol` | function | 25 | 35 | Implement symbol. |
| `_c_arithmetic` | function | 38 | 52 | Implement c arithmetic. |
| `_c_branches` | function | 55 | 72 | Implement c branches. |
| `_c_loop` | function | 75 | 93 | Implement c loop. |
| `_c_switch` | function | 96 | 112 | Implement c switch. |
| `_c_struct_alias` | function | 115 | 139 | Implement c struct alias. |
| `_c_bitfield` | function | 142 | 162 | Implement c bitfield. |
| `_c_float` | function | 165 | 179 | Implement c float. |
| `_c_indirect` | function | 182 | 194 | Implement c indirect. |
| `_cpp_virtual` | function | 197 | 221 | Implement cpp virtual. |
| `_cpp_multiple_inheritance` | function | 224 | 241 | Implement cpp multiple inheritance. |
| `_cpp_exception` | function | 244 | 261 | Implement cpp exception. |
| `_cpp_template` | function | 264 | 274 | Implement cpp template. |
| `generate_synthetic_corpus` | function | 295 | 380 | Generate deterministic source cases and a compiler-corpus input manifest. |
| `verify_synthetic_corpus` | function | 383 | 421 | Verify synthetic corpus. |
