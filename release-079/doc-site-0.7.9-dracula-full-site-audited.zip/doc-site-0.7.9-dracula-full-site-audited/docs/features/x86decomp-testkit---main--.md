---
title: x86decomp_testkit.__main__
description: Source module reference for x86decomp_testkit.__main__.
---

# `x86decomp_testkit.__main__`

**Source path:** `test-suite/src/x86decomp_testkit/__main__.py`  
**SHA-256:** `0b278af3b556bec1814d9f4de0a041bc815bd8bc9bb45a33c7635dcde6aecca6`  
**Documented symbols:** 0

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| _No class or function symbols declared._ |  |  |  |  |
