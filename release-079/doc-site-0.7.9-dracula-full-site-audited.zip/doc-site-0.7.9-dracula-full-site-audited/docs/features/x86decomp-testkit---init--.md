---
title: x86decomp_testkit.__init__
description: Source module reference for x86decomp_testkit.__init__.
---

# `x86decomp_testkit.__init__`

**Source path:** `test-suite/src/x86decomp_testkit/__init__.py`  
**SHA-256:** `df0e1410fd6044417f60f8bd9aed3740af170ba8af76f96a6c9968bef0df3523`  
**Documented symbols:** 0

| Symbol | Kind | Line | End line | Docstring summary |
| --- | --- | ---: | ---: | --- |
| _No class or function symbols declared._ |  |  |  |  |
