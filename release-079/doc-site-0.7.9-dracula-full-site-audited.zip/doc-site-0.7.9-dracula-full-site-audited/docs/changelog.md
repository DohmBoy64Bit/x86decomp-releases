---
title: Changelog
description: Active release notes for x86decomp 0.7.9.
---

# Changelog

## 0.7.9

- Added professional source-grounded docstrings across the editable Python implementation surface.
- Added `DOCSTRING_AUDIT_0.7.9.json` and `DOCSTRING_AUDIT_0.7.9.md` as release evidence.
- Added `docs/COMMAND_REFERENCE_0.7.9.json` and `docs/COMMAND_REFERENCE_0.7.9.md` generated from the current command parser surface.
- Updated the Dracula MkDocs documentation site to the 0.7.9 release baseline, including source coverage, feature/module pages, schema references, test-source references, release evidence, search metadata, and static pages.
- Preserved the prior adapter-capability and local-LLM coverage behavior while advancing documentation and audit completeness.

Earlier release history is retained in release archives and source-control history rather than being duplicated in the active site.
