# x86decomp-toolkit 0.7.9 final release bundle

This bundle contains the x86decomp-toolkit 0.7.9 source tree, docstring audit evidence, command reference artifacts, deterministic source manifests, and built 0.7.9 toolkit/test-suite wheels.

See `x86decomp-toolkit-0.7.9/RELEASE_VERIFICATION.md` and `x86decomp-toolkit-0.7.9/DOCSTRING_AUDIT_0.7.9.md` for verification details.
