"""Append-only, hash-chained project memory."""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any, Iterable

from .errors import ContractError, VerificationError
from .util import atomic_write_text, canonical_json_bytes, sha256_bytes, utc_now


class ProjectMemory:
    """Represent project memory state and behavior.
    
    Attributes, invariants, and helper methods are defined by the class body.
    """
    def __init__(self, project_root: Path):
        """Initialize the instance with the supplied constructor arguments.
        
        Parameters and return values follow the signature and runtime validation in the body.
        """
        self.project_root = project_root
        self.memory_dir = project_root / "memory"
        self.events_path = self.memory_dir / "events.jsonl"
        self.rendered_path = self.memory_dir / "PROJECT_MEMORY.md"
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        if not self.events_path.exists():
            self.events_path.touch()

    def read_events(self) -> list[dict[str, Any]]:
        """Read events.
        
        Parameters and return values follow the signature and runtime validation in the body.
        """
        events: list[dict[str, Any]] = []
        with self.events_path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ContractError(
                        f"invalid memory JSON at line {line_number}: {exc}"
                    ) from exc
                if not isinstance(event, dict):
                    raise ContractError(f"memory line {line_number} is not an object")
                events.append(event)
        return events

    def append(
        self,
        *,
        actor: str,
        category: str,
        summary: str,
        details: dict[str, Any] | None = None,
        evidence_ids: Iterable[str] = (),
    ) -> dict[str, Any]:
        """Implement append.
        
        Parameters and return values follow the signature and runtime validation in the body.
        """
        if not all(value.strip() for value in (actor, category, summary)):
            raise ContractError("actor, category, and summary must be non-empty")
        events = self.read_events()
        previous_hash = events[-1]["event_hash"] if events else None
        event: dict[str, Any] = {
            "schema_version": 1,
            "id": f"mem-{uuid.uuid4().hex[:16]}",
            "sequence": len(events) + 1,
            "timestamp": utc_now(),
            "actor": actor,
            "category": category,
            "summary": summary,
            "details": details or {},
            "evidence_ids": list(dict.fromkeys(evidence_ids)),
            "previous_hash": previous_hash,
        }
        event["event_hash"] = sha256_bytes(canonical_json_bytes(event))
        with self.events_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(event, sort_keys=True, ensure_ascii=False) + "\n")
            handle.flush()
        self.render()
        return event

    def verify(self) -> dict[str, Any]:
        """Verify the requested operation.
        
        Parameters and return values follow the signature and runtime validation in the body.
        """
        events = self.read_events()
        failures: list[str] = []
        previous_hash: str | None = None
        for index, event in enumerate(events, start=1):
            if event.get("sequence") != index:
                failures.append(f"event {index}: invalid sequence")
            if event.get("previous_hash") != previous_hash:
                failures.append(f"event {index}: previous_hash mismatch")
            recorded_hash = event.get("event_hash")
            unsigned = dict(event)
            unsigned.pop("event_hash", None)
            expected_hash = sha256_bytes(canonical_json_bytes(unsigned))
            if recorded_hash != expected_hash:
                failures.append(f"event {index}: event_hash mismatch")
            previous_hash = recorded_hash if isinstance(recorded_hash, str) else None
        return {"event_count": len(events), "valid": not failures, "failures": failures}

    def require_valid(self) -> None:
        """Implement require valid.
        
        Parameters and return values follow the signature and runtime validation in the body.
        """
        result = self.verify()
        if not result["valid"]:
            raise VerificationError("project memory is invalid: " + "; ".join(result["failures"]))

    def render(self) -> str:
        """Render the requested operation.
        
        Parameters and return values follow the signature and runtime validation in the body.
        """
        events = self.read_events()
        by_category: dict[str, list[dict[str, Any]]] = {}
        for event in events:
            by_category.setdefault(str(event.get("category", "unknown")), []).append(event)
        lines = [
            "# Project memory",
            "",
            "> Generated from the tamper-evident `events.jsonl` ledger. Do not edit this file by hand.",
            "",
            f"- Event count: **{len(events)}**",
            f"- Last event hash: `{events[-1]['event_hash'] if events else 'none'}`",
            "",
            "## Current recorded knowledge",
            "",
        ]
        if not events:
            lines.append("No memory events have been recorded.")
        for category in sorted(by_category):
            lines.extend([f"### {category}", ""])
            for event in by_category[category]:
                lines.append(
                    f"- **#{event['sequence']} — {event['timestamp']} — {event['actor']}**: "
                    f"{event['summary']}"
                )
                details = event.get("details", {})
                if details:
                    lines.append(f"  - Details: `{json.dumps(details, sort_keys=True, ensure_ascii=False)}`")
                evidence_ids = event.get("evidence_ids", [])
                if evidence_ids:
                    lines.append(f"  - Evidence: {', '.join(f'`{x}`' for x in evidence_ids)}")
            lines.append("")
        text = "\n".join(lines).rstrip() + "\n"
        atomic_write_text(self.rendered_path, text)
        return text
