"""Command-line interface for the x86 decompilation project toolkit."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .artifacts import import_function_artifact, verify_function_artifact
from .compiler import run_compiler_profile
from .diffing import compare_files
from .errors import X86DecompError
from .evidence import EvidenceStore
from .ghidra import build_export_command, run_export
from .memory import ProjectMemory
from .models import EvidenceKind
from .pe32 import parse_pe32
from .project import initialize_project, verify_project
from .tools import snapshot_tools


def _print(value: Any) -> None:
    print(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False))


def _path(value: str) -> Path:
    return Path(value).expanduser()


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="x86decomp",
        description="Evidence-governed x86 PE32 decompilation project toolkit",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="initialize a PE32/x86 project")
    init_parser.add_argument("binary", type=_path)
    init_parser.add_argument("project", type=_path)
    init_parser.add_argument(
        "--reference-binary",
        action="store_true",
        help="store an absolute reference instead of copying the binary into the project",
    )

    inspect_parser = subparsers.add_parser("inspect-pe", help="parse and print PE32 metadata")
    inspect_parser.add_argument("binary", type=_path)

    verify_parser = subparsers.add_parser("verify-project", help="verify project integrity")
    verify_parser.add_argument("project", type=_path)

    tools_parser = subparsers.add_parser("snapshot-tools", help="capture external tool availability")
    tools_parser.add_argument("--output", type=_path)
    tools_parser.add_argument("--ghidra-home", type=_path)

    compiler_parser = subparsers.add_parser("compile", help="run a compiler profile")
    compiler_parser.add_argument("profile", type=_path)
    compiler_parser.add_argument("source", type=_path)
    compiler_parser.add_argument("output", type=_path)
    compiler_parser.add_argument("--report", type=_path)

    diff_parser = subparsers.add_parser("diff-bytes", help="compare two files byte-for-byte")
    diff_parser.add_argument("target", type=_path)
    diff_parser.add_argument("candidate", type=_path)
    diff_parser.add_argument("--report", type=_path)
    diff_parser.add_argument("--max-mismatches", type=int, default=64)

    evidence_parser = subparsers.add_parser("evidence-add", help="add an evidence record")
    evidence_parser.add_argument("project", type=_path)
    evidence_parser.add_argument("--kind", choices=[kind.value for kind in EvidenceKind], required=True)
    evidence_parser.add_argument("--source", required=True)
    evidence_parser.add_argument("--locator", required=True)
    evidence_parser.add_argument("--assertion", required=True)
    evidence_parser.add_argument("--independent-group", required=True)
    evidence_parser.add_argument("--file", type=_path)
    evidence_parser.add_argument("--id")

    claim_parser = subparsers.add_parser("claim-create", help="create a proposed claim")
    claim_parser.add_argument("project", type=_path)
    claim_parser.add_argument("--subject", required=True)
    claim_parser.add_argument("--predicate", required=True)
    claim_parser.add_argument("--object", dest="object_value", required=True)
    claim_parser.add_argument("--evidence", action="append", default=[])
    claim_parser.add_argument("--id")

    attach_parser = subparsers.add_parser("claim-attach", help="attach evidence to a claim")
    attach_parser.add_argument("project", type=_path)
    attach_parser.add_argument("claim_id")
    attach_parser.add_argument("evidence_id")

    verify_claim_parser = subparsers.add_parser(
        "claim-verify", help="apply the three-independent-source verification gate"
    )
    verify_claim_parser.add_argument("project", type=_path)
    verify_claim_parser.add_argument("claim_id")

    contradiction_parser = subparsers.add_parser(
        "claim-contradict", help="attach unresolved contradiction evidence"
    )
    contradiction_parser.add_argument("project", type=_path)
    contradiction_parser.add_argument("claim_id")
    contradiction_parser.add_argument("evidence_id")

    memory_add_parser = subparsers.add_parser("memory-add", help="append a project memory event")
    memory_add_parser.add_argument("project", type=_path)
    memory_add_parser.add_argument("--actor", required=True)
    memory_add_parser.add_argument("--category", required=True)
    memory_add_parser.add_argument("--summary", required=True)
    memory_add_parser.add_argument("--details-json", default="{}")
    memory_add_parser.add_argument("--evidence", action="append", default=[])

    memory_verify_parser = subparsers.add_parser("memory-verify", help="verify memory hash chain")
    memory_verify_parser.add_argument("project", type=_path)

    memory_render_parser = subparsers.add_parser("memory-render", help="render project memory Markdown")
    memory_render_parser.add_argument("project", type=_path)


    artifact_import_parser = subparsers.add_parser(
        "artifact-import", help="import and integrity-seal a Ghidra function artifact"
    )
    artifact_import_parser.add_argument("project", type=_path)
    artifact_import_parser.add_argument("exported_dir", type=_path)

    artifact_verify_parser = subparsers.add_parser(
        "artifact-verify", help="verify a sealed function artifact"
    )
    artifact_verify_parser.add_argument("artifact_dir", type=_path)

    ghidra_parser = subparsers.add_parser("ghidra-export", help="run the bundled Ghidra exporters")
    ghidra_parser.add_argument("binary", type=_path)
    ghidra_parser.add_argument("ghidra_project_dir", type=_path)
    ghidra_parser.add_argument("ghidra_project_name")
    ghidra_parser.add_argument("output_dir", type=_path)
    ghidra_parser.add_argument("--scripts-dir", type=_path, default=Path("ghidra_scripts"))
    ghidra_parser.add_argument("--ghidra-home", type=_path)
    ghidra_parser.add_argument("--overwrite", action="store_true")
    ghidra_parser.add_argument("--selector", default="all")
    ghidra_parser.add_argument("--timeout", type=int, default=3600)
    ghidra_parser.add_argument("--report", type=_path)
    ghidra_parser.add_argument("--print-command", action="store_true")

    return parser


def _run(args: argparse.Namespace) -> Any:
    if args.command == "init":
        return initialize_project(args.binary, args.project, copy_binary=not args.reference_binary)
    if args.command == "inspect-pe":
        return parse_pe32(args.binary).to_dict()
    if args.command == "verify-project":
        return verify_project(args.project)
    if args.command == "snapshot-tools":
        return snapshot_tools(args.output, args.ghidra_home)
    if args.command == "compile":
        return run_compiler_profile(args.profile, args.source, args.output, report_path=args.report)
    if args.command == "diff-bytes":
        return compare_files(
            args.target,
            args.candidate,
            max_mismatches=args.max_mismatches,
            report_path=args.report,
        )
    if args.command == "evidence-add":
        item = EvidenceStore(args.project).add_evidence(
            kind=EvidenceKind(args.kind),
            source=args.source,
            locator=args.locator,
            assertion=args.assertion,
            independent_group=args.independent_group,
            file_path=args.file,
            evidence_id=args.id,
        )
        return item.to_dict()
    if args.command == "claim-create":
        claim = EvidenceStore(args.project).create_claim(
            subject=args.subject,
            predicate=args.predicate,
            object_value=args.object_value,
            evidence_ids=args.evidence,
            claim_id=args.id,
        )
        return claim.to_dict()
    if args.command == "claim-attach":
        return EvidenceStore(args.project).attach_evidence(args.claim_id, args.evidence_id).to_dict()
    if args.command == "claim-verify":
        return EvidenceStore(args.project).verify_claim(args.claim_id)
    if args.command == "claim-contradict":
        return EvidenceStore(args.project).add_contradiction(
            args.claim_id, args.evidence_id
        ).to_dict()
    if args.command == "memory-add":
        details = json.loads(args.details_json)
        if not isinstance(details, dict):
            raise ValueError("--details-json must decode to a JSON object")
        return ProjectMemory(args.project).append(
            actor=args.actor,
            category=args.category,
            summary=args.summary,
            details=details,
            evidence_ids=args.evidence,
        )
    if args.command == "memory-verify":
        return ProjectMemory(args.project).verify()
    if args.command == "memory-render":
        return {"path": str(ProjectMemory(args.project).rendered_path), "content": ProjectMemory(args.project).render()}
    if args.command == "artifact-import":
        destination = import_function_artifact(args.project, args.exported_dir)
        return {"artifact_dir": str(destination), "verification": verify_function_artifact(destination)}
    if args.command == "artifact-verify":
        return verify_function_artifact(args.artifact_dir)
    if args.command == "ghidra-export":
        command = build_export_command(
            binary=args.binary,
            ghidra_project_dir=args.ghidra_project_dir,
            ghidra_project_name=args.ghidra_project_name,
            scripts_dir=args.scripts_dir,
            output_dir=args.output_dir,
            ghidra_home=args.ghidra_home,
            overwrite=args.overwrite,
            function_selector=args.selector,
        )
        if args.print_command:
            return {"command": command}
        return run_export(command, timeout_seconds=args.timeout, report_path=args.report)
    raise AssertionError(f"unhandled command: {args.command}")


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        result = _run(args)
        _print(result)
        return 0
    except (X86DecompError, ValueError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
