"""Deterministic external compiler profile execution."""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

from .errors import ContractError, ExternalToolError
from .util import load_json, sha256_file, utc_now, write_json

_ALLOWED_TOKENS = {"{source}", "{output}"}


def load_profile(path: Path) -> dict[str, Any]:
    value = load_json(path)
    if not isinstance(value, dict):
        raise ContractError("compiler profile must be a JSON object")
    required = ("schema_version", "id", "executable", "arguments", "timeout_seconds", "output_kind")
    for key in required:
        if key not in value:
            raise ContractError(f"compiler profile is missing {key}")
    if value["schema_version"] != 1:
        raise ContractError("unsupported compiler profile schema")
    if not isinstance(value["arguments"], list) or not all(
        isinstance(arg, str) for arg in value["arguments"]
    ):
        raise ContractError("compiler profile arguments must be an array of strings")
    joined = "\n".join(value["arguments"])
    for token in _ALLOWED_TOKENS:
        if token not in joined:
            raise ContractError(f"compiler profile arguments must include {token}")
    unknown_tokens = {
        fragment
        for argument in value["arguments"]
        for fragment in __import__("re").findall(r"\{[^{}]+\}", argument)
        if fragment not in _ALLOWED_TOKENS
    }
    if unknown_tokens:
        raise ContractError(
            "compiler profile contains unsupported substitution token(s): "
            + ", ".join(sorted(unknown_tokens))
        )
    if not isinstance(value["timeout_seconds"], int) or value["timeout_seconds"] <= 0:
        raise ContractError("timeout_seconds must be a positive integer")
    env = value.get("environment", {})
    if not isinstance(env, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in env.items()):
        raise ContractError("environment must be a string-to-string object")
    return value


def _tool_version(executable: str) -> str | None:
    try:
        completed = subprocess.run(
            [executable, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    output = (completed.stdout or completed.stderr).strip()
    return output.splitlines()[0] if output else None


def run_compiler_profile(
    profile_path: Path,
    source: Path,
    output: Path,
    *,
    report_path: Path | None = None,
) -> dict[str, Any]:
    profile = load_profile(profile_path)
    source = source.resolve()
    output = output.resolve()
    if not source.is_file():
        raise ContractError(f"source file does not exist: {source}")
    if source == output:
        raise ContractError("source and output must be different paths")
    executable_value = str(profile["executable"])
    executable = shutil.which(executable_value)
    if executable is None:
        raise ExternalToolError(f"compiler executable is not available: {executable_value}")
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        if not output.is_file():
            raise ContractError(f"compiler output path is not a regular file: {output}")
        output.unlink()
    command = [
        executable,
        *[
            arg.replace("{source}", str(source)).replace("{output}", str(output))
            for arg in profile["arguments"]
        ],
    ]
    environment = os.environ.copy()
    environment.update(profile.get("environment", {}))
    started_at = utc_now()
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=profile["timeout_seconds"],
            env=environment,
            check=False,
        )
        timed_out = False
    except subprocess.TimeoutExpired as exc:
        completed = None
        timed_out = True
        stdout = exc.stdout.decode(errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
    if completed is not None:
        stdout = completed.stdout
        stderr = completed.stderr
        return_code = completed.returncode
    else:
        return_code = None
    report = {
        "schema_version": 1,
        "profile_id": profile["id"],
        "started_at": started_at,
        "finished_at": utc_now(),
        "command": command,
        "executable": executable,
        "executable_sha256": sha256_file(Path(executable)),
        "executable_version": _tool_version(executable),
        "source": str(source),
        "source_sha256": sha256_file(source),
        "output": str(output),
        "output_kind": profile["output_kind"],
        "return_code": return_code,
        "timed_out": timed_out,
        "stdout": stdout,
        "stderr": stderr,
        "success": return_code == 0 and output.is_file(),
        "output_sha256": sha256_file(output) if output.is_file() else None,
        "output_size": output.stat().st_size if output.is_file() else None,
    }
    if report_path is not None:
        write_json(report_path, report)
    if not report["success"]:
        reason = "timed out" if timed_out else f"exit code {return_code}"
        raise ExternalToolError(f"compiler failed ({reason}); stderr: {stderr.strip()}")
    return report
