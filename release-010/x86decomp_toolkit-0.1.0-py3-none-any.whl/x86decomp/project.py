"""Project initialization and integrity verification."""

from __future__ import annotations

import platform
import sys
import uuid
from pathlib import Path
from typing import Any

from .errors import ContractError, VerificationError
from .memory import ProjectMemory
from .pe32 import parse_pe32
from .util import copy_file_atomic, load_json, sha256_file, utc_now, write_json

PROJECT_SCHEMA_VERSION = 1

PROJECT_DIRS = (
    "analysis/ghidra",
    "analysis/exports",
    "build/compiler",
    "build/candidates",
    "config/compiler-profiles",
    "evidence/items",
    "evidence/claims",
    "evidence/files",
    "functions",
    "memory",
    "original",
    "reports",
)


def initialize_project(binary: Path, project_root: Path, *, copy_binary: bool = True) -> dict[str, Any]:
    source = binary.resolve()
    root = project_root.resolve()
    if root.exists() and any(root.iterdir()):
        raise ContractError(f"project directory is not empty: {root}")
    root.mkdir(parents=True, exist_ok=True)
    for directory in PROJECT_DIRS:
        (root / directory).mkdir(parents=True, exist_ok=True)

    image = parse_pe32(source)
    binary_name = source.name
    if copy_binary:
        stored_binary = root / "original" / binary_name
        copy_file_atomic(source, stored_binary)
        source_kind = "copied"
    else:
        stored_binary = source
        source_kind = "external_reference"

    project_id = f"x86d-{image.file_sha256[:16]}-{uuid.uuid4().hex[:8]}"
    project = {
        "schema_version": PROJECT_SCHEMA_VERSION,
        "project_id": project_id,
        "created_at": utc_now(),
        "supported_scope": "native Windows PE32 x86",
        "binary": {
            "name": binary_name,
            "source_kind": source_kind,
            "path": str(stored_binary if source_kind == "external_reference" else stored_binary.relative_to(root)),
            "sha256": image.file_sha256,
            "size": source.stat().st_size,
        },
        "program_manifest": "analysis/program.json",
        "memory_ledger": "memory/events.jsonl",
        "function_root": "functions",
        "evidence_root": "evidence",
        "status": "initialized",
    }
    write_json(root / "project.json", project)
    program_manifest = image.to_dict()
    program_manifest["source_path"] = project["binary"]["path"]
    write_json(root / "analysis" / "program.json", program_manifest)
    write_json(
        root / "analysis" / "host.json",
        {
            "schema_version": 1,
            "captured_at": utc_now(),
            "python": sys.version,
            "platform": platform.platform(),
            "implementation": platform.python_implementation(),
        },
    )

    memory = ProjectMemory(root)
    memory.append(
        actor="x86decomp",
        category="project",
        summary="Initialized a native PE32/x86 decompilation project.",
        details={
            "project_id": project_id,
            "binary_sha256": image.file_sha256,
            "binary_name": binary_name,
            "copy_binary": copy_binary,
        },
    )
    return project


def _resolve_binary_path(root: Path, project: dict[str, Any]) -> Path:
    binary = project.get("binary")
    if not isinstance(binary, dict):
        raise ContractError("project.binary must be an object")
    value = binary.get("path")
    if not isinstance(value, str) or not value:
        raise ContractError("project.binary.path must be a non-empty string")
    path = Path(value)
    if not path.is_absolute():
        path = root / path
    return path.resolve()


def verify_project(project_root: Path) -> dict[str, Any]:
    root = project_root.resolve()
    project_path = root / "project.json"
    if not project_path.is_file():
        raise ContractError(f"missing project.json: {project_path}")
    project = load_json(project_path)
    if not isinstance(project, dict):
        raise ContractError("project.json must contain an object")
    failures: list[str] = []
    if project.get("schema_version") != PROJECT_SCHEMA_VERSION:
        failures.append("unsupported project schema version")
    binary_path = _resolve_binary_path(root, project)
    expected_hash = project.get("binary", {}).get("sha256")
    if not binary_path.is_file():
        failures.append(f"binary is missing: {binary_path}")
    elif sha256_file(binary_path) != expected_hash:
        failures.append("binary SHA-256 does not match project.json")

    program_path = root / str(project.get("program_manifest", "analysis/program.json"))
    if not program_path.is_file():
        failures.append(f"program manifest is missing: {program_path}")
    elif binary_path.is_file():
        try:
            current = parse_pe32(binary_path).to_dict()
            recorded = load_json(program_path)
            for key in (
                "file_sha256",
                "machine",
                "image_base",
                "entry_rva",
                "number_of_sections",
                "size_of_image",
            ):
                if recorded.get(key) != current.get(key):
                    failures.append(f"program manifest mismatch: {key}")
        except Exception as exc:  # converted to an audit failure, not hidden
            failures.append(f"unable to reparse binary: {exc}")

    memory_result = ProjectMemory(root).verify()
    failures.extend(f"memory: {failure}" for failure in memory_result["failures"])
    return {
        "project_id": project.get("project_id"),
        "valid": not failures,
        "failures": failures,
        "binary_path": str(binary_path),
        "memory_event_count": memory_result["event_count"],
    }


def require_valid_project(project_root: Path) -> dict[str, Any]:
    result = verify_project(project_root)
    if not result["valid"]:
        raise VerificationError("project verification failed: " + "; ".join(result["failures"]))
    return result
