#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
python3 -m compileall -q src tests
PYTHONPATH=src python3 -m unittest discover -s tests -v
