#!/usr/bin/env sh
set -eu
if [ -z "${GHIDRA_HOME:-}" ]; then
  echo "GHIDRA_HOME is required" >&2
  exit 2
fi
if [ "$#" -ne 2 ]; then
  echo "usage: $0 <pe32-binary> <work-dir>" >&2
  exit 2
fi
BINARY=$(cd "$(dirname "$1")" && pwd)/$(basename "$1")
WORK=$2
ROOT=$(cd "$(dirname "$0")/.." && pwd)
mkdir -p "$WORK/project" "$WORK/export"
"$GHIDRA_HOME/support/analyzeHeadless" "$WORK/project" x86decomp_verify \
  -import "$BINARY" -overwrite \
  -scriptPath "$ROOT/ghidra_scripts" \
  -postScript ExportProjectManifest.java "$WORK/export" \
  -postScript ExportFunctionArtifacts.java "$WORK/export" all
python3 - <<'PY' "$WORK/export"
import json, pathlib, sys
root = pathlib.Path(sys.argv[1])
json.load((root / "program.json").open(encoding="utf-8"))
json.load((root / "sections.json").open(encoding="utf-8"))
json.load((root / "metrics.json").open(encoding="utf-8"))
for path in root.glob("functions/*/function.json"):
    json.load(path.open(encoding="utf-8"))
print("Ghidra export JSON validation passed")
PY
