# x86decomp-toolkit

An evidence-governed, human-in-the-loop project template for native Windows
PE32/x86 decompilation work.

This repository is deliberately not advertised as a universal binary-to-original-
source converter. It provides the repeatable infrastructure around decompilation:
project creation, immutable binary evidence, Ghidra exports, per-function artifacts,
compiler experiments, exact byte comparison, evidence claims, and project memory.

## Implemented in this package

- Strict native PE32/i386 parsing without executing the binary.
- PE headers, sections, imports, exports, base relocations, CodeView records, and TLS callbacks.
- Reproducible project initialization with SHA-256 integrity checks.
- Tamper-evident, append-only project memory.
- Evidence records copied into project-owned immutable storage and a three-independent-source verification gate.
- External compiler profiles with captured command, version, output, and hashes.
- Exact byte comparison with transparent mismatch reporting.
- Ghidra headless project manifest export.
- Ghidra per-function artifacts preserving discontiguous function bodies.
- Read-only Ghidra reference, disassembly, function, and caller queries.
- JSON Schema contracts, tests, CI, guardrails, and an agent skill.

## Explicitly not implemented or claimed

- Recovery of original source text, comments, names, file boundaries, or macros.
- Generic reconstruction of consumed COFF link-time relocations from a linked PE.
- A universal PE-executable-versus-object semantic diff engine.
- Automated proof of semantic equivalence.
- Safe execution of an unknown target binary.
- Packers, virtualized code, kernel drivers, DRM, or self-modifying code.
- Automatic public upload to decomp.me or any other service.

Those areas require separate research and target-specific engineering. The package
records them in `docs/roadmap.md` instead of presenting empty APIs as finished work.

## Requirements

- Python 3.11 or newer.
- Ghidra 12.1 or compatible for the bundled Java scripts.
- A compiler only when running compiler profiles.
- `objdiff-cli`, Capstone, LIEF, ghidra-mcp, or dynamic-analysis tools are optional
  integrations and are not required to run the core tests.

## Build and test

```bash
python3 -m pip install -e .
make verify
```

The core package has no mandatory third-party Python dependency.

## Initialize a project

```bash
x86decomp init path/to/program.exe projects/program
x86decomp verify-project projects/program
```

The default copies the binary into `original/`. Use `--reference-binary` only when
an absolute external path is intentionally required.

## Inspect PE metadata

```bash
x86decomp inspect-pe path/to/program.exe
```

## Export from Ghidra

```bash
export GHIDRA_HOME=/opt/ghidra_12.1.2_PUBLIC
x86decomp ghidra-export \
  path/to/program.exe \
  projects/program/analysis/ghidra \
  program \
  projects/program/analysis/exports \
  --scripts-dir ./ghidra_scripts \
  --overwrite
```

The export produces project-level manifests and one directory per function. Function
body ranges remain separate. The exporter never invents a contiguous range across
gaps.

## Compile a source candidate

```bash
x86decomp compile \
  examples/compiler-profiles/gcc-i686-object.json \
  examples/sample_source/add.c \
  build/add.o \
  --report build/add.compile.json
```

Compiler profiles use argument arrays, not shell strings. Only `{source}` and
`{output}` substitution is performed.

## Import and verify a function artifact

```bash
x86decomp artifact-import projects/program projects/program/analysis/exports/functions/pe-rva_00012340
x86decomp artifact-verify projects/program/functions/pe-rva_00012340
```

The importer rejects symlinks, validates half-open non-overlapping ranges, copies the
artifact into the project, and writes a per-file integrity manifest.

## Exact byte comparison

```bash
x86decomp diff-bytes target.bin candidate.bin --report reports/diff.json
```

This command claims byte equality only. A high similarity value is not labeled as
semantic equivalence.

## Evidence and verified claims

```bash
x86decomp evidence-add projects/program \
  --kind binary_bytes \
  --source original-image \
  --locator pe-rva:00012340 \
  --assertion "ECX is read before assignment at function entry" \
  --independent-group raw-bytes \
  --file reports/function-00012340.bin

x86decomp claim-create projects/program \
  --id cl-thiscall-00012340 \
  --subject pe-rva:00012340 \
  --predicate has_calling_convention \
  --object __thiscall

x86decomp claim-attach projects/program cl-thiscall-00012340 ev-example
x86decomp claim-verify projects/program cl-thiscall-00012340
```

A claim reaches `verified` only after the configured three-source gate passes. This
is a governance rule that reduces unsupported assertions; it cannot guarantee truth.

See `VERIFICATION.md` for the exact checks performed on this package and the separate Ghidra integration check.

## Repository layout

```text
src/x86decomp/               Python orchestration core
ghidra_scripts/              Complete headless Ghidra exporters and queries
schemas/                     JSON Schema contracts
docs/                        Architecture, guardrails, contracts, and roadmap
skills/x86decomp/SKILL.md     Evidence-first agent workflow
PROJECT_MEMORY.md             Memory operating contract for this repository
AGENTS.md                     Mandatory contributor/agent rules
tests/                        Deterministic unit and integration tests
examples/                     Working compiler profile and source example
```

## Upstream tools and factual basis

- Ghidra: https://github.com/NationalSecurityAgency/ghidra
- objdiff: https://github.com/encounter/objdiff
- decomp-toolkit template: https://github.com/encounter/dtk-template
- decomp.me: https://github.com/decompme/decomp.me
- ghidra-mcp: https://github.com/bethington/ghidra-mcp
- Capstone: https://github.com/capstone-engine/capstone
- LIEF: https://github.com/lief-project/LIEF

Review each upstream license before copying code. This template contains newly
written integration code and does not vendor those projects.
