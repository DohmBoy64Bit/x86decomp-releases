# Security policy

Treat every analyzed binary, PDB, project archive, compiler, script, and generated
source file as untrusted input.

- Run unknown binaries only inside an isolated virtual machine or sandbox.
- The toolkit does not execute the target binary during `init`, `inspect-pe`, or
  manifest verification.
- Compiler profiles execute external programs. Review profiles before use.
- Ghidra scripts write only beneath the output directory supplied to them.
- Never expose proprietary binaries or code through public decompilation services
  without authorization.
- Report vulnerabilities with a minimal reproducer that contains no third-party
  proprietary material.
