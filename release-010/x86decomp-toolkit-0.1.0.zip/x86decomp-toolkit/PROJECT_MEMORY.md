# Repository project memory

This document defines the durable memory contract for development of the toolkit.
Individual decompilation projects use the generated `memory/events.jsonl` ledger and
`memory/PROJECT_MEMORY.md` rendering.

## Mission

Build a reproducible, evidence-governed workflow that moves native PE32/x86 functions
from unknown machine code to reviewable source candidates and measurable validation
states. Do not claim recovery of information erased by compilation.

## Fixed architectural decisions

1. **x86 PE32 first.** PE32+ and x86-64 are rejected by the initial parser.
2. **Ghidra is an analysis backend, not the source of truth.** Raw binary bytes remain
   immutable evidence.
3. **Per-function artifacts are primary.** A monolithic decompiler dump is only a
   report and never the working source tree.
4. **Function bodies are address sets.** Discontiguous ranges are preserved.
5. **No universal equivalence claim.** Byte match, finite differential tests, bounded
   symbolic checks, and integration tests remain separate statuses.
6. **Claims require provenance.** Names, types, calling conventions, structures, and
   semantics begin as proposals unless backed by stronger evidence.
7. **Project memory is append-only and hash chained.** Rendered Markdown is derived.
8. **External tools are optional and isolated behind explicit process execution.**
9. **The core has no mandatory Python dependency.** Optional Capstone/LIEF extras may
   be used for independent analysis but do not replace raw evidence.
10. **No hidden network upload.** decomp.me integration begins with local packet
    generation; upload requires an explicit future feature and authorization review.

## Current implementation inventory

- `pe32.py`: strict parser and metadata extraction.
- `project.py`: initialization and integrity audit.
- `evidence.py`: project-owned evidence copies, integrity auditing, and three-source claim gate.
- `memory.py`: append-only hash-chain ledger.
- `compiler.py`: deterministic compiler profile runner with stale-output removal and tool hashing.
- `diffing.py`: exact byte comparison and non-semantic similarity report.
- `ghidra.py`: headless exporter command construction and execution.
- `artifacts.py`: per-function artifact import and integrity manifests.
- `ghidra_scripts/`: program/function export and read-only queries.

## Known limitations that must not be forgotten

- The Python byte comparator does not normalize relocations.
- The PE parser reports base relocations, not consumed COFF link-time relocations.
- Ghidra-produced prototypes and types remain analysis outputs.
- The Ghidra scripts require an installed, compatible Ghidra distribution for runtime
  verification.
- The compiler example emits an i386 ELF relocatable object, not a Windows COFF
  object. It proves the compiler-profile mechanism, not PE matching.
- Dynamic tracing and symbolic execution are not bundled in version 0.1.0.
- objdiff compares relocatable object files; direct PE-versus-object comparison needs
  a separate executable-aware subsystem.

## Next research milestones

1. Define a normalized x86 instruction/reference IR.
2. Add a COFF parser and relocation model.
3. Build executable-function versus COFF-function comparison.
4. Add compiler profiles for user-supplied historical MSVC toolchains.
5. Add controlled runtime tracing and indirect-target capture.
6. Add ABI checks for cdecl, stdcall, thiscall, fastcall, and structure returns.
7. Add optional ghidra-mcp transaction logging and read-only default policy.
8. Add x86-64 only after x86 contracts and validation are stable.

## Memory event categories

- `project`: initialization and lifecycle.
- `decision`: architectural choice and rationale.
- `fact`: verified property with evidence IDs.
- `hypothesis`: unverified working theory.
- `compiler`: profile or flag discovery.
- `function`: function-level status transition.
- `type`: type-layout proposal or verification.
- `blocker`: unresolved issue.
- `tool`: tool version or behavior change.
- `risk`: legal, security, or correctness concern.

## Required event detail

A durable event should include the affected stable IDs, old/new state, command or
change, result, evidence IDs, and any rollback information. Never use project memory
to launder a hypothesis into a fact.
