# Agent and contributor operating rules

These rules are mandatory for humans, coding agents, and reverse-engineering agents
working in this repository or in a project produced by it.

## 1. Truthfulness boundary

Never state or encode a guess as a recovered fact.

- Ghidra decompiler output is a candidate representation.
- An AI-proposed name is a proposed name.
- A compiler-generated match proves only the exact property measured by the report.
- Static-reference absence does not prove runtime-reference absence.
- Three-source verification is a project governance threshold, not infallibility.
- Byte equality does not by itself establish that reconstructed source was original.
- Behavioral agreement on a finite test set does not prove universal equivalence.

Use these labels consistently: `observed`, `derived`, `proposed`, `corroborated`,
`verified`, `rejected`, and `unknown`.

## 2. Evidence before mutation

Before renaming a function, changing a prototype, defining a structure, or promoting
source status:

1. Capture the current program/function artifact.
2. Create or identify evidence records.
3. Record the proposed claim.
4. Apply the change transactionally.
5. Re-export the affected artifact.
6. Run applicable compiler, byte, ABI, or dynamic checks.
7. Record the result in project memory.

Bulk write operations through Ghidra MCP are prohibited unless the exact change set
has been exported, reviewed, and can be reverted.

## 3. Triple-check policy

A claim may be marked `verified` only when:

- at least three evidence records support it;
- the records come from at least three independent groups;
- at least two evidence kinds are represented;
- file-backed hashes still match;
- no unresolved contradiction is attached.

Examples of independent groups include raw binary bytes, Ghidra static analysis,
an independently decoded Capstone trace, compiler output, a PDB, and a runtime trace.
Two outputs produced from the same Ghidra database and algorithm are not independent
merely because they are stored in separate files.

## 4. Address contracts

- Canonical function IDs use `pe-rva:XXXXXXXX`.
- RVA integers are unsigned 32-bit values.
- Ranges are half-open: `[start_rva, end_rva)`.
- Ghidra address strings are display/provenance fields, not stable IDs.
- Function bodies may be discontiguous. Never replace a range list with one enclosing
  interval unless a separate field explicitly says it is a storage span.

## 5. Source status

Every candidate function must use one state:

`unexplored -> exported -> candidate -> compiles -> abi_checked -> instruction_similar -> byte_matched`

Dynamic or symbolic results are orthogonal labels:

`differentially_tested`, `bounded_symbolic_check`, `integration_tested`.

Do not skip directly from `candidate` to `byte_matched` without preserving the
compiler report and comparison report.

## 6. Code quality

- No shell interpolation for compiler or analysis commands.
- All external processes must have timeouts.
- All outputs must be atomically written where practical.
- Preserve stdout, stderr, command arguments, return code, tool path, and tool version.
- JSON must be valid JSON; C escape syntax is not a JSON encoder.
- Inputs are untrusted. Enforce bounds and safety limits.
- Tests must cover malformed input and integrity failures.
- Do not add a dependency when the standard library implements the required behavior
  clearly and safely.

## 7. Legal and safety constraints

Analyze only material for which the operator has authorization. Do not upload binary
fragments, PDBs, proprietary code, or generated source to a third-party service by
default. Unknown binaries must not be executed on the host. Dynamic testing belongs
in an isolated environment with controlled inputs and network access.

## 8. Completion claims

A change is complete only when:

- relevant tests pass;
- contracts and documentation agree with implementation;
- there are no empty placeholder functions or unimplemented branches represented as
  working features;
- unsupported behavior fails explicitly;
- project memory records architectural decisions that affect later work.
