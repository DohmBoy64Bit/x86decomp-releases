# Document and filesystem contracts

## General rules

- JSON is UTF-8.
- JSON documents use `schema_version` integers.
- JSON Lines files contain one complete object per non-empty line.
- Hashes are lowercase hexadecimal SHA-256.
- Times use UTC RFC 3339 with a trailing `Z`.
- Tool outputs are immutable evidence once attached to a verified claim.
- Paths inside project documents are project-relative unless `source_kind` explicitly
  permits an external absolute path.

## Address representation

Canonical IDs use an unsigned 32-bit image-relative address:

```text
pe-rva:0001a2b0
```

Fields:

- `entry_rva`: integer suitable for sorting and arithmetic.
- `entry_rva_hex`: display-only hexadecimal.
- `entry`: Ghidra address string for provenance.
- `body_ranges`: sorted, non-overlapping half-open RVA intervals.

A range `{start_rva: 10, end_rva: 20}` contains ten bytes. The end is never inclusive.

## Project contract

`project.json` points to the immutable input, program manifest, memory ledger,
function root, and evidence root. Project verification reparses the binary and checks
selected fields against the recorded program manifest.

## Evidence file contract

When `evidence-add --file` is used, the file is copied into
`evidence/files/<evidence-id>_<sanitized-name>`. The evidence document stores a
project-relative path, size, original filename, and SHA-256 digest. Verification
resolves the path under the project root and rejects path escape. Editing the original
outside file does not alter captured evidence; editing the captured copy invalidates
the claim gate.

## Function artifact contract

A function artifact contains:

- `function.json`: identity and analysis metadata.
- `ranges/*.bin`: exact bytes for each Ghidra body range.
- `instructions.jsonl`: structured instruction listing.
- `listing.asm`: human-readable listing.
- `references.jsonl`: Ghidra static references from addresses in the body.
- `decompiler.c`: Ghidra source candidate or explicit failure comment.
- `high-pcode.txt`: textual High P-code when available.
- `context.h`: conservative context without fabricated extern types.
- `integrity.json`: hashes created during import into a toolkit project.

The decompiler and P-code files are analysis products. Raw range bytes remain the
stronger evidence.

## Evidence independence contract

`independent_group` identifies a shared failure domain. Examples:

- `raw-image`
- `ghidra-12.1-analysis-A`
- `capstone-5-independent-decode`
- `msvc-compiler-run-42`
- `runtime-trace-vm-7`
- `pdb-build-guid-...`

Two Ghidra scripts querying the same database normally share an independence group.
Changing formatting does not create independence.

## Compiler profile contract

Arguments are a JSON array. `{source}` and `{output}` must each be present as complete
array elements or substrings. Expansion is direct string replacement. No shell,
command substitution, wildcard expansion, or pipeline processing occurs.

## Verification report contract

`equal` is the authoritative byte-equality result. `sequence_similarity` is diagnostic
only. `semantic_equivalence_claimed` is fixed to false in the current implementation.
