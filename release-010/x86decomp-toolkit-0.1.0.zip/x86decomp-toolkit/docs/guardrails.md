# Guardrails and failure policy

## Anti-hallucination guardrails

- Never infer an original name from readability alone.
- Never convert Ghidra `undefined4` into a specific signed or pointer type without
  evidence.
- Never state that a static call graph is complete when indirect calls remain.
- Never describe a decompiler reconstruction as original source.
- Never call a finite test corpus a proof.
- Never convert “not observed” into “does not exist.”
- Never silently repair malformed input; fail with the violated contract.
- Never hide external-tool stderr or failed return codes.

## Ghidra MCP policy

1. Begin in read-only mode.
2. Export the relevant function artifacts before mutation.
3. Apply one conceptual change per transaction.
4. Record before/after names, types, comments, and structures.
5. Re-run analysis only when required and record that analysis state changed.
6. Re-export and diff affected artifacts.
7. Avoid bulk renaming from an LLM-generated list without independent review.
8. Treat MCP tool output as tool output, not external corroboration of the same Ghidra
   state.

## Unknown-binary execution policy

The core never executes a target. Dynamic work must specify:

- isolated VM/container boundary;
- snapshot or reset procedure;
- network policy;
- filesystem policy;
- deterministic inputs;
- capture method;
- timeout and kill behavior;
- target hash.

## Failure policy

Unsupported or uncertain behavior must fail explicitly. A command may return partial
results only when the report names each failure. Silent omission is prohibited for
project manifests, function artifacts, and verification reports.
