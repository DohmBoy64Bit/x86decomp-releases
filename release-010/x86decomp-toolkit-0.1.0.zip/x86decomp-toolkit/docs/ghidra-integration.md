# Ghidra integration

## Compatibility

The scripts are written for current Ghidra scripting APIs and target Ghidra 12.1 as
the documented baseline. Run `scripts/verify-ghidra.sh` against the installed Ghidra
version and a permitted PE32 fixture before adoption.

## Headless export

`x86decomp ghidra-export` constructs an argument array for `analyzeHeadless`. It does
not invoke a shell. Set `GHIDRA_HOME` or pass `--ghidra-home`.

The order is:

1. Import the binary.
2. Allow Ghidra auto-analysis.
3. Run `ExportProjectManifest.java`.
4. Run `ExportFunctionArtifacts.java`.

## Why raw range files matter

Ghidra functions use address sets. A body can have multiple ranges. Exporting one
`entry,max+1` interval may accidentally include unrelated bytes. Each range is
therefore written to a separate file and described with a half-open RVA interval.

## Decompiler output

`decompiler.c` is a starting candidate. It may contain synthetic types, temporary
variables, and control flow that differ from original source. The context file avoids
inventing extern prototypes or global widths.

## High P-code

The exporter records textual High P-code when decompilation succeeds. It is useful for
analysis and diagnostics but is not a stable cross-version serialization contract.
Future versions should add a versioned structured P-code export before making it a
long-lived interchange format.
