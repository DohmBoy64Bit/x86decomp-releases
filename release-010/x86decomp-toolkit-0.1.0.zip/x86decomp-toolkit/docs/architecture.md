# Architecture

## Design objective

The toolkit orchestrates evidence, analysis, source candidates, compiler experiments,
and verification. It does not replace a decompiler and does not claim to reconstruct
information absent from the binary.

## Components

### 1. Immutable input layer

`original/` contains the copied target or `project.json` records an explicit external
reference. The SHA-256 digest is authoritative. Any digest change invalidates the
project audit until a new project is intentionally created.

### 2. PE32 ingestion

`x86decomp.pe32` parses native i386 PE32 files with bounded reads. It extracts header
fields, sections, data directories, imports, exports, base relocations, CodeView
records, and PE32 TLS callbacks. Unsupported machine types and PE32+ are rejected.

### 3. Ghidra analysis adapter

The Java scripts export analysis facts without treating them as ground truth:

- `ExportProjectManifest.java` exports program, section, function, symbol, and metric
  documents.
- `ExportFunctionArtifacts.java` exports raw bytes by exact body range, instruction
  records, references, decompiler output, high P-code text, conservative context, and
  a function manifest.
- `QueryAnalysis.java` provides read-only reference, disassembly, function, and caller
  queries.

### 4. Function artifact store

The canonical function key is its image-relative entry RVA. Function directories use
`pe-rva_XXXXXXXX`; manifests use `pe-rva:XXXXXXXX`. Exact range files prevent gaps
from being silently treated as code.

### 5. Compiler laboratory

Compiler profiles are data. They contain an executable name, argument array,
environment, timeout, language, and output kind. Execution captures the resolved tool
path, version line, command, source/output hashes, process result, stdout, and stderr.
No shell is invoked.

### 6. Verification layer

Version 0.1.0 implements exact byte comparison. The report records equality, hashes,
sizes, first mismatches, prefix/suffix equality, and a sequence similarity score. It
explicitly sets `semantic_equivalence_claimed` to false.

Future executable-aware comparison must model COFF relocations, PE references, import
symbols, branch targets, and address normalization. It is not represented as complete
in this package.

### 7. Evidence and claims

Evidence records preserve source, locator, assertion, kind, independence group, file
hash, observation time, and metadata. Claims preserve subject/predicate/object,
supporting and contradicting evidence, and state. The verification gate is explicit
and deterministic.

### 8. Project memory

Memory events are append-only JSON Lines. Each event includes the previous event hash,
and its own hash covers all unsigned fields. The Markdown summary is generated from
the ledger and is not authoritative.

## Dependency direction

```text
CLI
 ├─ project ── pe32
 ├─ compiler
 ├─ diffing
 ├─ evidence ── models
 ├─ memory
 ├─ ghidra ── tools
 └─ artifacts

all modules ── util/errors
```

The PE parser does not depend on Ghidra. Evidence does not depend on compiler output
formats. The Ghidra scripts do not import Python code. These boundaries keep analysis,
policy, and execution concerns separate.
