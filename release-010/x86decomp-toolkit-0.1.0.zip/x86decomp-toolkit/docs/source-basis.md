# Source basis and upstream boundaries

This package is newly written integration code. It does not vendor Ghidra, objdiff,
decomp.me, Capstone, LIEF, or ghidra-mcp.

Primary upstream references:

- Ghidra repository and releases: https://github.com/NationalSecurityAgency/ghidra
- Ghidra SLEIGH/P-code documentation: https://ghidra.re/ghidra_docs/languages/html/sleigh.html
- objdiff: https://github.com/encounter/objdiff
- decomp-toolkit template: https://github.com/encounter/dtk-template
- decomp.me: https://github.com/decompme/decomp.me
- ghidra-mcp: https://github.com/bethington/ghidra-mcp
- Capstone documentation: https://www.capstone-engine.org/documentation.html
- LIEF PE documentation: https://lief.re/doc/latest/formats/pe/index.html
- Microsoft PE/COFF specification page: https://learn.microsoft.com/windows/win32/debug/pe-format

Before copying upstream code, inspect the exact revision and license. Tool names in
this repository identify integrations or factual context and do not imply endorsement.
