# Supported scope and non-goals

## Initial supported target

- Native Windows PE32.
- `IMAGE_FILE_MACHINE_I386`.
- User-mode executables and DLLs.
- Conventional C and C++ produced by recognizable compilers.
- Unpacked, statically analyzable code.
- Function-oriented incremental decompilation.

## Rejected by the core parser

- PE32+ / x86-64.
- ARM, ARM64, MIPS, PowerPC, or other machines.
- .NET/CLR as a managed-code workflow.
- Malformed files that exceed declared bounds.

## Not promised by the toolkit

- Original identifiers, comments, macros, formatting, templates, or translation units.
- Complete class recovery.
- Correct function boundaries in every optimized binary.
- Resolution of all indirect branches or calls.
- Whole-program semantic proof.
- Whole-image byte-identical relinking.
- Compatibility with packers, virtualization, encrypted sections, DRM, or intentional
  anti-analysis.
- Safe host execution of unknown binaries.

## Meaning of validation labels

- `compiles`: the configured compiler accepted the candidate.
- `byte_matched`: compared byte sequences were identical.
- `instruction_similar`: a normalized instruction comparator reported similarity.
- `differentially_tested`: observed outputs matched for recorded tests.
- `bounded_symbolic_check`: a solver checked a constrained model.
- `integration_tested`: selected application scenarios completed as expected.

None of these labels means “original source recovered.”
