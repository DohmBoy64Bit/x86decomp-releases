# Build and verification

## Core verification

```bash
make verify
```

This compiles all Python source to bytecode and runs the standard-library test suite.
The tests include a generated minimal PE32 fixture, project tamper detection, evidence
independence, memory-chain tamper detection, compiler profile execution when GCC is
available, and exact byte comparison.

## Ghidra verification

```bash
GHIDRA_HOME=/opt/ghidra_12.1.2_PUBLIC \
  scripts/verify-ghidra.sh sample.exe /tmp/x86decomp-ghidra-test
```

The script imports the target, runs both exporters, and parses generated JSON. Use a
legally redistributable fixture in CI.

## Reproducibility record

For every compiler run preserve:

- profile ID and profile file revision;
- resolved compiler path;
- compiler version line;
- full argument array;
- environment overrides;
- source hash;
- output hash and size;
- stdout, stderr, return code, timeout state.

For every byte comparison preserve both hashes, file paths or artifact IDs, and the
complete report.
