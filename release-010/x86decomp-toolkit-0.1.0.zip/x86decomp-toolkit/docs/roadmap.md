# Roadmap

## Phase 1 — delivered template

- PE32 ingestion and project integrity.
- Ghidra manifests and per-function artifacts.
- Compiler profiles.
- Exact byte comparison.
- Evidence claims and project memory.

## Phase 2 — x86 instruction/reference IR

- Independent Capstone or Zydis decoding.
- Structured operands, implicit register effects, and control-flow edges.
- Reference normalization for direct branches, imports, image addresses, and known
  globals.
- Cross-checks between Ghidra and the independent decoder.

## Phase 3 — COFF object support

- COFF parser.
- Section, symbol, COMDAT, and relocation contracts.
- Candidate function extraction from compiler objects.
- Direct linked-PE function versus COFF function comparison.

## Phase 4 — compiler matching laboratory

- User-supplied historical MSVC profiles.
- Flag-search experiment queue.
- Cached build matrix.
- Calling-convention and stack-cleanup checks.
- Floating-point and exception-model recording.

## Phase 5 — dynamic validation

- VM-controlled execution.
- Function coverage and indirect-target traces.
- Function harness generation for bounded leaf functions.
- State comparison with explicitly modeled memory.

## Phase 6 — relinking

- Synthetic target COFF objects only after relocation reconstruction is reliable.
- Section ordering, padding, resources, imports, RTTI, vtables, and static initializer
  reconstruction.
- Whole-image comparison as a target-specific capability, not a universal promise.

## Phase 7 — x86-64

Add PE32+, Windows x64 ABI, RIP-relative references, unwind information, and x64
exception metadata without weakening x86 contracts.
