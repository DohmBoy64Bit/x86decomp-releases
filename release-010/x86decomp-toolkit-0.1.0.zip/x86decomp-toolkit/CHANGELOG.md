# Changelog

## 0.1.0 — 2026-06-27

- Added project-owned immutable evidence copies and integrity path confinement.
- Added function-artifact import/verification CLI commands and path traversal tests.
- Added compiler executable hashing, unknown-token rejection, and stale-output removal.
- Added an explicit package verification record.

- Added a standard-library-only Python orchestration core.
- Added strict PE32/x86 parsing, project initialization, immutable hashes, and verification.
- Added evidence claims with a three-independent-source verification gate.
- Added tamper-evident project-memory events.
- Added compiler profile execution and byte-level verification reports.
- Added Ghidra project/function exporters and analysis query script.
- Added schemas, contracts, guardrails, CI, tests, and an agent skill.
