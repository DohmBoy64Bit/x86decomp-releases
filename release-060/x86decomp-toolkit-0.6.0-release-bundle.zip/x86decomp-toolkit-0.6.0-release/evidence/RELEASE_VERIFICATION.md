# v0.6.0 verification record

## Retained compatibility

The complete machine-readable 0.4.0 and 0.5.0 catalogs remain set-inclusion gates. The integrated legacy-compatible surface is 62 modules, 516 cataloged top-level functions/methods, 108 commands, 52 legacy schemas, three Ghidra scripts, 31 adapter contracts, and both matching and functional workflows. No baseline capability is recorded as removed.

## v0.6.0 delta

The project-scale plane contains 15 modules, 105 cataloged top-level functions/methods, 106 executable bodies including the nested header-cycle visitor, 67 leaf commands, and 12 namespaced JSON Schemas. Dedicated tests cover schema extension 5, modules, translation units, headers, build modes, provenance, edit reconciliation, ABI contracts, explicit shims, generated tests, capsules, library recognition, security findings, semantic changesets, all new command parsers, packaging, transactional upgrade, rollback, manifests, architecture maps, and retained-feature catalogs.

## Repository gates

Executed on 2026-06-30 with Python 3.13.5:

```text
complete repository collection: 214 passed, 0 failed, 0 skipped
standalone verifier repetition:   31 passed, 0 failed, 0 skipped
dedicated v0.6 collection:       26 passed, 0 failed, 0 skipped
recursive contracts/schemas:     passed
Python compileall:                passed
root and nested SHA-256 manifests: passed
```

## Comprehensive no-silent-skip harness

Run `run-20260630T140702498Z-c09a701b` completed with:

```text
PASS:    156
FAIL:      0
ERROR:     0
BLOCKED:   8
```

The blocked live adapters were container-runtime, dynamorio, ghidra, lief, llvm-readobj, msvc, objdiff, pip-audit. They were absent in this environment and were not omitted, skipped, or reported as passes. Non-strict mode returned zero because all implemented local gates passed; strict mode would return 2 while any declared adapter remains blocked.

No-omission and coverage results:

```text
retained-package function bodies: 516 / 516
legacy-compatible CLI commands:    108 / 108
v0.6 executable function bodies:   106 / 106
v0.6 leaf command parsers:           67 / 67
statement coverage:                78.61026707180554%
branch coverage:                   52.29957805907173%
```

The harness also built and clean-installed the toolkit wheel and source distribution and validated installed CLI and package data. A passing finite record does not establish original-source recovery, universal semantic equivalence, or live support for an unavailable external adapter.
