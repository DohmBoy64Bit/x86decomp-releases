x86decomp-toolkit 0.6.0 final release artifacts

Primary artifacts:
- x86decomp-toolkit-0.6.0-source.zip
- toolkit/x86decomp_toolkit-0.6.0-py3-none-any.whl
- toolkit/x86decomp_toolkit-0.6.0.tar.gz
- test-suite/x86decomp_test_suite-0.6.0-py3-none-any.whl
- test-suite/x86decomp_test_suite-0.6.0.tar.gz

Verification evidence is under evidence/. SHA256SUMS.txt covers every file in this directory except the aggregate bundle and its separate checksum.
