## v0.7.1 verification record

The sealed v0.7.1 source preserves byte-form assembly as the compatibility default and adds opt-in annotated and relocation-aware mnemonic modes. Mnemonic candidates are accepted only after COFF relocations are resolved against authoritative original RVAs and the resulting function bytes pass exact round-trip verification. Unsupported, noncanonical, or undecodable instructions remain explicit `.byte` escapes or whole-function byte fallbacks.

Verified source and upgrade gates:

- 270 integrated tests passed with zero failures and zero skips;
- 40 independently repeated standalone verifier tests passed with zero failures and zero skips;
- 23 dedicated toolkit-side v0.7.1 tests and 4 dedicated standalone release-contract tests passed;
- 64 retained-package modules, 518 retained top-level function/method symbols, 110 retained-plus-additive legacy commands, 52 legacy schemas, three Ghidra scripts, and 31 adapter contracts match the machine-readable catalog;
- 518/518 retained top-level package bodies, 142/142 v0.5 bodies, 105/105 v0.6 bodies, 74/74 v0.7 bodies, and 68/68 v0.7.1 bodies executed under coverage;
- all 12 v0.7.1 leaf commands parse independently and all five v0.7.1 schemas validate;
- a pristine final v0.7.0 source tree passed the same 270 + 40 staged gates before the transactional upgrade committed;
- nested test-suite and root SHA-256 manifests verify in nested-first order.

The comprehensive no-silent-skip harness reported 162 PASS, 0 FAIL, 0 ERROR, and 8 explicit BLOCKED external integrations. Statement coverage was 79.18148272391815% and branch coverage was 53.47902097902098%, above the retained 70% and 50% floors.

The blocked integrations were container runtime, DynamoRIO, Ghidra, LIEF, llvm-readobj, historical MSVC, objdiff, and pip-audit. They were absent from the release host, remained visible, and were neither skipped nor counted as passes. Strict mode treats any blocked integration as a non-zero release result.

No v0.7.0 or earlier capability is recorded as removed. `--asm-format bytes` remains the unchanged default; `annotated` and `mnemonic` are additive opt-in modes. Release packaging must additionally verify the deterministic source ZIP, toolkit and test-suite wheels/source distributions, clean-installed entry points, and the installed-wheel embedded transactional upgrade.
