# Architecture

## Objective

Provide one reproducible project that coordinates binary evidence, Ghidra analysis,
independent decoding, linker/compiler metadata, candidate source, compilers, matching
validators, functional validators, human/AI work and durable memory.

The architecture does not define “decompiled” as one boolean. It stores two independent
per-function modes and a chain of narrowly defined validation states.

## Data flow

```text
Original PE32/PE32+ + optional PDB/MAP/OBJ/LIB/reference image
  -> immutable hashes and bounded format manifests
  -> Ghidra project + exact function artifacts
  -> independent Capstone decode and cross-check
  -> COFF/bigobj/archive/COMDAT/linker-layout reconstruction evidence
  -> RTTI/vtable/TLS/exception/static-initializer/PDB evidence
  -> global symbol/reference/type/ABI database
  -> candidate C/C++/assembly + hybrid fallback tree
  -> compiler profile / version / flag experiment matrix
  -> matching validators
       PE bytes <-> COFF symbol
       relocation-normalized instructions/CFG
       exact bytes
       patched image
       manifest relink
       target-specific whole-image profile
  -> functional validators
       ABI observations
       Unicorn differential harness
       DynamoRIO coverage
       built-in Z3 bounded symbolic comparison
       optional angr region/alias comparison
       manifest-driven integration scenarios
  -> evidence, claims, work-queue acceptance and function status
  -> hash-chained project memory
```

## Layers and ownership

### Immutable input

The binary and attached evidence are content-addressed. A changed hash creates a new
artifact; it never silently updates an existing fact. Authorized test bundles are
inspected without executing supplied binaries and reject traversal, links, undeclared
files and resource-limit violations.

### PE ingestion

`pe32.py` and `pe.py` perform bounded parsing without executing the image. The parser
supports i386 PE32 and AMD64 PE32+ and records sections, directories, imports, delay
imports, exports, resources, base relocations, CodeView debug records, TLS callbacks,
load configuration and x64 runtime-function entries.

### Linker and debug evidence

`coff.py` parses classic COFF and bigobj sections, symbols, auxiliary records,
relocations, weak externals and COMDAT metadata. `coff_archive.py` inventories archive
symbol indexes, long names, import objects and embedded COFF members.
`linker_layout.py` parses map evidence while distinguishing symbol ordering from exact
section contributions. `pdb.py` parses the bounded MSF/PDB directory, identity,
TPI/IPI headers and DBI module/contribution/source mappings; it does not pretend to
implement complete CodeView semantics.

### Ghidra adapter

Ghidra remains the primary decompiler and static-analysis engine. Java exporters write
stable JSON/JSONL and exact range bytes. They preserve discontiguous function bodies
and expose raw/high P-code. The decompiler token tree is exported separately from
rendered C so consumers can retain token/address structure.

### Independent decoder

Capstone provides an independent instruction stream. It is used for operand/branch
normalization, CFG edges, fast indexing and disagreement detection. It is not used as
a source of C types or semantic proof.

### Windows C++ metadata

`msvc_metadata.py` provides bounded RTTI, vtable, PMD/class-hierarchy, x64 unwind,
x86 SafeSEH/exception-candidate, TLS and `.CRT$X*` initializer inventories. Every
record retains location and confidence/provenance; malformed or unsupported variants
remain explicit unknowns.

### Analysis database

SQLite owns cross-function entities, references, ABI records and type constraints.
Constraints retain provenance and conflict state. No LLM or MCP server owns canonical
project state.

### Function workflows

`workflow.json` owns the two independent mode states, active candidate, compiler
profile, report links and blockers. State regressions require an explicit audited flag.

### Matching subsystem

The executable-aware diff extracts a PE RVA range, extracts a COFF symbol, masks only
modeled address-dependent fields, compares normalized instructions/CFG and emits a
classification. Synthetic COFF output is available where the caller supplies the
reconstructed layout and relocations. Whole-image comparison uses a hash-bound,
target-specific profile; only declared nondeterministic fields are normalized. A
manifest-driven objdiff adapter executes a user-pinned CLI/configuration and captures
complete provenance.

### Functional subsystem

Unicorn executes function bytes in a declared memory/register/stack harness. Built-in
symbolic comparison supports a bounded x86/x64 leaf-function subset over explicit
symbolic inputs. The optional angr backend adds declared byte-addressed memory regions
and finite equal/distinct/disjoint/may-alias choices. DynamoRIO captures observed
coverage from explicitly launched applications. The integration runner compares
declared process and file observations under explicit host consent or an external
isolation wrapper.

### Compiler ground truth

The corpus subsystem builds legally supplied C/C++ cases under registered compilers,
architectures, optimization levels and frame-pointer settings. It records exact source,
compiler executable/version, argv, environment and output hashes, then inventories the
resulting COFF metadata. Proprietary toolchains are referenced from user-owned
installations and are never redistributed.

### Build integration

The hybrid generator creates assembly fallback objects from immutable ranges and keeps
decompiler output out of the default build. The patch backend writes into a copy of a
PE only after optional hash gates. The relink backend invokes a declared linker with
declared objects and can compare the result under a declared image profile; it does not
silently infer original linker decisions.

### Governance

Evidence records and claim gates distinguish observations from inference. The MCP
gateway is read-only by default and uses a hash-approved transaction for mutation. The
work queue requires evidence plus named validator reports before acceptance. Project
memory records durable transitions in a tamper-evident chain.

## Dependency direction

```text
CLI/service
  -> project/workflow/work_queue
  -> PE/COFF/archive/PDB/map/Ghidra adapters
  -> compiler/corpus/hybrid/patch/relink/image-profile
  -> ABI/diff/dynamic/symbolic/coverage validators
  -> evidence/claims/memory

all modules -> util/errors
```

No validator may rewrite immutable evidence. No analysis backend may promote its own
output to verified fact. No AI proposal bypasses compiler/runtime/evidence gates.
