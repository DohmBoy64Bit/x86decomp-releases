# Roadmap

## Version 0.3 production-depth baseline

Version 0.3 delivers the next depth milestones on top of the complete 0.2 command
surface:

- classic COFF and bigobj parsing, broader i386/AMD64 relocation semantics,
  relocation overflow, auxiliary symbol records, weak externals, all standard COMDAT
  selection policies and associative COMDAT relationships;
- bounded COFF archive (`.lib`/`.a`) parsing, linker symbol tables, long-name tables,
  import-object recognition and embedded-object inspection;
- MSVC/LLD map parsing with explicit distinction between public-symbol ordering and
  byte-accurate section-contribution evidence;
- target-specific whole-image profiles, rebasing and normalization of declared
  timestamp, checksum, certificate and debug fields;
- x86/x64 MSVC RTTI, vtable, PMD/class-hierarchy, TLS, static-initializer, SafeSEH,
  unwind and bounded exception-metadata inventory;
- bounded PDB/MSF 7.0 inventory including PDB identity, TPI/IPI headers, DBI modules,
  section contributions, source mappings and PE RSDS GUID/age correlation;
- a 24-case built-in C/C++ ABI/code-generation corpus spanning x86/x64,
  optimization levels and frame-pointer configurations, plus compiler/version and
  output hashing;
- richer angr symbolic memory regions, finite alias choices, disjoint/equal/may-alias
  relationships, byte-addressed memory observations and counterexample reports;
- a non-executing authorized test-bundle format covering PE, COFF, archives, PDB,
  map and whole-image comparison artifacts;
- permanent v0.2 command and schema compatibility tests.

## Next target-specific production milestones

These are depth and deployment tasks, not absent architecture boxes:

1. Decode full CodeView type, global/public symbol and named-stream records from PDBs,
   retaining byte offsets and provenance for every recovered fact.
2. Expand x86 exception-state maps and x64 language-specific handler data for each
   supported compiler/version family.
3. Model linker directives, default libraries, incremental-link metadata, ICF/LTCG
   evidence, SAFESEH tables and archive-resolution order for selected target projects.
4. Add compiler-specific object-layout solvers that can reproduce section groups,
   padding, import-library decisions and final image ordering for a named target.
5. Expand the symbolic ISA and environment summaries for heap objects, overlapping
   regions, Windows APIs, callbacks, threads and floating-point edge cases while
   preserving explicit path, memory and time bounds.
6. Execute the existing adapters against live Ghidra, DynamoRIO, objdiff and user-owned
   historical MSVC installations in reproducible CI workers.
7. Grow legally redistributable ground-truth corpora with source, exact toolchain
   identity, flags, objects, maps, PDBs and final images across compiler generations.
8. Complete at least one authorized real-world target through both a declared
   whole-image matching profile and a functional integration suite.

No roadmap item should be described as “100% automatic decompilation.” Production
readiness is target- and environment-specific and is measured through decomposed
metrics, immutable evidence and explicit unsupported cases.
