# Test-suite integration

The comprehensive harness is bundled inside the toolkit source repository while
remaining a separately installable Python project:

```text
x86decomp-toolkit/
  pyproject.toml
  src/
  tests/
  test-suite/
    pyproject.toml
    src/
    tests/
    docs/
    schemas/
```

Do not merge the two `pyproject.toml` files. Keeping the suite independent prevents
adapter-installation behavior and test-only dependencies from becoming runtime
dependencies of `x86decomp-toolkit`.

## Run from the bundled `test-suite/` directory

```bash
cd test-suite
python -m pip install -e ".[dev]"
x86decomp-test init-config \
  --toolkit-root .. \
  --output-root ./test-results \
  --config ./x86decomp-test.json
x86decomp-test run --config ./x86decomp-test.json --verbose
```

The generated `x86decomp-test.json`, `test-results/`, downloaded adapters, build
outputs, virtual environments, and coverage products are ignored and must not be
committed or packaged.

## Optional standalone checkout

The directory may also be copied beside the toolkit and renamed. In that layout,
point `--toolkit-root` at the toolkit checkout explicitly:

```text
workspace/
  x86decomp-toolkit/
  x86decomp-test-suite/
```

```bash
cd x86decomp-test-suite
python -m pip install -e ".[dev]"
x86decomp-test init-config \
  --toolkit-root ../x86decomp-toolkit \
  --output-root ./test-results \
  --config ./x86decomp-test.json
```

## CI release gate

Commit or generate a non-interactive configuration with explicit adapter paths supplied
by the CI image:

```json
{
  "strict": true,
  "interactive": false,
  "allow_network": false,
  "allow_install": false
}
```

A release CI environment should preinstall every required adapter. Exit code `2` means
an integration is unresolved and therefore untested; it is not a successful release
gate.
