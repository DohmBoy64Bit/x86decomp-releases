# Agent and contributor operating rules

These rules bind humans, coding agents and reverse-engineering agents working on this
repository or a generated project.

## 1. Truthfulness

Never encode a guess as recovered fact.

- Decompiler output is a candidate representation.
- AI-proposed names/types/source are proposals.
- A PDB/map/export name is original only when tied to the exact build by suitable
  identifiers and provenance.
- Static-reference absence is not proof of no runtime access.
- Three-source verification reduces unsupported claims; it does not guarantee truth.
- Byte equality, normalized equality, finite tests and bounded solver results are
  distinct properties.
- No completion claim may exceed the report's explicit scope statement.

Required epistemic labels: `observed`, `derived`, `proposed`, `corroborated`,
`verified`, `rejected`, `unknown`.

## 2. Two-mode separation

Every function may select `matching`, `functional`, or both.

Matching status:

```text
not_started -> decompiled -> compiles -> abi_compatible
            -> instruction_similar -> byte_matched
            -> image_integrated -> full_relink_validated
```

Functional status:

```text
not_started -> decompiled -> compiles -> abi_compatible
            -> differentially_validated
            -> symbolically_bounded
            -> integration_validated
```

Never promote one mode because the other advanced. State regressions require an
explicit audit event and preserved reason.

## 3. Evidence before mutation

Before a rename, prototype/type change, source promotion, PE patch or Ghidra write:

1. verify project and memory integrity;
2. capture the current exact function artifact;
3. create/identify evidence records;
4. state the narrow claim and expected validator;
5. apply one reversible conceptual change;
6. re-export/rebuild;
7. run named validators;
8. record outputs and status transition in memory.

Ghidra MCP writes require a tool allowlist, rationale, evidence IDs, persisted proposal
and exact approval-hash commit. Bulk writes are prohibited without a reviewed change
set and rollback plan.

## 4. Triple-check gate

A claim may be `verified` only with:

- at least three support records;
- at least three independent failure domains;
- at least two evidence kinds;
- valid content hashes;
- no unresolved contradiction;
- exact claim wording that does not overgeneralize.

Two reports derived from one Ghidra database are generally one independent group.
Multiple AI summaries are not independent evidence.

## 5. Address and artifact contracts

- Stable function ID: `pe-rva:XXXXXXXX`.
- Directory ID: `pe-rva_XXXXXXXX`.
- Ranges are unsigned, sorted and half-open.
- Preserve all discontiguous ranges.
- Ghidra address strings are display/provenance, not stable identity.
- Imported artifacts reject traversal and symlinks.
- Immutable evidence changes only by creating a new artifact/version.
- Classic COFF and bigobj use different symbol-record widths; never reinterpret one as
  the other after format detection.
- Linker public-symbol order is not byte-accurate contribution evidence.
- A whole-image normalization profile is valid only for its recorded reference hash.

## 6. Validator semantics

- `compiles`: declared compiler emitted the expected artifact.
- `abi_compatible`: every declared ABI check passed; it is not complete semantic proof.
- `instruction_similar`: versioned normalized decoder comparison passed.
- `byte_matched`: raw bytes in the stated scope are identical.
- `relocation_normalized_match`: equality after documented masks; never relabel as byte match.
- `differentially_validated`: all declared concrete harnesses passed.
- `symbolically_bounded`: selected model/backend returned equality within hard bounds.
- `integration_validated`: named scenarios passed in a recorded environment.
- `full_relink_validated`: declared linker/output gate passed, not automatic recovery of
  original linker decisions.
- `profile_normalized_match`: complete image equality after only named profile ranges;
  never call this byte identity.
- `COMDAT valid`: all selection and association rules passed for the supplied object set;
  it says nothing about objects that were not supplied.

## 7. Code quality

- No shell interpolation for external commands.
- Every external process has a timeout and captures stdout/stderr/return code.
- Hash compiler/linker/toolchain binaries and outputs.
- Use atomic writes for canonical documents where practical.
- JSON encoders must emit valid JSON, not C escape syntax.
- Treat all inputs as untrusted and enforce bounds/safety limits.
- Optional dependencies fail with explicit installation guidance.
- No fake implementation, empty success adapter, TODO branch or placeholder return may
  be represented as working capability.
- Tests must include malformed input, integrity failure and at least one positive real
  execution for each locally available backend.
- Every new schema must have a representative validated example or generated-report
  test.
- Preserve the previous release's CLI parser and state/schema compatibility tests.
- Archive readers must reject traversal, symlinks, duplicate names, size bombs and hash
  mismatches before analysis.

## 8. Dynamic and external execution

- Parsing, import and static export never execute the target.
- `dynamic-validate` emulates isolated bytes in Unicorn.
- `drcov-run` explicitly executes the selected program; use an isolated environment.
- `integration-run` requires explicit host consent or an external wrapper; unknown targets belong in a disposable VM.
- `objdiff-run`, compiler and linker profiles execute declared external tools and must preserve hashes and output.
- Unknown binaries must not run on a normal host.
- Historical/proprietary toolchains are operator-owned and referenced, never copied
  into the repository by the toolkit.
- Do not upload proprietary binaries/PDBs/source to public services by default.
- `test-bundle-create` and `test-bundle-inspect` are static-only; adding an artifact to a
  bundle never grants execution consent.
- PDB, map and object provenance must identify the exact image/build before their names
  can be promoted as build-authenticated evidence.

## 9. Linker, metadata and symbolic-depth rules

- Preserve every COFF relocation and auxiliary record; unknown forms remain raw evidence.
- Resolve COMDAT groups before using an object set to infer layout.
- Preserve ASSOCIATIVE parents and report selection conflicts rather than choosing a
  convenient winner.
- RTTI/vtable scans require pointer, section, count and executable-slot validation.
- x64 UNWIND_INFO proves unwind metadata, not source-level exception constructs.
- x86 FuncInfo scans remain candidates until handler-specific fields are validated.
- Keep linked TLS records separate from `.tls$*` and `.CRT$XL*` object subsections.
- Static initializer relocation symbols are candidate initializer targets, not proof of
  constructor semantics.
- Symbolic alias models must record region bases, sizes, alignments, relations,
  observations, bounds and truncation. Truncated exploration cannot pass a completed
  bounded-equivalence gate.
- Compiler-corpus byte similarity is code-generation evidence, not a compiler identity
  oracle.

## 10. AI work

AI can draft source, names, types, tests and compiler experiments. AI output cannot:

- count as evidence;
- accept its own work;
- mutate canonical state directly;
- hide contradictory evidence;
- invent unsupported API/tool behavior;
- skip required validators.

The work queue accepts a proposal only after all required validator reports pass.

## 11. Completion

A change is complete only when:

- implementation, schemas, examples, docs and skill agree;
- `make verify` passes;
- external integrations not available locally are clearly identified and have an
  executable verification procedure;
- no supported feature is merely documentation;
- unsupported/general-unsolved behavior is explicit;
- durable architectural decisions are recorded in project memory.
