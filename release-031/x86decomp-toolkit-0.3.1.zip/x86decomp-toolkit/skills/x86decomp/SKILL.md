---
name: x86decomp-evidence-engineer
description: Evidence-first operating contract for matching and functional decompilation of authorized native Windows x86 and x86-64 PE projects.
version: 3.1.0
license: Apache-2.0
compatibility: Python 3.11+, Ghidra 12.1 baseline, native PE32/i386 and PE32+/AMD64 targets
metadata:
  modes:
    - matching
    - functional
  architectures:
    - x86
    - x86_64
  release_contract: 0.3.1
  evidence_gate: three-independent-source
  execution_default: static-only
tags:
  - reverse-engineering
  - decompilation
  - x86
  - x86-64
  - pe
  - coff
  - ghidra
  - evidence
  - matching
  - differential-validation
---

# x86decomp evidence engineer

## Purpose

Use this skill to create, inspect, and advance an x86decomp-toolkit project while
preserving a strict boundary between observations, inferences, source candidates, and
verified properties.

The objective is not to claim automatic recovery of original source. The objective is
to produce a reproducible project in which every important assertion has provenance,
every source candidate is testable, and every status means one narrowly defined thing.

## Supported operating scope

The built-in static parsers support these image families:

- Native Windows PE32 / IMAGE_FILE_MACHINE_I386.
- Native Windows PE32+ / IMAGE_FILE_MACHINE_AMD64.
- Conventional user-mode C or C++ code.
- Classic COFF and ANON_OBJECT_HEADER_BIGOBJ object files for i386 and AMD64.
- Unpacked, non-virtualized images whose bytes can be analyzed without bypassing DRM.
- Function-oriented incremental matching and functional decompilation.
- Target-specific whole-image comparison under an explicit layout profile.
- Authorized artifacts only.

The preferred initial target remains an unpacked native PE32/i386 application built by
a recognized MSVC-compatible compiler. PE32+/AMD64 is supported, but x64 unwind,
exception, and RIP-relative behavior require architecture-specific evidence.

Stop and report `unsupported_scope` when an input is managed CLR, ARM or another
unsupported machine, kernel-only, packed or virtualized beyond the configured parser,
intentionally self-modifying, malicious or suspected malicious, or requires bypassing
access controls. Never execute an uploaded Windows image on the host merely because it
parses successfully. Use the static test-bundle path unless the user has separately
provided an isolated execution contract.

## Non-negotiable truth rules

1. Never say “original source” unless an exact source artifact from the same build is
   independently authenticated.
2. Never say “original name” because a proposed name is semantically plausible.
3. Never promote a Ghidra type, decompiler signature, or AI suggestion directly to
   fact.
4. Never treat absence from a static reference database as proof that runtime access
   cannot occur.
5. Never call byte similarity semantic equivalence.
6. Never call finite differential tests a universal proof.
7. Never claim three-source verification guarantees truth. It is a governance gate
   designed to reduce correlated errors.
8. Never hide a failure, timeout, unsupported format, parser bound error, compiler
   diagnostic, or contradictory evidence.
9. Never create a fake implementation, empty adapter, TODO branch, placeholder return,
   or success response for an unimplemented subsystem.
10. Never execute the target binary outside an explicitly documented isolated dynamic
    analysis environment.

## Required vocabulary

Use these terms precisely:

- **Observed:** directly present in a captured artifact, byte sequence, tool output, or
  runtime trace.
- **Derived:** deterministically calculated from observed data.
- **Proposed:** a working interpretation that may be useful but is not verified.
- **Corroborated:** supported by at least two records but below the verification gate.
- **Verified:** passed the project verification gate for the exact claim stated.
- **Rejected:** contradicted or falsified for the tested artifact/version.
- **Unknown:** insufficient evidence.

Avoid vague terms such as “basically matched,” “probably exact,” “fully recovered,” or
“confirmed” without naming the exact verification property.

## Separation of concerns

Keep these layers distinct.

### Immutable evidence layer

Contains target bytes, hashes, imported symbols, debug records, captured compiler
outputs, traces, and external documents. Do not edit evidence in place. Create a new
record when an artifact changes.

### Analysis layer

Contains Ghidra functions, P-code, references, decompiler output, Capstone decoding,
and analyst annotations. Analysis may be wrong or change after reanalysis.

### Candidate source layer

Contains C, C++, assembly, headers, compiler profiles, and build scripts. Candidate
source is an attempted implementation, not evidence of original source.

### Verification layer

Contains compiler reports, byte comparisons, ABI checks, differential tests, bounded
symbolic checks, and integration results. Each verifier reports only its defined
property.

### Project-memory layer

Contains durable decisions, hypotheses, blockers, tool changes, and status transitions
in an append-only hash chain. Memory references evidence; it does not replace evidence.

### Agent layer

May propose names, types, source, experiments, and tests. Agent output is always a
proposal until an independent verifier or evidence gate promotes the specific claim.

## Mandatory startup sequence

For any new task:

1. Read `project.json`.
2. Run `x86decomp verify-project <project>`.
3. Run `x86decomp memory-verify <project>`.
4. Read the generated `memory/PROJECT_MEMORY.md`.
5. Identify the exact stable IDs affected.
6. Inspect current function artifacts and integrity reports.
7. State the requested outcome as a measurable property.
8. Select the smallest workflow that can test that property.

Do not mutate Ghidra or candidate source before project integrity is valid.

## Stable identity rules

- Function IDs use `pe-rva:XXXXXXXX`.
- Directory form uses `pe-rva_XXXXXXXX`.
- RVA is unsigned and image-relative.
- Body ranges are sorted, non-overlapping, and half-open.
- A Ghidra address string is provenance/display, not the cross-build key.
- A function body may contain multiple discontiguous ranges.
- Never fabricate one enclosing byte interval as the function body.

## Triple fact-check protocol

A claim may reach `verified` only when all checks pass.

### Check A — evidence count

At least three evidence records support the same narrowly worded claim.

### Check B — independence

At least three independent groups are represented. Independence means different
failure domains, not different files. Examples:

- raw binary decoding;
- a Ghidra analysis database;
- independent Capstone/Zydis decoding;
- compiler output;
- a matching PDB tied by GUID/age;
- a runtime trace from an isolated run;
- authoritative format documentation.

Two scripts reading the same Ghidra program are normally one group. Two LLM summaries
of the same decompiler text are one group. Two compiler runs using identical source,
flags, and compiler build are one group unless the claim specifically concerns run
reproducibility.

### Check C — evidence diversity

At least two evidence kinds must be present. Three static-analysis reports are not
enough even when produced by separate tools.

### Check D — integrity

All file-backed evidence hashes must still match.

### Check E — contradiction handling

No unresolved contradiction evidence may remain attached. Contradiction does not get
ignored because supporting evidence is more numerous. Resolve the scope, version,
input, or interpretation first.

### Check F — exact claim wording

Verify only the narrow property tested. Examples:

- Good: `pe-rva:00012340 has callee stack cleanup of 8 bytes`.
- Bad: `pe-rva:00012340 is definitely __stdcall and fully understood`.
- Good: `candidate bytes equal target range 0 for compiler profile X`.
- Bad: `function is completely matched` when other ranges or relocations were not checked.

## Claim workflow

1. Capture evidence with `x86decomp evidence-add`.
2. Create the claim with `x86decomp claim-create`.
3. Attach evidence with `x86decomp claim-attach`.
4. Attach contradictions with `x86decomp claim-contradict`.
5. Run `x86decomp claim-verify`.
6. Read the failure list.
7. Promote downstream state only when the exact required claim is `verified`.
8. Record the transition in project memory with evidence IDs.

## Function workflow

Every function has two independent mode records. A function may advance in one mode
while remaining unknown in the other. Never infer one mode's status from the other.

### Matching mode state machine

```text
not_started
  -> decompiled
  -> compiles
  -> abi_compatible
  -> instruction_similar
  -> byte_matched
  -> image_integrated
  -> full_relink_validated
```

Definitions:

- `not_started`: no matching candidate is selected.
- `decompiled`: an identified candidate source or assembly artifact exists.
- `compiles`: a hash-recorded compiler profile produced the expected object artifact.
- `abi_compatible`: the configured calling convention, stack behavior, return channel,
  and required preserved registers passed the bounded ABI contract.
- `instruction_similar`: the PE function and COFF symbol passed the named normalized
  instruction/CFG comparison. This is not byte equality.
- `byte_matched`: the exact target function bytes and the candidate symbol bytes match
  under the recorded relocation policy. State whether the result is raw or normalized.
- `image_integrated`: the candidate was incorporated into a hash-pinned copy or hybrid
  image and the integration report passed.
- `full_relink_validated`: the complete relink completed and passed the target-specific
  image profile and required integration checks.

### Functional mode state machine

```text
not_started
  -> decompiled
  -> compiles
  -> abi_compatible
  -> differentially_validated
  -> symbolically_bounded
  -> integration_validated
```

Definitions:

- `differentially_validated`: original and candidate agreed for the exact Unicorn or
  other concrete harness inputs and observations recorded in the report.
- `symbolically_bounded`: no counterexample was found, or equivalence was established,
  only within the completed symbolic model, path bounds, memory model, alias policy,
  external summaries, and observations stated in the report.
- `integration_validated`: target and candidate application scenarios agreed for the
  exact process wrapper, inputs, exit status, streams, files, and environment captured.

### Shared source stage

Track source maturation independently from mode status:

```text
original_bytes
  -> generated_assembly
  -> decompiler_candidate
  -> human_candidate
  -> accepted_candidate
```

An `accepted_candidate` is accepted for a specific mode and validation scope. It is not
necessarily original source and need not be accepted for the other mode.

### Monotonicity and regression

- Status transitions are monotonic by default.
- A regression requires `--allow-regression`, an explanation, and a memory event.
- Replacing a compiler profile, source candidate, normalization profile, or harness
  invalidates downstream results unless report hashes remain exactly applicable.
- A passing report from another binary hash, architecture, function range, or candidate
  hash cannot be reused.

### Required report attachment

Attach the exact report that justifies each transition:

- `compiles` -> compiler report.
- `abi_compatible` -> ABI report.
- `instruction_similar` -> executable-to-COFF diff report.
- `byte_matched` -> raw or relocation-normalized byte report.
- `differentially_validated` -> concrete execution report.
- `symbolically_bounded` -> symbolic report including truncation state.
- `integration_validated` -> integration scenario report.
- image states -> patch/relink and whole-image reports.

## Ghidra read workflow

Prefer the bundled read-only scripts or read-only ghidra-mcp operations.

For a function:

1. Read `function.json`.
2. Read exact range bytes.
3. Read `instructions.jsonl`.
4. Read `references.jsonl`.
5. Read `decompiler.c` as a candidate representation.
6. Read `high-pcode.txt` for data-flow questions.
7. Query callers and target references where required.
8. Cross-check suspicious decoding with an independent decoder.

Do not reason solely from decompiler C when raw instructions or references answer the
question more directly.

## Ghidra mutation workflow

Default to no mutation.

Before a rename, prototype change, structure creation, comment, or data definition:

1. Export the affected artifact.
2. Record proposed claims and evidence.
3. Write a reversible change plan.
4. Use one transaction for one conceptual change.
5. Avoid mass changes from generated lists.
6. Re-run only the necessary analysis.
7. Re-export affected artifacts.
8. Compare before/after manifests.
9. Run downstream compiler or verification checks.
10. Record the change and rollback route in memory.

When using ghidra-mcp, do not count its write response as independent evidence that the
new type or name is correct.

## Naming policy

Names have provenance:

- `DEFAULT`: generated by Ghidra or importer.
- `IMPORTED`: from export/import metadata.
- `DEBUG`: from authenticated debug information.
- `ANALYST_DESCRIPTIVE`: useful human name, not claimed original.
- `AI_PROPOSED`: generated suggestion awaiting review.
- `ORIGINAL_VERIFIED`: reserved for authenticated same-build evidence.

Use semantic descriptive names freely when helpful, but record that they are analyst
or AI names. Never erase the stable function ID.

## Type policy

Track type properties independently:

- width;
- signedness;
- pointer versus integer;
- pointee type;
- constness;
- aggregate layout;
- field offsets;
- calling convention;
- parameter storage;
- return storage.

A verified width does not verify signedness. A verified field offset does not verify
the original field name. A vtable-like call does not alone verify a complete C++ class.

## Compiler experiment workflow

1. Select an explicit profile.
2. Confirm the executable path and version.
3. Hash the source.
4. Run through `x86decomp compile`; never construct an unrecorded shell command.
5. Preserve stdout and stderr.
6. Confirm output kind before comparison.
7. Extract the intended function or section using a versioned method.
8. Compare exact bytes and/or normalized instructions as separate reports.
9. Modify one source/compiler variable per experiment when identifying causality.
10. Record successful and failed experiments when they affect future strategy.

A historical proprietary compiler must be user-supplied and legally available. Do not
bundle it.

## Byte comparison rules

The bundled comparator answers only whether two supplied byte strings are equal.

- `equal=true` means identical length and content.
- Similarity is diagnostic.
- Mismatch truncation must be disclosed.
- File extraction boundaries must be recorded.
- Comparing a full COFF object to function bytes is invalid.
- Comparing linked PE bytes to compiler bytes without handling references/relocations
  may produce expected mismatches; do not “normalize” them ad hoc.

## objdiff integration policy

objdiff is designed around relocatable object comparisons. Use it when both sides are
appropriate object files and the project configuration accurately identifies units and
symbols. Do not present objdiff as direct proof against an arbitrary linked PE unless a
separate, documented target-object reconstruction pipeline produced the target object.

Capture:

- objdiff version;
- configuration revision;
- target and candidate hashes;
- selected symbol/unit;
- architecture backend;
- complete report.

## decomp.me policy

Use local per-function packets as the default integration. Before uploading anything:

- confirm operator authorization;
- inspect whether target assembly or context contains proprietary material;
- confirm service/privacy policy appropriate for the project;
- minimize the submitted fragment;
- record the upload decision.

Do not automate public upload in a default workflow.

## Capstone policy

Capstone is an independent decoder, not a decompiler or equivalence prover. Use it for:

- independent instruction boundaries;
- mnemonic/operand extraction;
- direct branch targets;
- display and indexing;
- cross-checking Ghidra.

Record architecture, mode, syntax, version, input bytes, and start address. Incorrect
mode or address produces misleading output.

## Dynamic validation policy

Dynamic validation requires an isolation plan. Before execution record:

- exact target hash;
- VM/container image;
- snapshot identifier;
- network state;
- input corpus;
- environment variables;
- filesystem mounts;
- timeout;
- trace instrumentation;
- expected cleanup/reset.

Dynamic results are observations for the executed paths and inputs only.

## Symbolic validation policy

Use symbolic or concolic execution for bounded functions with explicit state models.
Record:

- architecture semantics;
- memory model;
- unconstrained inputs;
- path bounds;
- loop bounds;
- external-call summaries;
- solver timeout;
- satisfiable counterexamples.

A timeout or path explosion is `unknown`, not success.

## Project memory workflow

Append memory after durable events, not every trivial command.

Required durable events:

- project initialization;
- architecture decisions;
- compiler-profile discoveries;
- function state promotions or reversions;
- accepted/rejected ABI or type claims;
- discovered packer/self-modification/exception complexity;
- tool version change affecting output;
- legal/security constraints;
- blocker creation and resolution.

A memory event should include stable IDs, old/new state, evidence IDs, exact result,
and rollback information. Verify the hash chain before appending.

## Context and efficiency optimization

To minimize irrelevant context without sacrificing evidence:

1. Work one function or one tightly connected call cluster at a time.
2. Load the manifest before large text outputs.
3. Prefer structured JSONL filters over full decompiler dumps.
4. Read only referenced ranges and callers needed for the claim.
5. Reuse stable IDs in notes and commands.
6. Summarize prior experiments in memory, linking reports rather than pasting them.
7. Generate compiler matrices programmatically but inspect only changed outcomes.
8. Keep raw evidence immutable and derive compact indexes.
9. Separate display artifacts from machine contracts.
10. Stop an experiment branch when its falsifying evidence is conclusive.

Optimization must never remove provenance, failure output, hashes, or contradiction
records.

## Required response structure for analytical work

When reporting a result, use this order:

1. **Finding:** narrow statement.
2. **Status:** observed, proposed, corroborated, verified, rejected, or unknown.
3. **Evidence:** stable evidence IDs and relevant artifact locations.
4. **Checks performed:** commands/reports and exact measured properties.
5. **Contradictions/limitations:** anything unresolved.
6. **Project changes:** files, Ghidra mutations, source changes, or state transitions.
7. **Next highest-value experiment:** one concrete action only when needed.

Do not bury uncertainty after a confident headline.

## Failure and escalation rules

Stop and report rather than improvise when:

- project integrity fails;
- memory hash chain fails;
- function body ranges overlap unexpectedly;
- binary hash differs from all recorded artifacts;
- Ghidra and independent decoding disagree on instruction boundaries;
- a compiler profile invokes an unexpected executable;
- evidence files changed after verification;
- contradiction evidence exists;
- target execution would be required without isolation;
- legal authorization is unclear;
- the requested claim exceeds implemented verifier capability.

Escalation report must name the failed contract, affected stable IDs, artifacts needed
to resolve it, and whether existing conclusions are invalidated.

## COFF, COMDAT, and linker-layout contract

### COFF parsing

For every object used in matching:

1. Record whether it is classic COFF or bigobj.
2. Record machine type and object hash.
3. Preserve section characteristics, alignment, raw bytes, symbols, auxiliary records,
   relocations, addends, relocation-overflow state, and string-table names.
4. Resolve weak externals only according to their auxiliary record; do not treat an
   undefined external as weak without that evidence.
5. Preserve section-definition checksums and COMDAT selection values.
6. Reject unsupported or malformed records instead of guessing their length.

### COMDAT resolution

Run `coff-comdat-resolve` across all participating objects. Apply NODUPLICATES, ANY,
SAME_SIZE, EXACT_MATCH, ASSOCIATIVE, LARGEST, and NEWEST according to the recorded
selection. A resolution with conflicts is not a valid linker-layout claim. An
ASSOCIATIVE section must retain its parent relationship.

### Linker map evidence

A map public symbol establishes a named symbol address and usually its object owner. It
does not by itself establish the full byte extent of the object's contribution.
Distinguish:

- `object_order_evidenced`: public or contribution records establish an order.
- `byte_accurate_contributions_evidenced`: explicit contribution ranges exist.
- `complete_original_layout_claimed`: must remain false unless every gap, padding,
  merged subsection, discarded COMDAT, and linker-generated record is accounted for.

Do not infer original translation-unit boundaries solely from adjacent addresses.

## Microsoft C++ metadata contract

### RTTI and vtables

Treat a TypeDescriptor, CompleteObjectLocator, class hierarchy, and vftable as accepted
only after internal pointers, section membership, counts, and executable function
slots pass structural checks. Demangled display names are derived labels, not proof of
original source spelling. For multiple and virtual inheritance, preserve PMD fields,
locator offsets, hierarchy attributes, and all discovered address points.

A vtable scan must:

- require a validated locator pointer immediately before the address point;
- stop at the first invalid or non-executable function pointer;
- preserve slot order and RVA;
- attach linker-map symbols when available without inventing missing names;
- avoid claiming pure-call, deleting-destructor, or thunk semantics without separate
  instruction or symbol evidence.

### Exceptions and unwind

For x64, parse `.pdata` runtime functions and UNWIND_INFO codes, chained records,
handlers, and language-specific data locations. A valid unwind record proves unwind
metadata, not source-level `try`/`catch` structure. Handler names from a map are
corroborating evidence only.

For x86, record a validated sorted SafeSEH table when present. Report MSVC FuncInfo
records as structurally plausible candidates until handler-specific maps and states are
independently validated. Never call a heuristic FuncInfo scan a complete EH recovery.

### TLS

Keep linked-image TLS and object-file TLS evidence separate:

- Linked image: template RVA/size/hash, index location, zero-fill, callbacks and RVAs.
- COFF objects: `.tls$*` template subsections and `.CRT$XL*` callback subsections,
  relocation targets, order keys, and hashes.

Do not claim final callback order from objects alone; linker subsection ordering and the
linked TLS directory must corroborate it.

### Static initializers

Inventory `.CRT$X*` object subsections, relocation targets, map contributions, and
lexicographic subsection order. Do not claim that every pointer is a C++ constructor or
that source initialization order is fully recovered without linked-image and runtime
evidence.

## Compiler ground-truth corpus contract

Ground-truth builds exist to measure compiler behavior, not to identify a compiler by
appearance alone.

For every build preserve:

- source hash;
- compiler executable hash and complete version text;
- architecture and language mode;
- complete argument vector without shell interpolation;
- environment inheritance policy;
- return code, diagnostics, output hash, and parsed COFF metadata.

Use the bundled corpus for arithmetic, branches, dense switches, structures, aliases,
calling conventions, globals, TLS, bitfields, floating point, loops, varargs, indirect
calls, tail calls, vectorization, unions, classes, multiple inheritance, virtual
inheritance, templates, member pointers, exceptions, and static initialization.

To compare versions, run `corpus-compare` on at least two completed corpus reports.
Identical object bytes are strong code-generation evidence for that case and flag set,
but do not prove compiler identity. Different bytes do not imply different behavior.
Historical proprietary toolchains must remain user-owned and hash-registered.

## Symbolic memory and alias contract

A symbolic result is valid only for the explicit model. Record:

- architecture, code hashes, instruction and path limits;
- symbolic input registers and stack words;
- every symbolic memory region, size, alignment, and initial policy;
- region-base alias slots and stride;
- `equal`, `distinct`, `disjoint`, or `may_alias` relationships;
- selected memory and register observations;
- deterministic external-call summaries;
- final, active, dead-ended, errored, and truncated path counts.

`may_alias` means the solver may choose either aliasing or separation. `distinct` only
constrains base addresses; use `disjoint` when non-overlap is required. A result with
truncation cannot be promoted as a completed bounded equivalence result. A counterexample
is valid only if its assignments satisfy the recorded model and can be replayed where
possible.

## Target-specific whole-image matching contract

Whole-image comparison requires a profile tied to the exact reference SHA-256. The
profile records architecture, image base, entry point, alignments, section order,
section layout, and each normalization range.

Classifications mean:

- `byte_identical`: every file byte matches.
- `profile_normalized_match`: every byte matches after only the explicitly recorded
  normalization and optional base-relocation rebasing.
- `different`: at least one byte remains different.

Never normalize a timestamp, checksum, certificate directory, debug record, padding,
or other range merely to improve the score. Every ignored range needs a reason. A
whole-image byte match does not recover comments, names, macros, build scripts, or
other erased source information.

## Authorized test-bundle contract

The preferred artifact for sandbox regression testing is a ZIP with a root
`x86decomp-test-bundle.json` manifest. The bundle must assert ownership or analysis
authorization and list every file with a role and SHA-256 when possible.

### PDB evidence procedure

Use `x86decomp pdb-inspect <pdb> --pe <image>` before trusting PDB-derived identity.
Require both GUID and age to match the PE RSDS record. Treat DBI module names, object
paths, source mappings, and section contributions as build evidence only for that exact
identity. The built-in parser does not fully decode CodeView type or symbol records; do
not describe its TPI/IPI header counts as recovered source types or its module inventory
as a complete symbol import. Preserve the PDB hash and the identity report.

Allowed roles include primary/reference/candidate PE images, PDB, linker map, COFF
objects, static libraries, source, compiler profile, image profile, and documentation.

The static bundle runner must:

- reject absolute paths, `..`, backslashes, drive-qualified paths, duplicate members,
  symlinks, oversized members, excessive expansion, and hash mismatches;
- never execute a bundled EXE, DLL, object, library, source file, or script;
- run bounded PE, metadata, COFF, COMDAT, map, layout, and image comparisons;
- report per-artifact parser failures without turning them into successful evidence;
- state that parser success is neither a malware-safety result nor semantic proof.

## Regression and release contract

Before modifying a release:

1. Run the complete previous test suite and record the baseline.
2. Preserve every existing CLI command and accepted schema field unless a documented
   migration and compatibility adapter are included.
3. Add tests for every fixed bug and new contract.
4. Run all tests, contract validation, Java syntax parsing, package build, clean-wheel
   installation, source-manifest verification, and extracted-archive verification.
5. Record unavailable external integrations separately from executed tests.
6. Never convert an unavailable tool into a passing fake test.

## Definition of done

A task is done only when:

- the requested measurable property has been checked;
- all commands and artifacts are preserved;
- relevant integrity checks pass;
- no unsupported fact is promoted;
- contradictions are stated;
- project memory is updated for durable changes;
- tests pass for modified toolkit code;
- documentation and schemas match behavior;
- unsupported follow-on work is clearly separated from implemented capability.

## Command reference

### Initialize, inspect, and audit

```bash
x86decomp inspect-pe program.exe
x86decomp init program.exe projects/program
x86decomp verify-project projects/program
x86decomp memory-verify projects/program
```

### Export and import Ghidra artifacts

```bash
x86decomp ghidra-export program.exe projects/program/analysis/ghidra program \
  projects/program/analysis/exports --scripts-dir ghidra_scripts --overwrite
x86decomp artifact-import projects/program \
  projects/program/analysis/exports/functions/pe-rva_00012340
```

### Function modes

```bash
x86decomp workflow-init projects/program pe-rva:00012340 \
  --mode matching --mode functional
x86decomp workflow-update projects/program pe-rva:00012340 \
  --matching-status compiles --report-kind compiler --report-path reports/compile.json
x86decomp workflow-show projects/program pe-rva:00012340
```

### COFF, COMDAT, maps, and layout

```bash
x86decomp coff-inspect candidate.obj
x86decomp coff-comdat-resolve build/*.obj --report reports/comdat.json
x86decomp map-inspect target.map
x86decomp layout-reconstruct target.exe target.map build/*.obj \
  --report reports/layout.json
x86decomp diff-function target.exe 0x12340 0x90 candidate.obj _Function \
  --report reports/function-diff.json
```

### Compiler corpus

```bash
x86decomp corpus-create-manifest . corpus/generated/clang-matrix.json
x86decomp corpus-build corpus/generated/clang-matrix.json corpus/output \
  --report corpus/output/corpus.json
x86decomp corpus-verify corpus/output/corpus.json
x86decomp corpus-compare corpus/msvc6.json corpus/msvc7.json corpus/clang.json \
  --report reports/compiler-comparison.json
```

### Metadata

```bash
x86decomp metadata-scan target.exe --object build/a.obj --object build/b.obj \
  --map target.map --report reports/msvc-metadata.json
```

### Concrete and symbolic functional validation

```bash
x86decomp dynamic-validate target.bin candidate.bin harness.json \
  --report reports/dynamic.json
x86decomp symbolic-validate target.bin candidate.bin --architecture x86 \
  --input-register ecx --report reports/symbolic.json
x86decomp symbolic-memory-validate target.bin candidate.bin alias-harness.json \
  --report reports/symbolic-memory.json
x86decomp integration-run scenarios.json --allow-host-execution \
  --report reports/integration.json
```

### Target-specific image matching

```bash
x86decomp image-profile original.exe profiles/original.json
x86decomp image-match original.exe rebuilt.exe --profile profiles/original.json \
  --report reports/image-match.json
x86decomp relink relink.json --report reports/relink.json
```

### Static authorized upload bundle

```bash
x86decomp test-bundle-inspect authorized-target.zip \
  --report reports/test-bundle.json
```

### Evidence and memory

```bash
x86decomp evidence-add projects/program --kind compiler_report \
  --source local-build --locator reports/compile.json \
  --assertion "candidate compiled with the recorded profile" \
  --independent-group compiler-run --file reports/compile.json
x86decomp memory-add projects/program --actor analyst --category function \
  --summary "pe-rva:00012340 matching candidate compiled" \
  --details-json '{"report":"reports/compile.json"}'
```

## Final safety reminder

This skill improves rigor and reproducibility. It does not make decompilation fully
automatic, guarantee factual correctness, or eliminate the need for expert review.
Whenever the tool cannot measure a property, label it unknown and design the next
experiment instead of filling the gap with a plausible story.
